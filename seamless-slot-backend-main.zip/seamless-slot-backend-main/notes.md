# Following Things to Be Considered While deployment

## Front end env variables to take care of

- change the backend api url
- change the oauth url for backend also 
- also change the application id for square according to the square client

```.dotenv
VITE_APP_ENV=dev
VITE_BASE_URL_BACKEND=http://localhost:3000
VITE_APP_SQUARE_ACCESS_TOKEN_PROD='sq0idp-cPA3SI-5e6KT-FLBXcSlDg'
VITE_AUTH_URL="http://localhost:3000/square-oauth/login/sandbox"
```

# Creating domains using lets encrypt

### Install Plugin

```txt
sudo apt update
sudo apt install certbot python3-certbot-dns-route53
```

### Create Certs using plugin

```txt
sudo certbot certonly \
  --dns-route53 \
  --dns-route53-propagation-seconds 30 \
  -d "*.staging.seamlessslot.co.uk" \
  -d "staging.seamlessslot.co.uk"

```

### Show Certs

```txt
sudo certbot certificates
```

### Delete Certs

```txt
sudo certbot delete --cert-name staging.seamlessslot.co.uk-0001

```


