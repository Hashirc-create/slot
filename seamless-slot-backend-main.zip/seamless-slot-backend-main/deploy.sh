#!/bin/bash

set -e

#echo 'Entering into super user mode'
##sudo su
#
## echo "Changing to seamless-slot-backend directory..."
##cd apps/seamless-slot-backend || { echo "Directory not found"; exit 1; }

echo "Checking out the latest code..."
git checkout .

echo "Pulling the latest changes from Git..."
git pull

echo "Installing npm dependencies..."
pnpm install

echo "Running Prisma migrations..."
pnpm run db:deploy

echo "Generating Prisma Client"
pnpm run db:generate

echo "Building the project..."
pnpm run build

echo "Restarting the application with PM2..."
pm2 restart ss

echo "Deployment completed successfully."
