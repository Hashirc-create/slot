import { BookingPolicy } from '../entities/BookingPolicy';
import { BaseRepository } from './base.repo';

export interface BookingPolicyRepository extends BaseRepository<BookingPolicy> {
  findByLocation(locationId: number): Promise<BookingPolicy | null>;
  defaultCreate(entity: BookingPolicy): Promise<string | null>;
}

export const IBookingPolicyRepository = Symbol('BookingPolicyRepository');
