import {} from '../entities';
import { BaseRepository } from './base.repo';
import { WorkingDayHistory } from '../entities';

export interface WorkingDayHistoryRepo
  extends BaseRepository<WorkingDayHistory> {
  findAllByLocation({
    locationId,
  }: {
    locationId: number;
  }): Promise<WorkingDayHistory[]>;
}

export const IWorkingDayHistoryRepo = Symbol('WorkingDayHistoryRepo');
