import { BaseRepository } from './base.repo';
import { GoogleTagManager } from '../entities';

export interface GoogleTagManagerRepo extends BaseRepository<GoogleTagManager> {
  findByLocation(
    locationId: number,
  ): Promise<Readonly<GoogleTagManager> | null>;

  isGoogleTagManagerConnected(locationId: number): Promise<boolean>;
}

export const IGoogleTagManagerRepo = Symbol('GoogleTagManagerRepo');
