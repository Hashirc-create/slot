import { WorkingDay } from '../entities';
import {} from '../entities';
import { BaseRepository } from './base.repo';

export interface WorkingDayRepository extends BaseRepository<WorkingDay> {
  findAllByLocation(locationId: number): Promise<WorkingDay[] | null>;

  findAllByLocationIncludeBreaks(locationId: number): Promise<WorkingDay[]>;

  findByLocationAndDay(
    locationId: number,
    day: string,
  ): Promise<WorkingDay | null>;

  defaultCreate(
    locationId: number,
    createdBy: number,
    defaultWorkingDays: {
      day: string;
      from: string;
      to: string;
      isClosed: boolean;
    }[],
  ): Promise<string>;
}

export const IWorkingDayRepository = Symbol('WorkingDayRepository');
