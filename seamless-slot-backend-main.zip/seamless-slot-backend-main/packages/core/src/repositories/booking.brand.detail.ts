import { BookingBrandDetail } from '../entities/BookingBrandDetail';
import { BaseRepository } from './base.repo';

export interface BookingBrandDetailRepository
  extends BaseRepository<BookingBrandDetail> {
  findByLocation(locationId: number): Promise<BookingBrandDetail | null>;
  defaultCreate(entity: BookingBrandDetail): Promise<string | null>;
}

export const IBookingBrandDetailRepository = Symbol(
  'BookingBrandDetailRepository',
);
