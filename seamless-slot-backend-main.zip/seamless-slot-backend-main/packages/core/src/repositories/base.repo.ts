import { Appointment } from '../entities';

export interface BaseRepository<T> {
  save(entity: T): Promise<T>;

  findById(id: number): Promise<T | null>;

  findByIds(ids: number[]): Promise<T[]>;

  findAll(): Promise<T[]>;

  findAllWithPagination(
    page: number,
    limit: number,
  ): Promise<{ data: T[]; total: number }>;

  update(id: number, entity: T): Promise<T>;

  delete(id: number, deletedBy: number): Promise<T>;

  deleteMany(id: number[], deletedBy: number): Promise<number>;

  search(
    query: string,
    columns: string[],
    page: number,
    limit: number,
  ): Promise<{ total: number; data: T[] }>;
}
