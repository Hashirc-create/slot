import { Service } from '../entities/Service';
import { BaseRepository } from './base.repo';

export interface ServiceRepository extends BaseRepository<Service> {
  findAllLiveServicesByLocation(
    locationId: number,
  ): Promise<Readonly<Service[]>>;
  findAllServicesByLocation(locationId: number): Promise<Readonly<Service[]>>;
}

export const IServiceRepository = Symbol('ServiceRepository');
