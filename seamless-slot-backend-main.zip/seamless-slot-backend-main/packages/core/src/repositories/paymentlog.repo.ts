import { BaseRepository } from './base.repo';
import { PaymentLog } from '../entities';

export interface PaymentLogRepository extends BaseRepository<PaymentLog> {
  findAllByAppointmentId(appointmentId: number): Promise<PaymentLog[]>;

  findAllByLocationIdWithPagination(
    locationId: number,
    page: number,
    perPage: number,
  ): Promise<
    Readonly<{
      prev: number;
      next: number;
      last: number;
      pages: number;
      total: number;
      data: PaymentLog[];
    }>
  >;

  findAllByLocationIdByDateRangeWithPagination(
    locationId: number,
    page: number,
    perPage: number,
    startDate: string,
    endDate: string,
  ): Promise<
    Readonly<{
      prev: number;
      next: number;
      last: number;
      pages: number;
      total: number;
      data: PaymentLog[];
    }>
  >;

  searchPaymentLogWithPagination(
    locationId: number,
    query: string,
    paymentLogColumns: unknown[],
    page: number,
    limit: number,
  ): Promise<
    Readonly<{
      prev: number;
      next: number;
      last: number;
      pages: number;
      total: number;
      data: PaymentLog[];
    }>
  >;
}

export const IPaymentLogRepository = Symbol('PaymentLogRepository');
