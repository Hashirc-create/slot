import { User } from '../entities/User';
import { BaseRepository } from './base.repo';

export interface UserRepository extends BaseRepository<User> {
  findByEmail(email: string): Promise<User | null>;

  block(id: number, blockedBy: number): Promise<User | null>;

  findAllAdminsByLocation(locationId: number): Promise<User[]>;

  hardDeleteUserById(id: number): Promise<User>;

  updateUserProfile(
    id: number,
    valuesToUpdate: {
      firstName: string;
      lastName: string;
      email: string;
      password?: string;
      phoneNo: string;
    },
  ): Promise<User>;
}

export const IUserRepository = Symbol('UserRepository');
