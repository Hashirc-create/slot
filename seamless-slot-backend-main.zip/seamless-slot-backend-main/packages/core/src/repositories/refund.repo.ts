import { SquareRefund } from '../entities/SquareRefunds';
import { BaseRepository } from './base.repo';

export interface RefundRepository extends BaseRepository<SquareRefund> {
  findBySquareRefundId(squareRefundId: string): Promise<SquareRefund | null>;

  findLastRefundAgainstPaymentTransaction(
    paymentTransactionId: number,
  ): Promise<SquareRefund | null>;

  findAllRefundsAgainstPaymentTransactionId(
    paymentTransactionId: number,
  ): Promise<readonly SquareRefund[]>;

  updateRefundStatus(id: number, status: string): Promise<SquareRefund>;

  findAllByLocationIdWithPagination(
    locationId: number,
    page: number,
    perPage: number,
  ): Promise<
    Readonly<{
      prev: number;
      next: number;
      last: number;
      pages: number;
      total: number;
      data: SquareRefund[];
    }>
  >;

  findAllByLocationIdWithPaginationAndDateRange(
    locationId: number,
    page: number,
    perPage: number,
    startDate: string,
    endDate: string,
  ): Promise<
    Readonly<{
      prev: number;
      next: number;
      last: number;
      pages: number;
      total: number;
      data: SquareRefund[];
    }>
  >;

  searchRefundsWithPagination(
    locationId: number,
    query: string,
    refundColumns: unknown[],
    page: number,
    limit: number,
  ): Promise<
    Readonly<{
      prev: number;
      next: number;
      last: number;
      pages: number;
      total: number;
      data: SquareRefund[];
    }>
  >;
}

export const IRefundRepository = Symbol('RefundRepository');
