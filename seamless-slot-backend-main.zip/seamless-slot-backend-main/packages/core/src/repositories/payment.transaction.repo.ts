import { BaseRepository } from './base.repo';
import { SquarePaymentTransaction } from '../entities';

export interface PaymentTransactionRepository
  extends BaseRepository<SquarePaymentTransaction> {
  getAllPaymentTranscationsByLocation(
    locationId: number,
  ): Promise<Readonly<SquarePaymentTransaction[]>>;

  findAllPaymentTransactionsByLocationWithPagination(
    locationId: number,
    page: number,
    perPage: number,
  ): Promise<
    Readonly<{
      prev: number;
      next: number;
      last: number;
      pages: number;
      total: number;
      data: SquarePaymentTransaction[];
    }>
  >;

  findAllPaymentTransactionsByLocationWithPaginationAndDateRange(
    locationId: number,
    page: number,
    perPage: number,
    startDate: string,
    endDate: string,
  ): Promise<
    Readonly<{
      prev: number;
      next: number;
      last: number;
      pages: number;
      total: number;
      data: SquarePaymentTransaction[];
    }>
  >;

  findPaymentTransactionWithAppointmentLocaitonAndService(
    id: number,
  ): Promise<SquarePaymentTransaction>;

  updateCompanyBalance(
    paymentTransactionId: number,
    newBalance: number,
  ): Promise<SquarePaymentTransaction>;

  searchPaymentTransactionWithPagination(
    locationId: number,
    query: string,
    SquarePaymentTransactionColumns: unknown[],
    page: number,
    limit: number,
  ): Promise<
    Readonly<{
      prev: number;
      next: number;
      last: number;
      pages: number;
      total: number;
      data: SquarePaymentTransaction[];
    }>
  >;
}

export const IPaymentTransactionRepository = Symbol(
  'PaymentTransactionRepository',
);
