export interface DashboardRepository {
  getCurrentMonthRevenueForLocation(locationId: number): Promise<number>;

  getLastSixMonthsRevenueForLocation(
    locationId: number,
  ): Promise<{ month: string; revenue: number }[]>;

  getAllTimeTotalAppointmentsForLocation(locationId: number): Promise<number>;

  getAllTimeTotalRefundsForLocation(locationId: number): Promise<number>;

  getAllTimeTotalCustomersForLocation(locationId: number): Promise<number>;

  getConversionRateForLocationCurrentMonth(locationId: number): Promise<number>;

  getCancellationRateForLocationCurrentMonth(
    locationId: number,
  ): Promise<number>;

  getNoShowRateForLocationCurrentMonth(locationId: number): Promise<number>;

  getAllTimeAppointmentsAgainstStatus(
    locationId: number,
  ): Promise<{ month: string; status: string; count: number }[]>;

  getAllTimeAppointmentsRevenueAgainstService(
    locationId: number,
  ): Promise<{ month: string; service: string; revenue: number }[]>;

  getCurrentMonthAppointmentsByWeek(
    locationId: number,
  ): Promise<{ day: string; count: number }[]>;

  getAllTimeRevenueForLocation(locationId: number): Promise<number>;
}

export const IDashboardRepository = Symbol('DashboardRepository');
