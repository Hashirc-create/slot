import { PaymentAccount } from '../entities/PaymentAccount';
import { PaymentAccountType } from '../entities/types';
import { BaseRepository } from './base.repo';

export interface PaymentAccountRepository
  extends BaseRepository<PaymentAccount> {
  findAllPaymentAccountsByType(
    type: PaymentAccountType,
  ): Promise<PaymentAccount[]>;
  findPaymentAccountByLocationAndType(
    type: PaymentAccountType,
    locationId: number,
  ): Promise<PaymentAccount | null>;
  checkPaymentAccountExist(
    type: PaymentAccountType,
    locationId: number,
  ): Promise<PaymentAccount | null>;
  deleteSquarePaymentAccount(locationId: number): Promise<PaymentAccount>;
}

export const IPaymentAccountRepository = Symbol('PaymentAccountRepository');
