import { Customer } from '../entities/Customer';
import { BaseRepository } from './base.repo';

export interface CustomerRepository extends BaseRepository<Customer> {
  findAllCustomersByLocation(locationId: number): Promise<Readonly<Customer[]>>;

  findCustomerByEmail(email: string): Promise<Readonly<Customer>>;

  findAllCustomerByIdWithAppointments(id: number): Promise<Readonly<Customer>>;

  findAllCustomersByLocationWithPagination(
    locationId: number,
    page: number,
    perPage: number,
  ): Promise<
    Readonly<{
      prev: number;
      next: number;
      last: number;
      pages: number;
      total: number;
      data: Customer[];
    }>
  >;

  bindNewLocationWithCustomer(
    locationId: number,
    customerId: number,
  ): Promise<Customer>;

  searchCustomerWithPagination(
    locationId: number,
    query: string,
    customerColumns: unknown[],
    page: number,
    limit: number,
  ): Promise<
    Readonly<{
      prev: number;
      next: number;
      last: number;
      pages: number;
      total: number;
      data: Customer[];
    }>
  >;
}

export const ICustomerRepository = Symbol('CustomerRepository');
