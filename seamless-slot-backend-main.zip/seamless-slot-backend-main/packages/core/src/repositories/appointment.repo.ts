import { Appointment, AppointmentStatus } from '../entities';
import { BaseRepository } from './base.repo';

export interface AppointmentRepository extends BaseRepository<Appointment> {
  cancel(id: number, cancelledBy: number): Promise<Appointment>;

  findAllByLocation(locationId: number): Promise<Appointment[]>;

  findAppointmentDetailsById(id: number): Promise<Appointment | null>;

  findByStartTimeAndEndTime(
    startTime: Date,
    endTime: Date,
  ): Promise<Appointment | null>;

  findAllWithDateRangeByLocationWithPagination(
    locationId: number,
    page: number,
    perPage: number,
    startDate: string,
    endDate: string,
  ): Promise<
    Readonly<{
      prev: number;
      next: number;
      last: number;
      pages: number;
      total: number;
      data: Appointment[];
    }>
  >;

  findAllByLocationWithPagination(
    locationId: number,
    page: number,
    perPage: number,
  ): Promise<
    Readonly<{
      prev: number;
      next: number;
      last: number;
      pages: number;
      total: number;
      data: Appointment[];
    }>
  >;

  findConfirmedAndFollowUpAppointmentsByLocationServiceAndDate(
    locationId: number,
    serviceId: number,
    date: string,
  ): Promise<Appointment[]>;

  findAppointmentByIdWithServiceLocationPayment(
    id: number,
  ): Promise<Appointment | null>;

  updateAppointmentStatus(
    id: number,
    updatedBy: number,
    status: AppointmentStatus,
  ): Promise<Appointment>;

  hardDelete(id: number): Promise<Appointment>;

  findAppointmetBySquareOrderIdNotConfirmed(
    squareOrderId: string,
  ): Promise<Appointment | null>;

  changeAppointmentDateTime(
    id: number,
    startTime: string,
    endTime: string,
    date: string,
  ): Promise<Appointment>;

  findAppointmentsByMonth(
    year: number,
    month: number,
    locationId: number,
  ): Promise<Readonly<Appointment[]>>;

  findByIdIncludingLocationServiceCustomerAndTransaction(
    id: number,
  ): Promise<Appointment | null>;

  searchAppointmentWithPagination(
    locationId: number,
    query: string,
    appointmentColumns: unknown[],
    customerColumns: unknown[],
    page: number,
    limit: number,
  ): Promise<
    Readonly<{
      prev: number;
      next: number;
      last: number;
      pages: number;
      total: number;
      data: Appointment[];
    }>
  >;
}

export const IAppointmentRepository = Symbol('AppointmentRepository');
