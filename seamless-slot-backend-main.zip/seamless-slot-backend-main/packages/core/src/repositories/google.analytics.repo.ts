import { BaseRepository } from './base.repo';
import { GoogleAnalytics } from '../entities/GoogleAnalytics';

export interface GoogleAnalyticsRepo extends BaseRepository<GoogleAnalytics> {
  findByLocation(locationId: number): Promise<Readonly<GoogleAnalytics> | null>;
}

export const IGoogleAnalyticsRepo = Symbol('GoogleAnalyticsRepo');
