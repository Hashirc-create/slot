import { TimeOff } from '../entities/TimeOffs';
import { BaseRepository } from './base.repo';

export interface TimeOffRepository extends BaseRepository<TimeOff> {
  findAllByLocationWithPagination(
    page: number,
    limit: number,
    locationId: number,
  ): Promise<Readonly<{ data: TimeOff[]; total: number }>>;
  findAllByLocation(locationId: number): Promise<Readonly<TimeOff[]>>;
  findAllByLocationAndDate(
    locationId: number,
    date: string,
  ): Promise<Readonly<TimeOff[]>>;
}

export const ITimeOffRepository = Symbol('TimeOffRepository');
