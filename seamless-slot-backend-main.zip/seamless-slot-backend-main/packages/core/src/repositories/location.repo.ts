import { CustomerReminderTimeUnit, Location } from '../entities';
import { CancellationTimeUnits, ScheduleSizeUnits } from '../entities';
import { BaseRepository } from './base.repo';

export interface LocationRepository extends BaseRepository<Location> {
  findByEmail(email: string): Promise<Location | null>;

  updateScheduleWindow(
    locationId: number,
    scheduleSize: number,
    scheduleSizeUnit: ScheduleSizeUnits,
  ): Promise<Location>;

  updateCancellationPolicy(
    locationId: number,
    cancellationTime: number,
    cancellationTimeUnits: CancellationTimeUnits,
    isCancellationPolicyEnabled: boolean,
  ): Promise<Location>;

  updateCustomerReminderTime(
    locationId: number,
    customerReminderTime: number,
    customerReminderTimeUnit: CustomerReminderTimeUnit,
  ): Promise<Location>;
}

export const ILocationRepository = Symbol('LocationRepository');
