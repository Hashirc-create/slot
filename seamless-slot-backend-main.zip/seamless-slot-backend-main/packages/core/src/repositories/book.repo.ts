import { Book } from '../entities/Book';
import { BaseRepository } from './base.repo';

export interface BookRepository extends BaseRepository<Book> {}

export const IBookRepository = Symbol('BookRepository');
