import { BaseRepository } from './base.repo';
import { Business } from '../entities';

export interface BusinessRepo extends BaseRepository<Business> {
  findAllIncludingLocations(): Promise<Readonly<Business[]>>;

  findBySubdomain(subdomain: string): Promise<Readonly<Business | null>>;

  findByEmail(email: string): Promise<Readonly<Business | null>>;
}

export const IBusinessRepository = Symbol('BusinessRepo');
