import { Notifications } from '../entities/Notifications';
import { BaseRepository } from './base.repo';

export interface NotificationsRepository extends BaseRepository<Notifications> {
  findAllNotificationsByLocation(
    locationId: number,
  ): Promise<readonly Notifications[]>;

  markNotificationsRead(ids: number[]): Promise<number>;
}

export const INotificationsRepository = Symbol('NotificationsRepository');
