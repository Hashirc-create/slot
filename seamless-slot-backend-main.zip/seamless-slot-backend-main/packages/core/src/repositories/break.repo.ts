import { Break } from '../entities/Break';
import { BaseRepository } from './base.repo';
import { WeekDays } from '../entities';

export interface BreakRepository extends BaseRepository<Break> {
  findAllByLocationAndDay(
    locationId: number,
    day: WeekDays,
  ): Promise<Readonly<Break[]>>;

  findAllByLocation(locationId: number): Promise<Readonly<Break[]>>;
  findAllByLocationIncludingNonActive(
    locationId: number,
  ): Promise<Readonly<Break[]>>;
}

export const IBreakRepository = Symbol('BreakRepository');
