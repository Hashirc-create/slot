export type SaleForceObject = 'Account';
export type SaleForceValidValues =
  | string
  | number
  | boolean
  | { [key: string]: SaleForceValidValues };
