import { Appointment } from './Appointment';
import { BaseEntity } from './BaseEntity';
import {
  Currency,
  PaymentMethod,
  PaymentStatus,
  SupportedPaymentMethods,
} from './types';
import { SquareRefund } from './SquareRefunds';

export interface SquarePaymentTransaction extends BaseEntity {
  date: string | Date;
  status: PaymentStatus;
  amount: string;
  currency: Currency;
  cardDetails: string;
  note: string;
  type: PaymentMethod;
  companyBalance: string;
  squareTransactionId: string;
  method: SupportedPaymentMethods;
  merchantId: string;
  squareCreatedAt: string;
  squareType: string;
  squareProduct: string;
  squareAddressLine1: string;
  squareAddressLine2: string;
  squareCountry: string;
  squareCustomerFirstName: string;
  squareCustomerLastNameName: string;
  squarePostalCode: string;
  squareLocality: string;
  squareBuyerEmailAddress: string;
  squareAuthResultCode: string;
  squareAvsStatus: string;
  squareBin: string;
  squareCardBrand: string;
  squareCardType: string;
  squareCardMonthExpiry: number;
  squareCardYearExpiry: number;
  squareFingerPrint: string;
  squareCardLast4: number;
  squarePaymentAccountReference: string;
  squarePerpaidType: string;
  squareReceiptURL: string;
  squareSourceType: string;
  squareStatus: string;
  squareUpdatedAt: string;

  refunds?: SquareRefund[];

  appointment: number | Appointment;
}
