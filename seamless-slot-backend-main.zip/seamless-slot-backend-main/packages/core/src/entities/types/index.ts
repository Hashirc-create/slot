export type Status = 'Active' | 'Inactive' | 'Freeze';
export type Role = 'Super Admin' | 'Admin' | 'Customer';
export type WeekDays =
  | 'Monday'
  | 'Tuesday'
  | 'Wednesday'
  | 'Thursday'
  | 'Friday'
  | 'Saturday'
  | 'Sunday';

export type DefaultWorkingDay = {
  day: WeekDays;
  from: Date;
  to: Date;
  isClosed: boolean;
};

export type WeeklyDefaultWorkingDays = [
  DefaultWorkingDay,
  DefaultWorkingDay,
  DefaultWorkingDay,
  DefaultWorkingDay,
  DefaultWorkingDay,
  DefaultWorkingDay,
  DefaultWorkingDay,
];

export type PaymentAccountType = 'Square-Pay' | 'Dojo';
export type SupportedPaymentMethods = 'Card' | 'Google Pay' | 'Apple Pay';

export type SupportedTimeZones = 'Europe/London' | 'Asia/Karachi';

export type AppointmentStatus =
  | 'Pending'
  | 'Paid'
  | 'No Show'
  | 'Confirmed'
  | 'Complete'
  | 'Cancelled'
  | 'Follow Up';

export type TwilioBoughtNumbers = '+447462428776';

export type TimeSlot = {
  start: string;
  end: string;
};

export type TimeParts = {
  hours: number;
  minutes: number;
  seconds: number;
};

export type PaymentStatus =
  | 'Paid'
  | 'Failed'
  | 'Rejected'
  | 'Cancelled'
  | 'Refunded'
  | 'Un Paid';

export type SlotPaymentStatus = 'Paid' | 'Unpaid' | 'Refunded';

export type Currency = 'GBP'; // iso-4217
export type PaymentMethod = 'Google Pay' | 'Apple Pay' | 'Credit Card' | 'Card';

//eslint-disable-next-line
export type EmailWithoutDomain<T extends string> =
  T extends `${infer LocalPart}@${string}` ? LocalPart : never;

export type CancellationTimeInHours =
  | 'any time'
  | '1 hours'
  | '2 hours'
  | '3 hours'
  | '4 hours'
  | '5 hours'
  | '6 hours';

export type CancellationTimeUnits = 'hours' | 'days' | 'months';
export type CustomerReminderTimeUnit = 'minutes' | 'hours';

export type ScheduleSizeUnits = 'days' | 'months';

export type CancellationTime<T extends CancellationTimeInHours> =
  T extends `${infer Duration} ${string}` ? Duration : never;

export type GeneratePaymentLinkPayload = {
  date: string;
  time: string;
  appointmentType: number;
  fullName: string;
  email: string;
  phoneNumber: string;
  address: string;
  comments: string;
  cancellationPolicy: boolean;
  bookingId: number;
  customerId: number;
  locationId: number;
};

export type BreakEvent = {
  id: string; // Unique identifier for the break
  title: string; // Title of the event
  start: string; // Start time in ISO 8601 format
  end: string; // End time in ISO 8601 format
  display: 'foreground' | 'background'; // Display style: 'foreground' or 'background'
  classNames?: string[]; // Optional array of custom class names
  editable: boolean; // Whether the event is editable
  interactive: boolean; // Whether the event is interactive (clickable, draggable, etc.)
  extendedProps?: {
    // Additional custom properties
    customerName: string;
    startTime: string;
    endTime: string;
  };
};

export type TimeOffEvent = {
  id: string; // Unique identifier for the break
  title: string; // Title of the event
  allDay: boolean;
  start: string; // Start time in ISO 8601 format
  end: string; // End time in ISO 8601 format
  display: 'foreground' | 'background'; // Display style: 'foreground' or 'background'
  classNames?: string[]; // Optional array of custom class names
  editable: boolean; // Whether the event is editable
  interactive: boolean; // Whether the event is interactive (clickable, draggable, etc.)
  extendedProps?: {
    // Additional custom properties
    customerName: string;
    startTime: string;
    endTime: string;
  };
};
