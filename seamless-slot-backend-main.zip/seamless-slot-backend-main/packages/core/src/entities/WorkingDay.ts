import { BaseEntity } from './BaseEntity';
import { Break } from './Break';
import { Location } from './Location';

export interface WorkingDay extends BaseEntity {
  day: string;
  from?: Date | string;
  to?: Date | string;
  isClosed: boolean;
  location: number | Location;
  breaks?: Break[];
}
