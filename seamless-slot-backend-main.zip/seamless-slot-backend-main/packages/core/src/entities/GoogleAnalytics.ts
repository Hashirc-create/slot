import { BaseEntity } from './BaseEntity';
import { Location } from './Location';

export interface GoogleAnalytics extends BaseEntity {
  measurementId: string;
  location: number | Location;
}
