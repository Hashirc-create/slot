import { BaseEntity } from './BaseEntity';
import { Status } from './types';
import { Location } from './Location';

export interface Business extends BaseEntity {
  name: string;
  contact: string;
  address: string;
  phoneNo: string;
  email: string;
  subdomain: string;
  status?: Status;
  locations?: number[] | Location[];
}
