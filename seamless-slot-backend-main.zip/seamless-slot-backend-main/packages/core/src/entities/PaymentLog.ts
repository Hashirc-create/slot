import { BaseEntity } from './BaseEntity';
import { PaymentMethod, PaymentStatus } from './types';
import { Appointment } from './Appointment';

export interface PaymentLog extends Omit<BaseEntity, 'business'> {
  orderId: string;
  transactionId: string;
  status: PaymentStatus;
  paymentMethod: PaymentMethod;
  failedReason: string;
  errorCode: string;
  errorDetail: string;
  errorCategory: string;
  amount: number;
  currency: string;
  cardBrand: string;
  last4Digits: string;
  cardExpMonth: string;
  cardExpYear: string;
  cardType: string;
  entryMethod: string;
  cvvStatus: string;
  avsStatus: string;
  fullPayload: unknown;
  appointment: Appointment | number;
}
