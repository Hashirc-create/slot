import { BaseEntity } from './BaseEntity';
import { Location } from './Location';

export interface GoogleTagManager extends BaseEntity {
  containerId: string;
  location: Location | number;
}
