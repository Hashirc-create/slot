import { BaseEntity } from './BaseEntity';
import { Location } from './Location';

export interface BookingBrandDetail extends BaseEntity {
  brand?: string;
  telephone: string;
  email: string;
  industry?: string;
  currency?: string;
  country: string;
  address: string;
  town: string;
  about: string;
  location: Location | number;
}
