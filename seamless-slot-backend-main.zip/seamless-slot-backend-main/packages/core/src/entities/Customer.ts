import { Appointment } from './Appointment';
import { BaseEntity } from './BaseEntity';
import { Location } from './Location';
import { Role } from './types';

export interface Customer extends BaseEntity {
  firstName: string;
  lastName: string;
  email: string;
  password: string;
  phoneNo?: string;
  companyName?: string;
  address?: string;
  notes?: string;
  tokenVersion: number;
  role: Role;
  location: number | Location | number[] | Location[];
  appointments: number | Appointment[] | Appointment;
}
