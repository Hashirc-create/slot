// eslint-disable-next-line @typescript-eslint/no-namespace
export namespace DentallyRequest {
  export interface AccessTokenPayload {
    client_id: string;
    redirect_uri: string;
    code: string;
    grant_type: string;
    client_secret: string;
  }

  export interface CreatePaymentPayload {
    account_id: string; // Required: The ID of the account to credit the payment to
    amount: string; // Required: The total value of the payment
    dated_on: Date; // Required: The date the payment was made
    method:
      | 'Credit Card'
      | 'Debit Card'
      | 'American Express'
      | 'Cash'
      | 'Cheque'
      | 'BACS'
      | 'Finance'
      | 'Other'; // Required: The method of the payment
    patient_id: number; // Required: The ID of the patient the payment is associated with
    payment_plan_id: number; // Required: The ID of the payment plan associated with the payment
    practitioner_id?: number; // Optional: The ID of the practitioner the payment is associated with
    site_id?: string; // Optional: The ID of the site the payment belongs to
    transaction_number?: string; // Optional: A transaction number for third-party identification
  }

  export interface CreateAppointmentPayload {
    start_time: Date; // Required: The start time of the appointment
    finish_time: Date; // Required: The finish time of the appointment
    practitioner_id: number; // Required: The ID of the practitioner
    reason:
      | 'Exam'
      | 'Scale & Polish'
      | 'Exam + Scale & Polish'
      | 'Continuing Treatment'
      | 'Emergency'
      | 'Review'
      | 'Other'; // Required: Reason for the appointment
    patient_id?: number; // Optional: The ID of the patient
    state?:
      | 'Pending'
      | 'Confirmed'
      | 'Arrived'
      | 'In surgery'
      | 'Completed'
      | 'Cancelled'
      | 'Did not attend'; // Optional: The state of the appointment, defaults to Pending
    notes?: string; // Optional: Notes specific to the appointment
    metadata?: Record<string, unknown>; // Optional: Key/value pairs for additional appointment information
    force_changes?: boolean; // Optional: Suppresses double booking errors if true
  }

  export interface CreatePatientPayload {
    title:
      | 'Mr'
      | 'Mrs'
      | 'Miss'
      | 'Ms'
      | 'Dr'
      | 'Master'
      | 'Prof'
      | 'Hon'
      | 'Rev'
      | 'Sir'
      | 'Lady'
      | 'Lord'
      | 'Earl'
      | 'Judge'
      | 'Dame';
    first_name: string;
    last_name: string;
    date_of_birth: Date;
    gender: boolean; // true for male, false for female
    ethnicity: string;
    address_line_1: string;
    postcode: string;
    payment_plan_id: number; // TODO DEFAULT PAYMENT PLAN ID CAN BE GET FROM SITES
    active?: boolean; // Default is true
    address_line_2?: string;
    county?: string;
    dentist_id?: number;
    dentist_recall_date?: Date;
    dentist_recall_interval?: number; // Must be between 0 & 24
    email_address?: string;
    home_phone?: string;
    home_phone_country?: string; // ISO country code
    hygienist_id?: number;
    hygienist_recall_date?: Date;
    hygienist_recall_interval?: number; // Must be between 0 & 24
    legacy_id?: string;
    marketing?: number; // Consent to receive marketing material
    medical_alert?: boolean; // Default is false
    medical_alert_text?: string;
    metadata?: Record<string, unknown>; // Key-value pairs for additional information
    middle_name?: string;
    mobile_phone?: string;
    mobile_phone_country?: string; // ISO country code
    nhs_number?: string;
    ni_number?: string;
    pps_number?: string;
    preferred_name?: string;
    preferred_phone_number?: 1 | 2 | 3; // 1 for home, 2 for work, 3 for mobile
    recall_method?: 'Letter' | 'SMS' | 'Email' | 'Phone'; // Default is Letter
    site_id?: string;
    town?: string;
    use_email?: boolean; // Default is true
    use_sms?: boolean; // Default is true
    work_phone?: string;
    work_phone_country?: string; // ISO country code
    emergency_contact_name?: string;
    emergency_contact_relationship?: string;
    emergency_contact_phone?: string;
    emergency_contact_phone_country?: string; // ISO country code
  }
}
