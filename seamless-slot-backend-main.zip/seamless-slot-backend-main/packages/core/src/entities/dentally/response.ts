// eslint-disable-next-line @typescript-eslint/no-namespace
export namespace DentallyResponse {
  export interface AccessTokenResponse {
    access_token: string;
    token_type: string;
  }

  export interface SitesResponse {
    sites: Site[];
    meta: {
      total: number;
      page: number;
    };
  }

  export interface SiteOpeningHours {
    open: string;
    close: string;
  }

  export interface Site {
    id: string;
    active: boolean;
    address_line_1: string;
    address_line_2?: string;
    default_payment_plan_id: number;
    logo_url: string;
    name: string;
    nickname: string;
    phone_number: string;
    postcode: string;
    practice_id: string;
    town: string;
    website: string;
    opening_hours: {
      Monday: SiteOpeningHours;
      Tuesday: SiteOpeningHours;
      Wednesday: SiteOpeningHours;
      Thursday: SiteOpeningHours;
      Friday: SiteOpeningHours;
    };
  }
}
