import { BaseEntity } from './BaseEntity';
import { Location } from './Location';

export interface Service extends BaseEntity {
  title: string;
  durationInMinutes: number;
  bufferTimeInMinutes: number;
  cost: string;
  venue: string;
  order: number;
  isLive: boolean;
  location: number | Location;
}
