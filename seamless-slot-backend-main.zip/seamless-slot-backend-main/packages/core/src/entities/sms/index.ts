export interface BaseSmsPayload {
  to: string;
}

export interface PaymentLinkSmsPayload extends BaseSmsPayload {
  customerFirstName: string;
  customerLastName: string;
  businessName: string;
  locationName: string;
  locationAddress: string;
  appointmentDate: string;
  appointmentStartTime: string;
  paymentLink: string;
}

export interface AppointmentRescheduledSmsPayload extends BaseSmsPayload {
  customerFirstName: string;
  customerLastName: string;
  businessName: string;
  locationName: string;
  locationAddress: string;
  oldAppointmentDate: string;
  oldAppointmentStartTime: string;
  newAppointmentDate: string;
  newAppointmentStartTime: string;
  telephone: string;
}

export interface AppointmentStatusUpdateSmsPayload extends BaseSmsPayload {
  customerFirstName: string;
  customerLastName: string;
  businessName: string;
  locationName: string;
  locationAddress: string;
  appointmentDate: string;
  appointmentStartTime: string;
  locationTelephone: string;
}

export interface PaymentLinkSmsAdminCreatedAppointmentPayload
  extends PaymentLinkSmsPayload {}

export interface AppointmentPaymentConfirmationSmsPayload
  extends BaseSmsPayload {
  customerFirstName: string;
  customerLastName: string;
  businessName: string;
  locationName: string;
  locationAddress: string;
  appointmentDate: string;
  appointmentStartTime: string;
  telephone: string;
}
