import { BaseEntity } from './BaseEntity';
import { Location } from './Location';
import { Role, Status } from './types';

export interface User extends BaseEntity {
  firstName: string;
  lastName: string;
  email: string;
  password: string;
  phoneNo?: string;
  companyName?: string;
  address?: string;
  tokenVersion: number;
  status?: Status;
  role: Role;
  location: number | Location;
}
