export interface SquareLocation {
  id?: string;
  name?: string | null;
  timezone?: string | null;
  capabilities?: string[];
  status?: string;
  createdAt?: string;
  merchantId?: string;
  country?: string;
  languageCode?: string | null;
  currency?: string;
  phoneNumber?: string | null;
  businessName?: string | null;
  type?: string;
  websiteUrl?: string | null;
  businessEmail?: string | null;
  description?: string | null;
  twitterUsername?: string | null;
  instagramUsername?: string | null;
  facebookUrl?: string | null;
  logoUrl?: string;
  posBackgroundUrl?: string;
  mcc?: string | null;
  fullFormatLogoUrl?: string;
}

export interface SquarePaymentUpdatedWebhookResponse {
  merchant_id: string;
  type: string;
  event_id: string;
  created_at: string;
  data: {
    type: string;
    id: string;
    object: {
      payment: {
        failure_details?: {
          code: string;
          detail: string;
          reason: string;
        };
        amount_money: {
          amount: number;
          currency: string;
        };
        application_details: {
          application_id: string;
          square_product: string;
        };
        approved_money: {
          amount: number;
          currency: string;
        };
        card_details: {
          auth_result_code: string;
          avs_status: string;
          card: {
            bin: string;
            card_brand: string;
            card_type: string;
            exp_month: number;
            exp_year: number;
            fingerprint: string;
            last_4: string;
            payment_account_reference: string;
            prepaid_type: string;
          };
          card_payment_timeline: {
            authorized_at: string;
            captured_at: string;
          };
          cvv_status: string;
          entry_method: string;
          statement_description: string;
          status: string;
        };
        created_at: string;
        customer_id: string;
        delay_action: string;
        delay_duration: string;
        delayed_until: string;
        id: string;
        location_id: string;
        note: string;
        order_id: string;
        processing_fee: {
          amount_money: {
            amount: number;
            currency: string;
          };
          effective_at: string;
          type: string;
        }[];
        receipt_number: string;
        receipt_url: string;
        risk_evaluation: {
          created_at: string;
          risk_level: string;
        };
        source_type: string;
        status: string;
        total_money: {
          amount: number;
          currency: string;
        };
        updated_at: string;
        version: number;
      };
    };
  };
}

export interface SquarePaymentWithUnderScore {
  failure_details?: {
    code: string;
    detail: string;
    reason: string;
  };
  amount_money: {
    amount: number;
    currency: string;
  };
  application_details: {
    application_id: string;
    square_product: string;
  };
  approved_money: {
    amount: number;
    currency: string;
  };
  card_details: {
    auth_result_code: string;
    avs_status: string;
    card: {
      bin: string;
      card_brand: string;
      card_type: string;
      exp_month: number;
      exp_year: number;
      fingerprint: string;
      last_4: string;
      payment_account_reference: string;
      prepaid_type: string;
    };
    card_payment_timeline: {
      authorized_at: string;
      captured_at: string;
    };
    cvv_status: string;
    entry_method: string;
    statement_description: string;
    status: string;
  };
  created_at: string;
  customer_id: string;
  delay_action: string;
  delay_duration: string;
  delayed_until: string;
  id: string;
  location_id: string;
  note: string;
  order_id: string;
  processing_fee: {
    amount_money: {
      amount: number;
      currency: string;
    };
    effective_at: string;
    type: string;
  }[];
  receipt_number: string;
  receipt_url: string;
  risk_evaluation: {
    created_at: string;
    risk_level: string;
  };
  source_type: string;
  status: string;
  total_money: {
    amount: number;
    currency: string;
  };
  updated_at: string;
  version: number;
}

export interface SquareRefundUpdatedWebhookResponse {
  merchant_id: string;
  type: string;
  event_id: string;
  created_at: string;
  data: {
    type: string;
    id: string;
    object: {
      refund: {
        id: string;
        created_at: string;
        updated_at: string;
        amount_money: {
          amount: number;
          currency: string;
        };
        status: string;
        processing_fee: Array<{
          effective_at: string;
          type: string;
          amount_money: {
            amount: number;
            currency: string;
          };
        }>;
        location_id: string;
        order_id: string;
        payment_id: string;
        version: number;
      };
    };
  };
}
