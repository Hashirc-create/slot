import { BaseEntity } from './BaseEntity';
import { Location } from './Location';

export interface WorkingDayHistory extends BaseEntity {
  day: string;
  prevFrom: Date | string;
  prevTo: Date | string;
  prevIsClosed: boolean;
  newFrom: Date | string;
  newTo: Date | string;
  newIsClosed: boolean;
  location: number | Location;
}
