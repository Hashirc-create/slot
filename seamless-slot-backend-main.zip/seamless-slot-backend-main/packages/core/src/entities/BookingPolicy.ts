import { BaseEntity } from './BaseEntity';
import { Location } from './Location';

export interface BookingPolicy extends BaseEntity {
  leadTime?: number;
  leadTimeType?: string;
  slotSize?: number;
  slotSizeType?: string;
  schedulingWindow?: number;
  schedulingWindowType?: string;
  cancellationPolicy?: string;
  location: Location | number;
}
