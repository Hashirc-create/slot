import { BaseEntity } from './BaseEntity';

export interface Book extends BaseEntity {
  title: string;
  description: string;
}
