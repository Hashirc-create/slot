import { BaseEntity } from './BaseEntity';
import { Location } from './Location';
import { PaymentAccountType } from './types';

export interface PaymentAccount extends BaseEntity {
  type: PaymentAccountType;
  accessToken: string;
  refreshToken: string;
  squareDefaultLocationId: string;
  location: number | Location;
}
