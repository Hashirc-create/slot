import { BaseEntity } from './BaseEntity';
import { Customer } from './Customer';
import { Location } from './Location';
import { SquarePaymentTransaction } from './SquarePaymentTransaction';
import { Service } from './Service';
import { AppointmentStatus } from './types';
import { PaymentLog } from './PaymentLog';

export interface Appointment extends BaseEntity {
  date: string | Date;
  status: AppointmentStatus;
  startTime: string | Date;
  endTime: string | Date;
  address?: string;
  isActive: boolean;
  location: Location | number;
  customer: Customer | number;
  service: Service | number;
  squareOrderId: string;
  payments?: number | SquarePaymentTransaction | null;
  paymentLogs?: PaymentLog[];
}
