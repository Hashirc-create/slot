import { BaseEntity } from './BaseEntity';
import { SquarePaymentTransaction } from './SquarePaymentTransaction';

export interface SquareRefund extends BaseEntity {
  refundSquareId: string;
  status: string;
  amount: string;
  currency: string;
  paymentId: string;
  orderId: string;
  squareLocationId: string;
  reason: string;
  remainingBalance: string;
  paymentTransaction: number | SquarePaymentTransaction;
}
