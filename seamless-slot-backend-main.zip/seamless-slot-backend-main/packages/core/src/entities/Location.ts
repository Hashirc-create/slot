import { BaseEntity } from './BaseEntity';
import {
  CancellationTimeInHours,
  CancellationTimeUnits,
  CustomerReminderTimeUnit,
  ScheduleSizeUnits,
  Status,
} from './types';
import { GoogleAnalytics } from './GoogleAnalytics';
import { GoogleTagManager } from './GoogleTagManager';
import { PaymentAccount } from './PaymentAccount';

export interface Location extends BaseEntity {
  name: string;
  email: string;
  site: string;
  address: string;
  timeZone: string;
  latitude: number;
  longitude: number;
  telephone: string;
  country: string;
  town: string;
  status?: Status;
  conferenceCall: string;
  about: string;
  cancellationTimeInHours: CancellationTimeInHours;
  cancellationTime: number;
  cancellationTimeUnit: CancellationTimeUnits;
  isCancellationPolicyEnabled: boolean;
  scheduleSize: number;
  googleMapUrl: string;
  customerReminderTime: number;
  customerReminderTimeUnit: CustomerReminderTimeUnit;
  scheduleSizeUnits: ScheduleSizeUnits;
  googleAnalytics?: GoogleAnalytics | number;
  googleTagManager?: GoogleTagManager | number;
  paymentAccount?: PaymentAccount;
}
