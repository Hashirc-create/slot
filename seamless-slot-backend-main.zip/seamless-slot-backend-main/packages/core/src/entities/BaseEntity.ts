import { Business } from './Business';

export interface BaseEntity {
  id?: number;
  business?: number | Business;

  isActive: boolean;
  createdBy: number;
  updatedBy: number;
  deletedBy: number;

  createdAt?: Date;
  updatedAt?: Date;
  deletedAt?: Date;
}
