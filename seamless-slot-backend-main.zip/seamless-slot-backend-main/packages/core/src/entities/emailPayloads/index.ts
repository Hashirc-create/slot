export interface AppointmentWithPendingPaymentPayload {
  fullName: string;
  paymentLink: string;
  bookingId: string;
  service: string;
  duration: string;
  cost: string;
  dateTimeOfAppointment: string;
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  amountCharged: string;
  businessName: string;
  locationAddress: string;
  gmapUrl: string;
}

export interface AppointmentWithConfirmedPayload {
  fullName: string;
  bookingId: string;
  service: string;
  duration: string;
  cost: string;
  dateTimeOfAppointment: string;
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  amountCharged: string;
  businessName: string;
  locationAddress: string;
  gmapUrl: string;
}

export interface AppointmentCreateAdminTemplatePayload {
  location: string;
  bookingId: string;
  service: string;
  duration: string;
  cost: string;
  dateTimeOfAppointment: string;
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  amountCharged: string;
  businessName: string;
}

export interface AppointmentCreatedWithOutPaymentAdminTemplatePayload {
  location: string;
  bookingId: string;
  service: string;
  duration: string;
  cost: string;
  dateTimeOfAppointment: string;
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  businessName: string;
}

export interface PaymentReceiptPayload {
  payerName: string;
  transactionId: string;
  paymentMethod: string;
  paymentDate: string;
  serviceTitle: string;
  serviceAmount: string;
  subTotal: string;
  discount: string;
  total: string;
  businessName: string;
}

export interface AppointmentCancelledPayload {
  bookingId: string;
  service: string;
  duration: string;
  cost: string;
  dateTimeOfAppointment: string;
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  amountCharged: string;
  businessName: string;
  locationAddress: string;
  googleMapUrl: string;
}

export interface AppointmentChangedPayload {
  bookingId: string;
  service: string;
  duration: string;
  cost: string;
  oldDate: string;
  oldTime: string;
  oldDateTime: string;
  newDate: string;
  newTime: string;
  newDateTime: string;
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  amountCharged: string;
  locationPhoneNo: string;
  businessName: string;
  locationAddress: string;
  gmapUrl: string;
}

export interface FollowUpAppointmentCreatedEmail {
  patientFullName: string;
  businessName: string;
  locationName: string;
  patientPhone: string;
  appointmentDate: string;
  appointmentTime: string;
  locationAddress: string;
  gmapUrl: string;
}
