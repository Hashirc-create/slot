interface BarChart {
  'x-axis': { categories: string[] };
  'y-axis': { name: string; data: string[] }[];
}

export interface DashboardForLocationResponse {
  currency: string;
  allTimeRevenue: string;
  thisMonthRevenue: string;
  earnings: number;
  last6monthRevenue: BarChart;
  revenueTrend: BarChart;
  totalAllTimeAppointments: number;
  totalAllTimeRefunds: number;
  totalAllTimeCustomers: number;
  conversionRate: string;
  cancellationRate: string;
  noShowRate: string;
  appointmentByStatusAllTime: {
    appointments: { name: string; data: number[] }[];
    colors: string[];
  };
  appointmentRevenueByServiceAllTime: {
    appointments: { name: string; data: string[] }[];
    colors: string[];
  };
  totalAppointmentThisMonthByWeekDays: {
    weekdays: string[];
    count: number[];
  };
}
