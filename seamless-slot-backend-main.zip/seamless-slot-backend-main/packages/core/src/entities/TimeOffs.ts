import { BaseEntity } from './BaseEntity';
import { Location } from './Location';

export interface TimeOff extends BaseEntity {
  title: string;
  startDateTime: string | Date;
  endDateTime: string | Date;
  allDay: boolean;
  location: number | Location;
}
