import { BaseEntity } from './BaseEntity';
import { Location } from './Location';

export interface Notifications extends BaseEntity {
  title: string;
  customerName: string;
  appointmentStartTime: Date | string;
  isMarkedRead: boolean;
  location: Location | number;
}
