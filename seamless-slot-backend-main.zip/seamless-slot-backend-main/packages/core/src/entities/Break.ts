import { BaseEntity } from './BaseEntity';
import { WorkingDay } from './WorkingDay';

export interface Break extends BaseEntity {
  title: string;
  startTime: string | Date;
  endTime: string | Date;
  workingDay: number | WorkingDay;
}
