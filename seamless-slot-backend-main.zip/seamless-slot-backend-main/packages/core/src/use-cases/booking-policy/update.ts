import { BookingPolicy } from '../../entities/BookingPolicy';

export interface UpdateBookingPoliciesUseCase {
  execute(bookingPolicy: BookingPolicy): Promise<Readonly<string>>;
}

export const IUpdateBookingPoliciesUseCase = Symbol(
  'UpdateBookingPoliciesUseCase',
);
