import { BookingPolicy } from '../../entities/BookingPolicy';

export interface GetBookingPoliciesByLocationUseCase {
  execute(location: number): Promise<BookingPolicy>;
}

export const IGetBookingPoliciesByLocationUseCase = Symbol(
  'GetBookingPoliciesByLocationUseCase',
);
