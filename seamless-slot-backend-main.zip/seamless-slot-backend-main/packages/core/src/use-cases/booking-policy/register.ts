import { BookingPolicy } from '../../entities/BookingPolicy';

export interface RegisterBookingPolicyUseCase {
  execute(workingDay: BookingPolicy): Promise<BookingPolicy>;
}

export const IRegisterBookingPolicyUseCase = Symbol(
  'RegisterBookingPolicyUseCase',
);
