export interface IsGoogleTagMangerConnectedUseCase {
  execute(locationId: number): Promise<Readonly<boolean>>;
}

export const IIsGoogleTagMangerConnectedUseCase = Symbol(
  'IsGoogleTagMangerConnectedUseCase',
);
