import { GoogleTagManager } from '../../entities/GoogleTagManager';

export interface FindGoogleTagManagerByLocationUseCase {
  execute(locationId: number): Promise<Readonly<GoogleTagManager | null>>;
}

export const IFindGoogleTagManagerByLocationUseCase = Symbol(
  'FindGoogleTagManagerByLocationUseCase',
);
