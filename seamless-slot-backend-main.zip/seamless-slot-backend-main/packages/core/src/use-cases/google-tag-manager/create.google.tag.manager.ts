import { GoogleTagManager } from '../../entities/GoogleTagManager';

export interface CreateGoogleTagManagerUseCase {
  execute({
    containerId,
    locationId,
    businessId,
  }: {
    containerId: string;
    locationId: number;
    businessId: number;
  }): Promise<Readonly<GoogleTagManager>>;
}

export const ICreateGoogleTagManagerUseCase = Symbol(
  'CreateGoogleTagManagerUseCase',
);
