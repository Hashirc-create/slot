import { GoogleTagManager } from '../../entities/GoogleTagManager';

export interface EditGoogleTagManagerUseCase {
  execute(
    googleTagManagerId: number,
    containerId: string,
    locationId: number,
  ): Promise<Readonly<GoogleTagManager>>;
}

export const IEditGoogleTagManagerUseCase = Symbol(
  'EditGoogleTagManagerUseCase',
);
