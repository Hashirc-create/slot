import { BookingBrandDetail } from '../../entities/BookingBrandDetail';

export interface GetBookingBrandDetailsByLocationUseCase {
  execute(location: number): Promise<BookingBrandDetail>;
}

export const IGetBookingBrandDetailsByLocationUseCase = Symbol(
  'GetBookingBrandDetailsByLocationUseCase',
);
