import { BookingBrandDetail } from '../../entities/BookingBrandDetail';

export interface UpdateBookingBrandDetailsUseCase {
  execute(bookingBrandDetail: BookingBrandDetail): Promise<Readonly<string>>;
}

export const IUpdateBookingBrandDetailsUseCase = Symbol(
  'UpdateBookingBrandDetailsUseCase',
);
