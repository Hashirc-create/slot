import { BookingBrandDetail } from '../../entities/BookingBrandDetail';

export interface RegisterBookingBrandDetailUseCase {
  execute(workingDay: BookingBrandDetail): Promise<BookingBrandDetail>;
}

export const IRegisterBookingBrandDetailUseCase = Symbol(
  'RegisterBookingBrandDetailUseCase',
);
