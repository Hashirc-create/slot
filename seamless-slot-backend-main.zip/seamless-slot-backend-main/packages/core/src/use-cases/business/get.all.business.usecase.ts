import { Business } from '../../entities/Business';

export interface GetAllBusinessUseCase {
  execute(): Promise<Business[]>;
}

export const IGetAllBusinessUseCase = Symbol('GetAllBusinessUseCase');
