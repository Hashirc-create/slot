import { Business } from '../../entities';

export interface GetBusinessWithLocationBySubdomainUseCase {
  execute(subdomain: string): Promise<Readonly<Business>>;
}

export const IGetBusinessWithLocationBySubdomainUseCase = Symbol(
  'GetBusinessWithLocationBySubdomainUseCase',
);
