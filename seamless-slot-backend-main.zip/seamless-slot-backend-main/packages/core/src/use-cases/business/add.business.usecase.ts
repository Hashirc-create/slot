import { Business } from '../../entities';

export interface AddBusinessUseCase {
  execute(business: Business): Promise<Business>;
}

export const IAddBusinessUseCase = Symbol('AddBusinessUseCase');
