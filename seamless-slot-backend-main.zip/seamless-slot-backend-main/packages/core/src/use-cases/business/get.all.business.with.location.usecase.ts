import { Business } from '../../entities';

export interface GetAllBusinessWithLocationUseCase {
  execute(): Promise<Readonly<Business[]>>;
}

export const IGetAllBusinessWithLocationUseCase = Symbol(
  'GetAllBusinessWithLocationUseCase',
);
