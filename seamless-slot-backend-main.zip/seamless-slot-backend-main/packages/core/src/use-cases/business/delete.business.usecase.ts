import { Business } from '../../entities';

export interface DeleteBusinessUseCase {
  execute(businessId: number): Promise<Business>;
}

export const IDeleteBusinessUseCase = Symbol('DeleteBusinessUseCase');
