import { Business } from '../../entities';

export interface UpdateBusinessUseCase {
  execute(business: Business): Promise<Business>;
}

export const IUpdateBusinessUseCase = Symbol('UpdateBusinessUseCase');
