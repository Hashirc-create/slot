import { Business } from '../../entities';

export interface GetBusinessByIdUseCase {
  execute(id: number): Promise<Readonly<Business>>;
}

export const IGetBusinessByIdUseCase = Symbol('GetBusinessByIdUseCase');
