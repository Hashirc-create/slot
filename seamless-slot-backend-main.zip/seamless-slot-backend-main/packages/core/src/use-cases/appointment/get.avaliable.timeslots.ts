export interface GetAvaliableTimeSlotsUseCase {
  execute(
    serviceId: number,
    date: string,
    locationId: number,
  ): Promise<Readonly<string[]>>;
}

export const IGetAvaliableTimeSlotsUseCase = Symbol(
  'GetAvaliableTimeSlotsUseCase',
);
