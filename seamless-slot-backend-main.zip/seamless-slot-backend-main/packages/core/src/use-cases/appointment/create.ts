import { Appointment } from '../../entities/Appointment';

export interface CreateAppointmentUseCase {
  execute(Appointment: Appointment): Promise<Readonly<Appointment>>;
}

export const ICreateAppointmentUseCase = Symbol('CreateAppointmentUseCase');
