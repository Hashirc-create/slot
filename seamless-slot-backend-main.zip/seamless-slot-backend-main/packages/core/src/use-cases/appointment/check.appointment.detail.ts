export interface CheckAppointmentDetailUseCase {
  execute(appointmentId: number): Promise<
    Readonly<{
      hasRefunds: boolean;
      hasPayments: boolean;
      hasPaymentLogs: boolean;
    }>
  >;
}

export const ICheckAppointmentDetailUseCase = Symbol(
  'CheckAppointmentDetailUseCase',
);
