import { Appointment } from '../../entities/Appointment';
import { Customer } from '../../entities/Customer';
import { SupportedPaymentMethods } from '../../entities/types';

export interface CreatePublicAppointmentUseCase {
  execute(
    appointment: Appointment,
    customer: Customer,
    squareSourceId: string,
    paymentMethod: SupportedPaymentMethods,
  ): Promise<Readonly<Appointment>>;
}

export const ICreatePublicAppointmentUseCase = Symbol(
  'CreatePublicAppointmentUseCase',
);
