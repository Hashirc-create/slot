import { Appointment } from '../../entities/Appointment';
import { AppointmentStatus } from '../../entities/types';

export interface ChangeAppointmentStatusUseCase {
  execute(
    id: number,
    status: AppointmentStatus,
  ): Promise<Readonly<Appointment>>;
}

export const IChangeAppointmentStatusUseCase = Symbol(
  'ChangeAppointmentStatusUseCase',
);
