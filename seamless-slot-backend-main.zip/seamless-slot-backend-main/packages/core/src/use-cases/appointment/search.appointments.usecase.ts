import { Appointment } from '../../entities/Appointment';

export interface SearchAppointmentsWithPaginationUseCase {
  execute(
    locationId: number,
    stringToBeSearched: string,
    page: number,
    limit: number,
  ): Promise<
    Readonly<{
      prev: number;
      next: number;
      last: number;
      pages: number;
      total: number;
      data: Appointment[];
    }>
  >;
}

export const ISearchAppointmentsWithPaginationUseCase = Symbol(
  'SearchAppointmentsWithPaginationUseCase',
);
