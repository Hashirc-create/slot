import { Appointment } from '../../entities/Appointment';

export interface GetAppointmentSummaryByBookingIdUseCase {
  execute(appointmentId: number): Promise<Readonly<Appointment>>;
}

export const IGetAppointmentSummaryByBookingIdUseCase = Symbol(
  'GetAppointmentSummaryByBookingIdUseCase',
);
