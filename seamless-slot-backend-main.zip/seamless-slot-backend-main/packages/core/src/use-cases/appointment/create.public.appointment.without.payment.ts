import { Appointment } from '../../entities/Appointment';
import { Customer } from '../../entities/Customer';

export interface CreatePublicAppointmentWithoutPaymentUseCase {
  execute(
    appointment: Appointment,
    customer: Customer,
  ): Promise<Readonly<Appointment>>;
}

export const ICreatePublicAppointmentWithoutPaymentUseCase = Symbol(
  'CreatePublicAppointmentWithoutPaymentUseCase',
);
