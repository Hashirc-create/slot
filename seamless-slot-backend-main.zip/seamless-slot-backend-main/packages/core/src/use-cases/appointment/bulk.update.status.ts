import { AppointmentStatus } from '../../entities';

export interface BulkUpdateStatusUseCase {
  execute(
    payload: {
      id: number;
      status: AppointmentStatus;
    }[],
  ): Promise<string>;
}

export const IBulkUpdateStatusUseCase = Symbol('BulkUpdateStatusUseCase');
