export interface CheckIfSlotBookedUseCase {
  execute(startTime: Date, endTime: Date): Promise<void>;
}

export const ICheckIfSlotBookedUseCase = Symbol('CheckIfSlotBookedUseCase');
