import { Appointment } from '../../entities/Appointment';

export interface GetAllAppointmentByMonthUseCase {
  execute(
    year: number,
    month: number,
    locationId: number,
  ): Promise<Readonly<Appointment[]>>;
}

export const IGetAllAppointmentByMonthUseCase = Symbol(
  'GetAllAppointmentByMonthUseCase',
);
