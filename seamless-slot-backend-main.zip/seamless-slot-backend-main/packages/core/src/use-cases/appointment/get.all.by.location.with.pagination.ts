import { Appointment } from '../../entities/Appointment';

export interface GetAllAppointmentsByLocationWithPaginationUseCase {
  execute(
    locationId: number,
    page: number,
    perPage: number,
    startDate: string,
    endDate: string,
  ): Promise<
    Readonly<{
      prev: number;
      next: number;
      last: number;
      pages: number;
      total: number;
      data: Appointment[];
    }>
  >;
}

export const IGetAllAppointmentsByLocationWithPaginationUseCase = Symbol(
  'GetAllAppointmentsByLocationWithPaginationUseCase',
);
