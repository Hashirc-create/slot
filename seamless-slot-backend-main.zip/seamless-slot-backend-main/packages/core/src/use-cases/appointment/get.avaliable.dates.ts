export interface GetAvaliableDatesUseCase {
  execute(locationId?: number): Promise<Readonly<string[]>>;
}

export const IGetAvaliableDatesUseCase = Symbol('GetAvaliableDatesUseCase');
