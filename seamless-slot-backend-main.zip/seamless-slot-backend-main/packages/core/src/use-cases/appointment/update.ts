import { Appointment } from '../../entities/Appointment';

export interface UpdateAppointmentUseCase {
  execute(id: number, Appointment: Appointment): Promise<Readonly<Appointment>>;
}

export const IUpdateAppointmentUseCase = Symbol('UpdateAppointmentUseCase');
