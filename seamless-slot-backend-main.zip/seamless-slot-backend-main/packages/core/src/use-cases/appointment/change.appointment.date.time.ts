import { Appointment } from '../../entities/Appointment';

export interface ChangeAppointmentDataTimeUseCase {
  execute(
    id: number,
    startTime: string,
    endTime: string,
  ): Promise<Readonly<Appointment>>;
}

export const IChangeAppointmentDataTimeUseCase = Symbol(
  'ChangeAppointmentDataTimeUseCase',
);
