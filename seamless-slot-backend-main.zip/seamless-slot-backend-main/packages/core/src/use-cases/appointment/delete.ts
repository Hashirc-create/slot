import { Appointment } from '../../entities/Appointment';

export interface DeleteAppointmentUseCase {
  execute(id: number): Promise<Readonly<Appointment>>;
}

export const IDeleteAppointmentUseCase = Symbol('DeleteAppointmentUseCase');
