import { Appointment } from '../../entities/Appointment';
import { SupportedPaymentMethods } from '../../entities/types';

export interface TakePaymentPublicAppointmentUseCase {
  execute(
    appointmentId: number,
    locationId: number,
    customerId: number,
    serviceId: number,
    squareSourceId: string,
    squareBuyerId: string,
    paymentMethod: SupportedPaymentMethods,
  ): Promise<Readonly<Appointment>>;
}

export const ITakePaymentPublicAppointmentUseCase = Symbol(
  'TakePaymentPublicAppointmentUseCase',
);
