import { Appointment } from '../../entities/Appointment';

export interface GetByIdAppointmentUseCase {
  execute(id: number): Promise<Readonly<Appointment>>;
}

export const IGetByIdAppointmentUseCase = Symbol('GetByIdAppointmentUseCase');
