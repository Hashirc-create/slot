import { Appointment } from '../../entities/Appointment';

export interface GetAllAppointmentsByLocationUseCase {
  execute(locationId: number): Promise<Readonly<Appointment[]>>;
}

export const IGetAllAppointmentsByLocationUseCase = Symbol(
  'GetAllAppointmentsByLocationUseCase',
);
