import { Location } from '../../entities/Location';
import { ScheduleSizeUnits } from '../../entities/types';

export interface ChangeLocationScheduleWindowUseCase {
  execute(
    locationId: number,
    scheduleSize: number,
    scheduleSizeUnit: ScheduleSizeUnits,
  ): Promise<Location>;
}

export const IChangeLocationScheduleWindowUseCase = Symbol(
  'ChangeLocationScheduleWindowUseCase',
);
