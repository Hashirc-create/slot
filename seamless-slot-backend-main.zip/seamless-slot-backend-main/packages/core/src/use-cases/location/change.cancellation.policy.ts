import { Location } from '../../entities/Location';
import { CancellationTimeUnits } from '../../entities/types';

export interface ChangeLocationCancellationPolicy {
  execute(
    locationId: number,
    cancellationTime: number,
    cancellationTimeUnits: CancellationTimeUnits,
    isCancellationPolicyEnabled: boolean,
  ): Promise<Location>;
}

export const IChangeLocationCancellationPolicy = Symbol(
  'ChangeLocationCancellationPolicy',
);
