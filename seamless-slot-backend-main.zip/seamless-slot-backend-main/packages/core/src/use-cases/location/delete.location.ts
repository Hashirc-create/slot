import { Location } from '../../entities/Location';

export interface DeleteLocationUseCase {
  execute(locationId: number): Promise<Location>;
}

export const IDeleteLocationUseCase = Symbol('DeleteLocationUseCase');
