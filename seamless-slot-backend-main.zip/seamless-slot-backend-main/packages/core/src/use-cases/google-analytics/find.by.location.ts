import { GoogleAnalytics } from '../../entities/GoogleAnalytics';

export interface FindGoogleAnalyticsByLocationUseCase {
  execute(locationId: number): Promise<Readonly<GoogleAnalytics | null>>;
}

export const IFindGoogleAnalyticsByLocationUseCase = Symbol(
  'FindGoogleAnalyticsByLocationUseCase',
);
