import { GoogleAnalytics } from '../../entities/GoogleAnalytics';

export interface CreateGoogleAnalyticsUseCase {
  execute({
    measurementId,
    locationId,
  }: {
    measurementId: string;
    locationId: number;
  }): Promise<Readonly<GoogleAnalytics>>;
}

export const ICreateGoogleAnalyticsUseCase = Symbol(
  'CreateGoogleAnalyticsUseCase',
);
