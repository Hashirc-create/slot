import { GoogleAnalytics } from '../../entities/GoogleAnalytics';

export interface EditGoogleAnalyticsUseCase {
  execute(
    googleAnalyticsId: number,
    locationId: number,
    measurementId: string,
  ): Promise<Readonly<GoogleAnalytics>>;
}

export const IEditGoogleAnalyticsUseCase = Symbol('EditGoogleAnalyticsUseCase');
