import { Break } from '../../entities/Break';

export interface UpdateBreakUseCase {
  execute(breaks: Break[]): Promise<Readonly<string>>;
}

export const IUpdateBreakUseCase = Symbol('UpdateBreakUseCase');
