import { Break } from '../../entities';

export interface GetAllBreaksByLocationUseCaseForHistory {
  execute(locationId: number): Promise<Readonly<Break[]>>;
}

export const IGetAllBreaksByLocationUseCaseForHistory = Symbol(
  'GetAllBreaksByLocationUseCaseForHistory',
);
