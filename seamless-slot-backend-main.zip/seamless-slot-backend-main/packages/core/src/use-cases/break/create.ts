import { Break } from '../../entities/Break';

export interface CreateBreakUseCase {
  execute(Break: Break): Promise<Readonly<Break>>;
}

export const ICreateBreakUseCase = Symbol('CreateBreakUseCase');
