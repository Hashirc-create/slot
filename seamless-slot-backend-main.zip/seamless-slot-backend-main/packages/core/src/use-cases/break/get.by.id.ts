import { Break } from '../../entities/Break';

export interface GetByIdBreakUseCase {
  execute(id: number): Promise<Readonly<Break>>;
}

export const IGetByIdBreakUseCase = Symbol('GetByIdBreakUseCase');
