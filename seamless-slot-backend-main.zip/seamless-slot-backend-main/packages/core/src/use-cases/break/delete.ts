import { Break } from '../../entities/Break';

export interface DeleteBreakUseCase {
  execute(id: number): Promise<Readonly<Break>>;
}

export const IDeleteBreakUseCase = Symbol('DeleteBreakUseCase');
