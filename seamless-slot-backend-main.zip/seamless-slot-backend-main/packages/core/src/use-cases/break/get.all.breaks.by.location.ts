import { BreakEvent } from '../../entities';

export interface GetAllBreaksByLocation {
  execute(locationId: number, year: number): Promise<Readonly<BreakEvent[]>>;
}

export const IGetAllBreaksByLocation = Symbol('GetAllBreaksByLocation');
