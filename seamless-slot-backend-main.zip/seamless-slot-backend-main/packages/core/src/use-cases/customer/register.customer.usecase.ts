import { Customer } from '../../entities/Customer';

export interface RegisterCustomerUseCase {
  execute(customer: Customer): Promise<Readonly<Customer>>;
}

export const IRegisterCustomerUseCase = Symbol('RegisterCustomerUseCase');
