import { Customer } from '../../entities/Customer';

export interface DeleteCustomerUseCase {
  execute(customerId: number): Promise<Readonly<Customer>>;
}

export const IDeleteCustomerUseCase = Symbol('DeleteCustomerUseCase');
