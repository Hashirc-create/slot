import { Customer } from '../../entities/Customer';

export interface SearchCustomerWithPaginationUseCase {
  execute(
    locationId: number,
    stringToBeSearched: string,
    page: number,
    limit: number,
  ): Promise<
    Readonly<{
      prev: number;
      next: number;
      last: number;
      pages: number;
      total: number;
      data: Customer[];
    }>
  >;
}

export const ISearchCustomerWithPaginationUseCase = Symbol(
  'SearchCustomerWithPaginationUseCase',
);
