import { Customer } from '../../entities/Customer';

export interface GetAllCustomerByLocationUseCase {
  execute(locationId: number): Promise<Readonly<Customer[]>>;
}

export const IGetAllCustomerByLocationUseCase = Symbol(
  'GetAllCustomerByLocationUseCase',
);
