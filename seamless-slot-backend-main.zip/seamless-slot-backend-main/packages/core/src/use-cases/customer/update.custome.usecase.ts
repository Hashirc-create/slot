import { Customer } from '../../entities/Customer';

export interface UpdateCustomerUseCase {
  execute(id: number, customer: Customer): Promise<Readonly<Customer>>;
}

export const IUpdateCustomerUseCase = Symbol('UpdateCustomerUseCase');
