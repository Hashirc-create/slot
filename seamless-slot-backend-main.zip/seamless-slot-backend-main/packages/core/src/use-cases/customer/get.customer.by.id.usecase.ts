import { Customer } from '../../entities/Customer';

export interface GetCustomerByIdUseCase {
  execute(customerId: number, locationId: number): Promise<Readonly<Customer>>;
}

export const IGetCustomerByIdUseCase = Symbol('GetCustomerByIdUseCase');
