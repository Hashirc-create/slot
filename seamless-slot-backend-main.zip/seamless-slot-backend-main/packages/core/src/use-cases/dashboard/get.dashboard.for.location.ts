import { DashboardForLocationResponse } from '../../entities/dashboard';

export interface GetDashboardForLocation {
  execute(locationId: number): Promise<Readonly<DashboardForLocationResponse>>;
}

export const IGetDashboardForLocation = Symbol('GetDashboardForLocation');
