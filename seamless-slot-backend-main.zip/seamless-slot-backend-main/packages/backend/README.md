<p align="center">
  <img src="./docs/logo.png" width="200" alt="Yummy Codes Logo" />
</p>
  <p align="center">Seamless Slot Backend Application Built Using Nestjs and Typescript </p>

## Installation

### Please make sure to create .env file with proper envoirnment variables sample given below

```bash
$ pnpm install
$ npx prisma migrate deploy
$ npx prisma generate
$ pnpm run start:dev (for running app in dev env) 
```

## Before Running the App

- Create Environment Variables .env

### Sample File (.env)

```.env

DATABASE_URL="postgresql://admin:admin@localhost:5432/seamless-slot?schema=public"
#DATABASE_URL="postgresql://slotadmin:Thisisfortesting12345@18.168.199.4:5432/seamlessslot?schema=public"


# development
# production
NODE_ENV=development

# SOCKETIO
SOCKETIO_PORT=3001

# AES encryption
# AES DATA ENCRYPTION
AES_KEY=d66837a4e15aea6b624420a67b514f5ab64671618d2759a0bdee24eb8495fad0
AES_IV=c0d97f54688a83a5b8a5049eed0607ec




# JWT
JWT_ACCESS_TOKEN_SECRETE_KEY=Thisisthestrongestkey

JWT_ACCESS_TOKEN_EXPIRY=10m
JWT_REFRESH_TOKEN_SECRETE_KEY=Thisisdsafdafdfdsfadsfdsfdsafdsafds
JWT_REFRESH_TOKEN_EXPIRY=1d


# GOOGLE OAUTH
GOOGLE_CLIENT_ID=763292967520-h91kvlv6s5p2rgcq7fipcqu93drlbl5u.apps.googleusercontent.com


# Dentally access token
DENTALLY_SANDBOX=false
DENTALLY_PERSONAL_ACCESS_TOKEN=eqT7ak8_KKVXpWXrr0MZk1Ee4UVEofwrJ6bZajpAeII

DENTALLY_CLIENT_ID_PROD=1vsIPQ3ECPZA834niWTDKobSEDN4vhDhk_DXN_RSg4Y
DENTALLY_CLIENT_SECRETE_PROD=N4MIiure9E7vtFgxfhlQ8ntnwUf8so5bfvBx5ccP0X0
DENTALLY_FRONT_END_REDIRECT_URL_PROD=https://stating.seamlesslsot.co.uk/callback

DENTALLY_CLIENT_ID_SANDBOX=
DENTALLY_CLIENT_SECRETE_SANDBOX=
DENTALLY_FRONT_END_REDIRECT_URL_SANDBOX=


# SMTP
# SMTP_HOST=email-smtp.eu-west-2.amazonaws.com
# SMTP_PORT=465
# SMTP_USERNAME=AKIA2EUDIUJXI543HFVP
# SMTP_PASSWORD=BI9SY0cYoYUEvES2vE+44ChX03rpKnHzo7+kQfRG5KLU

SMTP_HOST=smtp.sendgrid.net
SMTP_PORT=465
SMTP_USERNAME=apikey
SMTP_PASSWORD=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
SMTP_SENDER_DOMAIN=info@seamlessslot.co.uk


# TWILIO SMS
TWILIO_ACCOUNT_SID=AC4d2be414575277f003b29c5f401fd4ce
TWILIO_AUTH_TOKEN=496dfd56b0d48cf4035d5982f049a576


# RABBIT MQ
BROKER_URL=amqp://admin:admin@localhost:5672


SQUARE_SANDBOX=false

# SQUARE PAY OAUTH (SANDBOX)
SQUARE_PAY_CLIENT_ID_SANDBOX=sandbox-sq0idb-uTlO-tnPFkwvjLpFkx5UuQ
SQUARE_PAY_CLIENT_SECRETE_SANDBOX=sandbox-sq0csb--qm-U0W3c2FD7mcdPYl4hIp03Dbavz9HlEo8HAs3dfA
SQUARE_PAY_FRONT_END_REDIRECT_URL_SANDBOX=https://staging.seamlessslot.co.uk

# SQUARE PAY OAUTH (PROD)
SQUARE_PAY_CLIENT_ID_PROD=sq0idp-cPA3SI-5e6KT-FLBXcSlDg
SQUARE_PAY_CLIENT_SECRETE_PROD=sq0csp-Q7NkOAIB-h4FODl7IkbsDnVPkMmFD0L3CgsCLeEwcHs
SQUARE_PAY_FRONT_END_REDIRECT_URL_PROD=https://www.staging.seamlessslot.co.uk

# SALEFORCE
SALEFORCE_LOGIN_URL=https://test.salesforce.com
SALEFORCE_USERNAME=rizwan.malik2@seamlessideas.co.uk.sandbox
SALEFORCE_PASSWORD=Naded999!
SALEFORCE_SECURITY_TOKEN=XLbpwQnFmU5wmlA5RPw70ECN

# # SQUARE PAY OAUTH (PRODUCTION)
# SQUARE_PAY_CLIENT_ID=sq0idp-NDaTyZtvj2b-9GdlTFSTRw
# SQUARE_PAY_CLIENT_SECRETE=sq0csp-4YU3kmTC3jxi_lhjdLNI8BIfWrUYXWPKg41DIdV6KW4
# SQUARE_PAY_ACCESS_TOKEN=EAAAluVFMjQNAhvyjDa-3LW74Hv8Q3GbSR0oniJE5Dzs_y6cKhn7-_xM3tTllMwq

```

## Running the app

```bash
# development
$ pnpm run start:dev

```

## Test

```bash
# unit tests
$ pnpm run test

# e2e tests
$ pnpm run test:e2e

# test coverage
$ pnpm run test:cov
```

## Development Notes

### Contract Layer / Domain Layer

- Define the domain contract person.ts
- Define the business rules/usecases Razz
- Repository contract extends base repo contract

### Infrastructure Layer

- Mongo Model also add in the moongose.module
- Persistance Mapper also add in the factory and in the array at infrastrucutre/mappers/index.ts
- Repository Impl aslo add in the factory and in the array at infrastrucutre/repostiories/index.ts
- usecase Impl aslo add in the factory and in the array at infrastrucutre/usecase/index.ts

## Presentation Layer

testing

## Social Logins

### Google

```txt
eyJhbGciOiJSUzI1NiIsImtpZCI6IjZjZTExYWVjZjllYjE0MDI0YTQ0YmJmZDFiY2Y4YjMyYTEyMjg3ZmEiLCJ0eXAiOiJKV1QifQ.eyJpc3MiOiJodHRwczovL2FjY291bnRzLmdvb2dsZS5jb20iLCJhenAiOiI3NjMyOTI5Njc1MjAtdDU0dDI2cG1ha21ubGhkdDZwdjZnbzFpOWxyaG1mYmguYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJhdWQiOiI3NjMyOTI5Njc1MjAtaDkxa3ZsdjZzNXAycmdjcTdmaXBjcXU5M2RybGJsNXUuYXBwcy5nb29nbGV1c2VyY29udGVudC5jb20iLCJzdWIiOiIxMDMwMDcyOTA1NTM3MjU4ODE5MjIiLCJoZCI6InNlYW1sZXNzaWRlYXMuY28udWsiLCJlbWFpbCI6InplZXNoYW4uemFmYXJAc2VhbWxlc3NpZGVhcy5jby51ayIsImVtYWlsX3ZlcmlmaWVkIjp0cnVlLCJhdF9oYXNoIjoiQWxBbFRNVE1ES3VWSDk3OGdiWGVMUSIsIm5vbmNlIjoiVmxFUFhoMmN1YjFkcDh2Mmt0MVplWkdhb18zUWdQYjUxS2pxMzhOc0w0VSIsIm5hbWUiOiJaZWVzaGFuIFphZmFyIiwicGljdHVyZSI6Imh0dHBzOi8vbGgzLmdvb2dsZXVzZXJjb250ZW50LmNvbS9hL0FDZzhvY0xvYUFjVVlzS0JvaTVOSzc3M1ZmMkpWR1lIQzVyU1lMWDBGMlFqbVJEbkVCWXhZZz1zOTYtYyIsImdpdmVuX25hbWUiOiJaZWVzaGFuICIsImZhbWlseV9uYW1lIjoiWmFmYXIiLCJpYXQiOjE3MTM0MjI0OTIsImV4cCI6MTcxMzQyNjA5Mn0.a29YlJK4srL48OrYkyi7qkvukmGVZxauhEGgkiKKRTL4ots8UmH1weZn8ZAXD1p5Y5tlyKM7JNPnLY1WdmALDNTj8CNqJpSvA7a0osRTTR_Bu56On22vqy5AmN_D08n7buVXoBRO_xUKpbasbKd3ETi2C1_BWUWqt_hcK2z3X55NMgQraUm9wk73OPZ2eHA-G_bw6LnL9gDu3c6ulHx5Yo4XGIvUjdMf7S4LuEY-2NgM3hhgGi4H5Vd-HZyBQ0k-tg1d1H37R6prfs6fPnD6WlHUGCBC8IV8uzc5Clbb94SOWfbKvqxgndQ2cFkK3zt3UTKi6_9Niyf642hW0be4pA
```

```json
{
  "iss": "https://accounts.google.com",
  "azp": "763292967520-t54t26pmakmnlhdt6pv6go1i9lrhmfbh.apps.googleusercontent.com",
  "aud": "763292967520-h91kvlv6s5p2rgcq7fipcqu93drlbl5u.apps.googleusercontent.com",
  "sub": "103007290553725881922",
  "hd": "seamlessideas.co.uk",
  "email": "zeeshan.zafar@seamlessideas.co.uk",
  "email_verified": true,
  "at_hash": "AlAlTMTMDKuVH978gbXeLQ",
  "nonce": "VlEPXh2cub1dp8v2kt1ZeZGao_3QgPb51Kjq38NsL4U",
  "name": "Zeeshan Zafar",
  "picture": "https://lh3.googleusercontent.com/a/ACg8ocLoaAcUYsKBoi5NK773Vf2JVGYHC5rSYLX0F2QjmRDnEBYxYg=s96-c",
  "given_name": "Zeeshan ",
  "family_name": "Zafar",
  "iat": 1713422492,
  "exp": 1713426092
}
```

### Apple

```txt
eyJraWQiOiJsVkhkT3g4bHRSIiwiYWxnIjoiUlMyNTYifQ.eyJpc3MiOiJodHRwczovL2FwcGxlaWQuYXBwbGUuY29tIiwiYXVkIjoiY29tLnl1bW15Y29kZS5zZWFtbGVzcyIsImV4cCI6MTcxMzUwODk2MywiaWF0IjoxNzEzNDIyNTYzLCJzdWIiOiIwMDExMDUuOThmZDAwMGI1M2E4NDk2MGExMzVkYjE1YmQyNWQ3OTMuMDMzNCIsIm5vbmNlIjoiN2M1MmEyNWI1ZmU1YmE5OTJjNGQ0ZmUwZTZhMDUwNDUxYTc4ZDYwMTQyYTliMWE1YzhhYTg5NTA3NDdhZDY5NSIsImNfaGFzaCI6ImxiZzVvSkc3OHJkTm9FcURVamtVTlEiLCJlbWFpbCI6InpvcmF6ZTU1NzI2MTVAaWNsb3VkLmNvbSIsImVtYWlsX3ZlcmlmaWVkIjp0cnVlLCJhdXRoX3RpbWUiOjE3MTM0MjI1NjMsIm5vbmNlX3N1cHBvcnRlZCI6dHJ1ZX0.U5JlkoGYIcIf6I8PUPrQMqgAEpsOz_kkZaQqx5hTeEqV9-LiIei8hPU_MhZUE8YIn9A8ia0OlhHuUnDZlFRrPlkB-nOiF-inOluQFLxk5anbMaMQxosJVr4UxGDCzmClp9zamEQrl6Gu1zHhx8sGUOCMe4cBH1SLPW0S6D-GnZU-2qb1pVucCWbkxX3U3qbhBJhgp09cf_WzqaY4tj0QEUzv_yHZBJHCEpwUi2N38Dc0cYwngr68GiOrAOvUfCBNbYIQw9aSf2mLs7ju78EgOEDIFHio3g-0sAOGH-IE-Anj-w8IS0dNIWpojQhSTiUF9rr2fcjJJMu5H8ejpHocmQ
```

```json
{
  "iss": "https://appleid.apple.com",
  "aud": "com.yummycode.seamless",
  "exp": 1713508963,
  "iat": 1713422563,
  "sub": "001105.98fd000b53a84960a135db15bd25d793.0334",
  "nonce": "7c52a25b5fe5ba992c4d4fe0e6a050451a78d60142a9b1a5c8aa8950747ad695",
  "c_hash": "lbg5oJG78rdNoEqDUjkUNQ",
  "email": "zoraze5572615@icloud.com",
  "email_verified": true,
  "auth_time": 1713422563,
  "nonce_supported": true
}
```

<!-- testing pushing into master -->

```

```

# sudo su - <<'EOF'

            # cd  seamless-slot-backend/
            # git checkout .
            # git pull
            # npm install
            # npx prisma migrate deploy
            # npx prisma generate
            # npm run build
            # pm2 restart ss

### Prisma Suppported Date Time

- 2024-06-01T09:00:00Z (ISO 8601 format with 'Z' indicating UTC)

```ts
const newEvent = await prisma.event.create({
  data: {
    name: 'Conference',
    startTime: new Date('2024-06-01T09:00:00Z'), // ISO 8601 format with 'Z' indicating UTC
    endTime: new Date('2024-06-01T17:00:00Z'),
  },
});
```

# OAUTH SQUARE CHANGES

- Change the auth url on the frontend

  - VITE_AUTH_URL_DEV = "http://localhost:3000/square-oauth/login/sandbox"
  - VITE_AUTH_URL_STAGING = "https://backend.staging.seamlessslot.co.uk/square-oauth/login/sandbox"

- Change the callback url on the square pay dashboard

  - http://localhost:3000/square-oauth/callback/sandbox
  - https://backend.statging.seamlessslot.co.uk/square-oauth/callback/sandbox

- Change the redirect of the url in Square Auth Controller (/callback/sandbox)

  - https://localhost:5173/callback?access_token=${result.result.accessToken}&refresh_token=${result.result.refreshToken}
  - https://staging.seamlessslot.co.uk/callback?access_token=${result.result.accessToken}&refresh_token=${result.result.refreshToken}

#Square Web Hooks

## ORDER CREATED

```json
{
  "merchant_id": "MLXXJY48XF780",
  "type": "order.created",
  "event_id": "64acb257-4174-3d6d-8a4e-386b5f33305f",
  "created_at": "2024-07-10T06:14:51Z",
  "data": {
    "type": "order_created",
    "id": "E3eCCMnCHXL93idMgdOGBbRaY4FZY",
    "object": {
      "order_created": {
        "created_at": "2024-07-10T06:14:50.837Z",
        "location_id": "L5BDB5VAAHTNA",
        "order_id": "E3eCCMnCHXL93idMgdOGBbRaY4FZY",
        "state": "DRAFT",
        "version": 1
      }
    }
  }
}
```

## PAYMENT UPDATED (PAYMENT DONE)

```json
{
  "merchant_id": "mlxxjy48xf780",
  "type": "payment.updated",
  "event_id": "368cb4ad-f6d4-32a3-afec-78720cb71248",
  "created_at": "2024-07-10t06:18:07.454z",
  "data": {
    "type": "payment",
    "id": "posuxdiwdjstrt1njtxgez9ljktzy",
    "object": {
      "payment": {
        "amount_money": {
          "amount": 10,
          "currency": "gbp"
        },
        "application_details": {
          "application_id": "sq0idp-w46nj_ncndmsoywacy0mwa",
          "square_product": "ecommerce_api"
        },
        "approved_money": {
          "amount": 10,
          "currency": "gbp"
        },
        "buyer_email_address": "zeeshan.zafar@seamlessideas.co.uk",
        "card_details": {
          "auth_result_code": "T08343",
          "avs_status": "AVS_REJECTED",
          "card": {
            "bin": "519345",
            "card_brand": "MASTERCARD",
            "card_type": "CREDIT",
            "exp_month": 11,
            "exp_year": 2026,
            "fingerprint": "sq-1-I1hngmrQQaTUMOz-pHOaOqkmtwYuDsfi7gSKvPi-GLXtMlyARbp9ZPUsHt4-EKtuWg",
            "last_4": "0360",
            "payment_account_reference": "0133012950010OSASC3WZABWEA90R1R6CNKVR",
            "prepaid_type": "NOT_PREPAID"
          },
          "card_payment_timeline": {
            "authorized_at": "2024-07-10T06:18:00.987Z",
            "captured_at": "2024-07-10T06:18:01.273Z"
          },
          "cvv_status": "CVV_ACCEPTED",
          "entry_method": "KEYED",
          "statement_description": "SQ *NIGHT AND DAY EMERGE",
          "status": "CAPTURED"
        },
        "created_at": "2024-07-10T06:18:00.481Z",
        "customer_id": "084NNCFDJFJFRD9Y882XD2TKNG",
        "delay_action": "CANCEL",
        "delay_duration": "PT168H",
        "delayed_until": "2024-07-17T06:18:00.481Z",
        "id": "poSuXdiwDjSTRt1nJTxgEZ9lJkTZY",
        "location_id": "L5BDB5VAAHTNA",
        "order_id": "E3eCCMnCHXL93idMgdOGBbRaY4FZY",
        "processing_fee": [
          {
            "amount_money": {
              "amount": 10,
              "currency": "GBP"
            },
            "effective_at": "2024-07-10T21:18:01.000Z",
            "type": "INITIAL"
          }
        ],
        "receipt_number": "poSu",
        "receipt_url": "https://squareup.com/receipt/preview/poSuXdiwDjSTRt1nJTxgEZ9lJkTZY",
        "risk_evaluation": {
          "created_at": "2024-07-10T06:18:01.168Z",
          "risk_level": "NORMAL"
        },
        "source_type": "CARD",
        "status": "COMPLETED",
        "tip_money": {
          "amount": 0,
          "currency": "GBP"
        },
        "total_money": {
          "amount": 10,
          "currency": "GBP"
        },
        "updated_at": "2024-07-10T06:18:01.949Z",
        "version": 4
      }
    }
  }
}
```

## ORDER FULLFILMENT UPDATED

```json
{
  "merchant_id": "MLXXJY48XF780",
  "type": "order.fulfillment.updated",
  "event_id": "e96f05ef-dc87-3822-bd42-fc40a77d810f",
  "created_at": "2024-07-10T06:18:01Z",
  "data": {
    "type": "order_fulfillment_updated",
    "id": "E3eCCMnCHXL93idMgdOGBbRaY4FZY",
    "object": {
      "order_fulfillment_updated": {
        "created_at": "2024-07-10T06:14:50.837Z",
        "fulfillment_update": [
          {
            "fulfillment_uid": "lXP3Yk5jLe0PxX8rkcgwmD",
            "new_state": "PROPOSED",
            "old_state": "PROPOSED"
          }
        ],
        "location_id": "L5BDB5VAAHTNA",
        "order_id": "E3eCCMnCHXL93idMgdOGBbRaY4FZY",
        "state": "OPEN",
        "updated_at": "2024-07-10T06:18:01.309Z",
        "version": 7
      }
    }
  }
}
```

## PAYMENT UPDATED (PAYMENT DONE USING GOOGLE PAY)

```json
## PAYMENT UPDATED (PAYMENT DONE)

{"merchant_id":"MLXXJY48XF780","type":"payment.updated","event_id":"48cc1db5-3824-32a6-a2a6-3a67fad89eb6","created_at":"2024-07-11T13:24:49.97Z","data":{"type":"payment","id":"NiuUA1XNHXrw6YeN1oaEh7PPMCBZY","object":{"payment":{"amount_money":{"amount":10,"currency":"GBP"},"application_details":{"application_id":"sq0idp-w46nJ_NCNDMSOywaCY0mwA","square_product":"ECOMMERCE_API"},"approved_money":{"amount":10,"currency":"GBP"},"billing_address":{"address_line_1":"ssss","address_line_2":"sss","country":"PK","first_name":"Zeeshan","last_name":"Zafar","locality":"sss","postal_code":"46000"},"buyer_email_address":"zeeshan.zafar@seamlessideas.co.uk","card_details":{"auth_result_code":"T25388","avs_status":"AVS_REJECTED","card":{"bin":"519345","card_brand":"MASTERCARD","card_type":"CREDIT","exp_month":11,"exp_year":2026,"fingerprint":"sq-1-I1hngmrQQaTUMOz-pHOaOqkmtwYuDsfi7gSKvPi-GLXtMlyARbp9ZPUsHt4-EKtuWg","last_4":"0360","payment_account_reference":"0133012950010OSASC3WZABWEA90R1R6CNKVR","prepaid_type":"NOT_PREPAID"},"card_payment_timeline":{"authorized_at":"2024-07-11T13:24:45.076Z","captured_at":"2024-07-11T13:24:45.389Z"},"cvv_status":"CVV_NOT_CHECKED","entry_method":"KEYED","statement_description":"SQ *NIGHT AND DAY EMERGE","status":"CAPTURED"},"created_at":"2024-07-11T13:24:44.316Z","customer_id":"084NNCFDJFJFRD9Y882XD2TKNG","delay_action":"CANCEL","delay_duration":"PT168H","delayed_until":"2024-07-18T13:24:44.316Z","id":"NiuUA1XNHXrw6YeN1oaEh7PPMCBZY","location_id":"L5BDB5VAAHTNA","order_id":"c1jGtQIkRucaPT6L4szfeBJs097YY","processing_fee":[{"amount_money":{"amount":10,"currency":"GBP"},"effective_at":"2024-07-12T04:24:47.000Z","type":"INITIAL"}],"receipt_number":"NiuU","receipt_url":"https://squareup.com/receipt/preview/NiuUA1XNHXrw6YeN1oaEh7PPMCBZY","risk_evaluation":{"created_at":"2024-07-11T13:24:45.281Z","risk_level":"NORMAL"},"source_type":"CARD","status":"COMPLETED","tip_money":{"amount":0,"currency":"GBP"},"total_money":{"amount":10,"currency":"GBP"},"updated_at":"2024-07-11T13:24:47.869Z","version":4}}}}

```

## Square Refund Updated Webhook Response

```json
{
  "merchant_id": "MLXXJY48XF780",
  "type": "refund.updated",
  "event_id": "2422902b-dad3-32e1-8241-ace8f4ab81c1",
  "created_at": "2024-07-23T05:29:08.516Z",
  "data": {
    "type": "refund",
    "id": "1I7WWicV5g3xdDbvA6AXEGqA3tUZY_Cnr6d0QZI5cN8B61AWjGjOWcrJRNlkNb3WpvL0ScK7S",
    "object": {
      "refund": {
        "amount_money": { "amount": 3, "currency": "GBP" },
        "created_at": "2024-07-23T04:49:53.668Z",
        "destination_type": "CARD",
        "id": "1I7WWicV5g3xdDbvA6AXEGqA3tUZY_Cnr6d0QZI5cN8B61AWjGjOWcrJRNlkNb3WpvL0ScK7S",
        "location_id": "L5BDB5VAAHTNA",
        "order_id": "Sk58oWmUgEKMD3qDoOPh9RtSKLVZY",
        "payment_id": "1I7WWicV5g3xdDbvA6AXEGqA3tUZY",
        "processing_fee": [
          {
            "amount_money": { "amount": 0, "currency": "GBP" },
            "effective_at": "2024-07-23T04:51:18.000Z",
            "type": "INITIAL"
          }
        ],
        "status": "COMPLETED",
        "updated_at": "2024-07-23T05:29:03.084Z",
        "version": 28
      }
    }
  }
}
```
#testing branch roles