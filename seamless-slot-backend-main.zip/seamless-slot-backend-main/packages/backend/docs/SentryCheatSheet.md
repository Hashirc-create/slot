
# **Sentry Error Capture Cheat Sheet**

## **1. Basic Setup**
Before capturing errors, initialize Sentry in your application.

### Node.js / NestJS Example:
```typescript
import * as Sentry from '@sentry/node';

Sentry.init({
  dsn: 'your-sentry-dsn',
  tracesSampleRate: 1.0, // Adjust this for performance monitoring
  environment: 'production', // or 'staging', 'development'
});
```

---

## **2. Capturing Exceptions**

### Automatically Capture Unhandled Exceptions
- Sentry will automatically capture unhandled exceptions once initialized.
- For NestJS, integrate it with a global exception filter.

### Manually Capture Exceptions
```typescript
try {
  // Your code that might throw an error
  throw new Error('Something went wrong!');
} catch (error) {
  Sentry.captureException(error);
}
```

---

## **3. Capturing Custom Messages**

### Log a Message
```typescript
Sentry.captureMessage('A custom informational message', Sentry.Severity.Info);
```

### Set Severity Levels
```typescript
Sentry.captureMessage('Critical issue detected!', Sentry.Severity.Critical);
```

---

## **4. Adding Contextual Information**

### Tags
```typescript
Sentry.setTag('feature', 'user-authentication');
```

### User Context
```typescript
Sentry.setUser({
  id: '12345',
  email: 'user@example.com',
  username: 'test_user',
});
```

### Additional Context
```typescript
Sentry.setContext('Session', {
  sessionId: 'abc123',
  cartItems: 5,
});
```

---

## **5. Breadcrumbs**

### Add Breadcrumbs Manually
```typescript
Sentry.addBreadcrumb({
  category: 'auth',
  message: 'User login attempt',
  level: Sentry.Severity.Info,
});
```

---

## **6. Wrapping Functions for Error Handling**

### Wrap Code Blocks
```typescript
Sentry.withScope(scope => {
  scope.setTag('scope', 'example');
  Sentry.captureException(new Error('Scoped error'));
});
```

---

## **7. Capturing Performance Issues**

### Transaction Monitoring
```typescript
const transaction = Sentry.startTransaction({ name: 'User Login' });
try {
  // Code to monitor
} finally {
  transaction.finish();
}
```

### Attach Spans
```typescript
const span = transaction.startChild({ op: 'db.query', description: 'Fetching user data' });
// Perform the operation
span.finish();
```

---

## **8. Integration with Frameworks**

### NestJS Exception Filters
```typescript
import { ExceptionFilter, Catch, ArgumentsHost } from '@nestjs/common';
import * as Sentry from '@sentry/node';

@Catch()
export class SentryExceptionFilter implements ExceptionFilter {
  catch(exception: any, host: ArgumentsHost) {
    Sentry.captureException(exception);
    // Optionally rethrow or handle the exception
  }
}
```

### Express Middleware
```typescript
app.use(Sentry.Handlers.requestHandler());
app.use(Sentry.Handlers.errorHandler());
```

---

## **9. Handling Release Tracking**

### Set Release
```typescript
Sentry.setTag('release', '1.2.3');
```

### Mark Deployments
```typescript
Sentry.configureScope(scope => {
  scope.setExtra('deploymentId', 'deployment-xyz');
});
```

---

## **10. Sending Logs from External Sources**

### Log Warnings/Errors
```typescript
console.error = (...args) => {
  Sentry.captureMessage(`Console Error: ${args.join(' ')}`, Sentry.Severity.Error);
};
```

---

## **11. Debugging in Development**

### Adjust Sampling
```typescript
tracesSampleRate: process.env.NODE_ENV === 'production' ? 1.0 : 0.1,
```

---

## **12. Ignoring Specific Errors**

### Filter Out Errors
```typescript
Sentry.init({
  dsn: 'your-dsn',
  beforeSend(event) {
    // Ignore certain errors
    if (event.message && event.message.includes('Non-critical error')) {
      return null; // Discard the event
    }
    return event;
  },
});
```

---

This cheat sheet provides all the ways you can use Sentry to capture errors and debug your application efficiently.
