import { PrismaService } from '@seamlessslot/database';

const service = new PrismaService();

async function main() {
  console.log(new Date('2024-08-20T19:20:00Z').toString());
  const appointmentFound = await service.appointment.findFirst({
    where: {
      startTime: new Date(`2024-08-20T19:20:00Z`),
      endTime: new Date(`2024-08-20T19:50:00Z`),
    },
  });

  console.log(appointmentFound);
}

main();
