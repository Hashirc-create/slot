# Docker

- Connect to Database inside container
    - ```psql -h localhost -U admin -d seamless-slot```