import { Inject, Injectable } from '@nestjs/common';
import { RepositoryFactory } from '@seamlessslot/database';
import { GetAllSquareLocations } from '@seamlessslot/core';
import { SquareLocation } from '@seamlessslot/core';
import { ISquareApi, SquareApi } from '../../shared/square/square.api.service';

@Injectable()
export class GetAllSquareLocationsUseCaseImpl implements GetAllSquareLocations {
  constructor(
    private readonly repoFactory: RepositoryFactory,
    @Inject(ISquareApi)
    private readonly squareApiService: SquareApi,
  ) {}

  async execute(locationId: number): Promise<Readonly<SquareLocation[]>> {
    const paymentAccount =
      await this.repoFactory.paymentAccountRepository.findPaymentAccountByLocationAndType(
        'Square-Pay',
        locationId,
      );

    if (paymentAccount === null) return [];

    return await this.squareApiService.getAllSquareLocations(
      paymentAccount.accessToken,
    );
  }
}
