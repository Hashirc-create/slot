import { Inject, Injectable, Logger } from '@nestjs/common';
import { RepositoryFactory } from '@seamlessslot/database';
import {
  Business,
  ConfirmAppointmentOnPaymentUseCase,
  PaymentMethod,
} from '@seamlessslot/core';
import { Appointment } from '@seamlessslot/core';
import { Currency } from '@seamlessslot/core';
import { SquarePaymentTransaction } from '@seamlessslot/core';
import { SquarePaymentUpdatedWebhookResponse } from '@seamlessslot/core';
import {
  EmailGateway,
  IEmailGateway,
} from '../../shared/gateways/email/email.gateway';
import { getPaymentReceiptTemplate } from '../../shared/gateways/templates/paymentReceipt';
import { Customer } from '@seamlessslot/core';
import { TimeZoneService } from '../../shared/utils/timezone.util';
import { Service } from '@seamlessslot/core';
import { Location } from '@seamlessslot/core';
import { getAppointmentCreatedAdminEmailTemplate } from '../../shared/gateways/templates/publicAppointmentCreated';
import { ConfigService } from '@nestjs/config';

@Injectable()
export class ConfirmAppointmentOnPaymentUseCaseImpl
  implements ConfirmAppointmentOnPaymentUseCase
{
  private readonly logger: Logger = new Logger(
    'ConfirmAppointmentOnPaymentUseCaseImpl',
  );

  constructor(
    private readonly repoFactory: RepositoryFactory,
    @Inject(IEmailGateway)
    private readonly emailGateway: EmailGateway,
    private readonly timeZoneService: TimeZoneService,
    private readonly configService: ConfigService,
  ) {}

  async execute(
    payment: SquarePaymentUpdatedWebhookResponse,
  ): Promise<Readonly<string>> {
    const appointment: Appointment =
      await this.repoFactory.appointmentRepository.findAppointmetBySquareOrderIdNotConfirmed(
        payment.data.object.payment.order_id,
      );

    if (!appointment) {
      this.logger.warn(
        'done since no appointment exists against this square order id which is pending',
      );
      return 'done since no appointment exists against this square order id which is pending';
    }

    if (payment.data.object.payment.status === 'FAILED') {
      await this.repoFactory.paymentLogRepository.save({
        transactionId: payment.data.object.payment.id,
        orderId: payment.data.object.payment.order_id,
        status: 'Failed',
        paymentMethod: payment.data.object.payment.source_type as PaymentMethod, // TODO check later the types
        failedReason: payment.data.object.payment.failure_details.code,
        appointment: appointment.id,
        last4Digits: payment.data.object.payment.card_details.card.last_4,
        errorCode: payment.data.object.payment.failure_details.code,
        errorDetail: payment.data.object.payment.failure_details.detail,
        errorCategory: payment.data.object.payment.failure_details.reason,
        amount: payment.data.object.payment.amount_money.amount,
        currency: payment.data.object.payment.amount_money.currency,
        cardBrand: payment.data.object.payment.card_details.card.card_brand,
        cardExpMonth:
          payment.data.object.payment.card_details.card.exp_month.toString(),
        cardExpYear:
          payment.data.object.payment.card_details.card.exp_year.toString(),
        cardType: payment.data.object.payment.card_details.card.card_type,
        entryMethod: payment.data.object.payment.card_details.entry_method,
        cvvStatus: payment.data.object.payment.card_details.cvv_status,
        avsStatus: payment.data.object.payment.card_details.avs_status,
        fullPayload: payment,
        isActive: true,
        createdBy: 0,
        updatedBy: 0,
        deletedBy: 0,
      });

      return;
    }

    if (payment.data.object.payment.status === 'COMPLETED') {
      await this.repoFactory.paymentLogRepository.save({
        transactionId: payment.data.object.payment.id,
        orderId: payment.data.object.payment.order_id,
        status: 'Paid',
        paymentMethod: payment.data.object.payment.source_type as PaymentMethod, // TODO check later the types
        last4Digits: payment.data.object.payment.card_details.card.last_4,
        failedReason: 'none',
        errorCode: 'none',
        errorDetail: 'none',
        errorCategory: 'none',
        amount: payment.data.object.payment.amount_money.amount,
        currency: payment.data.object.payment.amount_money.currency,
        cardBrand: payment.data.object.payment.card_details.card.card_brand,
        cardExpMonth:
          payment.data.object.payment.card_details.card.exp_month.toString(),
        cardExpYear:
          payment.data.object.payment.card_details.card.exp_year.toString(),
        cardType: payment.data.object.payment.card_details.card.card_type,
        entryMethod: payment.data.object.payment.card_details.entry_method,
        cvvStatus: payment.data.object.payment.card_details.cvv_status,
        avsStatus: payment.data.object.payment.card_details.avs_status,
        fullPayload: payment,
        appointment: appointment.id,
        isActive: true,
        createdBy: 0,
        updatedBy: 0,
        deletedBy: 0,
      });
    }

    const business = await this.repoFactory.businessRepository.findById(
      (appointment.location as Location).business as number,
    );

    const paymentTrasnaction: SquarePaymentTransaction = {
      date: new Date().toISOString(),
      status: 'Paid',
      amount: Number(
        payment.data.object.payment.amount_money.amount,
      ).toString(),
      companyBalance: Number(
        payment.data.object.payment.amount_money.amount,
      ).toString(),
      currency: payment.data.object.payment.amount_money.currency as Currency,
      cardDetails: payment.data.object.payment.card_details.card.last_4,
      squareTransactionId: payment.data.object.payment.id,
      note: 'Charged For Seamless Slot Appointment',
      type: 'Credit Card',
      method: 'Card',
      appointment: appointment.id,
      business: business.id,

      merchantId: '',
      squareCreatedAt: payment.data.object.payment.created_at,
      squareType: payment.data.type,
      squareProduct:
        payment.data.object.payment.application_details.square_product,
      squareAddressLine1: '',
      squareAddressLine2: '',
      squareCountry: '',
      squareCustomerFirstName: '',
      squareCustomerLastNameName: '',
      squarePostalCode: '',
      squareLocality: '',
      squareBuyerEmailAddress: '',
      squareAuthResultCode:
        payment.data.object.payment.card_details.auth_result_code,
      squareAvsStatus: payment.data.object.payment.card_details.avs_status,
      squareBin: payment.data.object.payment.card_details.card.bin,
      squareCardBrand: payment.data.object.payment.card_details.card.card_brand,
      squareCardType: payment.data.object.payment.card_details.card.card_type,
      squareCardMonthExpiry: Number(
        payment.data.object.payment.card_details.card.exp_month,
      ),
      squareCardYearExpiry: Number(
        payment.data.object.payment.card_details.card.exp_year,
      ),
      squareFingerPrint:
        payment.data.object.payment.card_details.card.fingerprint,
      squareCardLast4: Number(
        payment.data.object.payment.card_details.card.last_4,
      ),
      squarePaymentAccountReference:
        payment.data.object.payment.card_details.card.payment_account_reference,
      squarePerpaidType:
        payment.data.object.payment.card_details.card.prepaid_type,
      squareReceiptURL: payment.data.object.payment.receipt_url,
      squareSourceType: payment.data.object.payment.source_type,
      squareStatus: payment.data.object.payment.status,
      squareUpdatedAt: payment.data.object.payment.updated_at,

      isActive: true,
      createdBy: 0,
      updatedBy: 0,
      deletedBy: 0,
      deletedAt: null,
    };

    await this.repoFactory.paymentTransactionRepository.save(
      paymentTrasnaction,
    );

    await this.repoFactory.appointmentRepository.updateAppointmentStatus(
      appointment.id,
      0,
      'Confirmed',
    );

    const customer = appointment.customer as Customer;
    const service = appointment.service as Service;
    const location = appointment.location as Location;

    await Promise.all([
      await this.sendConfirmationEmail(
        business,
        customer,
        appointment,
        service,
        payment,
      ),
      // await this.sendConfirmationSms(business, location, customer, appointment),
    ]);

    const admins =
      await this.repoFactory.userRepository.findAllAdminsByLocation(
        location.id,
      );

    for (const admin of admins) {
      await this.sendAdminEmail(
        admin.email,
        business,
        location,
        customer,
        appointment,
        service,
      );
    }

    if (this.configService.get('NODE_ENV') === 'production') {
      await Promise.all([
        this.sendAdminEmail(
          `rizwan.malik@seamlessideas.co.uk`,
          business,
          location,
          customer,
          appointment,
          service,
        ),
        this.sendAdminEmail(
          `tosif.khan@seamlessideas.co.uk`,
          business,
          location,
          customer,
          appointment,
          service,
        ),
      ]);
    }

    return 'done with success';
  }

  // async sendConfirmationSms(
  //   business: Business,
  //   location: Location,
  //   customer: Customer,
  //   savedAppointment: Appointment,
  // ) {
  //   return this.smsService.sendSms(
  //     customer.phoneNo,
  //     '+447462428776',
  //     `Hi ${customer.firstName + ' ' + customer.lastName}, thanks for booking with us at ${business.name} (${location.name}) ${location.address}. Your appointment is confirmed for ${this.timeZoneService.formatDatePreservingUTC(
  //       savedAppointment.startTime as Date,
  //       'EEEE dd MMM yyyy',
  //     )} at ${this.timeZoneService.formatDatePreservingUTC(
  //       savedAppointment.startTime as Date,
  //       'hh:mm a',
  //     )}. See you then! Any questions? Call us at ${(savedAppointment.location as Location).telephone}.`,
  //   );
  // }

  sendConfirmationEmail(
    business: Business,
    customer: Customer,
    appointment: Appointment,
    service: Service,
    payment: SquarePaymentUpdatedWebhookResponse,
  ) {
    return this.emailGateway.sendEmailFromInfo({
      title: business.name,
      to: customer.email,
      subject: 'Payment Receipt',
      html: getPaymentReceiptTemplate({
        businessName: business.name,
        discount: '0',
        payerName: customer.firstName + ' ' + customer.lastName,
        paymentDate: '',
        paymentMethod: 'Card',
        serviceAmount: service.cost.toString(),
        subTotal: service.cost.toString(),
        total: (
          Number(payment.data.object.payment.amount_money.amount) / 100
        ).toString(),
        serviceTitle: service.title,
        transactionId: payment.data.object.payment.id,
      }),
    });
  }

  async sendAdminEmail(
    to: string,
    business: Business,
    location: Location,
    customer: Customer,
    savedAppointment: Appointment,
    service: Service,
  ) {
    return this.emailGateway.sendEmailFromInfo({
      title: business.name,
      to,
      subject: 'Seamless Slot (Appointment Booked)',
      html: getAppointmentCreatedAdminEmailTemplate({
        businessName: business.name,
        location: location.name,
        bookingId: savedAppointment.id.toString(),
        service: service.title,
        duration: service.durationInMinutes.toString(),
        cost: service.cost.toString(),
        dateTimeOfAppointment:
          this.timeZoneService.formatDatePreservingUTC(
            savedAppointment.startTime as Date,
            'EEEE dd MMM yyyy hh:mm a',
          ) +
          '-' +
          this.timeZoneService.formatDatePreservingUTC(
            savedAppointment.endTime as Date,
            'hh:mm a',
          ),
        customerName: customer.firstName + ' ' + customer.lastName,
        customerEmail: customer.email,
        customerPhone: customer.phoneNo,
        amountCharged: service.cost.toString(),
      }),
    });
  }
}
