import { IConfirmAppointmentOnPaymentUseCase } from '@seamlessslot/core';
import { IGetAllSquareLocations } from '@seamlessslot/core';
import { ConfirmAppointmentOnPaymentUseCaseImpl } from './confirm.appointment.on.payment.usecase.impl';
import { GetAllSquareLocationsUseCaseImpl } from './get.all.square.locations.usecase.impl';

export const SQUARE_USECASES = [
  {
    provide: IGetAllSquareLocations,
    useClass: GetAllSquareLocationsUseCaseImpl,
  },
  {
    provide: IConfirmAppointmentOnPaymentUseCase,
    useClass: ConfirmAppointmentOnPaymentUseCaseImpl,
  },
];
