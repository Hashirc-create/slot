import { Global, Module } from '@nestjs/common';
import { UseCaseFactory } from './usecase.factory';

import { IRefreshTokenUseCase } from '@seamlessslot/core';
import { LOCATION_USECASES } from './location';
import { RefreshTokenUseCaseImpl } from './refresh.token.usecase.impl';
import { SERVICE_USECASES } from './service';
import { TIMEOFF_USECASES } from './time-offs';
import { USER_USECASES } from './user';
import { WORKING_DAYS_USECASES } from './working-day';
import { BREAK_USECASES } from './break';
import { PAYMENT_ACCOUNT_USECASES } from './payment-account';
import { APPOINTMENT_USECASES } from './appointment';
import { CUSTOMER_USECASES } from './customer';
import { SQUARE_USECASES } from './square';
import { BOOKING_BRAND_DETAIL_USECASES } from './booking-brand-detail';
import { PAYMENT_TRANSACTION_USECASES } from './payment-transaction';
import { BOOKING_POLICY_USECASES } from './booking-policy';
import { REFUNDS_USECASES } from './refunds';
import { NOTIFICATION_USECASES } from './notifications';
import { GOOGLE_ANALYTICS_USECASES } from './google-analytics';
import { GOOGLE_TAG_MANAGER_USECASES } from './google-tag-manager';
import { BUSINESS_USECASES } from './business';
import { PAYMENT_LOG_USECASES } from './payment-log';
import { PAYMENT_LINK_SHORTENER_USECASES } from './payment-link-shortner';
import { DASHBOARD_USECASES } from './dashboard';
import { WORKING_DAYS_HISTORY_USECASES } from './working-day-history';

const USE_CASES = [
  {
    provide: IRefreshTokenUseCase,
    useClass: RefreshTokenUseCaseImpl,
  },
  ...LOCATION_USECASES,
  ...BUSINESS_USECASES,
  ...SERVICE_USECASES,
  ...USER_USECASES,
  ...WORKING_DAYS_USECASES,
  ...TIMEOFF_USECASES,
  ...BREAK_USECASES,
  ...PAYMENT_ACCOUNT_USECASES,
  ...APPOINTMENT_USECASES,
  ...CUSTOMER_USECASES,
  ...SQUARE_USECASES,
  ...BOOKING_BRAND_DETAIL_USECASES,
  ...PAYMENT_TRANSACTION_USECASES,
  ...BOOKING_POLICY_USECASES,
  ...REFUNDS_USECASES,
  ...NOTIFICATION_USECASES,
  ...GOOGLE_ANALYTICS_USECASES,
  ...GOOGLE_TAG_MANAGER_USECASES,
  ...PAYMENT_LOG_USECASES,
  ...PAYMENT_LINK_SHORTENER_USECASES,
  ...DASHBOARD_USECASES,
  ...WORKING_DAYS_HISTORY_USECASES,
];

@Global()
@Module({
  providers: [...USE_CASES, UseCaseFactory],
  exports: [UseCaseFactory],
})
export class UseCaseModule {}
