import { Injectable } from '@nestjs/common';
import {
  Break,
  GetAllBreaksByLocationUseCaseForHistory,
} from '@seamlessslot/core';
import { RepositoryFactory } from '@seamlessslot/database';

@Injectable()
export class GetAllByLocationForHistoryImpl
  implements GetAllBreaksByLocationUseCaseForHistory
{
  constructor(private readonly repoFactory: RepositoryFactory) {}

  async execute(locationId: number): Promise<Readonly<Break[]>> {
    return await this.repoFactory.breakRepository.findAllByLocationIncludingNonActive(
      locationId,
    );
  }
}
