import { Injectable } from '@nestjs/common';
import { Break } from '@seamlessslot/core';
import { RepositoryFactory } from '@seamlessslot/database';
import { UpdateBreakUseCase } from '@seamlessslot/core';

@Injectable()
export class UpdateBreakUseCaseImpl implements UpdateBreakUseCase {
  constructor(private readonly repoFactory: RepositoryFactory) {}
  async execute(breaks: Break[]): Promise<Readonly<string>> {
    console.log(breaks);
    const updatedPromises = breaks.map((breakItem) => {
      this.repoFactory.breakRepository.update(breakItem.id, breakItem);
    });

    await Promise.all(updatedPromises);

    return 'success';
  }
}
