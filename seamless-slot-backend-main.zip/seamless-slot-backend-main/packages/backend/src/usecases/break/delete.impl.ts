import { Injectable } from '@nestjs/common';
import { Break, DeleteBreakUseCase } from '@seamlessslot/core';
import { RepositoryFactory } from '@seamlessslot/database';
import { SecurityContext } from '../../shared/auth/context/security.context';

@Injectable()
export class DeleteBreakUseCaseImpl implements DeleteBreakUseCase {
  constructor(
    private readonly repoFactory: RepositoryFactory,
    private readonly securityContext: SecurityContext,
  ) {}

  execute(id: number): Promise<Readonly<Break>> {
    return this.repoFactory.breakRepository.delete(
      id,
      this.securityContext.getId(),
    );
  }
}
