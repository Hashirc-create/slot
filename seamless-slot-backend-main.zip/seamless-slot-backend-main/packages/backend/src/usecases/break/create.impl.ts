import { Injectable } from '@nestjs/common';
import { Break, CreateBreakUseCase } from '@seamlessslot/core';
import { RepositoryFactory } from '@seamlessslot/database';

@Injectable()
export class CreateBreakUseCaseImpl implements CreateBreakUseCase {
  constructor(private readonly repoFactory: RepositoryFactory) {}
  execute(workDayBreak: Break): Promise<Readonly<Break>> {
    return this.repoFactory.breakRepository.save(workDayBreak);
  }
}
