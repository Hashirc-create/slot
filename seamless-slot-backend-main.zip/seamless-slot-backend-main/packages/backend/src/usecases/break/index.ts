import {
  ICreateBreakUseCase,
  IGetAllBreaksByLocation,
  IGetAllBreaksByLocationUseCaseForHistory,
} from '@seamlessslot/core';
import { IDeleteBreakUseCase } from '@seamlessslot/core';
import { IUpdateBreakUseCase } from '@seamlessslot/core';
import { CreateBreakUseCaseImpl } from './create.impl';
import { DeleteBreakUseCaseImpl } from './delete.impl';
import { UpdateBreakUseCaseImpl } from './update.impl';
import { GetAllBreaksByLocationImpl } from './get.all.breaks.by.location.impl';
import { GetAllByLocationForHistoryImpl } from './get.all.by.location.for.history.impl';

export const BREAK_USECASES = [
  {
    provide: ICreateBreakUseCase,
    useClass: CreateBreakUseCaseImpl,
  },
  {
    provide: IDeleteBreakUseCase,
    useClass: DeleteBreakUseCaseImpl,
  },
  {
    provide: IUpdateBreakUseCase,
    useClass: UpdateBreakUseCaseImpl,
  },
  {
    provide: IGetAllBreaksByLocation,
    useClass: GetAllBreaksByLocationImpl,
  },
  {
    provide: IGetAllBreaksByLocationUseCaseForHistory,
    useClass: GetAllByLocationForHistoryImpl,
  },
];
