import { Injectable } from '@nestjs/common';
import {
  BreakEvent,
  GetAllBreaksByLocation,
  WorkingDay,
} from '@seamlessslot/core';
import { RepositoryFactory } from '@seamlessslot/database';
import {
  format,
  getDay,
  startOfYear,
  endOfYear,
  eachDayOfInterval,
} from 'date-fns';
import { randomUUID } from 'crypto';
import { TimeZoneService } from '../../shared/utils/timezone.util';

@Injectable()
export class GetAllBreaksByLocationImpl implements GetAllBreaksByLocation {
  constructor(
    private readonly repoFactory: RepositoryFactory,
    private readonly timeZoneService: TimeZoneService,
  ) {}

  async execute(
    locationId: number,
    year: number,
  ): Promise<Readonly<BreakEvent[]>> {
    const breaks =
      await this.repoFactory.breakRepository.findAllByLocation(locationId);

    if (breaks.length === 0) {
      return [];
    }

    return breaks.flatMap((singleBreak) => {
      const weekday = (singleBreak.workingDay as WorkingDay).day;
      const allDatesForWeekday = this.findDatesForWeekDay(year, weekday);
      const breakStatTime = this.timeZoneService.formatDatePreservingUTC(
        singleBreak.startTime as Date,
        'HH:mm:ss',
      );

      const breakEndTime = this.timeZoneService.formatDatePreservingUTC(
        singleBreak.endTime as Date,
        'HH:mm:ss',
      );

      const breakStartTimeShow = this.timeZoneService.formatDatePreservingUTC(
        singleBreak.startTime as Date,
        'hh:mm aa',
      );

      const breakEndTimeShow = this.timeZoneService.formatDatePreservingUTC(
        singleBreak.endTime as Date,
        'hh:mm aa',
      );

      return allDatesForWeekday.map((date) => ({
        id: `singleBreak.id.toString()_${randomUUID()}`,
        title: 'Break',
        start: `${date}T${breakStatTime}`,
        end: `${date}T${breakEndTime}`,
        display: 'foreground',
        classNames: ['break-event'],
        editable: false,
        interactive: false,
        extendedProps: {
          customerName: 'Break',
          startTime: breakStartTimeShow,
          endTime: breakEndTimeShow,
        },
      }));
    });
  }

  // private findDatesForWeekDay(year: number, weekday: string): string[] {
  //   const dates: string[] = [];
  //   const getWeekDayNumber = () => {
  //     if (weekday === 'Monday') return 1;
  //     if (weekday === 'Tuesday') return 2;
  //     if (weekday === 'Wednesday') return 3;
  //     if (weekday === 'Thursday') return 4;
  //     if (weekday === 'Friday') return 5;
  //     if (weekday === 'Saturday') return 6;
  //     if (weekday === 'Sunday') return 0;
  //
  //     return 100;
  //   }; // +1 is important
  //
  //   console.log(weekday, getWeekDayNumber());
  //
  //   const currentDate = new Date(year, 0, 1);
  //
  //   while (currentDate.getFullYear() === year) {
  //     console.log(currentDate.getDay());
  //     if (currentDate.getDay() === getWeekDayNumber()) {
  //       dates.push(currentDate.toISOString().split('T')[0]);
  //     }
  //     currentDate.setDate(currentDate.getDate() + 1);
  //   }
  //
  //   return dates;
  // }
  private findDatesForWeekDay(year: number, weekday: string): string[] {
    const dates: string[] = [];

    const getWeekDayNumber = () => {
      const weekdays = [
        'Sunday',
        'Monday',
        'Tuesday',
        'Wednesday',
        'Thursday',
        'Friday',
        'Saturday',
      ];
      return weekdays.indexOf(weekday); // Map weekday name to its index
    };

    const weekDayNumber = getWeekDayNumber();
    if (weekDayNumber === -1) {
      throw new Error('Invalid weekday name');
    }

    // Get the start and end dates for the year
    const startDate = startOfYear(new Date(year, 0, 1)); // First day of the year
    const endDate = endOfYear(new Date(year, 0, 1)); // Last day of the year

    // Iterate through each day of the year
    eachDayOfInterval({
      start: startDate,
      end: endDate,
    }).forEach((date) => {
      if (getDay(date) === weekDayNumber) {
        dates.push(format(date, 'yyyy-MM-dd')); // Format date as ISO string
      }
    });

    return dates;
  }
}
