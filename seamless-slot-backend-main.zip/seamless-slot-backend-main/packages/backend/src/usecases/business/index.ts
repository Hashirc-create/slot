import {
  IAddBusinessUseCase,
  IDeleteBusinessUseCase,
  IGetAllBusinessUseCase,
  IGetAllBusinessWithLocationUseCase,
  IGetBusinessByIdUseCase,
  IGetBusinessWithLocationBySubdomainUseCase,
  IUpdateBusinessUseCase,
} from '@seamlessslot/core';
import { GetAllBusinessUseCaseImpl } from './get.all.business.usecase.impl';
import { GetAllBusinessWithLocationUseCaseImpl } from './get.all.business.with.location.usecase.impl';
import { AddBusinessUseCaseImpl } from './add.business.usecase.impl';
import { GetBusinessWithLocationBySubdomainUseCaseImpl } from './get.business.with.location.by.subdomain.usecase.impl';
import { GetBusinessByIdUseCaseImpl } from './get.business.by.id.usecase';
import { DeleteBusinessUseCaseImpl } from './delete.business.usecase.impl';
import { UpdateBusinessUseCaseImpl } from './update.business.usecase.impl';

export const BUSINESS_USECASES = [
  {
    provide: IGetAllBusinessUseCase,
    useClass: GetAllBusinessUseCaseImpl,
  },
  {
    provide: IUpdateBusinessUseCase,
    useClass: UpdateBusinessUseCaseImpl,
  },
  {
    provide: IGetBusinessByIdUseCase,
    useClass: GetBusinessByIdUseCaseImpl,
  },
  {
    provide: IAddBusinessUseCase,
    useClass: AddBusinessUseCaseImpl,
  },
  {
    provide: IDeleteBusinessUseCase,
    useClass: DeleteBusinessUseCaseImpl,
  },
  {
    provide: IGetAllBusinessWithLocationUseCase,
    useClass: GetAllBusinessWithLocationUseCaseImpl,
  },
  {
    provide: IGetBusinessWithLocationBySubdomainUseCase,
    useClass: GetBusinessWithLocationBySubdomainUseCaseImpl,
  },
];
