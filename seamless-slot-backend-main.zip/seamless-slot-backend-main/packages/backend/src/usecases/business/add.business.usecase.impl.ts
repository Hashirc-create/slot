import { HttpException, HttpStatus, Inject, Injectable } from '@nestjs/common';
import { AddBusinessUseCase, Business } from '@seamlessslot/core';
import { RepositoryFactory } from '@seamlessslot/database';
import { AwsService, IAwsService } from '../../shared/aws/aws.service';
import { ConfigService } from '@nestjs/config';
import { BaseResponse } from '../../shared/interceptor/response.interceptor';

@Injectable()
export class AddBusinessUseCaseImpl implements AddBusinessUseCase {
  constructor(
    private readonly repoFactory: RepositoryFactory,
    @Inject(IAwsService)
    private readonly awsService: AwsService,
    private readonly configService: ConfigService,
  ) {}

  async execute(business: Business): Promise<Business> {
    const businessFoundBySubdomain =
      await this.repoFactory.businessRepository.findBySubdomain(
        business.subdomain,
      );

    const businessFoundByEmail =
      await this.repoFactory.businessRepository.findByEmail(business.email);

    if (businessFoundByEmail)
      throw new HttpException(
        {
          code: 0,
          message: 'Business with the associated email already exists',
        } as BaseResponse<string>,
        HttpStatus.BAD_REQUEST,
      );

    if (businessFoundBySubdomain)
      throw new HttpException(
        {
          code: 0,
          message: 'Provided booking page url not is not available',
        } as BaseResponse<string>,
        HttpStatus.BAD_REQUEST,
      );

    if (this.configService.get('NODE_ENV') !== 'development')
      await this.awsService.createSubdomain(
        this.configService.get('PARENT_DOMAIN'),
        business.subdomain,
        this.configService.get('TARGET_IP_ADDRESS'),
      );

    return await this.repoFactory.businessRepository.save(business);
  }
}
