import { Injectable } from '@nestjs/common';
import { GetAllBusinessUseCase } from '@seamlessslot/core';
import { RepositoryFactory } from '@seamlessslot/database';
import { Business } from '@seamlessslot/core';

@Injectable()
export class GetAllBusinessUseCaseImpl implements GetAllBusinessUseCase {
  constructor(private readonly repoFactory: RepositoryFactory) {}

  async execute(): Promise<Business[]> {
    return this.repoFactory.businessRepository.findAll();
  }
}
