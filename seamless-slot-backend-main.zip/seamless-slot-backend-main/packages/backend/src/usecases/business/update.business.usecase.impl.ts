import { Injectable } from '@nestjs/common';
import { Business, UpdateBusinessUseCase } from '@seamlessslot/core';
import { RepositoryFactory } from '@seamlessslot/database';

@Injectable()
export class UpdateBusinessUseCaseImpl implements UpdateBusinessUseCase {
  constructor(private readonly repoFactory: RepositoryFactory) {}

  async execute(business: Business): Promise<Business> {
    return await this.repoFactory.businessRepository.update(
      business.id,
      business,
    );
  }
}
