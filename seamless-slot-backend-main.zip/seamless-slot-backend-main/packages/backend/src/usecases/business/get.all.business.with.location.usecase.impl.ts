import { Injectable } from '@nestjs/common';
import { GetAllBusinessWithLocationUseCase } from '@seamlessslot/core';
import { RepositoryFactory } from '@seamlessslot/database';
import { Business } from '@seamlessslot/core';
import { SecurityContext } from '../../shared/auth/context/security.context';

@Injectable()
export class GetAllBusinessWithLocationUseCaseImpl
  implements GetAllBusinessWithLocationUseCase
{
  constructor(
    private readonly repoFactory: RepositoryFactory,
    private readonly securityContext: SecurityContext,
  ) {}

  async execute(): Promise<Readonly<Business[]>> {
    if (this.securityContext.getRole() === 'Super Admin')
      return this.repoFactory.businessRepository.findAllIncludingLocations();

    const user = await this.repoFactory.userRepository.findById(
      this.securityContext.getId(),
    );

    const business = await this.repoFactory.businessRepository.findById(
      (user.business as Business).id,
    );

    return [business];
  }
}
