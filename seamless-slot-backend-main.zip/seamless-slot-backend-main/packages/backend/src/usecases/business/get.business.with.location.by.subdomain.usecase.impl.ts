import { Injectable } from '@nestjs/common';
import { GetBusinessWithLocationBySubdomainUseCase } from '@seamlessslot/core';
import { RepositoryFactory } from '@seamlessslot/database';
import { Business } from '@seamlessslot/core';

@Injectable()
export class GetBusinessWithLocationBySubdomainUseCaseImpl
  implements GetBusinessWithLocationBySubdomainUseCase
{
  constructor(private readonly repoFactory: RepositoryFactory) {}

  async execute(subdomain: string): Promise<Readonly<Business>> {
    return await this.repoFactory.businessRepository.findBySubdomain(subdomain);
  }
}
