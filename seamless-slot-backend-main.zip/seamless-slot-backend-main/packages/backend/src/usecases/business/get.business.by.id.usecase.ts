import { Injectable } from '@nestjs/common';
import { Business, GetBusinessByIdUseCase } from '@seamlessslot/core';
import { RepositoryFactory } from '@seamlessslot/database';

@Injectable()
export class GetBusinessByIdUseCaseImpl implements GetBusinessByIdUseCase {
  constructor(private readonly repoFactory: RepositoryFactory) {}

  async execute(id: number): Promise<Business> {
    return await this.repoFactory.businessRepository.findById(id);
  }
}
