import { Injectable } from '@nestjs/common';
import { Business, DeleteBusinessUseCase } from '@seamlessslot/core';
import { RepositoryFactory } from '@seamlessslot/database';
import { SecurityContext } from '../../shared/auth/context/security.context';

@Injectable()
export class DeleteBusinessUseCaseImpl implements DeleteBusinessUseCase {
  constructor(
    private readonly repoFactory: RepositoryFactory,
    private readonly securityContext: SecurityContext,
  ) {}

  async execute(businessId: number): Promise<Business> {
    return await this.repoFactory.businessRepository.delete(
      businessId,
      this.securityContext.getId(),
    );
  }
}
