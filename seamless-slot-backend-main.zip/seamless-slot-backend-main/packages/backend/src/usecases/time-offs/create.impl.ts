import { Injectable } from '@nestjs/common';
import { TimeOff } from '@seamlessslot/core';
import { CreateTimeOffUseCase } from '@seamlessslot/core';
import { RepositoryFactory } from '@seamlessslot/database';

@Injectable()
export class CreateTimeOffUseCaseImpl implements CreateTimeOffUseCase {
  constructor(private readonly repoFactory: RepositoryFactory) {}
  execute(timeOff: TimeOff): Promise<Readonly<TimeOff>> {
    const saved = this.repoFactory.timeOffRepository.save(timeOff);
    return saved;
  }
}
