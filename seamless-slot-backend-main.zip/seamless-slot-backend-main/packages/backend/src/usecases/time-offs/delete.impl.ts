import { Injectable } from '@nestjs/common';
import { DeleteTimeOffUseCase, TimeOff } from '@seamlessslot/core';
import { RepositoryFactory } from '@seamlessslot/database';
import { SecurityContext } from '../../shared/auth/context/security.context';

@Injectable()
export class DeleteTimeOffUseCaseImpl implements DeleteTimeOffUseCase {
  constructor(
    private readonly repoFactory: RepositoryFactory,
    private readonly securityContext: SecurityContext,
  ) {}

  execute(id: number): Promise<Readonly<TimeOff>> {
    return this.repoFactory.timeOffRepository.delete(
      id,
      this.securityContext.getId(),
    );
  }
}
