import {
  ICreateTimeOffUseCase,
  IGetAllTimeOffsByLocationForCalendarUseCase,
} from '@seamlessslot/core';
import { IDeleteTimeOffUseCase } from '@seamlessslot/core';
import { IGetAllTimeOffsByLocationWithPaginationUseCase } from '@seamlessslot/core';
import { IUpdateTimeOffUseCase } from '@seamlessslot/core';
import { CreateTimeOffUseCaseImpl } from './create.impl';
import { DeleteTimeOffUseCaseImpl } from './delete.impl';
import { GetAllTimeOffsByLocationWithPaginationUseCaseImpl } from './get.all.by.location.impl';
import { UpdateTimeoffUseCaseImpl } from './update.impl';
import { GetAllTimeOffsByLocationForCalendarImpl } from './get.all.by.location.for.calendar.impl';

export const TIMEOFF_USECASES = [
  {
    provide: IGetAllTimeOffsByLocationWithPaginationUseCase,
    useClass: GetAllTimeOffsByLocationWithPaginationUseCaseImpl,
  },
  {
    provide: ICreateTimeOffUseCase,
    useClass: CreateTimeOffUseCaseImpl,
  },
  {
    provide: IDeleteTimeOffUseCase,
    useClass: DeleteTimeOffUseCaseImpl,
  },
  {
    provide: IUpdateTimeOffUseCase,
    useClass: UpdateTimeoffUseCaseImpl,
  },
  {
    provide: IGetAllTimeOffsByLocationForCalendarUseCase,
    useClass: GetAllTimeOffsByLocationForCalendarImpl,
  },
];
