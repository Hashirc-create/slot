import { Injectable } from '@nestjs/common';
import {
  GetAllTimeOffsByLocationForCalendarUseCase,
  TimeOffEvent,
} from '@seamlessslot/core';
import { RepositoryFactory } from '@seamlessslot/database';
import { TimeZoneService } from '../../shared/utils/timezone.util';

@Injectable()
export class GetAllTimeOffsByLocationForCalendarImpl
  implements GetAllTimeOffsByLocationForCalendarUseCase
{
  constructor(
    private readonly repoFactory: RepositoryFactory,
    private readonly timeZoneService: TimeZoneService,
  ) {}

  async execute(locationId?: number): Promise<Readonly<TimeOffEvent[]>> {
    const timeoffs =
      await this.repoFactory.timeOffRepository.findAllByLocation(locationId);

    return timeoffs.map((timeoff) => {
      const starDateTime = this.timeZoneService.formatDatePreservingUTC(
        timeoff.startDateTime as Date,
        `yyyy-MM-dd'T'hh:mm:ss`,
      );

      const endDateTime = this.timeZoneService.formatDatePreservingUTC(
        timeoff.endDateTime as Date,
        `yyyy-MM-dd'T'hh:mm:ss`,
      );

      const startTimeOnly = this.timeZoneService.formatDatePreservingUTC(
        timeoff.startDateTime as Date,
        `hh:mm aa`,
      );

      const endTimeOnly = this.timeZoneService.formatDatePreservingUTC(
        timeoff.endDateTime as Date,
        `hh:mm aa`,
      );

      return {
        id: timeoff.id.toString(),
        title: timeoff.title,
        allDay: timeoff.allDay,
        start: starDateTime,
        end: endDateTime,
        display: 'foreground',
        classNames: ['break-event'],
        editable: false,
        interactive: false,
        extendedProps: {
          customerName: timeoff.title,
          startTime: timeoff.allDay ? 'All Day' : startTimeOnly,
          endTime: endTimeOnly,
        },
      };
    });
  }
}
