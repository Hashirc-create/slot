import { Injectable } from '@nestjs/common';
import { TimeOff } from '@seamlessslot/core';
import { UpdateTimeOffUseCase } from '@seamlessslot/core';
import { RepositoryFactory } from '@seamlessslot/database';

@Injectable()
export class UpdateTimeoffUseCaseImpl implements UpdateTimeOffUseCase {
  constructor(private readonly repoFactory: RepositoryFactory) {}
  execute(id: number, timeOff: TimeOff): Promise<Readonly<TimeOff>> {
    const updated = this.repoFactory.timeOffRepository.update(id, timeOff);
    return updated;
  }
}
