import { Injectable } from '@nestjs/common';
import { TimeOff } from '@seamlessslot/core';
import { SecurityContext } from '../../shared/auth/context/security.context';
import { RepositoryFactory } from '@seamlessslot/database';
import { GetAllTimeOffsByLocationWithPaginationUseCase } from '@seamlessslot/core';

@Injectable()
export class GetAllTimeOffsByLocationWithPaginationUseCaseImpl
  implements GetAllTimeOffsByLocationWithPaginationUseCase
{
  constructor(
    private readonly repoFactory: RepositoryFactory,
    private readonly securityContext: SecurityContext,
  ) {}

  execute(locationId?: number): Promise<Readonly<TimeOff[]>> {
    const updated = this.repoFactory.timeOffRepository.findAllByLocation(
      locationId || this.securityContext.getLocationId(),
    );
    return updated;
  }
}
