import { Inject, Injectable } from '@nestjs/common';
import {
  IBindSquareLocationIdUseCase,
  IBlockUserUseCase,
  IChangeAppointmentDataTimeUseCase,
  IChangeAppointmentStatusUseCase,
  IChangeLocationCancellationPolicy,
  IChangeLocationScheduleWindowUseCase,
  ICheckPaymentAccountExists,
  IConfirmAppointmentOnPaymentUseCase,
  ICreateAppointmentUseCase,
  ICreateBreakUseCase,
  ICreateDojoPaymentAccountUseCase,
  ICreateGoogleAnalyticsUseCase,
  ICreateGoogleTagManagerUseCase,
  ICreatePublicAppointmentWithoutPaymentUseCase,
  ICreateServiceUseCase,
  ICreateSquarePaymentAccountUseCase,
  ICreateTimeOffUseCase,
  IDeleteAppointmentUseCase,
  IDeleteBreakUseCase,
  IDeleteCustomerUseCase,
  IDeletePaymentAccountUseCase,
  IDeleteServiceUseCase,
  IDeleteSquarePaymentAccountUseCase,
  IDeleteTimeOffUseCase,
  IEditGoogleAnalyticsUseCase,
  IEditGoogleTagManagerUseCase,
  IFindGoogleAnalyticsByLocationUseCase,
  IFindGoogleTagManagerByLocationUseCase,
  IGetAllAdminsByLocationUseCase,
  IGetAllAppointmentByMonthUseCase,
  IGetAllAppointmentsByLocationUseCase,
  IGetAllAppointmentsByLocationWithPaginationUseCase,
  IGetAllCustomerByLocationUseCase,
  IGetAllCustomerByLocationWithPaginationUseCase,
  IGetAllLiveServiceByLocationUseCase,
  IGetAllLocationUseCase,
  IGetAllLocationWithPaginationUseCase,
  IGetAllNotificationByLocationUseCase,
  IGetAllPaymentTransactionsByLocationWithPagination,
  IGetAllServicesByLocation,
  IGetAllServiceUseCase,
  IGetAllSquareLocations,
  IGetAllSquarePaymentTransactionsByLocationUseCase,
  IGetAllSquareRefundsBySquarePaymentTransaction,
  IGetAllTimeOffsByLocationWithPaginationUseCase,
  IGetAllUsersUseCase,
  IGetAllWorkDaysByLocationUseCase,
  IGetAllWorkingDaysByLocationIncludeBreaks,
  IGetAppointmentSummaryByBookingIdUseCase,
  IGetAvaliableDatesUseCase,
  IGetAvaliableTimeSlotsUseCase,
  IGetBookingBrandDetailsByLocationUseCase,
  IGetBookingPoliciesByLocationUseCase,
  IGetByIdAppointmentUseCase,
  IGetByIdLocationUseCase,
  IGetByIdPaymentAccountUseCase,
  IGetCancellationPolicyUseCase,
  IGetCustomerByIdUseCase,
  IGetServiceByIdUseCase,
  IGetUserByIdUseCase,
  IHardDeleteUserUseCase,
  IIsSquareConnectedUseCase,
  IIssueSquareRefundUseCase,
  ILoginUserUseCase,
  IMarkNotificationsReadUseCase,
  IRefreshTokenUseCase,
  IRegisterAdminUseCase,
  IRegisterBookingBrandDetailUseCase,
  IRegisterBookingPolicyUseCase,
  IRegisterCustomerUseCase,
  IRegisterLocationUseCase,
  IRegisterWorkingDayUseCase,
  ISearchAppointmentsWithPaginationUseCase,
  ISearchCustomerWithPaginationUseCase,
  ITakePaymentPublicAppointmentUseCase,
  IUpdateAppointmentUseCase,
  IUpdateBookingBrandDetailsUseCase,
  IUpdateBookingPoliciesUseCase,
  IUpdateBreakUseCase,
  IUpdateCustomerUseCase,
  IUpdateLocationUseCase,
  IUpdatePaymentAccountUseCase,
  IUpdateRefundStatusUseCase,
  IUpdateServiceUseCase,
  IUpdateTimeOffUseCase,
  IUpdateUserProfileUseCase,
  IUpdateUserUseCase,
  IUpdateWorkingDaysUseCase,
  IIsGoogleTagMangerConnectedUseCase,
  IGetAllBusinessUseCase,
  IGetAllBusinessWithLocationUseCase,
  IAddBusinessUseCase,
  IDeleteLocationUseCase,
  BindSquareLocationIdUseCase,
  BlockUserUseCase,
  ChangeAppointmentDataTimeUseCase,
  ChangeAppointmentStatusUseCase,
  ChangeLocationCancellationPolicy,
  ChangeLocationScheduleWindowUseCase,
  CheckPaymentAccountExists,
  ConfirmAppointmentOnPaymentUseCase,
  CreateAppointmentUseCase,
  CreateBreakUseCase,
  CreateDojoPaymentAccountUseCase,
  CreateGoogleAnalyticsUseCase,
  CreateGoogleTagManagerUseCase,
  CreatePublicAppointmentWithoutPaymentUseCase,
  CreateServiceUseCase,
  CreateSquarePaymentAccountUseCase,
  CreateTimeOffUseCase,
  DeleteAppointmentUseCase,
  DeleteBreakUseCase,
  DeleteCustomerUseCase,
  DeletePaymentAccountUseCase,
  DeleteServiceUseCase,
  DeleteSquarePaymentAccountUseCase,
  DeleteTimeOffUseCase,
  EditGoogleAnalyticsUseCase,
  EditGoogleTagManagerUseCase,
  FindGoogleAnalyticsByLocationUseCase,
  FindGoogleTagManagerByLocationUseCase,
  GetAllAdminsByLocationUseCase,
  GetAllAppointmentByMonthUseCase,
  GetAllAppointmentsByLocationUseCase,
  GetAllAppointmentsByLocationWithPaginationUseCase,
  GetAllCustomerByLocationUseCase,
  GetAllCustomerByLocationWithPaginationUseCase,
  GetAllLiveServiceByLocationUseCase,
  GetAllLocationUseCase,
  GetAllLocationWithPaginationUseCase,
  GetAllNotificationByLocationUseCase,
  GetAllPaymentTransactionsByLocationWithPagination,
  GetAllServiceUseCase,
  GetAllSquareLocations,
  GetAllSquarePaymentTransactionsByLocationUseCase,
  GetAllSquareRefundsBySquarePaymentTransaction,
  GetAllTimeOffsByLocationWithPaginationUseCase,
  GetAllUsersUseCase,
  GetAllWorkDaysByLocationUseCase,
  GetAllWorkingDaysByLocationIncludeBreaks,
  GetAppointmentSummaryByBookingIdUseCase,
  GetAvaliableDatesUseCase,
  GetAvaliableTimeSlotsUseCase,
  GetBookingBrandDetailsByLocationUseCase,
  GetBookingPoliciesByLocationUseCase,
  GetByIdAppointmentUseCase,
  GetByIdLocationUseCase,
  GetByIdPaymentAccountUseCase,
  GetCancellationPolicyUseCase,
  GetCustomerByIdUseCase,
  GetServiceByIdUseCase,
  GetUserByIdUseCase,
  HardDeleteUserUseCase,
  IsSquareConnectedUseCase,
  IssueSquareRefundUseCase,
  LoginUserUseCase,
  MarkNotificationsReadUseCase,
  RefreshTokenUseCase,
  RegisterAdminUseCase,
  RegisterBookingBrandDetailUseCase,
  RegisterBookingPolicyUseCase,
  RegisterCustomerUseCase,
  RegisterLocationUseCase,
  RegisterWorkingDayUseCase,
  SearchAppointmentsWithPaginationUseCase,
  SearchCustomerWithPaginationUseCase,
  TakePaymentPublicAppointmentUseCase,
  UpdateAppointmentUseCase,
  UpdateBookingBrandDetailsUseCase,
  UpdateBookingPoliciesUseCase,
  UpdateBreakUseCase,
  UpdateCustomerUseCase,
  UpdateLocationUseCase,
  UpdatePaymentAccountUseCase,
  UpdateRefundStatusUseCase,
  UpdateServiceUsecase,
  UpdateTimeOffUseCase,
  UpdateUserProfileUseCase,
  UpdateUserUseCase,
  UpdateWorkingDaysUseCase,
  IsGoogleTagMangerConnectedUseCase,
  GetAllBusinessUseCase,
  GetAllBusinessWithLocationUseCase,
  AddBusinessUseCase,
  DeleteLocationUseCase,
  IGetBusinessWithLocationBySubdomainUseCase,
  GetBusinessWithLocationBySubdomainUseCase,
  IGetBusinessByIdUseCase,
  GetBusinessByIdUseCase,
  IDeleteBusinessUseCase,
  DeleteBusinessUseCase,
  IUpdateBusinessUseCase,
  UpdateBusinessUseCase,
  GetAllServicesByLocation,
  IFindAllRefundsByLocationWithPaginationUseCase,
  FindAllRefundsByLocationWithPaginationUseCase,
  ISearchRefundsByLocationWithPaginationUseCase,
  SearchRefundsByLocationWithPaginationUseCase,
  IBulkUpdateStatusUseCase,
  BulkUpdateStatusUseCase,
  IGetAllBreaksByLocation,
  GetAllBreaksByLocation,
  IGetAllTimeOffsByLocationForCalendarUseCase,
  GetAllTimeOffsByLocationForCalendarUseCase,
  IPaymentLinkShortenerUseCase,
  PaymentLinkShortenerUseCase,
  IGetDashboardForLocation,
  GetDashboardForLocation,
  IGetAllWorkingDaysHistoryByLocationUseCase,
  GetAllWorkingDaysHistoryByLocationUseCase,
  IGetAllBreaksByLocationUseCaseForHistory,
  GetAllBreaksByLocationUseCaseForHistory,
} from '@seamlessslot/core';
import {
  FindAllPaymentLogByLocationIdWithPagination,
  FindPaymentLogByAppointmentId,
  IFindAllPaymentLogByLocationIdWithPagination,
  IFindPaymentLogByAppointmentId,
  ISearchPaymentLogByLocationIdWithPagination,
  SearchPaymentLogByLocationIdWithPagination,
} from '@seamlessslot/core/dist/use-cases/payment-log';
import {
  CheckAppointmentDetailUseCase,
  ICheckAppointmentDetailUseCase,
} from '@seamlessslot/core/dist/use-cases/appointment/check.appointment.detail';
import {
  IUpdateCustomerReminderTimeUseCase,
  UpdateCustomerReminderTimeUseCase,
} from '@seamlessslot/core/dist/use-cases/location/update.customer.reminder.time.location';
import {
  ISearchAllTransactionsByLocationWithPaginationUseCase,
  SearchAllTransactionsByLocationWithPaginationUseCase,
} from '@seamlessslot/core/dist/use-cases/payment-transactions/search.all.transactions.by.location.with.pagination.usecase';
import { GetAllByLocationForHistoryImpl } from './break/get.all.by.location.for.history.impl';
import {
  CheckIfSlotBookedUseCase,
  ICheckIfSlotBookedUseCase,
} from '@seamlessslot/core/dist/use-cases/appointment/check.if.slot.booked';

//import { GetBusinessWithLocationBySubdomainUseCaseImpl } from './use-cases/business/get.business.with.location.by.subdomain.usecase.impl';

@Injectable()
export class UseCaseFactory {
  /*
                                      ************
                                      ****
                                      **
                                      Payment Log UseCases
                                      **
                                      ****
                                      ***********
                                   */

  @Inject(ISearchPaymentLogByLocationIdWithPagination)
  public readonly searchPaymentLogByLocationIdWithPagination: SearchPaymentLogByLocationIdWithPagination;

  @Inject(IFindAllPaymentLogByLocationIdWithPagination)
  public readonly findAllPaymentLogByLocationIdWithPagination: FindAllPaymentLogByLocationIdWithPagination;

  @Inject(IFindPaymentLogByAppointmentId)
  public readonly findPaymentLogByAppointmentId: FindPaymentLogByAppointmentId;

  /*
                                       ************
                                       ****
                                       **
                                       Refresh Token  UseCases
                                       **
                                       ****
                                       ***********
                                    */

  @Inject(IRefreshTokenUseCase)
  public readonly refreshTokenUseCase: RefreshTokenUseCase;

  /*
                                     ************
                                     ****
                                     **
                                     Business UseCases
                                     **
                                     ****
                                     ***********
                                    */

  @Inject(IUpdateBusinessUseCase)
  public readonly updateBusinessUseCase: UpdateBusinessUseCase;

  @Inject(IDeleteBusinessUseCase)
  public readonly deleteBusinessUseCase: DeleteBusinessUseCase;

  @Inject(IGetBusinessByIdUseCase)
  public readonly getBusinessByIdUseCase: GetBusinessByIdUseCase;

  @Inject(IGetBusinessWithLocationBySubdomainUseCase)
  public readonly getBusinessWithLocationBySubdomainUseCase: GetBusinessWithLocationBySubdomainUseCase;

  @Inject(IAddBusinessUseCase)
  public readonly addBusinessUseCase: AddBusinessUseCase;

  @Inject(IGetAllBusinessUseCase)
  public readonly getAllBusinessUseCase: GetAllBusinessUseCase;

  @Inject(IGetAllBusinessWithLocationUseCase)
  public readonly getAllBusinessWithLocationUseCase: GetAllBusinessWithLocationUseCase;

  /*
                                       ************
                                       ****
                                       **
                                       Location UseCases
                                       **
                                       ****
                                       ***********
                                    */

  @Inject(IUpdateCustomerReminderTimeUseCase)
  public readonly updateCustomerReminderTimeUseCase: UpdateCustomerReminderTimeUseCase;

  @Inject(IDeleteLocationUseCase)
  public readonly deleteLocationUseCase: DeleteLocationUseCase;

  @Inject(IGetCancellationPolicyUseCase)
  public readonly getCancellationPolicyUseCase: GetCancellationPolicyUseCase;

  @Inject(IChangeLocationCancellationPolicy)
  public readonly changeLocationCancellationPolicy: ChangeLocationCancellationPolicy;

  @Inject(IChangeLocationScheduleWindowUseCase)
  public readonly changeLocationScheduleWindowUseCase: ChangeLocationScheduleWindowUseCase;

  @Inject(IRegisterLocationUseCase)
  public readonly registerLocationUseCase: RegisterLocationUseCase;

  @Inject(IUpdateLocationUseCase)
  public readonly updateLocationUseCase: UpdateLocationUseCase;

  @Inject(IGetByIdLocationUseCase)
  public readonly getByIdLocationUseCase: GetByIdLocationUseCase;

  @Inject(IGetAllLocationUseCase)
  public readonly getAllLocationUseCase: GetAllLocationUseCase;

  @Inject(IGetAllLocationWithPaginationUseCase)
  public readonly getAllLocationWithPaginationUseCase: GetAllLocationWithPaginationUseCase;

  /*
                                       ************
                                       ****
                                       **
                                       User UseCases
                                       **
                                       ****
                                       ***********
                                    */

  @Inject(IUpdateUserProfileUseCase)
  public readonly updateUserProfileUseCase: UpdateUserProfileUseCase;

  @Inject(IHardDeleteUserUseCase)
  public readonly hardDeleteUserUseCase: HardDeleteUserUseCase;

  @Inject(IGetAllAdminsByLocationUseCase)
  public readonly getAllAdminsByLocationUseCase: GetAllAdminsByLocationUseCase;

  @Inject(IRegisterAdminUseCase)
  public readonly registerUserUseCase: RegisterAdminUseCase;

  @Inject(ILoginUserUseCase)
  public readonly loginUserUseCase: LoginUserUseCase;

  @Inject(IGetAllUsersUseCase)
  public readonly getAllUsersUseCase: GetAllUsersUseCase;

  @Inject(IGetUserByIdUseCase)
  public readonly getUserByIdUseCase: GetUserByIdUseCase;

  @Inject(IUpdateUserUseCase)
  public readonly updateUserUseCase: UpdateUserUseCase;

  @Inject(IBlockUserUseCase)
  public readonly blockUserUseCase: BlockUserUseCase;

  /*
                                       ************
                                       ****
                                       **
                                       Service UseCases
                                       **
                                       ****
                                       ***********
                                    */

  @Inject(IGetAllServicesByLocation)
  public readonly getAllServicesByLocationUseCase: GetAllServicesByLocation;

  @Inject(IGetAllServiceUseCase)
  public readonly getAllServiceUseCase: GetAllServiceUseCase;

  @Inject(IGetServiceByIdUseCase)
  public readonly getServiceByIdUseCase: GetServiceByIdUseCase;

  @Inject(IDeleteServiceUseCase)
  public readonly deleteServiceUseCase: DeleteServiceUseCase;

  @Inject(IUpdateServiceUseCase)
  public readonly updateServiceUseCase: UpdateServiceUsecase;

  @Inject(IGetAllLiveServiceByLocationUseCase)
  public readonly getAllLiveServiceByLocationUseCase: GetAllLiveServiceByLocationUseCase;

  @Inject(ICreateServiceUseCase)
  public readonly createServiceUseCase: CreateServiceUseCase;

  /*
                                       ************
                                       ****
                                       **
                                       Working Day UseCases
                                       TimeOff UseCases
                                       Break UseCases
                                       **
                                       ****
                                       ***********
                                    */

  @Inject(IGetAllBreaksByLocationUseCaseForHistory)
  public readonly getAllBreaksByLocationUseCaseForHistory: GetAllBreaksByLocationUseCaseForHistory;

  @Inject(IRegisterWorkingDayUseCase)
  public readonly registerWorkingDayUseCase: RegisterWorkingDayUseCase;

  @Inject(IUpdateWorkingDaysUseCase)
  public readonly updateWorkingDaysUseCase: UpdateWorkingDaysUseCase;

  @Inject(IGetAllWorkDaysByLocationUseCase)
  public readonly getAllWorkingDayByLocationUseCase: GetAllWorkDaysByLocationUseCase;

  @Inject(IGetAllWorkingDaysByLocationIncludeBreaks)
  public readonly getAllWorkingDaysByLocationIncludeBreaksUseCase: GetAllWorkingDaysByLocationIncludeBreaks;

  @Inject(ICreateTimeOffUseCase)
  public readonly createTimeOffUseCase: CreateTimeOffUseCase;

  @Inject(IDeleteTimeOffUseCase)
  public readonly deleteTimeOffUseCase: DeleteTimeOffUseCase;

  @Inject(IGetAllTimeOffsByLocationWithPaginationUseCase)
  public readonly getAllTimeOffsByLocationUseCase: GetAllTimeOffsByLocationWithPaginationUseCase;

  @Inject(IUpdateTimeOffUseCase)
  public readonly updateTimeOffUseCase: UpdateTimeOffUseCase;

  @Inject(ICreateBreakUseCase)
  public readonly createBreakUseCase: CreateBreakUseCase;

  @Inject(IDeleteBreakUseCase)
  public readonly deleteBreakUseCase: DeleteBreakUseCase;

  @Inject(IUpdateBreakUseCase)
  public readonly updateBreakUseCase: UpdateBreakUseCase;

  @Inject(IGetAllBreaksByLocation)
  public readonly getAllBreaksByLocation: GetAllBreaksByLocation;

  @Inject(IGetAllTimeOffsByLocationForCalendarUseCase)
  public readonly getAllTimeOffsByLocationForCalendarUseCase: GetAllTimeOffsByLocationForCalendarUseCase;

  /*
                                       ************
                                       ****
                                       **
                                       Payment Account UseCases
                                       **
                                       ****
                                       ***********
                                    */

  @Inject(IIsSquareConnectedUseCase)
  public readonly isSquareConnectedUseCase: IsSquareConnectedUseCase;

  @Inject(IDeletePaymentAccountUseCase)
  public readonly deletePaymentAccountUseCase: DeletePaymentAccountUseCase;

  @Inject(IGetByIdPaymentAccountUseCase)
  public readonly getPaymentAccountByIdUseCase: GetByIdPaymentAccountUseCase;

  @Inject(IUpdatePaymentAccountUseCase)
  public readonly updatePaymentAccountUseCase: UpdatePaymentAccountUseCase;

  @Inject(ICreateSquarePaymentAccountUseCase)
  public readonly createSquarePaymentAccountUseCase: CreateSquarePaymentAccountUseCase;

  @Inject(ICreateDojoPaymentAccountUseCase)
  public readonly createDojoPaymentAccountUseCase: CreateDojoPaymentAccountUseCase;

  @Inject(IBindSquareLocationIdUseCase)
  public readonly bindSquareLocationIdUseCase: BindSquareLocationIdUseCase;

  @Inject(ICheckPaymentAccountExists)
  public readonly checkPaymentAccountExsistsUseCase: CheckPaymentAccountExists;

  /*
                                       ************
                                       ****
                                       **
                                       Appoitnment UseCases
                                       **
                                       ****
                                       ***********
                                    */

  @Inject(ICheckIfSlotBookedUseCase)
  public readonly checkIfSlotBookedUseCase: CheckIfSlotBookedUseCase;

  @Inject(IBulkUpdateStatusUseCase)
  public readonly bulkUpdateStatusUseCase: BulkUpdateStatusUseCase;

  @Inject(ICheckAppointmentDetailUseCase)
  public readonly checkAppointmentDetailUseCase: CheckAppointmentDetailUseCase;

  @Inject(ISearchAppointmentsWithPaginationUseCase)
  public readonly searchAppointmentsWithPaginationUseCase: SearchAppointmentsWithPaginationUseCase;

  @Inject(ITakePaymentPublicAppointmentUseCase)
  public readonly takePaymentPublicAppointmentUseCase: TakePaymentPublicAppointmentUseCase;

  @Inject(ICreatePublicAppointmentWithoutPaymentUseCase)
  public readonly createPublicAppointmentWithoutPaymentUseCase: CreatePublicAppointmentWithoutPaymentUseCase;

  @Inject(IGetAllAppointmentByMonthUseCase)
  public readonly getAppointmentByMonthUseCase: GetAllAppointmentByMonthUseCase;

  @Inject(IGetAllAppointmentsByLocationWithPaginationUseCase)
  public readonly getAllAppointmentsByLocationWithPaginationUseCase: GetAllAppointmentsByLocationWithPaginationUseCase;

  @Inject(IChangeAppointmentDataTimeUseCase)
  public readonly changeAppointmentDateTimeUseCase: ChangeAppointmentDataTimeUseCase;

  @Inject(ICreateAppointmentUseCase)
  public readonly createAppointmentUseCase: CreateAppointmentUseCase;

  @Inject(IChangeAppointmentStatusUseCase)
  public readonly changeAppointmentStatusUseCase: ChangeAppointmentStatusUseCase;

  @Inject(IGetAppointmentSummaryByBookingIdUseCase)
  public readonly getAppointmentSummaryByBookingIdUseCase: GetAppointmentSummaryByBookingIdUseCase;

  @Inject(IGetByIdAppointmentUseCase)
  public readonly getAppointmentByIdUseCase: GetByIdAppointmentUseCase;

  @Inject(IUpdateAppointmentUseCase)
  public readonly updateAppointmentUseCase: UpdateAppointmentUseCase;

  @Inject(IDeleteAppointmentUseCase)
  public readonly deleteAppointmentUseCase: DeleteAppointmentUseCase;

  @Inject(IGetAllAppointmentsByLocationUseCase)
  public readonly getAllAppointmentsByLocationUseCase: GetAllAppointmentsByLocationUseCase;

  @Inject(IGetAvaliableDatesUseCase)
  public readonly getAvaliableDatesUseCase: GetAvaliableDatesUseCase;

  @Inject(IGetAvaliableTimeSlotsUseCase)
  public readonly getAvaliableTimeSlotsUseCase: GetAvaliableTimeSlotsUseCase;

  @Inject(IDeleteSquarePaymentAccountUseCase)
  public readonly deleteSquarePaymentAccountUseCase: DeleteSquarePaymentAccountUseCase;

  /*
                                       ************
                                       ****
                                       **
                                       Customer UseCases
                                       **
                                       ****
                                       ***********
                                    */

  @Inject(ISearchCustomerWithPaginationUseCase)
  public readonly searchCustomerWithPaginationUseCase: SearchCustomerWithPaginationUseCase;

  @Inject(IGetAllCustomerByLocationUseCase)
  public readonly getAllCustomerByLocationUseCase: GetAllCustomerByLocationUseCase;

  @Inject(IRegisterCustomerUseCase)
  public readonly registerCustomerUseCase: RegisterCustomerUseCase;

  @Inject(IDeleteCustomerUseCase)
  public readonly deleteCustomerUseCase: DeleteCustomerUseCase;

  @Inject(IUpdateCustomerUseCase)
  public readonly updateCustomerUseCase: UpdateCustomerUseCase;

  @Inject(IGetCustomerByIdUseCase)
  public readonly getCustomerByIdUseCase: GetCustomerByIdUseCase;

  @Inject(IGetAllCustomerByLocationWithPaginationUseCase)
  public readonly getAllCustomerByLocationWithPaginationUseCase: GetAllCustomerByLocationWithPaginationUseCase;

  /*
                                       ************
                                       ****
                                       **
                                       Square UseCases
                                       **
                                       ****
                                       ***********
                                    */
  @Inject(IGetAllSquareLocations)
  public readonly getAllSquareLocations: GetAllSquareLocations;

  @Inject(IConfirmAppointmentOnPaymentUseCase)
  public readonly confirmAppointmentOnPaymentUseCase: ConfirmAppointmentOnPaymentUseCase;

  /*
                                       ************
                                       ****
                                       **
                                       Payment Transaction UseCases
                                       **
                                       ****
                                       ***********
                                    */

  @Inject(ISearchAllTransactionsByLocationWithPaginationUseCase)
  public readonly searchAllTransactionsByLocationWithPaginationUseCase: SearchAllTransactionsByLocationWithPaginationUseCase;

  @Inject(IGetAllSquarePaymentTransactionsByLocationUseCase)
  public readonly getAllPaymentTransactionsByLocationUseCase: GetAllSquarePaymentTransactionsByLocationUseCase;

  @Inject(IGetAllPaymentTransactionsByLocationWithPagination)
  public readonly getAllPaymentTransactionByLocationWithPaginationUseCase: GetAllPaymentTransactionsByLocationWithPagination;

  /*
                                       ************
                                       ****
                                       **
                                       Booking Brand Detail UseCases
                                       **
                                       ****
                                       ***********
                                    */

  @Inject(IGetBookingBrandDetailsByLocationUseCase)
  public readonly getBookingBrandDetailsByLocationUseCase: GetBookingBrandDetailsByLocationUseCase;

  @Inject(IUpdateBookingBrandDetailsUseCase)
  public readonly updateBookingBrandDetailUseCase: UpdateBookingBrandDetailsUseCase;

  @Inject(IRegisterBookingBrandDetailUseCase)
  public readonly registerBookingBrandDetailUseCase: RegisterBookingBrandDetailUseCase;

  /*
                                       ************
                                       ****
                                       **
                                       Booking Policy UseCases
                                       **
                                       ****
                                       ***********
                                    */

  @Inject(IGetBookingPoliciesByLocationUseCase)
  public readonly getBookingPoliciesByLocationUseCase: GetBookingPoliciesByLocationUseCase;

  @Inject(IUpdateBookingPoliciesUseCase)
  public readonly updateBookingPolicyUseCase: UpdateBookingPoliciesUseCase;

  @Inject(IRegisterBookingPolicyUseCase)
  public readonly registerBookingPolicyUseCase: RegisterBookingPolicyUseCase;

  /*
                                       ************
                                       ****
                                       **
                                       Refund  UseCases
                                       **
                                       ****
                                       ***********
                                    */
  @Inject(ISearchRefundsByLocationWithPaginationUseCase)
  public readonly searchRefundsByLocationWithPaginationUseCase: SearchRefundsByLocationWithPaginationUseCase;

  @Inject(IFindAllRefundsByLocationWithPaginationUseCase)
  public readonly findAllRefundsByLocationWithPaginationUseCase: FindAllRefundsByLocationWithPaginationUseCase;

  @Inject(IIssueSquareRefundUseCase)
  public readonly issueRefundUseCase: IssueSquareRefundUseCase;

  @Inject(IUpdateRefundStatusUseCase)
  public readonly updateRefundStatusUseCase: UpdateRefundStatusUseCase;

  @Inject(IGetAllSquareRefundsBySquarePaymentTransaction)
  public readonly getAllRefundsByPaymentTransactionUseCase: GetAllSquareRefundsBySquarePaymentTransaction;

  /*
                                       ************
                                       ****
                                       **
                                       Notification UseCases
                                       **
                                       ****
                                       ***********
                                    */

  @Inject(IGetAllNotificationByLocationUseCase)
  public readonly getAllNotificationsByLocationUseCase: GetAllNotificationByLocationUseCase;

  @Inject(IMarkNotificationsReadUseCase)
  public readonly getMarkNotificationsReadUseCase: MarkNotificationsReadUseCase;

  /*
                                     ************
                                     ****
                                     **
                                     Google Analytics UseCases
                                     **
                                     ****
                                     ***********
                                    */

  @Inject(ICreateGoogleAnalyticsUseCase)
  public readonly createGoogleAnalyticsUseCase: CreateGoogleAnalyticsUseCase;

  @Inject(IEditGoogleAnalyticsUseCase)
  public readonly editGoogleAnalyticsUseCase: EditGoogleAnalyticsUseCase;

  @Inject(IFindGoogleAnalyticsByLocationUseCase)
  public readonly findGoogleAnalyticsByLocationUseCase: FindGoogleAnalyticsByLocationUseCase;

  /*
                                     ************
                                     ****
                                     **
                                     Google Tag Manager UseCases
                                     **
                                     ****
                                     ***********
                                    */

  @Inject(ICreateGoogleTagManagerUseCase)
  public readonly createGoogleTagManagerUseCase: CreateGoogleTagManagerUseCase;

  @Inject(IEditGoogleTagManagerUseCase)
  public readonly editGoogleTagManagerUseCase: EditGoogleTagManagerUseCase;

  @Inject(IFindGoogleTagManagerByLocationUseCase)
  public readonly findGoogleTagManagerByLocationUseCase: FindGoogleTagManagerByLocationUseCase;

  @Inject(IIsGoogleTagMangerConnectedUseCase)
  public readonly isGoogleTagManagerConnectedUseCase: IsGoogleTagMangerConnectedUseCase;

  /*
                                     ************
                                     ****
                                     **
                                     Payment Link Shortener  UseCases
                                     **
                                     ****
                                     ***********
                                  */

  @Inject(IPaymentLinkShortenerUseCase)
  public readonly paymentLinkShortenerUseCase: PaymentLinkShortenerUseCase;

  /*
                                   ************
                                   ****
                                   **
                                   Dashboard UseCases
                                   **
                                   ****
                                   ***********
                                */

  @Inject(IGetDashboardForLocation)
  public readonly getDashboardForLocation: GetDashboardForLocation;

  /*
                                   ************
                                   ****
                                   **
                                   Working Day History UseCases
                                   **
                                   ****
                                   ***********
                                */

  @Inject(IGetAllWorkingDaysHistoryByLocationUseCase)
  public readonly getAllWorkingDaysHistoryByLocationUseCase: GetAllWorkingDaysHistoryByLocationUseCase;
}
