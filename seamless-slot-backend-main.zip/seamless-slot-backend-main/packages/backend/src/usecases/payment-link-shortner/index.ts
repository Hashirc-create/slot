import { IPaymentLinkShortenerUseCase } from '@seamlessslot/core';
import { PaymentLinkShortenerImpl } from './payment.link.shortener.impl';

export const PAYMENT_LINK_SHORTENER_USECASES = [
  {
    provide: IPaymentLinkShortenerUseCase,
    useClass: PaymentLinkShortenerImpl,
  },
];
