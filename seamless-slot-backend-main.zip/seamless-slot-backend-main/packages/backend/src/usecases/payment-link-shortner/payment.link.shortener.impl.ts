import { Injectable } from '@nestjs/common';
import {
  Customer,
  GeneratePaymentLinkPayload,
  Location,
  PaymentLinkShortenerUseCase,
  Service,
} from '@seamlessslot/core';
import { RepositoryFactory } from '@seamlessslot/database';
import { TimeZoneService } from '../../shared/utils/timezone.util';
import { ConfigService } from '@nestjs/config';

@Injectable()
export class PaymentLinkShortenerImpl implements PaymentLinkShortenerUseCase {
  constructor(
    private readonly repoFactory: RepositoryFactory,
    private readonly timeZoneService: TimeZoneService,
    private readonly configService: ConfigService,
  ) {}

  async execute(bookingId: number): Promise<Readonly<string>> {
    const appointmentFound =
      await this.repoFactory.appointmentRepository.findByIdIncludingLocationServiceCustomerAndTransaction(
        bookingId,
      );

    const business = await this.repoFactory.businessRepository.findById(
      appointmentFound.business as number,
    );
    const customer = appointmentFound.customer as Customer;
    const location = appointmentFound.location as Location;
    const service = appointmentFound.service as Service;

    const payload: GeneratePaymentLinkPayload = {
      date: this.timeZoneService.formatDatePreservingUTC(
        appointmentFound.startTime as Date,
        `dd MMM yyyy`,
      ),
      time:
        this.timeZoneService.formatDatePreservingUTC(
          appointmentFound.startTime as Date,
          'hh:mm aa',
        ) +
        ' - ' +
        this.timeZoneService.formatDatePreservingUTC(
          appointmentFound.endTime as Date,
          'hh:mm aa',
        ),
      appointmentType: service.id,
      fullName: customer.firstName + ' ' + customer.lastName,
      email: customer.email,
      phoneNumber: customer.phoneNo,
      address: customer.address,
      comments: '',
      cancellationPolicy: true,
      bookingId: appointmentFound.id,
      customerId: customer.id,
      locationId: location.id,
    };

    const base64EncodedPayload = btoa(
      new URLSearchParams(
        payload as unknown as Record<string, string>,
      ).toString(),
    );

    const protocol: string =
      this.configService.get('NODE_ENV') === 'development' ? 'http' : 'https';

    return `${protocol}://${business.subdomain}.${this.configService.get('PARENT_DOMAIN')}/patientInfo?query=${base64EncodedPayload}`;
  }
}
