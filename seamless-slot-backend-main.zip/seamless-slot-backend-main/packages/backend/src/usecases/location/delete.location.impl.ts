import { Injectable } from '@nestjs/common';
import { RepositoryFactory } from '@seamlessslot/database';
import { DeleteLocationUseCase, Location } from '@seamlessslot/core';
import { SecurityContext } from '../../shared/auth/context/security.context';

@Injectable()
export class DeleteLocationUseCaseImpl implements DeleteLocationUseCase {
  constructor(
    private readonly repoFactory: RepositoryFactory,
    private readonly securityContext: SecurityContext,
  ) {}

  async execute(locationId: number): Promise<Location> {
    return await this.repoFactory.locationRepository.delete(
      locationId,
      this.securityContext.getId(),
    );
  }
}
