describe('Get All Location UseCase', () => {
  it('should get all locations', async () => {
    expect(true).toBe(true);
  });
});
