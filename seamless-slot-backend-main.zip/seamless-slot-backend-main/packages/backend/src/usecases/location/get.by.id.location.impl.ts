import { Injectable } from '@nestjs/common';
import { GetByIdLocationUseCase, Location } from '@seamlessslot/core';
import { RepositoryFactory } from '@seamlessslot/database';

@Injectable()
export class GetByIdLocationUseCaseImpl implements GetByIdLocationUseCase {
  constructor(private readonly repoFactory: RepositoryFactory) {}

  async execute(id: number): Promise<Location> {
    const location = await this.repoFactory.locationRepository.findById(id);

    location.business = await this.repoFactory.businessRepository.findById(
      location.business as number,
    );

    return location;
  }
}
