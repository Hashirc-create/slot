import { Injectable } from '@nestjs/common';
import { GetAllLocationUseCase } from '@seamlessslot/core';
import { RepositoryFactory } from '@seamlessslot/database';
import { Location } from '@seamlessslot/core';

@Injectable()
export class GetAllLocationUseCaseImpl implements GetAllLocationUseCase {
  constructor(private readonly repoFactory: RepositoryFactory) {}
  async execute(): Promise<Location[]> {
    const data = await this.repoFactory.locationRepository.findAll();

    return data;
  }
}
