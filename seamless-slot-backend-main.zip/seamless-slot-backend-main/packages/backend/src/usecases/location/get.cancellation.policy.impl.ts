import { Injectable } from '@nestjs/common';
import { RepositoryFactory } from '@seamlessslot/database';
import {
  CancellationTimeUnits,
  GetCancellationPolicyUseCase,
} from '@seamlessslot/core';

@Injectable()
export class GetCancellationPolicyImpl implements GetCancellationPolicyUseCase {
  constructor(private readonly repoFactory: RepositoryFactory) {}

  async execute(locationId: number): Promise<{
    email: string;
    telephone: string;
    isCancellationPolicyEnabled: boolean;
    cancellationTime: number;
    cancellationTimeUnit: CancellationTimeUnits;
  }> {
    const {
      email,
      telephone,
      isCancellationPolicyEnabled,
      cancellationTime,
      cancellationTimeUnit,
    } = await this.repoFactory.locationRepository.findById(locationId);

    return {
      email,
      telephone,
      isCancellationPolicyEnabled,
      cancellationTime,
      cancellationTimeUnit,
    };
  }
}
