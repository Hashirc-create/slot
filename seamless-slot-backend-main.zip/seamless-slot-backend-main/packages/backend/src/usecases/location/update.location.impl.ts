import { HttpException, HttpStatus, Injectable } from '@nestjs/common';
import { Location, UpdateLocationUseCase } from '@seamlessslot/core';
import { RepositoryFactory } from '@seamlessslot/database';
import { BaseResponse } from '../../shared/interceptor/response.interceptor';

@Injectable()
export class UpdateLocationUseCaseImpl implements UpdateLocationUseCase {
  constructor(private readonly repoFactory: RepositoryFactory) {}

  /**
   * Executes the location update.
   * Validates requirements if the location status is "Active".
   */
  async execute(id: number, location: Location): Promise<Location> {
    if (location.status === 'Active') {
      const { isValid, message } = await this.validateLocationRequirements(id);

      if (!isValid) {
        throw new HttpException(
          {
            code: 0,
            message,
            data: null,
          } as BaseResponse<null>,
          HttpStatus.BAD_REQUEST,
        );
      }
    }

    return this.repoFactory.locationRepository.update(id, location);
  }

  /**
   * Validates requirements for marking a location as active.
   * Collects errors if requirements are not met.
   */
  private async validateLocationRequirements(locationId: number): Promise<{
    isValid: boolean;
    message: string;
  }> {
    let errors = '';

    // Check if the location has active services
    const services =
      await this.repoFactory.serviceRepository.findAllLiveServicesByLocation(
        locationId,
      );

    if (services.length === 0) {
      errors += 'Location must have at least one active service.\n';
    }

    // Check if the location has a linked payment account
    const paymentAccount =
      await this.repoFactory.paymentAccountRepository.findPaymentAccountByLocationAndType(
        'Square-Pay',
        locationId,
      );
    if (!paymentAccount) {
      errors += 'Location must have an active Square-Pay account linked.\n';
    }

    // Return validation results
    return {
      isValid: errors === '',
      message: errors.trim(),
    };
  }
}
