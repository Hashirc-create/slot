import { HttpException, Injectable } from '@nestjs/common';
import { RepositoryFactory } from '@seamlessslot/database';
import { Location } from '@seamlessslot/core';
import { ChangeLocationScheduleWindowUseCase } from '@seamlessslot/core';
import { ScheduleSizeUnits } from '@seamlessslot/core';
import { BaseResponse } from '../../shared/interceptor/response.interceptor';

@Injectable()
export class ChangeLocationScheduleWindowUseCaseImpl
  implements ChangeLocationScheduleWindowUseCase
{
  constructor(private readonly repoFactory: RepositoryFactory) {}

  async execute(
    locationId: number,
    scheduleSize: number,
    scheduleSizeUnit: ScheduleSizeUnits,
  ): Promise<Location> {
    if (!this.isScheduleSizeUnits(scheduleSizeUnit))
      throw new HttpException(
        {
          code: 0,
          message: 'Unit should be months or days',
          data: 'Unit should be months or days',
        } as BaseResponse<string>,
        400,
      );

    const data = await this.repoFactory.locationRepository.updateScheduleWindow(
      locationId,
      scheduleSize,
      scheduleSizeUnit,
    );

    return data;
  }

  isScheduleSizeUnits(value: ScheduleSizeUnits): value is ScheduleSizeUnits {
    return value === 'days' || value === 'months';
  }
}
