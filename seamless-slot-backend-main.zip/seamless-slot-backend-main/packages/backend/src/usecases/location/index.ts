import {
  IChangeLocationCancellationPolicy,
  IDeleteLocationUseCase,
} from '@seamlessslot/core';
import { IChangeLocationScheduleWindowUseCase } from '@seamlessslot/core';
import { IGetAllLocationUseCase } from '@seamlessslot/core';
import { IGetAllLocationWithPaginationUseCase } from '@seamlessslot/core';
import { IGetByIdLocationUseCase } from '@seamlessslot/core';
import { IRegisterLocationUseCase } from '@seamlessslot/core';
import { IUpdateLocationUseCase } from '@seamlessslot/core';
import { ChangeLocationCancellationPolicyImpl } from './change.cancellation.policy';
import { ChangeLocationScheduleWindowUseCaseImpl } from './change.schedule.window.location';
import { GetAllLocationUseCaseImpl } from './get.all.locations.impl';
import { GetAllLocationWithPaginationUseCaseImpl } from './get.all.locations.with.pagination.impl';
import { GetByIdLocationUseCaseImpl } from './get.by.id.location.impl';
import { RegisterLocationUseCaseImpl } from './register.location.impl';
import { UpdateLocationUseCaseImpl } from './update.location.impl';
import { IGetCancellationPolicyUseCase } from '@seamlessslot/core';
import { GetCancellationPolicyImpl } from './get.cancellation.policy.impl';
import { DeleteLocationUseCaseImpl } from './delete.location.impl';
import { IUpdateCustomerReminderTimeUseCase } from '@seamlessslot/core/dist/use-cases/location/update.customer.reminder.time.location';
import { UpdateCustomerReminderTimeUseCaseImpl } from './update.customer.reminder.time.usecase.impl';

export const LOCATION_USECASES = [
  {
    provide: IUpdateCustomerReminderTimeUseCase,
    useClass: UpdateCustomerReminderTimeUseCaseImpl,
  },
  {
    provide: IChangeLocationCancellationPolicy,
    useClass: ChangeLocationCancellationPolicyImpl,
  },
  {
    provide: IDeleteLocationUseCase,
    useClass: DeleteLocationUseCaseImpl,
  },
  {
    provide: IChangeLocationScheduleWindowUseCase,
    useClass: ChangeLocationScheduleWindowUseCaseImpl,
  },
  {
    provide: IRegisterLocationUseCase,
    useClass: RegisterLocationUseCaseImpl,
  },
  {
    provide: IGetAllLocationUseCase,
    useClass: GetAllLocationUseCaseImpl,
  },
  {
    provide: IGetAllLocationWithPaginationUseCase,
    useClass: GetAllLocationWithPaginationUseCaseImpl,
  },
  {
    provide: IUpdateLocationUseCase,
    useClass: UpdateLocationUseCaseImpl,
  },
  {
    provide: IGetByIdLocationUseCase,
    useClass: GetByIdLocationUseCaseImpl,
  },
  {
    provide: IGetCancellationPolicyUseCase,
    useClass: GetCancellationPolicyImpl,
  },
];
