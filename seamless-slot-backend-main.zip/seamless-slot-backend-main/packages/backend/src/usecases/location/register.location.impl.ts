import { HttpException, HttpStatus, Injectable } from '@nestjs/common';
import { RegisterLocationUseCase } from '@seamlessslot/core';
import { RepositoryFactory } from '@seamlessslot/database';
import { Location } from '@seamlessslot/core';
import { BookingBrandDetail } from '@seamlessslot/core';
import { BookingPolicy } from '@seamlessslot/core';
import { SecurityContext } from '../../shared/auth/context/security.context';
import { BaseResponse } from '../../shared/interceptor/response.interceptor';
import { UTILS } from '../../shared/utils/utils.util';
import { TimeZoneService } from '../../shared/utils/timezone.util';

@Injectable()
export class RegisterLocationUseCaseImpl implements RegisterLocationUseCase {
  constructor(
    private readonly repoFactory: RepositoryFactory,
    private readonly securityContext: SecurityContext,
    private readonly timeZoneService: TimeZoneService,
  ) {}

  async execute(location: Location): Promise<Location> {
    const foundLocation = await this.repoFactory.locationRepository.findByEmail(
      location.email,
    );

    if (foundLocation !== null)
      throw new HttpException(
        {
          code: 0,
          message: 'Location already exists Against Email : ' + location.email,
          data: 'Location already exists Against Email : ' + location.email,
        } as BaseResponse<string>,
        HttpStatus.BAD_REQUEST,
      );

    const persistLocation =
      await this.repoFactory.locationRepository.save(location);

    // creating default working days
    await this.repoFactory.workingDayRepository.defaultCreate(
      persistLocation.id,
      this.securityContext.getId(),
      UTILS.getDefaultWorkingDays(),
    );

    // creating default booking brand detail
    const entity: BookingBrandDetail = {
      telephone: persistLocation.telephone,
      email: persistLocation.email,
      country: persistLocation.country,
      address: persistLocation.address,
      town: persistLocation.town,
      about: persistLocation.about,
      location: persistLocation.id,
      isActive: true,
      createdBy: this.securityContext.getId(),
      updatedBy: this.securityContext.getId(),
      deletedBy: this.securityContext.getId(),
    };
    await this.repoFactory.bookingBrandDetailRepository.defaultCreate(entity);
    // creating default booking brand detail
    const entityBookingPolicy: BookingPolicy = {
      location: persistLocation.id,
      isActive: true,
      createdBy: this.securityContext.getId(),
      updatedBy: this.securityContext.getId(),
      deletedBy: this.securityContext.getId(),
    };
    await this.repoFactory.bookingPolicyRepository.defaultCreate(
      entityBookingPolicy,
    );

    return persistLocation;
  }
}
