import { Injectable } from '@nestjs/common';
import { CustomerReminderTimeUnit } from '@seamlessslot/core';
import { RepositoryFactory } from '@seamlessslot/database';
import { Location } from '@seamlessslot/core';
import { UpdateCustomerReminderTimeUseCase } from '@seamlessslot/core/dist/use-cases/location/update.customer.reminder.time.location';

@Injectable()
export class UpdateCustomerReminderTimeUseCaseImpl
  implements UpdateCustomerReminderTimeUseCase
{
  constructor(private readonly repoFactory: RepositoryFactory) {}

  async execute(
    id: number,
    customerReminderTime: number,
    unit: CustomerReminderTimeUnit,
  ): Promise<Location> {
    return await this.repoFactory.locationRepository.updateCustomerReminderTime(
      id,
      customerReminderTime,
      unit,
    );
  }
}
