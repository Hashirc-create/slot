import { Injectable } from '@nestjs/common';
import { RepositoryFactory } from '@seamlessslot/database';
import { Location } from '@seamlessslot/core';
import { GetAllLocationWithPaginationUseCase } from '@seamlessslot/core';

@Injectable()
export class GetAllLocationWithPaginationUseCaseImpl
  implements GetAllLocationWithPaginationUseCase
{
  constructor(private readonly repoFactory: RepositoryFactory) {}
  async execute(
    page: number,
    limit: number,
  ): Promise<{
    totalRecords: number;
    data: Location[];
  }> {
    const { data, total } =
      await this.repoFactory.locationRepository.findAllWithPagination(
        page,
        limit,
      );

    return {
      totalRecords: total,
      data: data,
    };
  }
}
