import { HttpException, HttpStatus, Injectable } from '@nestjs/common';
import { RepositoryFactory } from '@seamlessslot/database';
import {
  CancellationTimeUnits,
  ChangeLocationCancellationPolicy,
  Location,
} from '@seamlessslot/core';
import { BaseResponse } from '../../shared/interceptor/response.interceptor';

@Injectable()
export class ChangeLocationCancellationPolicyImpl
  implements ChangeLocationCancellationPolicy
{
  constructor(private readonly repoFactory: RepositoryFactory) {}

  async execute(
    locationId: number,
    cancellationTime: number,
    cancellationTimeUnits: CancellationTimeUnits,
    isCancellationPolicyEnabled: boolean,
  ): Promise<Location> {
    if (!this.isCancellationTimeUnits(cancellationTimeUnits))
      throw new HttpException(
        {
          code: 0,
          message: 'validation failed on cancellation policy units',
          data: null,
        } as BaseResponse<null>,
        HttpStatus.BAD_REQUEST,
      );

    return await this.repoFactory.locationRepository.updateCancellationPolicy(
      locationId,
      cancellationTime,
      cancellationTimeUnits,
      isCancellationPolicyEnabled,
    );
  }

  isCancellationTimeUnits(
    value: CancellationTimeUnits,
  ): value is CancellationTimeUnits {
    return value === 'hours' || value === 'months' || value === 'days';
  }
}
