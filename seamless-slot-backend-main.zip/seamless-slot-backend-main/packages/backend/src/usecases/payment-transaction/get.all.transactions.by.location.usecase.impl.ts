import { Injectable } from '@nestjs/common';
import { RepositoryFactory } from '@seamlessslot/database';
import { GetAllSquarePaymentTransactionsByLocationUseCase } from '@seamlessslot/core';
import { SquarePaymentTransaction } from '@seamlessslot/core';

@Injectable()
export class GetAllTransactionsByLocationUseCaseImpl
  implements GetAllSquarePaymentTransactionsByLocationUseCase
{
  constructor(private readonly repoFactory: RepositoryFactory) {}
  async execute(
    locationId: number,
  ): Promise<Readonly<SquarePaymentTransaction[]>> {
    const data =
      await this.repoFactory.paymentTransactionRepository.getAllPaymentTranscationsByLocation(
        locationId,
      );

    return data;
  }
}
