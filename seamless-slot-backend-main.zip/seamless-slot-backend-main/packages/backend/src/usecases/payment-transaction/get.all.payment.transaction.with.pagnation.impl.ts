import { Injectable } from '@nestjs/common';
import { RepositoryFactory } from '@seamlessslot/database';
import { SquarePaymentTransaction } from '@seamlessslot/core';
import { GetAllPaymentTransactionsByLocationWithPagination } from '@seamlessslot/core';
import { SecurityContext } from '../../shared/auth/context/security.context';
import { TimeZoneService } from '../../shared/utils/timezone.util';

@Injectable()
export class GetAllPaymentTransactionByLocationWithPaginationImpl
  implements GetAllPaymentTransactionsByLocationWithPagination
{
  constructor(
    private readonly repoFactory: RepositoryFactory,
    private readonly securityContext: SecurityContext,
    private readonly timeZoneService: TimeZoneService,
  ) {}

  execute(
    locationId: number,
    page: number,
    perPage: number,
    startDate: string,
    endDate: string,
  ): Promise<
    Readonly<{
      prev: number;
      next: number;
      last: number;
      pages: number;
      total: number;
      data: SquarePaymentTransaction[];
    }>
  > {
    if (startDate === '' && endDate === '')
      return this.repoFactory.paymentTransactionRepository.findAllPaymentTransactionsByLocationWithPagination(
        locationId,
        page,
        perPage,
      );

    // const startDateConverted =
    //   this.timeZoneService.formatISOInSpecifiedTimeZone(
    //     startDate,
    //     `yyyy-MM-dd'T'HH:mm:ss`,
    //     this.securityContext.getTimeZone(),
    //   );
    //
    // const endDateConverted = this.timeZoneService.formatISOInSpecifiedTimeZone(
    //   endDate,
    //   `yyyy-MM-dd'T'HH:mm:ss`,
    //   this.securityContext.getTimeZone(),
    // );

    return this.repoFactory.paymentTransactionRepository.findAllPaymentTransactionsByLocationWithPaginationAndDateRange(
      locationId,
      page,
      perPage,
      startDate,
      endDate,
    );
  }
}
