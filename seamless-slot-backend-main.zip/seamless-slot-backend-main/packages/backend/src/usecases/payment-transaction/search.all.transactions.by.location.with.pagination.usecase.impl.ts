import { Injectable } from '@nestjs/common';
import { RepositoryFactory } from '@seamlessslot/database';
import { SquarePaymentTransaction } from '@seamlessslot/core';
import { SearchAllTransactionsByLocationWithPaginationUseCase } from '@seamlessslot/core/dist/use-cases/payment-transactions/search.all.transactions.by.location.with.pagination.usecase';

@Injectable()
export class SearchAllTransactionsByLocationWithPaginationUseCaseImpl
  implements SearchAllTransactionsByLocationWithPaginationUseCase
{
  constructor(private readonly repoFactory: RepositoryFactory) {}

  async execute(
    locationId: number,
    stringToBeSearched: string,
    page: number,
    limit: number,
  ): Promise<
    Readonly<{
      prev: number;
      next: number;
      last: number;
      pages: number;
      total: number;
      data: SquarePaymentTransaction[];
    }>
  > {
    return await this.repoFactory.paymentTransactionRepository.searchPaymentTransactionWithPagination(
      locationId,
      stringToBeSearched,
      ['status', 'cardDetails', 'method'],
      page,
      limit,
    );
  }
}
