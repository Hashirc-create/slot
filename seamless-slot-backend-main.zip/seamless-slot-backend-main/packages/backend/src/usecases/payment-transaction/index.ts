import { IGetAllSquarePaymentTransactionsByLocationUseCase } from '@seamlessslot/core';
import { GetAllTransactionsByLocationUseCaseImpl } from './get.all.transactions.by.location.usecase.impl';
import { IGetAllPaymentTransactionsByLocationWithPagination } from '@seamlessslot/core';
import { GetAllPaymentTransactionByLocationWithPaginationImpl } from './get.all.payment.transaction.with.pagnation.impl';
import { ISearchAllTransactionsByLocationWithPaginationUseCase } from '@seamlessslot/core/dist/use-cases/payment-transactions/search.all.transactions.by.location.with.pagination.usecase';
import { SearchAllTransactionsByLocationWithPaginationUseCaseImpl } from './search.all.transactions.by.location.with.pagination.usecase.impl';

export const PAYMENT_TRANSACTION_USECASES = [
  {
    provide: IGetAllSquarePaymentTransactionsByLocationUseCase,
    useClass: GetAllTransactionsByLocationUseCaseImpl,
  },
  {
    provide: IGetAllPaymentTransactionsByLocationWithPagination,
    useClass: GetAllPaymentTransactionByLocationWithPaginationImpl,
  },
  {
    provide: ISearchAllTransactionsByLocationWithPaginationUseCase,
    useClass: SearchAllTransactionsByLocationWithPaginationUseCaseImpl,
  },
];
