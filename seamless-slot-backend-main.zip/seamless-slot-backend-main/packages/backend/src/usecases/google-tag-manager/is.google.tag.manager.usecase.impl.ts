import { IsGoogleTagMangerConnectedUseCase } from '@seamlessslot/core';
import { RepositoryFactory } from '@seamlessslot/database';
import { Injectable } from '@nestjs/common';

@Injectable()
export class IsGoogleTagManagerUseCaseImpl
  implements IsGoogleTagMangerConnectedUseCase
{
  constructor(private readonly repoFactory: RepositoryFactory) {}

  execute(locationId: number): Promise<Readonly<boolean>> {
    return this.repoFactory.googleTagManagerRepo.isGoogleTagManagerConnected(
      locationId,
    );
  }
}
