import { RepositoryFactory } from '@seamlessslot/database';
import { SecurityContext } from '../../shared/auth/context/security.context';
import { EditGoogleTagManagerUseCase } from '@seamlessslot/core';
import { GoogleTagManager } from '@seamlessslot/core';
import { Injectable } from '@nestjs/common';

@Injectable()
export class EditGoogleTagManagerImpl implements EditGoogleTagManagerUseCase {
  constructor(
    private readonly repoFactory: RepositoryFactory,
    private readonly securityContext: SecurityContext,
  ) {}

  async execute(
    googleTagManagerId: number,
    containerId: string,
    locationId: number,
  ): Promise<Readonly<GoogleTagManager>> {
    return await this.repoFactory.googleTagManagerRepo.update(
      googleTagManagerId,
      {
        createdBy: this.securityContext.getId(),
        deletedBy: 0,
        isActive: true,
        location: locationId,
        updatedBy: this.securityContext.getId(),
        containerId: containerId,
      },
    );
  }
}
