import {
  ICreateGoogleTagManagerUseCase,
  IIsGoogleTagMangerConnectedUseCase,
} from '@seamlessslot/core';
import { CreateGoogleTagManagerImpl } from './create.google.tag.manager.impl';
import { IEditGoogleTagManagerUseCase } from '@seamlessslot/core';
import { EditGoogleTagManagerImpl } from './edit.google.tag.manager.impl';
import { IFindGoogleTagManagerByLocationUseCase } from '@seamlessslot/core';
import { FindGoogleTagManagerByLocationImpl } from './find.google.tag.manager.by.location.impl';
import { IsGoogleTagManagerUseCaseImpl } from './is.google.tag.manager.usecase.impl';

export const GOOGLE_TAG_MANAGER_USECASES = [
  {
    provide: ICreateGoogleTagManagerUseCase,
    useClass: CreateGoogleTagManagerImpl,
  },
  {
    provide: IEditGoogleTagManagerUseCase,
    useClass: EditGoogleTagManagerImpl,
  },
  {
    provide: IIsGoogleTagMangerConnectedUseCase,
    useClass: IsGoogleTagManagerUseCaseImpl,
  },
  {
    provide: IFindGoogleTagManagerByLocationUseCase,
    useClass: FindGoogleTagManagerByLocationImpl,
  },
];
