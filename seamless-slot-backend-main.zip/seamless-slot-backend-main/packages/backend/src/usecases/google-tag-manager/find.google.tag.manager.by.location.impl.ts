import { FindGoogleTagManagerByLocationUseCase } from '@seamlessslot/core';
import { GoogleTagManager } from '@seamlessslot/core';
import { RepositoryFactory } from '@seamlessslot/database';
import { Injectable } from '@nestjs/common';

@Injectable()
export class FindGoogleTagManagerByLocationImpl
  implements FindGoogleTagManagerByLocationUseCase
{
  constructor(private readonly repoFactory: RepositoryFactory) {}

  async execute(
    locationId: number,
  ): Promise<Readonly<GoogleTagManager | null>> {
    return await this.repoFactory.googleTagManagerRepo.findByLocation(
      locationId,
    );
  }
}
