import { RepositoryFactory } from '@seamlessslot/database';
import { SecurityContext } from '../../shared/auth/context/security.context';
import { CreateGoogleTagManagerUseCase } from '@seamlessslot/core';
import { GoogleTagManager } from '@seamlessslot/core';
import { Injectable } from '@nestjs/common';

@Injectable()
export class CreateGoogleTagManagerImpl
  implements CreateGoogleTagManagerUseCase
{
  constructor(
    private readonly repoFactory: RepositoryFactory,
    private readonly securityContext: SecurityContext,
  ) {}

  async execute({
    containerId,
    locationId,
    businessId,
  }: {
    containerId: string;
    locationId: number;
    businessId: number;
  }): Promise<Readonly<GoogleTagManager>> {
    const googleTagManager: GoogleTagManager = {
      containerId,
      location: locationId,
      business: businessId,
      isActive: true,
      createdBy: this.securityContext.getId(),
      updatedBy: 0,
      deletedBy: 0,
    };

    return await this.repoFactory.googleTagManagerRepo.save(googleTagManager);
  }
}
