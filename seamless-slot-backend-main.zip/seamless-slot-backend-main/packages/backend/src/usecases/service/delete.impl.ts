import { Injectable } from '@nestjs/common';
import { RepositoryFactory } from '@seamlessslot/database';
import { DeleteServiceUseCase, Service } from '@seamlessslot/core';
import { SecurityContext } from '../../shared/auth/context/security.context';

@Injectable()
export class DeleteServiceUseCaseImpl implements DeleteServiceUseCase {
  constructor(
    private readonly repoFactory: RepositoryFactory,
    private readonly securityContext: SecurityContext,
  ) {}

  async execute(id: number): Promise<Readonly<Service>> {
    return await this.repoFactory.serviceRepository.delete(
      id,
      this.securityContext.getId(),
    );
  }
}
