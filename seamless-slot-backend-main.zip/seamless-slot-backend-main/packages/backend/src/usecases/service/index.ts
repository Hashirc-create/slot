import { ICreateServiceUseCase } from '@seamlessslot/core';
import { IDeleteServiceUseCase } from '@seamlessslot/core';
import { IGetAllServiceUseCase } from '@seamlessslot/core';
import { IGetServiceByIdUseCase } from '@seamlessslot/core';
import { IGetAllLiveServiceByLocationUseCase } from '@seamlessslot/core';
import { IUpdateServiceUseCase } from '@seamlessslot/core';
import { CreateServiceUseCaseImpl } from './create.impl';
import { DeleteServiceUseCaseImpl } from './delete.impl';
import { GetAllLiveServicesByLocationImpl } from './get.all.live.services.by.location.impl';
import { GetAllServiceUseCaseImpl } from './get.all.impl';
import { GetServiceByIdUseCaseImpl } from './get.by.id.impl';
import { UpdateServiceUseCaseImpl } from './update.impl';
import { IGetAllServicesByLocation } from '@seamlessslot/core';
import { GetAllServicesByLocationImpl } from './get.all.by.location.impl';

export const SERVICE_USECASES = [
  {
    provide: IGetAllLiveServiceByLocationUseCase,
    useClass: GetAllLiveServicesByLocationImpl,
  },
  {
    provide: IGetAllServicesByLocation,
    useClass: GetAllServicesByLocationImpl,
  },
  {
    provide: ICreateServiceUseCase,
    useClass: CreateServiceUseCaseImpl,
  },
  {
    provide: IDeleteServiceUseCase,
    useClass: DeleteServiceUseCaseImpl,
  },
  {
    provide: IUpdateServiceUseCase,
    useClass: UpdateServiceUseCaseImpl,
  },
  {
    provide: IGetAllServiceUseCase,
    useClass: GetAllServiceUseCaseImpl,
  },
  {
    provide: IGetServiceByIdUseCase,
    useClass: GetServiceByIdUseCaseImpl,
  },
];
