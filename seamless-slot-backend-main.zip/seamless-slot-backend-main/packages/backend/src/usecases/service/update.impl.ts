import { Injectable } from '@nestjs/common';
import { RepositoryFactory } from '@seamlessslot/database';
import { Service } from '@seamlessslot/core';
import { UpdateServiceUsecase } from '@seamlessslot/core';

@Injectable()
export class UpdateServiceUseCaseImpl implements UpdateServiceUsecase {
  constructor(private readonly repoFactory: RepositoryFactory) {}
  async execute(id: number, service: Service): Promise<Readonly<Service>> {
    const saved = await this.repoFactory.serviceRepository.update(id, service);
    return saved;
  }
}
