import { Injectable } from '@nestjs/common';
import { RepositoryFactory } from '@seamlessslot/database';
import { Service } from '@seamlessslot/core';
import { GetAllLiveServiceByLocationUseCase } from '@seamlessslot/core';

@Injectable()
export class GetAllLiveServicesByLocationImpl
  implements GetAllLiveServiceByLocationUseCase
{
  constructor(private readonly repoFactory: RepositoryFactory) {}

  async execute(locationId: number): Promise<Readonly<Service[]>> {
    const result =
      await this.repoFactory.serviceRepository.findAllLiveServicesByLocation(
        locationId,
      );

    console.log(result);

    return result;
  }
}
