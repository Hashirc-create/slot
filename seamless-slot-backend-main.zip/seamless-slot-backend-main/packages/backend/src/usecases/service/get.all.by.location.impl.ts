import { Injectable } from '@nestjs/common';
import { RepositoryFactory } from '@seamlessslot/database';
import { Service } from '@seamlessslot/core';
import { GetAllServicesByLocation } from '@seamlessslot/core';

@Injectable()
export class GetAllServicesByLocationImpl implements GetAllServicesByLocation {
  constructor(private readonly repoFactory: RepositoryFactory) {}

  async execute(locationId: number): Promise<Readonly<Service[]>> {
    const result =
      await this.repoFactory.serviceRepository.findAllServicesByLocation(
        locationId,
      );

    return result;
  }
}
