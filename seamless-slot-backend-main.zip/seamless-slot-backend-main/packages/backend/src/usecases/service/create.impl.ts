import { Injectable } from '@nestjs/common';
import { RepositoryFactory } from '@seamlessslot/database';
import { CreateServiceUseCase } from '@seamlessslot/core';
import { Service } from '@seamlessslot/core';

@Injectable()
export class CreateServiceUseCaseImpl implements CreateServiceUseCase {
  constructor(private readonly repoFactory: RepositoryFactory) {}

  async execute(service: Service): Promise<Readonly<Service>> {
    const saved = await this.repoFactory.serviceRepository.save(service);
    return saved;
  }
}
