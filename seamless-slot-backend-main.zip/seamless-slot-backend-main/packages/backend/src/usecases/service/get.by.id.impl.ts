import { Injectable } from '@nestjs/common';
import { RepositoryFactory } from '@seamlessslot/database';
import { Service } from '@seamlessslot/core';
import { GetServiceByIdUseCase } from '@seamlessslot/core';

@Injectable()
export class GetServiceByIdUseCaseImpl implements GetServiceByIdUseCase {
  constructor(private readonly repoFactory: RepositoryFactory) {}
  async execute(id: number): Promise<Readonly<Service>> {
    const serviceFound = await this.repoFactory.serviceRepository.findById(id);
    return serviceFound;
  }
}
