import { Injectable } from '@nestjs/common';
import { RepositoryFactory } from '@seamlessslot/database';
import { Service } from '@seamlessslot/core';
import { GetAllServiceUseCase } from '@seamlessslot/core';

@Injectable()
export class GetAllServiceUseCaseImpl implements GetAllServiceUseCase {
  constructor(private readonly repoFactory: RepositoryFactory) {}
  async execute(
    page: number,
    limit: number,
  ): Promise<
    Readonly<{
      data: Service[];
      total: number;
    }>
  > {
    const allServices =
      await this.repoFactory.serviceRepository.findAllWithPagination(
        page,
        limit,
      );
    return allServices;
  }
}
