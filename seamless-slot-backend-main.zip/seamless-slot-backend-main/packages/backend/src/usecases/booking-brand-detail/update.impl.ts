import { Injectable } from '@nestjs/common';
import { UpdateBookingBrandDetailsUseCase } from '@seamlessslot/core';
import { RepositoryFactory } from '@seamlessslot/database';
import { BookingBrandDetail } from '@seamlessslot/core';

@Injectable()
export class UpdateBookingBrandDetailsUseCaseImpl
  implements UpdateBookingBrandDetailsUseCase
{
  constructor(private readonly repoFactory: RepositoryFactory) {}

  async execute(
    bookingBrandDetail: BookingBrandDetail,
  ): Promise<Readonly<string>> {
    this.repoFactory.bookingBrandDetailRepository.update(
      bookingBrandDetail.id,
      bookingBrandDetail,
    );
    return 'success';
  }
}
