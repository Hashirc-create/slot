import { Injectable } from '@nestjs/common';
import { RepositoryFactory } from '@seamlessslot/database';
import { RegisterBookingBrandDetailUseCase } from '@seamlessslot/core';
import { BookingBrandDetail } from '@seamlessslot/core';

@Injectable()
export class RegisterBookingBrandDetailUseCaseImpl
  implements RegisterBookingBrandDetailUseCase
{
  constructor(private readonly repoFactory: RepositoryFactory) {}
  async execute(
    bookingBrandDetail: BookingBrandDetail,
  ): Promise<BookingBrandDetail> {
    const persistBookingBrandDetail =
      await this.repoFactory.bookingBrandDetailRepository.save(
        bookingBrandDetail,
      );
    return persistBookingBrandDetail;
  }
}
