import { IRegisterBookingBrandDetailUseCase } from '@seamlessslot/core';
import { IUpdateBookingBrandDetailsUseCase } from '@seamlessslot/core';
import { IGetBookingBrandDetailsByLocationUseCase } from '@seamlessslot/core';
import { RegisterBookingBrandDetailUseCaseImpl } from './register.impl';
import { UpdateBookingBrandDetailsUseCaseImpl } from './update.impl';
import { GetBookingBrandDetailByLocationUseCaseImpl } from './get.by.location.impl';
export const BOOKING_BRAND_DETAIL_USECASES = [
  {
    provide: IRegisterBookingBrandDetailUseCase,
    useClass: RegisterBookingBrandDetailUseCaseImpl,
  },
  {
    provide: IUpdateBookingBrandDetailsUseCase,
    useClass: UpdateBookingBrandDetailsUseCaseImpl,
  },
  {
    provide: IGetBookingBrandDetailsByLocationUseCase,
    useClass: GetBookingBrandDetailByLocationUseCaseImpl,
  },
];
