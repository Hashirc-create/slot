import { Injectable } from '@nestjs/common';
import { RepositoryFactory } from '@seamlessslot/database';
import { BookingBrandDetail } from '@seamlessslot/core';
import { GetBookingBrandDetailsByLocationUseCase } from '@seamlessslot/core';

@Injectable()
export class GetBookingBrandDetailByLocationUseCaseImpl
  implements GetBookingBrandDetailsByLocationUseCase
{
  constructor(private readonly repoFactory: RepositoryFactory) {}
  async execute(locationId: number): Promise<BookingBrandDetail> {
    const bookingBrandDetails =
      await this.repoFactory.bookingBrandDetailRepository.findByLocation(
        locationId,
      );

    return bookingBrandDetails;
  }
}
