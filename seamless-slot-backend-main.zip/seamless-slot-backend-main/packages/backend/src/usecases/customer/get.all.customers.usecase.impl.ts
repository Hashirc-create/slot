import { Injectable } from '@nestjs/common';
import { RepositoryFactory } from '@seamlessslot/database';
import { Customer } from '@seamlessslot/core';
import { GetAllCustomerByLocationUseCase } from '@seamlessslot/core';

@Injectable()
export class GetAllCustomerByLocationUseCaseImpl
  implements GetAllCustomerByLocationUseCase
{
  constructor(private readonly repoFactory: RepositoryFactory) {}
  async execute(locationId: number): Promise<Readonly<Customer[]>> {
    return await this.repoFactory.customerRepository.findAllCustomersByLocation(
      locationId,
    );
  }
}
