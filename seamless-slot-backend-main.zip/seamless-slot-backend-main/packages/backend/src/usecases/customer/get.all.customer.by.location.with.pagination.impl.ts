import { Injectable } from '@nestjs/common';
import { RepositoryFactory } from '@seamlessslot/database';
import { GetAllCustomerByLocationWithPaginationUseCase } from '@seamlessslot/core';
import { Customer } from '@seamlessslot/core';

@Injectable()
export class GetAllCustomerByLocationWithPaginationImpl
  implements GetAllCustomerByLocationWithPaginationUseCase
{
  constructor(private readonly repoFactory: RepositoryFactory) {}

  execute(
    locationId: number,
    page: number,
    perPage: number,
  ): Promise<
    Readonly<{
      prev: number;
      next: number;
      last: number;
      pages: number;
      total: number;
      data: Customer[];
    }>
  > {
    return this.repoFactory.customerRepository.findAllCustomersByLocationWithPagination(
      locationId,
      page,
      perPage,
    );
  }
}
