import { Injectable } from '@nestjs/common';
import { RepositoryFactory } from '@seamlessslot/database';
import {
  Appointment,
  Customer,
  GetCustomerByIdUseCase,
  Location,
} from '@seamlessslot/core';
import { SecurityContext } from '../../shared/auth/context/security.context';

@Injectable()
export class GetCustomerByIdUseCaseImpl implements GetCustomerByIdUseCase {
  constructor(
    private readonly repoFactory: RepositoryFactory,
    private readonly securityContext: SecurityContext,
  ) {}

  async execute(id: number, locationId: number): Promise<Readonly<Customer>> {
    console.log(locationId);
    const customer =
      await this.repoFactory.customerRepository.findAllCustomerByIdWithAppointments(
        id,
      );

    const filteredAppointments = (
      customer.appointments as Appointment[]
    ).filter((appointment) => {
      return (appointment.location as Location).id === locationId;
    });

    console.log(filteredAppointments, this.securityContext.getLocationId());

    return {
      ...customer,
      appointments: filteredAppointments,
    };
  }
}
