import { Injectable } from '@nestjs/common';
import { RepositoryFactory } from '@seamlessslot/database';
import { Customer } from '@seamlessslot/core';
import { SearchCustomerWithPaginationUseCase } from '@seamlessslot/core';

@Injectable()
export class SearchCustomerWithPaginationUseCaseImpl
  implements SearchCustomerWithPaginationUseCase
{
  constructor(private readonly repoFactory: RepositoryFactory) {}

  execute(
    locationId: number,
    stringToBeSearched: string,
    page: number,
    limit: number,
  ): Promise<
    Readonly<{
      prev: number;
      next: number;
      last: number;
      pages: number;
      total: number;
      data: Customer[];
    }>
  > {
    return this.repoFactory.customerRepository.searchCustomerWithPagination(
      locationId,
      stringToBeSearched,
      ['firstName', 'lastName', 'email', 'phoneNo'],
      page,
      limit,
    );
  }
}
