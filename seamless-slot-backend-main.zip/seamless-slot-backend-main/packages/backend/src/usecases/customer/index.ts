import { IDeleteCustomerUseCase } from '@seamlessslot/core';
import { IGetAllCustomerByLocationUseCase } from '@seamlessslot/core';
import { IGetCustomerByIdUseCase } from '@seamlessslot/core';
import { IRegisterCustomerUseCase } from '@seamlessslot/core';
import { IUpdateCustomerUseCase } from '@seamlessslot/core';
import { DeleteCustomerUseCaseImpl } from './delete.customer.usecase.impl';
import { GetAllCustomerByLocationUseCaseImpl } from './get.all.customers.usecase.impl';
import { GetCustomerByIdUseCaseImpl } from './get.by.id.customer.usecase.impl';
import { RegisterCustomerUseCaseImpl } from './register.customer.usecase.impl';
import { UpdateCustomerUseCaseImpl } from './update.customer.usecase.impl';
import { IGetAllCustomerByLocationWithPaginationUseCase } from '@seamlessslot/core';
import { GetAllCustomerByLocationWithPaginationImpl } from './get.all.customer.by.location.with.pagination.impl';
import { ISearchCustomerWithPaginationUseCase } from '@seamlessslot/core';
import { SearchCustomerWithPaginationUseCaseImpl } from './search.customer.with.pagination.usecase.impl';

export const CUSTOMER_USECASES = [
  {
    provide: IRegisterCustomerUseCase,
    useClass: RegisterCustomerUseCaseImpl,
  },
  {
    provide: IGetCustomerByIdUseCase,
    useClass: GetCustomerByIdUseCaseImpl,
  },
  {
    provide: IDeleteCustomerUseCase,
    useClass: DeleteCustomerUseCaseImpl,
  },
  {
    provide: IUpdateCustomerUseCase,
    useClass: UpdateCustomerUseCaseImpl,
  },
  {
    provide: IGetAllCustomerByLocationWithPaginationUseCase,
    useClass: GetAllCustomerByLocationWithPaginationImpl,
  },
  {
    provide: IGetAllCustomerByLocationUseCase,
    useClass: GetAllCustomerByLocationUseCaseImpl,
  },
  {
    provide: ISearchCustomerWithPaginationUseCase,
    useClass: SearchCustomerWithPaginationUseCaseImpl,
  },
];
