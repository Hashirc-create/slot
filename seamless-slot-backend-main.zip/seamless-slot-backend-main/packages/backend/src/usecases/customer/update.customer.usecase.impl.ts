import { Injectable } from '@nestjs/common';
import { RepositoryFactory } from '@seamlessslot/database';
import { Customer, UpdateCustomerUseCase } from '@seamlessslot/core';

@Injectable()
export class UpdateCustomerUseCaseImpl implements UpdateCustomerUseCase {
  constructor(private readonly repoFactory: RepositoryFactory) {}
  async execute(id: number, customer: Customer): Promise<Customer> {
    customer.id = id;
    return await this.repoFactory.customerRepository.update(id, customer);
  }
}
