import { Injectable } from '@nestjs/common';
import { RepositoryFactory } from '@seamlessslot/database';
import { RegisterCustomerUseCase } from '@seamlessslot/core';
import { Customer } from '@seamlessslot/core';

@Injectable()
export class RegisterCustomerUseCaseImpl implements RegisterCustomerUseCase {
  constructor(private readonly repoFactory: RepositoryFactory) {}

  async execute(customer: Customer): Promise<Customer> {
    // make sure the role is customer
    customer.role = 'Customer';

    const foundCustomer =
      await this.repoFactory.customerRepository.findCustomerByEmail(
        customer.email,
      );

    if (foundCustomer) {
      await this.repoFactory.customerRepository.bindNewLocationWithCustomer(
        customer.location as number,
        foundCustomer.id,
      );
      return foundCustomer;
    }

    return await this.repoFactory.customerRepository.save(customer);
  }
}
