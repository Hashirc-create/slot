import { Injectable } from '@nestjs/common';
import { RepositoryFactory } from '@seamlessslot/database';
import { Customer, DeleteCustomerUseCase } from '@seamlessslot/core';
import { SecurityContext } from '../../shared/auth/context/security.context';

@Injectable()
export class DeleteCustomerUseCaseImpl implements DeleteCustomerUseCase {
  constructor(
    private readonly repoFactory: RepositoryFactory,
    private readonly securityContext: SecurityContext,
  ) {}

  async execute(id: number): Promise<Customer> {
    return await this.repoFactory.customerRepository.delete(
      id,
      this.securityContext.getId(),
    );
  }
}
