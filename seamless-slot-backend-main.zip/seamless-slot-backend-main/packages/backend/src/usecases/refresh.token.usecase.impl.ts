import { HttpException, HttpStatus, Injectable } from '@nestjs/common';
import { RefreshTokenUseCase } from '@seamlessslot/core';
import { CustomJwtService } from '../shared/auth/service/jwt.service';
import { JWTPayLoad, RefreshPayload } from '../shared/auth/types';
import { Location } from '@seamlessslot/core';
import { BaseResponse } from '../shared/interceptor/response.interceptor';
import { Business } from '@seamlessslot/core';
import { RepositoryFactory } from '@seamlessslot/database';

@Injectable()
export class RefreshTokenUseCaseImpl implements RefreshTokenUseCase {
  constructor(
    private readonly repoFactory: RepositoryFactory,
    private readonly jwtService: CustomJwtService,
  ) {}

  async execute(refreshToken: string) {
    const payload: RefreshPayload =
      this.jwtService.verfiyRefreshToken(refreshToken);

    const user = await this.repoFactory.userRepository.findById(payload.userId);

    if (user.tokenVersion !== payload.tokenVersion)
      throw new HttpException(
        {
          code: 0,
          message: 'invalid refresh token',
          data: 'invalid refresh token',
        } as BaseResponse<string>,
        HttpStatus.UNAUTHORIZED,
      );

    const accessTokenPayload: JWTPayLoad = {
      id: user.id,
      role: user.role,
      firstName: user.firstName,
      lastName: user.lastName,
      email: user.email,
      locationId: (user.location as Location).id,
      businessId: (user.business as Business).id,
      timeZone: (user.location as Location).timeZone,
    };

    const refreshTokenPayload: RefreshPayload = {
      userId: user.id,
      tokenVersion: user.tokenVersion,
      role: user.role,
    };

    const accessToken =
      await this.jwtService.generateAccessToken(accessTokenPayload);

    const newRefreshToken =
      await this.jwtService.generateRefreshToken(refreshTokenPayload);

    return {
      user: user,
      accessToken: accessToken,
      refreshToken: newRefreshToken,
    };
  }
}
