import { Inject, Injectable } from '@nestjs/common';
import { RepositoryFactory } from '@seamlessslot/database';
import { SearchRefundsByLocationWithPaginationUseCase } from '@seamlessslot/core';
import { ISquareApi, SquareApi } from '../../shared/square/square.api.service';
import { SecurityContext } from '../../shared/auth/context/security.context';
import { SquareRefund } from '@seamlessslot/core';

@Injectable()
export class SearchRefundsByLocationWithPaginationUseCaseImpl
  implements SearchRefundsByLocationWithPaginationUseCase
{
  constructor(
    private readonly repoFactory: RepositoryFactory,
    @Inject(ISquareApi)
    public readonly squareApi: SquareApi,
    private readonly securityContext: SecurityContext,
  ) {}

  async execute(
    locationId: number,
    stringToBeSearched: string,
    page: number,
    limit: number,
  ): Promise<
    Readonly<{
      prev: number;
      next: number;
      last: number;
      pages: number;
      total: number;
      data: SquareRefund[];
    }>
  > {
    return await this.repoFactory.refundRepository.searchRefundsWithPagination(
      locationId,
      stringToBeSearched,
      ['status', 'orderId'],
      page,
      limit,
    );
  }
}
