import { Injectable } from '@nestjs/common';
import { RepositoryFactory } from '@seamlessslot/database';
import {
  FindAllRefundsByLocationWithPaginationUseCase,
  SquareRefund,
} from '@seamlessslot/core';
import { TimeZoneService } from '../../shared/utils/timezone.util';
import { SecurityContext } from '../../shared/auth/context/security.context';

@Injectable()
export class FindAllRefundsByLocationWithPaginationUseCaseImpl
  implements FindAllRefundsByLocationWithPaginationUseCase
{
  constructor(
    private readonly repoFactory: RepositoryFactory,
    private readonly timeZoneService: TimeZoneService,
    private readonly securityContext: SecurityContext,
  ) {}

  async execute(
    locationId: number,
    page: number,
    perPage: number,
    startDate: string,
    endDate: string,
  ): Promise<
    Readonly<
      Readonly<{
        prev: number;
        next: number;
        last: number;
        pages: number;
        total: number;
        data: SquareRefund[];
      }>
    >
  > {
    if (startDate === '' && endDate === '')
      return await this.repoFactory.refundRepository.findAllByLocationIdWithPagination(
        locationId,
        page,
        perPage,
      );

    // const startDateConverted = this.timeZoneService.formatDatePreservingUTC(
    //   startDate,
    //   `yyyy-MM-dd'T'HH:mm:ss`,
    // );
    //
    // const endDateConverted = this.timeZoneService.formatISOInSpecifiedTimeZone(
    //   endDate,
    //   `yyyy-MM-dd'T'HH:mm:ss`,
    //   this.securityContext.getTimeZone(),
    // );

    return await this.repoFactory.refundRepository.findAllByLocationIdWithPaginationAndDateRange(
      locationId,
      page,
      perPage,
      startDate,
      endDate,
    );
  }
}
