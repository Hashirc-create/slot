import { Inject, Injectable, Logger } from '@nestjs/common';
import { RepositoryFactory } from '@seamlessslot/database';
import { IssueSquareRefundUseCase } from '@seamlessslot/core';
import { ISquareApi, SquareApi } from '../../shared/square/square.api.service';
import { Appointment } from '@seamlessslot/core';
import { Location } from '@seamlessslot/core';
import { SecurityContext } from '../../shared/auth/context/security.context';
import { SquareRefund } from '@seamlessslot/core';

@Injectable()
export class IssueRefundsUseCaseImpl implements IssueSquareRefundUseCase {
  private logger: Logger = new Logger(IssueRefundsUseCaseImpl.name);

  constructor(
    private readonly repoFactory: RepositoryFactory,
    @Inject(ISquareApi)
    public readonly squareApi: SquareApi,
    private readonly securityContext: SecurityContext,
  ) {}

  async execute(
    paymentTransactionId: number,
    amount: string,
  ): Promise<Readonly<SquareRefund>> {
    const paymentTransaction =
      await this.repoFactory.paymentTransactionRepository.findPaymentTransactionWithAppointmentLocaitonAndService(
        paymentTransactionId,
      );

    const appointment: Appointment =
      paymentTransaction.appointment as Appointment;

    const location: Location = appointment.location as Location;

    const linkedSquareAccount =
      await this.repoFactory.paymentAccountRepository.findPaymentAccountByLocationAndType(
        'Square-Pay',
        location.id,
      );

    const response = await this.squareApi.refundSquareTransaction(
      linkedSquareAccount.accessToken,
      paymentTransaction.squareTransactionId,
      parseFloat(amount) * 100, // square takes amount in cents
    );

    const refund: SquareRefund = {
      refundSquareId: response.refund.id || '',
      status: response.refund.status || '',
      amount: response.refund.amountMoney.amount.toString() || '',
      currency: response.refund.amountMoney.currency || '',
      paymentId: response.refund.paymentId || '',
      orderId: response.refund.paymentId || '',
      squareLocationId: response.refund.locationId || '',
      reason: 'Seamless Slot Amount Refunded',
      remainingBalance: (
        parseFloat(paymentTransaction.companyBalance) -
        parseFloat(amount) * 100
      ).toString(),
      paymentTransaction: paymentTransaction.id as number,
      isActive: true,
      createdBy: this.securityContext.getId(),
      updatedBy: 0,
      deletedBy: 0,
    };

    await this.repoFactory.paymentTransactionRepository.updateCompanyBalance(
      paymentTransaction.id,
      parseFloat(paymentTransaction.companyBalance) - parseFloat(amount),
    );

    return await this.repoFactory.refundRepository.save(refund);
  }
}
