import { Injectable } from '@nestjs/common';
import { RepositoryFactory } from '@seamlessslot/database';
import { UpdateRefundStatusUseCase } from '@seamlessslot/core';
import { SquareRefundUpdatedWebhookResponse } from '@seamlessslot/core';

@Injectable()
export class UpdateRefundStatusUseCaseImpl
  implements UpdateRefundStatusUseCase
{
  constructor(private readonly repoFactory: RepositoryFactory) {}
  async execute(
    payload: SquareRefundUpdatedWebhookResponse,
  ): Promise<Readonly<string>> {
    const refund = await this.repoFactory.refundRepository.findBySquareRefundId(
      payload.data.id,
    );

    if (refund === null) {
      return 'Done Since No Refund Exsist Against Square Webhook Refund Id';
    }

    await this.repoFactory.refundRepository.updateRefundStatus(
      refund.id,
      payload.data.object.refund.status,
    );

    return 'Updated Refund Status Sucessfully';
  }
}
