import { Injectable } from '@nestjs/common';
import { RepositoryFactory } from '@seamlessslot/database';
import { SquareRefund } from '@seamlessslot/core';

import { GetAllSquareRefundsBySquarePaymentTransaction } from '@seamlessslot/core';

@Injectable()
export class GetAllRefundsByPaymentTransactionImpl
  implements GetAllSquareRefundsBySquarePaymentTransaction
{
  constructor(private readonly repoFactory: RepositoryFactory) {}
  async execute(
    paymentTransactionId: number,
  ): Promise<Readonly<SquareRefund[]>> {
    return await this.repoFactory.refundRepository.findAllRefundsAgainstPaymentTransactionId(
      paymentTransactionId,
    );
  }
}
