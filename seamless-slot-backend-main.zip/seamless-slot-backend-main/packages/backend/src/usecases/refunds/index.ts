import {
  IFindAllRefundsByLocationWithPaginationUseCase,
  IGetAllSquareRefundsBySquarePaymentTransaction,
  ISearchRefundsByLocationWithPaginationUseCase,
} from '@seamlessslot/core';
import { IIssueSquareRefundUseCase } from '@seamlessslot/core';
import { IUpdateRefundStatusUseCase } from '@seamlessslot/core';
import { GetAllRefundsByPaymentTransactionImpl } from './get.all.refunds.by.payment.transaction';
import { IssueRefundsUseCaseImpl } from './issue.refund.usecase.impl';
import { UpdateRefundStatusUseCaseImpl } from './update.refund.status.usecase.impl';
import { FindAllRefundsByLocationWithPaginationUseCaseImpl } from './find.all.refunds.by.location.with.pagination.usecase.impl';
import { SearchRefundsByLocationWithPaginationUseCaseImpl } from './search.refunds.by.location.with.pagination.usecase.impl';

export const REFUNDS_USECASES = [
  {
    provide: IIssueSquareRefundUseCase,
    useClass: IssueRefundsUseCaseImpl,
  },
  {
    provide: IUpdateRefundStatusUseCase,
    useClass: UpdateRefundStatusUseCaseImpl,
  },
  {
    provide: IGetAllSquareRefundsBySquarePaymentTransaction,
    useClass: GetAllRefundsByPaymentTransactionImpl,
  },
  {
    provide: IFindAllRefundsByLocationWithPaginationUseCase,
    useClass: FindAllRefundsByLocationWithPaginationUseCaseImpl,
  },
  {
    provide: ISearchRefundsByLocationWithPaginationUseCase,
    useClass: SearchRefundsByLocationWithPaginationUseCaseImpl,
  },
];
