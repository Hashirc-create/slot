import { Injectable } from '@nestjs/common';
import { RepositoryFactory } from '@seamlessslot/database';
import { BookingPolicy } from '@seamlessslot/core';
import { GetBookingPoliciesByLocationUseCase } from '@seamlessslot/core';

@Injectable()
export class GetBookingPolicyByLocationUseCaseImpl
  implements GetBookingPoliciesByLocationUseCase
{
  constructor(private readonly repoFactory: RepositoryFactory) {}
  async execute(locationId: number): Promise<BookingPolicy> {
    const bookingPolicies =
      await this.repoFactory.bookingPolicyRepository.findByLocation(locationId);

    return bookingPolicies;
  }
}
