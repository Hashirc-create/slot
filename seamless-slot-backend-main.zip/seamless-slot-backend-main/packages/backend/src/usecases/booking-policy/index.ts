import { IRegisterBookingPolicyUseCase } from '@seamlessslot/core';
import { IUpdateBookingPoliciesUseCase } from '@seamlessslot/core';
import { IGetBookingPoliciesByLocationUseCase } from '@seamlessslot/core';
import { RegisterBookingPolicyUseCaseImpl } from './register.impl';
import { UpdateBookingPoliciesUseCaseImpl } from './update.impl';
import { GetBookingPolicyByLocationUseCaseImpl } from './get.by.location.impl';
export const BOOKING_POLICY_USECASES = [
  {
    provide: IRegisterBookingPolicyUseCase,
    useClass: RegisterBookingPolicyUseCaseImpl,
  },
  {
    provide: IUpdateBookingPoliciesUseCase,
    useClass: UpdateBookingPoliciesUseCaseImpl,
  },
  {
    provide: IGetBookingPoliciesByLocationUseCase,
    useClass: GetBookingPolicyByLocationUseCaseImpl,
  },
];
