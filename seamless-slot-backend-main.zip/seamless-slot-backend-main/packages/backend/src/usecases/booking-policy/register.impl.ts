import { Injectable } from '@nestjs/common';
import { RepositoryFactory } from '@seamlessslot/database';
import { RegisterBookingPolicyUseCase } from '@seamlessslot/core';
import { BookingPolicy } from '@seamlessslot/core';

@Injectable()
export class RegisterBookingPolicyUseCaseImpl
  implements RegisterBookingPolicyUseCase
{
  constructor(private readonly repoFactory: RepositoryFactory) {}
  async execute(bookingPolicy: BookingPolicy): Promise<BookingPolicy> {
    const persistBookingPolicy =
      await this.repoFactory.bookingPolicyRepository.save(bookingPolicy);
    return persistBookingPolicy;
  }
}
