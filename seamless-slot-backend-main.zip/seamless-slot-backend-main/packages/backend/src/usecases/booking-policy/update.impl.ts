import { Injectable } from '@nestjs/common';
import { UpdateBookingPoliciesUseCase } from '@seamlessslot/core';
import { RepositoryFactory } from '@seamlessslot/database';
import { BookingPolicy } from '@seamlessslot/core';

@Injectable()
export class UpdateBookingPoliciesUseCaseImpl
  implements UpdateBookingPoliciesUseCase
{
  constructor(private readonly repoFactory: RepositoryFactory) {}

  async execute(bookingPolicy: BookingPolicy): Promise<Readonly<string>> {
    this.repoFactory.bookingPolicyRepository.update(
      bookingPolicy.id,
      bookingPolicy,
    );
    return 'success';
  }
}
