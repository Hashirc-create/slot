import { RepositoryFactory } from '@seamlessslot/database';
import { HttpException, HttpStatus } from '@nestjs/common';
import { BaseResponse } from '../../shared/interceptor/response.interceptor';

export class RestrictDoubleBooking {
  private readonly startTime: Date;
  private readonly endTime: Date;
  private readonly repoFactory: RepositoryFactory;

  constructor(startTime: Date, endTime: Date, repoFactory: RepositoryFactory) {
    this.startTime = startTime;
    this.endTime = endTime;
    this.repoFactory = repoFactory;
  }

  async restrictDoubleBooking(): Promise<void> {
    const appointment =
      await this.repoFactory.appointmentRepository.findByStartTimeAndEndTime(
        this.startTime,
        this.endTime,
      );

    console.log(
      appointment,
      this.startTime.toDateString(),
      this.endTime.toDateString(),
    );

    if (appointment !== null && appointment.status === 'Confirmed')
      throw new HttpException(
        {
          code: 0,
          message: 'The selected time slot is already booked.',
          data: null,
        } as BaseResponse<null>,
        HttpStatus.OK,
      );
  }
}
