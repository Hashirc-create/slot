import { RepositoryFactory } from '@seamlessslot/database';
import { GoogleAnalytics } from '@seamlessslot/core';
import { SecurityContext } from '../../shared/auth/context/security.context';
import { EditGoogleAnalyticsUseCase } from '@seamlessslot/core';
import { Injectable } from '@nestjs/common';

@Injectable()
export class EditGoogleAnalyticsImpl implements EditGoogleAnalyticsUseCase {
  constructor(
    private readonly repoFactory: RepositoryFactory,
    private readonly securityContext: SecurityContext,
  ) {}

  async execute(
    googleAnalyticsId: number,
    locationId: number,
    measurementId: string,
  ): Promise<Readonly<GoogleAnalytics>> {
    return await this.repoFactory.googleAnalyticsRepo.update(
      googleAnalyticsId,
      {
        createdBy: this.securityContext.getId(),
        deletedBy: 0,
        isActive: true,
        location: locationId,
        updatedBy: this.securityContext.getId(),
        measurementId,
      },
    );
  }
}
