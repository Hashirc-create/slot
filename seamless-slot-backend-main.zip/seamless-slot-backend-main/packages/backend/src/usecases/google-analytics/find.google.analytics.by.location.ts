import { FindGoogleAnalyticsByLocationUseCase } from '@seamlessslot/core';
import { GoogleAnalytics } from '@seamlessslot/core';
import { Injectable } from '@nestjs/common';
import { RepositoryFactory } from '@seamlessslot/database';

@Injectable()
export class FindGoogleAnalyticsByLocationUseCaseImpl
  implements FindGoogleAnalyticsByLocationUseCase
{
  constructor(private readonly repoFactory: RepositoryFactory) {}

  async execute(locationId: number): Promise<Readonly<GoogleAnalytics | null>> {
    return await this.repoFactory.googleAnalyticsRepo.findByLocation(
      locationId,
    );
  }
}
