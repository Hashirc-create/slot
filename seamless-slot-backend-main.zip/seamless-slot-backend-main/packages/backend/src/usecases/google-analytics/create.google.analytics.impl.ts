import { CreateGoogleAnalyticsUseCase } from '@seamlessslot/core';
import { RepositoryFactory } from '@seamlessslot/database';
import { GoogleAnalytics } from '@seamlessslot/core';
import { SecurityContext } from '../../shared/auth/context/security.context';
import { Injectable } from '@nestjs/common';

@Injectable()
export class CreateGoogleAnalyticsImpl implements CreateGoogleAnalyticsUseCase {
  constructor(
    private readonly repoFactory: RepositoryFactory,
    private readonly securityContext: SecurityContext,
  ) {}

  async execute({
    measurementId,
    locationId,
  }: {
    measurementId: string;
    locationId: number;
  }): Promise<Readonly<GoogleAnalytics>> {
    const googleAnalytics: GoogleAnalytics = {
      measurementId,
      location: locationId,
      isActive: true,
      createdBy: this.securityContext.getId(),
      updatedBy: 0,
      deletedBy: 0,
    };

    return await this.repoFactory.googleAnalyticsRepo.save(googleAnalytics);
  }
}
