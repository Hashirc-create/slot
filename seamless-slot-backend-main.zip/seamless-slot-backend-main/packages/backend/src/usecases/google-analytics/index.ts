import { ICreateGoogleAnalyticsUseCase } from '@seamlessslot/core';
import { CreateGoogleAnalyticsImpl } from './create.google.analytics.impl';
import { IEditGoogleAnalyticsUseCase } from '@seamlessslot/core';
import { EditGoogleAnalyticsImpl } from './edit.google.analytics.impl';
import { IFindGoogleAnalyticsByLocationUseCase } from '@seamlessslot/core';
import { FindGoogleAnalyticsByLocationUseCaseImpl } from './find.google.analytics.by.location';

export const GOOGLE_ANALYTICS_USECASES = [
  {
    provide: ICreateGoogleAnalyticsUseCase,
    useClass: CreateGoogleAnalyticsImpl,
  },
  {
    provide: IEditGoogleAnalyticsUseCase,
    useClass: EditGoogleAnalyticsImpl,
  },
  {
    provide: IFindGoogleAnalyticsByLocationUseCase,
    useClass: FindGoogleAnalyticsByLocationUseCaseImpl,
  },
];
