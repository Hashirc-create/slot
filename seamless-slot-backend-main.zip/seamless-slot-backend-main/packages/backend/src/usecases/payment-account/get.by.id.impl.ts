import { Injectable } from '@nestjs/common';
import { PaymentAccount } from '@seamlessslot/core';
import { GetByIdPaymentAccountUseCase } from '@seamlessslot/core';
import { RepositoryFactory } from '@seamlessslot/database';

@Injectable()
export class GetByIdPaymentAccountUseCaseImpl
  implements GetByIdPaymentAccountUseCase
{
  constructor(private readonly repoFactory: RepositoryFactory) {}
  async execute(id: number): Promise<PaymentAccount> {
    return await this.repoFactory.paymentAccountRepository.findById(id);
  }
}
