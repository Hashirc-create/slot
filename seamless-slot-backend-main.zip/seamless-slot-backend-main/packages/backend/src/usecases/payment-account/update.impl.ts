import { Injectable } from '@nestjs/common';
import { PaymentAccount } from '@seamlessslot/core';
import { RepositoryFactory } from '@seamlessslot/database';
import { UpdatePaymentAccountUseCase } from '@seamlessslot/core';

@Injectable()
export class UpdatePaymentAccountUseCaseImpl
  implements UpdatePaymentAccountUseCase
{
  constructor(private readonly repoFactory: RepositoryFactory) {}
  execute(
    id: number,
    paymentAccount: PaymentAccount,
  ): Promise<Readonly<PaymentAccount>> {
    const updated = this.repoFactory.paymentAccountRepository.update(
      id,
      paymentAccount,
    );
    return updated;
  }
}
