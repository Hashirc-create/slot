// import { Injectable } from '@nestjs/common';
// import { PaymentAccount } from '@seamlessslot/core';
// import { GetAllPaymentAccountsByLocationUseCase } from '../../../contract/use-cases/payment-account/get.all.by.location';
// import { RepositoryFactory } from '@seamlessslot/database';

// @Injectable()
// export class GetPaymentAccountByLocationImpl
//   implements GetPaymentAccountByLocationUseCase
// {
//   constructor(private readonly repoFactory: RepositoryFactory) {}
//   execute(
//     locationId?: number,
//   ): Promise<Readonly<{ data: PaymentAccount[]; total: number }>> {
//     const updated = this.repoFactory.breakRepository.findByLocation(locationId);
//     return updated;
//   }
// }
