import { HttpException, HttpStatus, Injectable } from '@nestjs/common';
import { PaymentAccount } from '@seamlessslot/core';
import { CreateSquarePaymentAccountUseCase } from '@seamlessslot/core';
import { RepositoryFactory } from '@seamlessslot/database';
import { BaseResponse } from '../../shared/interceptor/response.interceptor';

@Injectable()
export class CreateSquarePaymentAccountUseCaseImpl
  implements CreateSquarePaymentAccountUseCase
{
  constructor(private readonly repoFactory: RepositoryFactory) {}

  execute(paymentAccount: PaymentAccount): Promise<Readonly<PaymentAccount>> {
    if (paymentAccount.type !== 'Square-Pay')
      throw new HttpException(
        {
          message: 'Only Square Account Supported',
          data: 'Only Square Account Supported',
          code: 0,
        } as BaseResponse<string>,
        HttpStatus.BAD_REQUEST,
      );
    return this.repoFactory.paymentAccountRepository.save(paymentAccount);
  }
}
