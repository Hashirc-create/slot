import { Inject, Injectable, Logger } from '@nestjs/common';
import {
  DeleteSquarePaymentAccountUseCase,
  PaymentAccount,
} from '@seamlessslot/core';
import { RepositoryFactory } from '@seamlessslot/database';
import { SquareEnvService } from '../../shared/square/square.env.service';
import { ISquareApi, SquareApi } from '../../shared/square/square.api.service';

@Injectable()
export class DeleteSquarePaymentAccountUseCaseImpl
  implements DeleteSquarePaymentAccountUseCase
{
  private readonly logger: Logger = new Logger(
    DeleteSquarePaymentAccountUseCaseImpl.name,
  );

  constructor(
    private readonly repoFactory: RepositoryFactory,
    private readonly squareEnvService: SquareEnvService,
    @Inject(ISquareApi)
    private readonly squareApiService: SquareApi,
  ) {}

  async execute(locationId: number): Promise<Readonly<PaymentAccount>> {
    // Don't revoke tokens
    // const response = await this.squareApiService.revokeAccessToken(
    //   deleted.accessToken,
    // );

    return await this.repoFactory.paymentAccountRepository.deleteSquarePaymentAccount(
      locationId,
    );
  }
}
