import { IBindSquareLocationIdUseCase } from '@seamlessslot/core';
import { ICheckPaymentAccountExists } from '@seamlessslot/core';
import { ICreateSquarePaymentAccountUseCase } from '@seamlessslot/core';
import { IDeletePaymentAccountUseCase } from '@seamlessslot/core';
import { IDeleteSquarePaymentAccountUseCase } from '@seamlessslot/core';
import { IGetByIdPaymentAccountUseCase } from '@seamlessslot/core';
import { IUpdatePaymentAccountUseCase } from '@seamlessslot/core';
import { BindSquareLocationIdUseCaseImpl } from './bind.square.locationid.usecase.impl';
import { CheckPaymentAccountExistUseCaseImpl } from './check-payment-account-exist-use-case-impl.service';
import { CreateSquarePaymentAccountUseCaseImpl } from './create.square.payment.account.usecase.impl';
import { DeletePaymentAccountUseCaseImpl } from './delete.impl';
import { DeleteSquarePaymentAccountUseCaseImpl } from './delete.square.payment.account.usecase.impl';
import { GetByIdPaymentAccountUseCaseImpl } from './get.by.id.impl';
import { UpdatePaymentAccountUseCaseImpl } from './update.impl';
import { ICreateDojoPaymentAccountUseCase } from '@seamlessslot/core';
import { CreateDojoPaymentAccountUseCaseImpl } from './create.dojo.payment.account.usecase.impl';
import { IsSquareConnectedUsecaseImpl } from './is.square.connected.usecase.impl';
import { IIsSquareConnectedUseCase } from '@seamlessslot/core';

export const PAYMENT_ACCOUNT_USECASES = [
  {
    provide: IIsSquareConnectedUseCase,
    useClass: IsSquareConnectedUsecaseImpl,
  },
  {
    provide: ICreateSquarePaymentAccountUseCase,
    useClass: CreateSquarePaymentAccountUseCaseImpl,
  },
  {
    provide: ICreateDojoPaymentAccountUseCase,
    useClass: CreateDojoPaymentAccountUseCaseImpl,
  },
  {
    provide: IDeletePaymentAccountUseCase,
    useClass: DeletePaymentAccountUseCaseImpl,
  },
  {
    provide: IUpdatePaymentAccountUseCase,
    useClass: UpdatePaymentAccountUseCaseImpl,
  },
  {
    provide: IGetByIdPaymentAccountUseCase,
    useClass: GetByIdPaymentAccountUseCaseImpl,
  },
  {
    provide: IBindSquareLocationIdUseCase,
    useClass: BindSquareLocationIdUseCaseImpl,
  },
  {
    provide: ICheckPaymentAccountExists,
    useClass: CheckPaymentAccountExistUseCaseImpl,
  },
  {
    provide: IDeleteSquarePaymentAccountUseCase,
    useClass: DeleteSquarePaymentAccountUseCaseImpl,
  },
];
