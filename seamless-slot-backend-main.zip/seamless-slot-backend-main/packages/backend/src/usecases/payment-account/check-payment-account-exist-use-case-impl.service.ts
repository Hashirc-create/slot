import { Injectable } from '@nestjs/common';
import { RepositoryFactory } from '@seamlessslot/database';
import { CheckPaymentAccountExists } from '@seamlessslot/core';
import { PaymentAccountType } from '@seamlessslot/core';

@Injectable()
export class CheckPaymentAccountExistUseCaseImpl
  implements CheckPaymentAccountExists
{
  constructor(private readonly repoFactory: RepositoryFactory) {}

  async execute(locationId: number): Promise<
    Readonly<
      {
        type: PaymentAccountType;
        isConnected: boolean;
      }[]
    >
  > {
    const squareAccount =
      await this.repoFactory.paymentAccountRepository.findPaymentAccountByLocationAndType(
        'Square-Pay',
        locationId,
      );

    const dojoAccount =
      await this.repoFactory.paymentAccountRepository.findPaymentAccountByLocationAndType(
        'Dojo',
        locationId,
      );

    return [
      {
        type: 'Square-Pay',
        isConnected: squareAccount !== null,
      },
      {
        type: 'Dojo',
        isConnected: dojoAccount !== null,
      },
    ];
  }
}
