import { Injectable } from '@nestjs/common';
import { PaymentAccount } from '@seamlessslot/core';
import { RepositoryFactory } from '@seamlessslot/database';
import { BindSquareLocationIdUseCase } from '@seamlessslot/core';

@Injectable()
export class BindSquareLocationIdUseCaseImpl
  implements BindSquareLocationIdUseCase
{
  constructor(private readonly repoFactory: RepositoryFactory) {}
  async execute(
    squareLocationId: string,
    locationId: number,
  ): Promise<Readonly<PaymentAccount>> {
    const paymentAccount =
      await this.repoFactory.paymentAccountRepository.findPaymentAccountByLocationAndType(
        'Square-Pay',
        locationId,
      );

    paymentAccount.squareDefaultLocationId = squareLocationId;

    const updatedPaymentLocation =
      this.repoFactory.paymentAccountRepository.update(
        paymentAccount.id,
        paymentAccount,
      );
    return updatedPaymentLocation;
  }
}
