import { Injectable } from '@nestjs/common';
import { RepositoryFactory } from '@seamlessslot/database';
import { IsSquareConnectedUseCase } from '@seamlessslot/core';

@Injectable()
export class IsSquareConnectedUsecaseImpl implements IsSquareConnectedUseCase {
  constructor(private readonly repoFactory: RepositoryFactory) {}

  async execute(locationId: number): Promise<
    Readonly<{
      status: boolean;
      squareLocationId: string;
    }>
  > {
    const paymentAccount =
      await this.repoFactory.paymentAccountRepository.checkPaymentAccountExist(
        'Square-Pay',
        locationId,
      );

    if (paymentAccount === null) {
      return {
        status: false,
        squareLocationId: '',
      };
    }

    return {
      status: true,
      squareLocationId: paymentAccount.squareDefaultLocationId,
    };
  }
}
