import { HttpException, HttpStatus, Injectable } from '@nestjs/common';
import { PaymentAccount } from '@seamlessslot/core';
import { RepositoryFactory } from '@seamlessslot/database';
import { CreateDojoPaymentAccountUseCase } from '@seamlessslot/core';
import { BaseResponse } from '../../shared/interceptor/response.interceptor';

@Injectable()
export class CreateDojoPaymentAccountUseCaseImpl
  implements CreateDojoPaymentAccountUseCase
{
  constructor(private readonly repoFactory: RepositoryFactory) {}

  async execute(
    paymentAccount: PaymentAccount,
  ): Promise<Readonly<PaymentAccount>> {
    const paymentAccountSquare =
      await this.repoFactory.paymentAccountRepository.findPaymentAccountByLocationAndType(
        'Square-Pay',
        paymentAccount.location as number,
      );

    if (paymentAccountSquare)
      throw new HttpException(
        {
          message: 'Square Account Already Linked With This Location',
          data: 'Square Account Already Linked With This Location',
          code: 0,
        } as BaseResponse<string>,
        HttpStatus.OK,
      );

    if (paymentAccount.type !== 'Dojo')
      throw new HttpException(
        {
          message: 'Only Square Account Supported',
          data: 'Only Square Account Supported',
          code: 0,
        } as BaseResponse<string>,
        HttpStatus.BAD_REQUEST,
      );

    // not required in case of dojo payment;
    paymentAccount.refreshToken = '';
    paymentAccount.squareDefaultLocationId = '';

    return this.repoFactory.paymentAccountRepository.save(paymentAccount);
  }
}
