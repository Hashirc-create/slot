import { Injectable } from '@nestjs/common';
import {
  DeletePaymentAccountUseCase,
  PaymentAccount,
} from '@seamlessslot/core';
import { RepositoryFactory } from '@seamlessslot/database';
import { SecurityContext } from '../../shared/auth/context/security.context';

@Injectable()
export class DeletePaymentAccountUseCaseImpl
  implements DeletePaymentAccountUseCase
{
  constructor(
    private readonly repoFactory: RepositoryFactory,
    private readonly securityContext: SecurityContext,
  ) {}

  execute(id: number): Promise<Readonly<PaymentAccount>> {
    return this.repoFactory.paymentAccountRepository.delete(
      id,
      this.securityContext.getId(),
    );
  }
}
