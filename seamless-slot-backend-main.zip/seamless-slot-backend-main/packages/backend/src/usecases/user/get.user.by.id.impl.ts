import { Injectable } from '@nestjs/common';
import { User } from '@seamlessslot/core';
import { GetUserByIdUseCase } from '@seamlessslot/core';
import { RepositoryFactory } from '@seamlessslot/database';

@Injectable()
export class GetUserByIdUseCaseImpl implements GetUserByIdUseCase {
  constructor(private readonly repoFactory: RepositoryFactory) {}
  async execute(id: number): Promise<User> {
    return await this.repoFactory.userRepository.findById(id);
  }
}
