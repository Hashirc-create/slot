import { HttpException, HttpStatus, Injectable } from '@nestjs/common';
import { RegisterAdminUseCase, User } from '@seamlessslot/core';
import { RepositoryFactory } from '@seamlessslot/database';
import { BaseResponse } from '../../shared/interceptor/response.interceptor';

@Injectable()
export class RegisterAdminUseCaseImpl implements RegisterAdminUseCase {
  constructor(private readonly repoFactory: RepositoryFactory) {}

  async execute(user: User): Promise<User> {
    const foundUser = await this.repoFactory.userRepository.findByEmail(
      user.email,
    );

    if (foundUser !== null)
      throw new HttpException(
        {
          code: 0,
          message: 'User with this email Already Exists',
          data: 'User with this email Already Exists',
        } as BaseResponse<string>,
        HttpStatus.BAD_REQUEST,
      );

    // just making sure that the role is admin
    user.role = 'Admin';

    return await this.repoFactory.userRepository.save(user);
  }
}
