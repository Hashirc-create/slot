import { Injectable } from '@nestjs/common';
import { GetAllUsersUseCase } from '@seamlessslot/core';
import { RepositoryFactory } from '@seamlessslot/database';
import { User } from '@seamlessslot/core';

@Injectable()
export class GetAllUsersUseCaseImpl implements GetAllUsersUseCase {
  constructor(private readonly repoFactory: RepositoryFactory) {}
  async execute(
    page: number,
    limit: number,
  ): Promise<{
    totalRecords: number;
    data: User[];
  }> {
    const { data, total } =
      await this.repoFactory.userRepository.findAllWithPagination(page, limit);

    return {
      totalRecords: total,
      data: data,
    };
  }
}
