import { HttpException, HttpStatus, Injectable } from '@nestjs/common';
import { LoginUserUseCase } from '@seamlessslot/core';
import { User } from '@seamlessslot/core';
import { comparePassword } from '../../shared/utils/encrypt.util';
import { CustomJwtService } from '../../shared/auth/service/jwt.service';
import { JWTPayLoad, RefreshPayload } from '../../shared/auth/types';
import { RepositoryFactory } from '@seamlessslot/database';
import { Location } from '@seamlessslot/core';
import { BaseResponse } from '../../shared/interceptor/response.interceptor';
import { Business } from '@seamlessslot/core';

@Injectable()
export class LoginUserUseCaseImpl implements LoginUserUseCase {
  constructor(
    private readonly repoFactory: RepositoryFactory,
    private readonly jwtService: CustomJwtService,
  ) {}

  async execute(
    email: string,
    password: string,
  ): Promise<{
    user: User;
    accessToken: string;
    refreshToken: string;
  }> {
    const user = await this.repoFactory.userRepository.findByEmail(email);

    if (user === null)
      throw new HttpException(
        {
          code: 0,
          message: 'Invalid Credentials',
          data: 'Invalid Credentials',
        } as BaseResponse<string>,
        HttpStatus.UNAUTHORIZED,
      );

    if (!user.isActive)
      throw new HttpException(
        {
          code: 0,
          message: 'Your account is inactive please contact admin',
          data: 'Your account is inactive please contact admin',
        } as BaseResponse<string>,
        HttpStatus.UNAUTHORIZED,
      );
    const isMatch = comparePassword(password, user.password);

    if (!isMatch)
      throw new HttpException(
        {
          code: 0,
          message: 'Invalid Credentials',
          data: 'Invalid Credentials',
        } as BaseResponse<string>,
        HttpStatus.UNAUTHORIZED,
      );

    const accessTokenPayload: JWTPayLoad = {
      id: user.id,
      role: user.role,
      firstName: user.firstName,
      lastName: user.lastName,
      email: user.email,
      locationId: (user.location as Location).id,
      timeZone: (user.location as Location).timeZone,
      businessId: (user.business as Business).id,
    };

    const refreshTokenPayload: RefreshPayload = {
      userId: user.id,
      tokenVersion: user.tokenVersion,
      role: user.role,
    };

    const accessToken =
      await this.jwtService.generateAccessToken(accessTokenPayload);

    const refreshToken =
      await this.jwtService.generateRefreshToken(refreshTokenPayload);

    return {
      user: user,
      accessToken: accessToken,
      refreshToken: refreshToken,
    };
  }
}
