import { Injectable } from '@nestjs/common';
import { RepositoryFactory } from '@seamlessslot/database';
import { User } from '@seamlessslot/core';
import { GetAllAdminsByLocationUseCase } from '@seamlessslot/core';

@Injectable()
export class GetAllAdminsByLocationUseCaseImpl
  implements GetAllAdminsByLocationUseCase
{
  constructor(private readonly repoFactory: RepositoryFactory) {}
  async execute(locationId: number): Promise<User[]> {
    const adminsByLocation =
      await this.repoFactory.userRepository.findAllAdminsByLocation(locationId);
    return adminsByLocation;
  }
}
