import { Injectable } from '@nestjs/common';
import { UpdateUserUseCase } from '@seamlessslot/core';
import { RepositoryFactory } from '@seamlessslot/database';
import { User } from '@seamlessslot/core';

@Injectable()
export class UpdateUserUseCaseImpl implements UpdateUserUseCase {
  constructor(private readonly repoFactory: RepositoryFactory) {}
  execute(id: number, user: User): Promise<User> {
    const updatedUser = this.repoFactory.userRepository.update(id, user);
    return updatedUser;
  }
}
