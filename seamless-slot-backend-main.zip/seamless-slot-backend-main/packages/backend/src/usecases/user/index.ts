import { IBlockUserUseCase } from '@seamlessslot/core';
import { IGetAllAdminsByLocationUseCase } from '@seamlessslot/core';
import { IGetAllUsersUseCase } from '@seamlessslot/core';
import { IGetUserByIdUseCase } from '@seamlessslot/core';
import { IHardDeleteUserUseCase } from '@seamlessslot/core';
import { ILoginUserUseCase } from '@seamlessslot/core';
import { IRegisterAdminUseCase } from '@seamlessslot/core';
import { IUpdateUserUseCase } from '@seamlessslot/core';
import { BlockUserUseCaseImpl } from './block.user.impl';
import { GetAllAdminsByLocationUseCaseImpl } from './get.all.admins.by.location.impl';
import { GetAllUsersUseCaseImpl } from './get.all.users.impl';
import { GetUserByIdUseCaseImpl } from './get.user.by.id.impl';
import { HardDeleteUserUseCaseImpl } from './hard.delete.user.usecase.impl';
import { LoginUserUseCaseImpl } from './login.user.impl';
import { RegisterAdminUseCaseImpl } from './register.user.impl';
import { UpdateUserUseCaseImpl } from './update.user.impl';
import { IUpdateUserProfileUseCase } from '@seamlessslot/core';
import { UpdateUserProfileImpl } from './update.user.profile.impl';

export const USER_USECASES = [
  {
    provide: IRegisterAdminUseCase,
    useClass: RegisterAdminUseCaseImpl,
  },
  {
    provide: ILoginUserUseCase,
    useClass: LoginUserUseCaseImpl,
  },
  {
    provide: IGetAllUsersUseCase,
    useClass: GetAllUsersUseCaseImpl,
  },
  {
    provide: IGetUserByIdUseCase,
    useClass: GetUserByIdUseCaseImpl,
  },
  {
    provide: IUpdateUserUseCase,
    useClass: UpdateUserUseCaseImpl,
  },
  {
    provide: IBlockUserUseCase,
    useClass: BlockUserUseCaseImpl,
  },
  {
    provide: IHardDeleteUserUseCase,
    useClass: HardDeleteUserUseCaseImpl,
  },
  {
    provide: IUpdateUserProfileUseCase,
    useClass: UpdateUserProfileImpl,
  },
  {
    provide: IGetAllAdminsByLocationUseCase,
    useClass: GetAllAdminsByLocationUseCaseImpl,
  },
];
