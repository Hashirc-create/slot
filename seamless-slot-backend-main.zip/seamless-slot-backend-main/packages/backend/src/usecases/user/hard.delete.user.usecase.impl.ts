import { Injectable } from '@nestjs/common';
import { User } from '@seamlessslot/core';
import { RepositoryFactory } from '@seamlessslot/database';
import { HardDeleteUserUseCase } from '@seamlessslot/core';

@Injectable()
export class HardDeleteUserUseCaseImpl implements HardDeleteUserUseCase {
  constructor(private readonly repoFactory: RepositoryFactory) {}
  async execute(id: number): Promise<User> {
    const user = await this.repoFactory.userRepository.hardDeleteUserById(id);
    return user;
  }
}
