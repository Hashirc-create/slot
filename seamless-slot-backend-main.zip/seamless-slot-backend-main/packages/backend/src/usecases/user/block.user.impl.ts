import { Injectable } from '@nestjs/common';
import { BlockUserUseCase, User } from '@seamlessslot/core';
import { RepositoryFactory } from '@seamlessslot/database';
import { SecurityContext } from '../../shared/auth/context/security.context';

@Injectable()
export class BlockUserUseCaseImpl implements BlockUserUseCase {
  constructor(
    private readonly repoFactory: RepositoryFactory,
    private securityContext: SecurityContext,
  ) {}

  async execute(id: number): Promise<User> {
    return await this.repoFactory.userRepository.block(
      id,
      this.securityContext.getId(),
    );
  }
}
