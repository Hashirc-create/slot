import { HttpException, HttpStatus, Injectable } from '@nestjs/common';
import { RepositoryFactory } from '@seamlessslot/database';
import { User } from '@seamlessslot/core';
import { UpdateUserProfileUseCase } from '@seamlessslot/core';
import { SecurityContext } from '../../shared/auth/context/security.context';
import { encrypt } from '../../shared/utils/encrypt.util';
import { BaseResponse } from '../../shared/interceptor/response.interceptor';

@Injectable()
export class UpdateUserProfileImpl implements UpdateUserProfileUseCase {
  constructor(
    private readonly repoFactory: RepositoryFactory,
    private readonly securityContext: SecurityContext,
  ) {}

  async execute(
    id: number,
    valuesToUpdate: {
      firstName: string;
      lastName: string;
      email: string;
      password: string;
      confirmPassword: string;
      phoneNo: string;
    },
  ): Promise<User> {
    if (
      this.securityContext.getRole() === 'Admin' &&
      this.securityContext.getId() !== id
    )
      throw new HttpException(
        {
          code: 0,
          message:
            'Admin users are only allowed to change their own respective profiles',
          data: 'Admin users are only allowed to change their own respective profiles',
        } as BaseResponse<string>,
        HttpStatus.OK,
      );

    const userFound = await this.repoFactory.userRepository.findByEmail(
      valuesToUpdate.email,
    );

    if (userFound && id !== userFound.id)
      throw new HttpException(
        {
          message: 'User already registered against the provided email ',
          data: 'User already registered against the provided email ',
          code: 0,
        } as BaseResponse<string>,
        HttpStatus.OK,
      );

    if (valuesToUpdate.password !== valuesToUpdate.confirmPassword)
      throw new HttpException(
        {
          message: 'Password do not match',
          data: 'Password do not match',
          code: 0,
        } as BaseResponse<string>,
        HttpStatus.OK,
      );

    if (valuesToUpdate.password === '') {
      return this.repoFactory.userRepository.updateUserProfile(id, {
        firstName: valuesToUpdate.firstName,
        lastName: valuesToUpdate.lastName,
        email: valuesToUpdate.email,
        phoneNo: valuesToUpdate.phoneNo,
      });
    } else {
      return this.repoFactory.userRepository.updateUserProfile(id, {
        firstName: valuesToUpdate.firstName,
        lastName: valuesToUpdate.lastName,
        email: valuesToUpdate.email,
        password: await encrypt(valuesToUpdate.password),
        phoneNo: valuesToUpdate.phoneNo,
      });
    }
  }
}
