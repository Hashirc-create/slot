import { Injectable } from '@nestjs/common';
import { RepositoryFactory } from '@seamlessslot/database';
import { WorkingDay } from '@seamlessslot/core';
import { GetAllWorkDaysByLocationUseCase } from '@seamlessslot/core';

@Injectable()
export class GetAllWorkingDayByLocationUseCaseImpl
  implements GetAllWorkDaysByLocationUseCase
{
  constructor(private readonly repoFactory: RepositoryFactory) {}
  async execute(locationId: number): Promise<WorkingDay[]> {
    return await this.repoFactory.workingDayRepository.findAllByLocation(
      locationId,
    );
  }
}
