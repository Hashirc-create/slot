import { HttpException, HttpStatus, Injectable } from '@nestjs/common';
import { RegisterWorkingDayUseCase } from '@seamlessslot/core';
import { RepositoryFactory } from '@seamlessslot/database';
import { WorkingDay } from '@seamlessslot/core';
import { BaseResponse } from '../../shared/interceptor/response.interceptor';

@Injectable()
export class RegisterWorkingDayUseCaseImpl
  implements RegisterWorkingDayUseCase
{
  constructor(private readonly repoFactory: RepositoryFactory) {}

  async execute(workingDay: WorkingDay): Promise<WorkingDay> {
    const foundWorkingDay =
      await this.repoFactory.workingDayRepository.findByLocationAndDay(
        workingDay.location as number,
        workingDay.day,
      );

    if (foundWorkingDay !== null)
      throw new HttpException(
        {
          message: 'Working Day already exists Against : ' + workingDay.day,
          data: 'Working Day already exists Against : ' + workingDay.day,
          code: 0,
        } as BaseResponse<string>,
        HttpStatus.BAD_REQUEST,
      );

    return await this.repoFactory.workingDayRepository.save(workingDay);
  }
}
