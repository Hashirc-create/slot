import { Injectable } from '@nestjs/common';
import { RepositoryFactory } from '@seamlessslot/database';
import { WorkingDay } from '@seamlessslot/core';
import { GetAllWorkingDaysByLocationIncludeBreaks } from '@seamlessslot/core';

@Injectable()
export class GetAllWorkingDaysByLocationIncludeBreaksImpl
  implements GetAllWorkingDaysByLocationIncludeBreaks
{
  constructor(private readonly repoFactory: RepositoryFactory) {}
  async execute(locationId: number): Promise<WorkingDay[]> {
    return await this.repoFactory.workingDayRepository.findAllByLocationIncludeBreaks(
      locationId,
    );
  }
}
