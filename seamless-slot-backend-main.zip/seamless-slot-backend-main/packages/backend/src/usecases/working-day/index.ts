import { IRegisterWorkingDayUseCase } from '@seamlessslot/core';
import { IUpdateWorkingDaysUseCase } from '@seamlessslot/core';
import { IGetAllWorkDaysByLocationUseCase } from '@seamlessslot/core';
import { RegisterWorkingDayUseCaseImpl } from './register.impl';
import { UpdateWorkingDaysUseCaseImpl } from './update.impl';
import { GetAllWorkingDayByLocationUseCaseImpl } from './get.all.by.location.impl';
import { IGetAllWorkingDaysByLocationIncludeBreaks } from '@seamlessslot/core';
import { GetAllWorkingDaysByLocationIncludeBreaksImpl } from './get.all.by.location.include.breaks.impl';

export const WORKING_DAYS_USECASES = [
  {
    provide: IRegisterWorkingDayUseCase,
    useClass: RegisterWorkingDayUseCaseImpl,
  },
  {
    provide: IUpdateWorkingDaysUseCase,
    useClass: UpdateWorkingDaysUseCaseImpl,
  },
  {
    provide: IGetAllWorkDaysByLocationUseCase,
    useClass: GetAllWorkingDayByLocationUseCaseImpl,
  },
  {
    provide: IGetAllWorkingDaysByLocationIncludeBreaks,
    useClass: GetAllWorkingDaysByLocationIncludeBreaksImpl,
  },
];
