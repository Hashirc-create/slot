import { Injectable } from '@nestjs/common';
import { UpdateWorkingDaysUseCase } from '@seamlessslot/core';
import { RepositoryFactory } from '@seamlessslot/database';
import { WorkingDay } from '@seamlessslot/core';
import { SecurityContext } from '../../shared/auth/context/security.context';
import { TimeZoneService } from '../../shared/utils/timezone.util';

@Injectable()
export class UpdateWorkingDaysUseCaseImpl implements UpdateWorkingDaysUseCase {
  constructor(
    private readonly repoFactory: RepositoryFactory,
    private readonly securityContext: SecurityContext,
    private readonly timeZoneService: TimeZoneService,
  ) {}

  async execute(workingDays: WorkingDay[]): Promise<Readonly<string>> {
    for (const workingDay of workingDays) {
      const prevWorkingDay =
        await this.repoFactory.workingDayRepository.findById(workingDay.id);

      const prevFromFormatted = this.timeZoneService.formatDatePreservingUTC(
        prevWorkingDay.from as Date,
        'HH:mm',
      );

      const prevToFormatted = this.timeZoneService.formatDatePreservingUTC(
        prevWorkingDay.to as Date,
        'HH:mm',
      );

      const newFromFormatted = this.timeZoneService.formatDatePreservingUTC(
        new Date(workingDay.from),
        'HH:mm',
      );

      const newToFormatted = this.timeZoneService.formatDatePreservingUTC(
        new Date(workingDay.to),
        'HH:mm',
      );

      console.log(prevWorkingDay.day);
      console.log(prevFromFormatted, newFromFormatted);
      console.log(prevToFormatted, newToFormatted);

      console.log('---------');

      if (
        prevFromFormatted !== newFromFormatted ||
        prevToFormatted !== newToFormatted ||
        prevWorkingDay.isClosed !== workingDay.isClosed
      )
        await this.repoFactory.workingDayHistoryRepo.save({
          day: workingDay.day,
          prevFrom: prevWorkingDay.from,
          prevTo: prevWorkingDay.to,
          prevIsClosed: prevWorkingDay.isClosed,
          newFrom: workingDay.from,
          newTo: workingDay.to,
          newIsClosed: workingDay.isClosed,
          location: prevWorkingDay.location as number,
          business: prevWorkingDay.business as number,

          isActive: true,
          createdBy: this.securityContext.getId(),
          updatedBy: 0,
          deletedBy: 0,
        });
    }

    const updatedPromises = workingDays.map((workingDay) => {
      this.repoFactory.workingDayRepository.update(workingDay.id, workingDay);
    });

    await Promise.all(updatedPromises);

    return 'success';
  }
}
