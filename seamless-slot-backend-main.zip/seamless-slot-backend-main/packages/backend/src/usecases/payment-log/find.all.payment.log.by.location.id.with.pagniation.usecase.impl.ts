import { Injectable } from '@nestjs/common';
import { PaymentLog } from '@seamlessslot/core';
import { RepositoryFactory } from '@seamlessslot/database';
import { FindAllPaymentLogByLocationIdWithPagination } from '@seamlessslot/core/dist/use-cases/payment-log';
import { TimeZoneService } from '../../shared/utils/timezone.util';
import { SecurityContext } from '../../shared/auth/context/security.context';

@Injectable()
export class FindAllPaymentLogByLocationIdWithPaginationUseCaseImpl
  implements FindAllPaymentLogByLocationIdWithPagination
{
  constructor(
    private readonly repoFactory: RepositoryFactory,
    private readonly timeZoneService: TimeZoneService,
    private readonly securityContext: SecurityContext,
  ) {}

  execute(
    locationId: number,
    page: number,
    perPage: number,
    startDate: string,
    endDate: string,
  ): Promise<
    Readonly<
      Readonly<{
        prev: number;
        next: number;
        last: number;
        pages: number;
        total: number;
        data: PaymentLog[];
      }>
    >
  > {
    if (startDate === '' && endDate === '')
      return this.repoFactory.paymentLogRepository.findAllByLocationIdWithPagination(
        locationId,
        page,
        perPage,
      );

    // const startDateConverted =
    //   this.timeZoneService.formatISOInSpecifiedTimeZone(
    //     startDate,
    //     `yyyy-MM-dd'T'HH:mm:ss`,
    //     this.securityContext.getTimeZone(),
    //   );
    //
    // const endDateConverted = this.timeZoneService.formatISOInSpecifiedTimeZone(
    //   endDate,
    //   `yyyy-MM-dd'T'HH:mm:ss`,
    //   this.securityContext.getTimeZone(),
    // );

    return this.repoFactory.paymentLogRepository.findAllByLocationIdByDateRangeWithPagination(
      locationId,
      page,
      perPage,
      startDate,
      endDate,
    );
  }
}
