import { Injectable } from '@nestjs/common';
import { PaymentLog } from '@seamlessslot/core';
import { RepositoryFactory } from '@seamlessslot/database';
import { FindPaymentLogByAppointmentId } from '@seamlessslot/core/dist/use-cases/payment-log';

@Injectable()
export class FindAllPaymentLogByAppointmentIdUseCaseImpl
  implements FindPaymentLogByAppointmentId
{
  constructor(private readonly repoFactory: RepositoryFactory) {}

  async execute(appointmentId: number): Promise<Readonly<PaymentLog[]>> {
    return await this.repoFactory.paymentLogRepository.findAllByAppointmentId(
      appointmentId,
    );
  }
}
