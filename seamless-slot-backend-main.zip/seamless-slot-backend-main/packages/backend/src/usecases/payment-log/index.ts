import {
  IFindAllPaymentLogByLocationIdWithPagination,
  IFindPaymentLogByAppointmentId,
  ISearchPaymentLogByLocationIdWithPagination,
} from '@seamlessslot/core/dist/use-cases/payment-log';
import { FindAllPaymentLogByAppointmentIdUseCaseImpl } from './find.all.payment.log.by.appointment.id.usecase.impl';
import { FindAllPaymentLogByLocationIdWithPaginationUseCaseImpl } from './find.all.payment.log.by.location.id.with.pagniation.usecase.impl';
import { SearchPaymentLogByLocationIdWithPagniationUseCaseImpl } from './search.payment.log.by.location.id.with.pagniation.usecase.impl';

export const PAYMENT_LOG_USECASES = [
  {
    provide: IFindPaymentLogByAppointmentId,
    useClass: FindAllPaymentLogByAppointmentIdUseCaseImpl,
  },
  {
    provide: IFindAllPaymentLogByLocationIdWithPagination,
    useClass: FindAllPaymentLogByLocationIdWithPaginationUseCaseImpl,
  },
  {
    provide: ISearchPaymentLogByLocationIdWithPagination,
    useClass: SearchPaymentLogByLocationIdWithPagniationUseCaseImpl,
  },
];
