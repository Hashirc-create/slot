import { Injectable } from '@nestjs/common';
import { PaymentLog } from '@seamlessslot/core';
import { RepositoryFactory } from '@seamlessslot/database';
import { SearchPaymentLogByLocationIdWithPagination } from '@seamlessslot/core/dist/use-cases/payment-log';

@Injectable()
export class SearchPaymentLogByLocationIdWithPagniationUseCaseImpl
  implements SearchPaymentLogByLocationIdWithPagination
{
  constructor(private readonly repoFactory: RepositoryFactory) {}

  execute(
    locationId: number,
    stringToBeSearched: string,
    page: number,
    limit: number,
  ): Promise<
    Readonly<{
      prev: number;
      next: number;
      last: number;
      pages: number;
      total: number;
      data: PaymentLog[];
    }>
  > {
    return this.repoFactory.paymentLogRepository.searchPaymentLogWithPagination(
      locationId,
      stringToBeSearched,
      ['transactionId', 'orderId', 'status', 'errorCode', 'last4Digits'],
      page,
      limit,
    );
  }
}
