import { HttpException, HttpStatus, Injectable } from '@nestjs/common';
import { RepositoryFactory } from '@seamlessslot/database';
import {
  AppointmentStatus,
  DashboardForLocationResponse,
  GetDashboardForLocation,
} from '@seamlessslot/core';
import { BaseResponse } from '../../shared/interceptor/response.interceptor';

type DataItem = { month: string; status: string; count: number };
type DataItemRevenue = { month: string; service: string; revenue: number };

@Injectable()
export class GetDashboardForLocationImpl implements GetDashboardForLocation {
  constructor(private readonly repoFactory: RepositoryFactory) {}

  async execute(
    locationId: number,
  ): Promise<Readonly<DashboardForLocationResponse>> {
    const location =
      await this.repoFactory.locationRepository.findById(locationId);

    if (location.status === 'Inactive') {
      throw new HttpException(
        {
          code: 0,
          message: 'Location is Inactive',
          data: null,
        } as BaseResponse<null>,
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }

    const allServices = (
      await this.repoFactory.serviceRepository.findAllLiveServicesByLocation(
        locationId,
      )
    ).map((service) => service.title);

    const last6MonthRevenue =
      await this.repoFactory.dashboardRepository.getLastSixMonthsRevenueForLocation(
        locationId,
      );

    const totalAppointmentThisMonthByWeekDays =
      await this.repoFactory.dashboardRepository.getCurrentMonthAppointmentsByWeek(
        locationId,
      );

    let allAppointmentsByMonth =
      await this.repoFactory.dashboardRepository.getAllTimeAppointmentsAgainstStatus(
        locationId,
      );

    let allAppointmentsRevenueByMonth =
      await this.repoFactory.dashboardRepository.getAllTimeAppointmentsRevenueAgainstService(
        locationId,
      );

    allAppointmentsByMonth = this.fillMissingMonthsOnStatus(
      allAppointmentsByMonth,
    );

    allAppointmentsRevenueByMonth = await this.fillMissingMonthsOnService(
      allAppointmentsRevenueByMonth,
      allServices,
    );

    return {
      currency: '£',
      allTimeRevenue: (
        await this.repoFactory.dashboardRepository.getAllTimeRevenueForLocation(
          locationId,
        )
      ).toFixed(2),
      earnings: 87,
      totalAppointmentThisMonthByWeekDays: {
        weekdays: totalAppointmentThisMonthByWeekDays.map((item) => item.day),
        count: totalAppointmentThisMonthByWeekDays.map((item) => item.count),
      },
      thisMonthRevenue: (
        await this.repoFactory.dashboardRepository.getCurrentMonthRevenueForLocation(
          locationId,
        )
      ).toFixed(2),
      last6monthRevenue: {
        'x-axis': { categories: last6MonthRevenue.map((item) => item.month) },
        'y-axis': [
          {
            name: 'Earnings',
            data: last6MonthRevenue.map((item) => item.revenue.toFixed(2)),
          },
        ],
      },
      revenueTrend: {
        'x-axis': { categories: last6MonthRevenue.map((item) => item.month) },
        'y-axis': [
          {
            name: 'Earnings',
            data: last6MonthRevenue.map((item) => item.revenue.toFixed(2)),
          },
        ],
      },
      totalAllTimeAppointments:
        await this.repoFactory.dashboardRepository.getAllTimeTotalAppointmentsForLocation(
          locationId,
        ),
      totalAllTimeRefunds:
        await this.repoFactory.dashboardRepository.getAllTimeTotalRefundsForLocation(
          locationId,
        ),
      totalAllTimeCustomers:
        await this.repoFactory.dashboardRepository.getAllTimeTotalCustomersForLocation(
          locationId,
        ),
      conversionRate:
        (
          await this.repoFactory.dashboardRepository.getConversionRateForLocationCurrentMonth(
            locationId,
          )
        ).toFixed(2) + '%',
      cancellationRate:
        (
          await this.repoFactory.dashboardRepository.getCancellationRateForLocationCurrentMonth(
            locationId,
          )
        ).toFixed(2) + '%',
      noShowRate:
        (
          await this.repoFactory.dashboardRepository.getNoShowRateForLocationCurrentMonth(
            locationId,
          )
        ).toFixed() + '%',
      appointmentByStatusAllTime: {
        appointments: [
          {
            name: 'Cancelled' as AppointmentStatus,
            data: allAppointmentsByMonth
              .filter(
                (item) => item.status === ('Cancelled' as AppointmentStatus),
              )
              .map((item) => Number(item.count)),
          },
          {
            name: 'Complete' as AppointmentStatus,
            data: allAppointmentsByMonth
              .filter(
                (item) => item.status === ('Complete' as AppointmentStatus),
              )
              .map((item) => Number(item.count)),
          },
          {
            name: 'Confirmed' as AppointmentStatus,
            data: allAppointmentsByMonth
              .filter(
                (item) => item.status === ('Confirmed' as AppointmentStatus),
              )
              .map((item) => Number(item.count)),
          },
          {
            name: 'No Show' as AppointmentStatus,
            data: allAppointmentsByMonth
              .filter(
                (item) => item.status === ('No Show' as AppointmentStatus),
              )
              .map((item) => Number(item.count)),
          },
          {
            name: 'Pending' as AppointmentStatus,
            data: allAppointmentsByMonth
              .filter(
                (item) => item.status === ('Pending' as AppointmentStatus),
              )
              .map((item) => Number(item.count)),
          },
          {
            name: 'Follow Up' as AppointmentStatus,
            data: allAppointmentsByMonth
              .filter(
                (item) => item.status === ('Follow Up' as AppointmentStatus),
              )
              .map((item) => Number(item.count)),
          },
        ],
        colors: [
          `rgba(244, 106, 106, 1)`,
          `rgba(52, 195, 143, 1)`,
          `rgba(85, 109, 230, 1)`,
          `rgba(0, 0, 0, 1)`,
          `rgba(241, 180, 76, 1)`,
          `rgba(235, 52, 204, 1)`,
        ],
      },
      appointmentRevenueByServiceAllTime: {
        appointments: allServices.map((service) => {
          return {
            name: service,
            data: allAppointmentsRevenueByMonth
              .filter((item) => item.service === service)
              .map((item) => item.revenue.toFixed(2)),
          };
        }),
        colors: [
          'rgba(255, 99, 71, 1)', // Tomato Red
          'rgba(72, 61, 139, 1)', // Dark Slate Blue
          'rgba(255, 165, 0, 1)', // Orange
          'rgba(60, 179, 113, 1)', // Medium Sea Green
          'rgba(123, 104, 238, 1)', // Medium Slate Blue
          'rgba(255, 20, 147, 1)', // Deep Pink
          'rgba(70, 130, 180, 1)', // Steel Blue
          'rgba(189, 183, 107, 1)', // Dark Khaki
          'rgba(255, 105, 180, 1)', // Hot Pink
          'rgba(0, 206, 209, 1)', // Dark Turquoise
        ],
      },
    };
  }

  fillMissingMonthsOnStatus(data: DataItem[]): DataItem[] {
    // List of all months in sequence
    const allMonths = [
      'Jan',
      'Feb',
      'Mar',
      'Apr',
      'May',
      'Jun',
      'Jul',
      'Aug',
      'Sep',
      'Oct',
      'Nov',
      'Dec',
    ];

    // Possible statuses
    const allStatuses: AppointmentStatus[] = [
      'Cancelled',
      'Complete',
      'Confirmed',
      'No Show',
      'Pending',
      'Follow Up',
    ];

    // Create a map of the existing data categorized by month and status
    const dataMap: Record<string, Record<string, number>> = {};
    data.forEach((item) => {
      if (!dataMap[item.month]) {
        dataMap[item.month] = {};
      }
      dataMap[item.month][item.status] = item.count;
    });

    // Result array
    const completeData: DataItem[] = [];

    // Iterate through all months and for each ensure all statuses are included
    allMonths.forEach((month) => {
      // Check if the month exists in the current dataset
      const monthData = dataMap[month] || {};

      // Iterate through all possible statuses
      allStatuses.forEach((status) => {
        completeData.push({
          month,
          status,
          count: monthData[status] || 0, // Assign existing count or default to 0
        });
      });
    });

    return completeData;
  }

  async fillMissingMonthsOnService(
    data: DataItemRevenue[],
    allServices: string[],
  ): Promise<DataItemRevenue[]> {
    // List of all months in sequence
    const allMonths = [
      'Jan',
      'Feb',
      'Mar',
      'Apr',
      'May',
      'Jun',
      'Jul',
      'Aug',
      'Sep',
      'Oct',
      'Nov',
      'Dec',
    ];

    // Create a map of the existing data categorized by month and status
    const dataMap: Record<string, Record<string, number>> = {};
    data.forEach((item) => {
      if (!dataMap[item.month]) {
        dataMap[item.month] = {};
      }
      dataMap[item.month][item.service] = item.revenue;
    });

    // Result array
    const completeData: DataItemRevenue[] = [];

    // Iterate through all months and for each ensure all statuses are included
    allMonths.forEach((month) => {
      // Check if the month exists in the current dataset
      const monthData = dataMap[month] || {};

      // Iterate through all possible statuses
      allServices.forEach((service) => {
        completeData.push({
          month,
          service,
          revenue: monthData[service] || 0, // Assign existing count or default to 0
        });
      });
    });

    return completeData;
  }
}
