import { IGetDashboardForLocation } from '@seamlessslot/core';
import { GetDashboardForLocationImpl } from './get.dashboard.for.location.impl';

export const DASHBOARD_USECASES = [
  {
    provide: IGetDashboardForLocation,
    useClass: GetDashboardForLocationImpl,
  },
];
