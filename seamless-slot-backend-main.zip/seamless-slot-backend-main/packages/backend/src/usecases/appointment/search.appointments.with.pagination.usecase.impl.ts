import { Injectable } from '@nestjs/common';
import { Appointment } from '@seamlessslot/core';
import { RepositoryFactory } from '@seamlessslot/database';
import { SearchAppointmentsWithPaginationUseCase } from '@seamlessslot/core';

@Injectable()
export class SearchAppointmentsWithPaginationUseCaseImpl
  implements SearchAppointmentsWithPaginationUseCase
{
  constructor(private readonly repoFactory: RepositoryFactory) {}

  async execute(
    locationId: number,
    stringToBeSearched: string,
    page: number,
    limit: number,
  ): Promise<
    Readonly<{
      prev: number;
      next: number;
      last: number;
      pages: number;
      total: number;
      data: Appointment[];
    }>
  > {
    return await this.repoFactory.appointmentRepository.searchAppointmentWithPagination(
      locationId,
      stringToBeSearched,
      ['status'],
      ['firstName', 'lastName', 'email'],
      page,
      limit,
    );
  }
}
