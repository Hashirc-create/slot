import { HttpException, Inject, Injectable } from '@nestjs/common';
import {
  Appointment,
  Business,
  ChangeAppointmentDataTimeUseCase,
  Customer,
  Location,
  Service,
  SquarePaymentTransaction,
} from '@seamlessslot/core';
import { RepositoryFactory } from '@seamlessslot/database';
import { TimeZoneService } from '../../shared/utils/timezone.util';
import { SecurityContext } from '../../shared/auth/context/security.context';
import {
  EmailGateway,
  IEmailGateway,
} from '../../shared/gateways/email/email.gateway';
import { getAppointmentChangeTemplate } from '../../shared/gateways/templates/appointmentChanged';
import { BaseResponse } from '../../shared/interceptor/response.interceptor';
import {
  ISmsServiceSeamlessSlot,
  SmsServiceSeamlessSlot,
} from '@seamlessslot/sms/dist/src/sms.service';

@Injectable()
export class ChangeAppointmentDateTimeUseCaseImpl
  implements ChangeAppointmentDataTimeUseCase
{
  constructor(
    private readonly repoFactory: RepositoryFactory,
    private readonly timeZoneService: TimeZoneService,
    @Inject(IEmailGateway)
    private readonly emailService: EmailGateway,
    @Inject(ISmsServiceSeamlessSlot)
    private readonly smsService: SmsServiceSeamlessSlot,
    private readonly securityContext: SecurityContext,
  ) {}

  async execute(
    id: number,
    startTime: string,
    endTime: string,
  ): Promise<Readonly<Appointment>> {
    const oldAppointment =
      await this.repoFactory.appointmentRepository.findById(id);

    if (oldAppointment.status === 'Cancelled')
      throw new HttpException(
        {
          code: 0,
          message: 'Cancelled Appointment Can not be Updated!!!',
          data: 'Cancelled Appointment Can not be Updated!!!',
        } as BaseResponse<string>,
        500,
      );

    const newAppointment =
      await this.repoFactory.appointmentRepository.changeAppointmentDateTime(
        id,
        startTime,
        endTime,
        startTime,
      );

    const business = await this.repoFactory.businessRepository.findById(
      newAppointment.business as number,
    );

    this.sendAppointmentChangeEmail(newAppointment, oldAppointment, business);
    this.sendAppointmentChangeSms(business, newAppointment, oldAppointment);

    return newAppointment;
  }

  sendAppointmentChangeSms(
    business: Business,
    appointment: Appointment,
    oldAppointment: Appointment,
  ) {
    const location = appointment.location as Location;

    const customer = appointment.customer as Customer;

    const oldAppointmentDate = this.timeZoneService.formatDatePreservingUTC(
      oldAppointment.startTime as Date,
      'dd MMM yyyy',
    );

    const oldAppointmentStartTime =
      this.timeZoneService.formatDatePreservingUTC(
        oldAppointment.startTime as Date,
        'hh:mm aa',
      );

    const newAppointmentDate = this.timeZoneService.formatDatePreservingUTC(
      appointment.startTime as Date,
      'dd MMM yyyy',
    );

    const newAppointmentStartTime =
      this.timeZoneService.formatDatePreservingUTC(
        appointment.startTime as Date,
        'hh:mm aa',
      );

    this.smsService.sendAppointmentRescheduleSms({
      to: customer.phoneNo,
      customerFirstName: customer.firstName,
      customerLastName: customer.lastName,
      businessName: business.name,
      locationName: location.name,
      locationAddress: location.address,
      oldAppointmentDate: oldAppointmentDate,
      oldAppointmentStartTime: oldAppointmentStartTime,
      newAppointmentDate: newAppointmentDate,
      newAppointmentStartTime: newAppointmentStartTime,
      telephone: location.telephone,
    });
  }

  sendAppointmentChangeEmail(
    appointment: Appointment,
    oldAppointment: Appointment,
    business: Business,
  ) {
    const location = appointment.location as Location;
    const service = appointment.service as Service;
    const payment = appointment.payments as SquarePaymentTransaction;
    const customer = appointment.customer as Customer;

    const oldAppointmentDate = this.timeZoneService.formatDatePreservingUTC(
      oldAppointment.startTime as Date,
      'dd MMM yyyy',
    );

    const oldAppointmentStartTime =
      this.timeZoneService.formatDatePreservingUTC(
        oldAppointment.startTime as Date,
        'hh:mm aa',
      );

    const oldAppointmentEndTime = this.timeZoneService.formatDatePreservingUTC(
      oldAppointment.endTime as Date,
      'hh:mm aa',
    );

    const newAppointmentDate = this.timeZoneService.formatDatePreservingUTC(
      appointment.startTime as Date,
      'dd MMM yyyy',
    );

    const newAppointmentStartTime =
      this.timeZoneService.formatDatePreservingUTC(
        appointment.startTime as Date,
        'hh:mm aa',
      );

    const newAppointmentEndTime = this.timeZoneService.formatDatePreservingUTC(
      appointment.endTime as Date,
      'hh:mm aa',
    );

    // dd MMM yyyy hh:mm aa

    this.emailService.sendEmailFromInfo({
      title: business.name,
      to: customer.email,
      subject: 'Appointment Update',
      html: getAppointmentChangeTemplate({
        businessName: business.name,
        bookingId: appointment.id.toString(),
        service: service.title,
        duration: service.durationInMinutes.toString(),
        cost: service.cost.toString(),
        oldDate: oldAppointmentDate,
        oldTime: oldAppointmentStartTime,
        oldDateTime:
          this.timeZoneService.formatDatePreservingUTC(
            oldAppointment.startTime as Date,
            'dd MMM yyyy hh:mm aa',
          ) +
          ' - ' +
          oldAppointmentEndTime,
        newDate: newAppointmentDate,
        newTime: newAppointmentStartTime,
        newDateTime:
          this.timeZoneService.formatDatePreservingUTC(
            appointment.startTime as Date,
            'dd MMM yyyy hh:mm aa',
          ) +
          ' - ' +
          newAppointmentEndTime,
        customerName: customer.firstName + ' ' + customer.lastName,
        customerEmail: customer.email,
        customerPhone: customer.phoneNo,
        amountCharged: payment
          ? (parseFloat(payment.amount) / 100).toString()
          : '0',
        locationPhoneNo: location.telephone,
        locationAddress: location.address,
        gmapUrl: location.googleMapUrl,
      }),
    });
  }
}
