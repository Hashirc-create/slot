import { Injectable } from '@nestjs/common';
import { RepositoryFactory } from '@seamlessslot/database';
import { CheckAppointmentDetailUseCase } from '@seamlessslot/core/dist/use-cases/appointment/check.appointment.detail';
import { SquarePaymentTransaction } from '@seamlessslot/core';

@Injectable()
export class CheckAppointmentDetailImpl
  implements CheckAppointmentDetailUseCase
{
  constructor(private readonly repoFactory: RepositoryFactory) {}

  async execute(appointmentId: number): Promise<
    Readonly<{
      hasRefunds: boolean;
      hasPayments: boolean;
      hasPaymentLogs: boolean;
    }>
  > {
    const appointmentFound =
      await this.repoFactory.appointmentRepository.findAppointmentDetailsById(
        appointmentId,
      );

    if (appointmentFound.payments === null) {
      return {
        hasRefunds: false,
        hasPayments: false,
        hasPaymentLogs: appointmentFound.paymentLogs.length !== 0,
      };
    }

    return {
      hasPayments: true,
      hasRefunds:
        (appointmentFound.payments as SquarePaymentTransaction).refunds
          .length !== 0,
      hasPaymentLogs: appointmentFound.paymentLogs.length !== 0,
    };
  }
}
