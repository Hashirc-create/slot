import { HttpException, HttpStatus, Inject, Injectable } from '@nestjs/common';
import {
  Appointment,
  Business,
  FollowUpAppointmentCreatedEmail,
} from '@seamlessslot/core';
import { CreateAppointmentUseCase } from '@seamlessslot/core';
import { RepositoryFactory } from '@seamlessslot/database';
import { AppointmentWithPendingPaymentPayload } from '@seamlessslot/core';
import { TimeZoneService } from '../../shared/utils/timezone.util';
import { SecurityContext } from '../../shared/auth/context/security.context';
import {
  EmailGateway,
  IEmailGateway,
} from '../../shared/gateways/email/email.gateway';
import { getAppointmentWithPendingStatusTemplate } from '../../shared/gateways/templates/appointmentPaymentPending';
import { ISquareApi, SquareApi } from '../../shared/square/square.api.service';
import { Customer } from '@seamlessslot/core';
import { Service } from '@seamlessslot/core';
import { Location } from '@seamlessslot/core';
import { BaseResponse } from '../../shared/interceptor/response.interceptor';
import { getFollowUpAppointmentCreatedTemplate } from '../../shared/gateways/templates/followUpAppointmentCreated';
import {
  ISmsServiceSeamlessSlot,
  SmsServiceSeamlessSlot,
} from '@seamlessslot/sms/dist/src/sms.service';
import { UTILS } from '../../shared/utils/utils.util';

@Injectable()
export class CreateAppointmentUseCaseImpl implements CreateAppointmentUseCase {
  constructor(
    private readonly repoFactory: RepositoryFactory,
    @Inject(ISquareApi)
    private readonly squareApiService: SquareApi,
    private readonly timeZoneService: TimeZoneService,
    @Inject(IEmailGateway)
    private readonly emailService: EmailGateway,
    @Inject(ISmsServiceSeamlessSlot)
    private readonly smsService: SmsServiceSeamlessSlot,
    private readonly securityContext: SecurityContext,
  ) {}

  async execute(appointment: Appointment): Promise<Readonly<Appointment>> {
    if (appointment.status === 'Follow Up') {
      appointment.squareOrderId = '';
      const savedAppointment =
        await this.repoFactory.appointmentRepository.save(appointment);

      const [business, customer, location] = await Promise.all([
        this.repoFactory.businessRepository.findById(
          savedAppointment.business as number,
        ),
        this.repoFactory.customerRepository.findById(
          savedAppointment.customer as number,
        ),
        this.repoFactory.locationRepository.findById(
          savedAppointment.location as number,
        ),
      ]);

      this.sendFollowUpAppointmentCreatedEmail(
        business,
        customer.email,
        'Your Followup Appointment Has Been Confirmed',
        {
          businessName: business.name,
          locationName: location.name,
          patientPhone: customer.phoneNo,
          patientFullName: customer.firstName + ' ' + customer.lastName,
          appointmentTime:
            this.timeZoneService.formatDatePreservingUTC(
              appointment.startTime as Date,
              'hh:mm aa',
            ) +
            ' - ' +
            this.timeZoneService.formatDatePreservingUTC(
              appointment.endTime as Date,
              'hh:mm aa',
            ),
          appointmentDate: this.timeZoneService.formatDatePreservingUTC(
            appointment.startTime as Date,
            'dd MMM, yyyy',
          ),
          locationAddress: location.address,
          gmapUrl: location.googleMapUrl,
        },
      );

      return savedAppointment;
    }

    const customer = await this.repoFactory.customerRepository.findById(
      appointment.customer as number,
    );

    const location = await this.repoFactory.locationRepository.findById(
      appointment.location as number,
    );

    const service = await this.repoFactory.serviceRepository.findById(
      appointment.service as number,
    );

    const business = await this.repoFactory.businessRepository.findById(
      appointment.business as number,
    );

    const squarePaymentAccount =
      await this.repoFactory.paymentAccountRepository.findPaymentAccountByLocationAndType(
        'Square-Pay',
        appointment.location as number,
      );

    if (!squarePaymentAccount) {
      throw new HttpException(
        {
          code: 0,
          message: 'Payment Account Not Linked',
          data: 'Payment Account Not Linked',
        } as BaseResponse<string>,
        HttpStatus.OK,
      );
    }

    // TODO need to remove this column from prisma schema
    appointment.squareOrderId = '';

    const savedAppointment =
      await this.repoFactory.appointmentRepository.save(appointment);

    const paymentLink: string = UTILS.getPaymentLinkShortURL(
      savedAppointment.id.toString(),
    );

    this.sendPaymentLinkEmail(
      business,
      location,
      customer,
      paymentLink,
      savedAppointment,
      service,
    );
    this.sendPaymentLinkSms(
      business,
      customer,
      paymentLink,
      savedAppointment,
      location,
    );

    return savedAppointment;
  }

  async sendPaymentLinkSms(
    business: Business,
    customer: Customer,
    paymentLink: string,
    appointment: Appointment,
    location: Location,
  ) {
    this.smsService.sendPaymentLinkSmsAdminCreatedAppointmentSms({
      to: customer.phoneNo,
      customerFirstName: customer.firstName,
      customerLastName: customer.lastName,
      businessName: business.name,
      locationName: location.name,
      locationAddress: location.address,
      appointmentDate: this.timeZoneService.formatDatePreservingUTC(
        appointment.startTime as Date,
        'EEEE dd MMM yyyy',
      ),
      appointmentStartTime: this.timeZoneService.formatDatePreservingUTC(
        appointment.startTime as Date,
        'hh:mm a',
      ),
      paymentLink: paymentLink,
    });
  }

  async sendPaymentLinkEmail(
    business: Business,
    location: Location,
    customer: Customer,
    paymentLink: string,
    appointment: Appointment,
    service: Service,
  ) {
    // EEEE dd MMMM yyyy hh:mm aa
    const templatePayload: AppointmentWithPendingPaymentPayload = {
      businessName: business.name,
      fullName: customer.firstName + ' ' + customer.lastName,
      paymentLink: paymentLink,
      bookingId: appointment.id.toString(),
      service: service.title,
      duration: service.durationInMinutes.toString(),
      cost: service.cost.toString(),
      dateTimeOfAppointment:
        this.timeZoneService.formatDatePreservingUTC(
          appointment.startTime as Date,
          'EEEE dd MMMM yyyy hh:mm aa',
        ) +
        ' - ' +
        this.timeZoneService.formatDatePreservingUTC(
          appointment.endTime as Date,
          'hh:mm aa',
        ),
      customerName: customer.firstName + ' ' + customer.lastName,
      customerEmail: customer.email,
      customerPhone: customer.phoneNo,
      amountCharged: service.cost.toString(),
      locationAddress: location.address,
      gmapUrl: location.googleMapUrl,
    };

    await this.emailService.sendEmailFromInfo({
      title: business.name,
      to: customer.email,
      subject: 'Seamless Slot Appointment Booking (Pending Payment)',
      bcc: '',
      html: getAppointmentWithPendingStatusTemplate(templatePayload),
    });
  }

  async sendFollowUpAppointmentCreatedEmail(
    business: Business,
    to: string,
    subject: string,
    payload: FollowUpAppointmentCreatedEmail,
  ) {
    await this.emailService.sendEmailFromInfo({
      title: business.name,
      to,
      subject,
      bcc: '',
      html: getFollowUpAppointmentCreatedTemplate(payload),
    });
  }
}
