import { Injectable } from '@nestjs/common';
import { Appointment } from '@seamlessslot/core';
import { DeleteAppointmentUseCase } from '@seamlessslot/core';
import { RepositoryFactory } from '@seamlessslot/database';
import { SecurityContext } from '../../shared/auth/context/security.context';

@Injectable()
export class DeleteAppointmentUseCaseImpl implements DeleteAppointmentUseCase {
  constructor(
    private readonly repoFactory: RepositoryFactory,
    private readonly securityContext: SecurityContext,
  ) {}

  execute(id: number): Promise<Readonly<Appointment>> {
    return this.repoFactory.appointmentRepository.delete(
      id,
      this.securityContext.getId(),
    );
  }
}
