// import {
//   HttpException,
//   HttpStatus,
//   Inject,
//   Injectable,
//   Logger,
// } from '@nestjs/common';
// import { Appointment, Business, User } from '@seamlessslot/core';
// import { RepositoryFactory } from '@seamlessslot/database';
// import { CreatePublicAppointmentUseCase } from '@seamlessslot/core';
// import { ApiResponse, CreatePaymentResponse, Error } from 'square';
// import { SquareEnvService } from '../../shared/square/square.env.service';
// import { randomUUID } from 'crypto';
// import { Currency, SupportedPaymentMethods } from '@seamlessslot/core';
// import { Customer } from '@seamlessslot/core';
// import {
//   EmailGateway,
//   IEmailGateway,
// } from '../../shared/gateways/email/email.gateway';
// import { getAppointmentConfirmedTemplate } from '../../shared/gateways/templates/appointmentConfirmed';
// import { TimeZoneService } from '../../shared/utils/timezone.util';
// import { SecurityContext } from '../../shared/auth/context/security.context';
// import { getPaymentReceiptTemplate } from '../../shared/gateways/templates/paymentReceipt';
// import { Service } from '@seamlessslot/core';
// import { PaymentAccount } from '@seamlessslot/core';
// import { SmsService } from '../../shared/sms/sms.service';
// import { Location } from '@seamlessslot/core';
// import { WebSocketService } from '../../shared/websocket/websocket.service';
// import { CONSTANTS } from '../../shared/utils/constants';
// import { getAppointmentCreatedAdminEmailTemplate } from '../../shared/gateways/templates/publicAppointmentCreated';
// import { SquarePaymentTransaction } from '@seamlessslot/core';
// import { BaseResponse } from '../../shared/interceptor/response.interceptor';
// import { ConfigService } from '@nestjs/config';
//
// @Injectable()
// export class CreatePublicAppointmentUseCaseImpl
//   implements CreatePublicAppointmentUseCase
// {
//   private logger: Logger = new Logger(CreatePublicAppointmentUseCaseImpl.name);
//
//   constructor(
//     private readonly repoFactory: RepositoryFactory,
//     private readonly squareEnvService: SquareEnvService,
//     @Inject(IEmailGateway) private readonly emailGateway: EmailGateway,
//     private readonly timeZoneService: TimeZoneService,
//     private readonly smsService: SmsService,
//     private readonly webSocketService: WebSocketService,
//     private readonly securityContext: SecurityContext,
//     private readonly configService: ConfigService,
//   ) {}
//
//   async execute(
//     appointment: Appointment,
//     customer: Customer,
//     squareSourceId: string,
//     paymentMethod: SupportedPaymentMethods,
//   ): Promise<Readonly<Appointment>> {
//     const linkedSquareAccount =
//       await this.repoFactory.paymentAccountRepository.findPaymentAccountByLocationAndType(
//         'Square-Pay',
//         appointment.location as number,
//       );
//
//     if (linkedSquareAccount === null)
//       throw new HttpException(
//         {
//           code: 0,
//           message:
//             'Square Payment Account not linked for the provided location',
//           data: 'Square Payment Account not linked for the provided location',
//         } as BaseResponse<string>,
//         HttpStatus.OK,
//       );
//
//     const service = await this.repoFactory.serviceRepository.findById(
//       appointment.service as number,
//     );
//
//     let foundCustomer =
//       await this.repoFactory.customerRepository.findCustomerByEmail(
//         customer.email,
//       );
//
//     if (foundCustomer === null) {
//       customer.location = appointment.location;
//       foundCustomer = await this.repoFactory.customerRepository.save(customer);
//     } else {
//       await this.repoFactory.customerRepository.bindNewLocationWithCustomer(
//         appointment.location as number,
//         foundCustomer.id,
//       );
//     }
//
//     appointment.status = 'Confirmed';
//     appointment.customer = foundCustomer.id;
//     appointment.squareOrderId = 'already paid';
//
//     const savedAppointment =
//       await this.repoFactory.appointmentRepository.save(appointment);
//
//     //make square payment
//     const result: ApiResponse<CreatePaymentResponse> =
//       await this.makeSquarePayment(
//         squareSourceId,
//         linkedSquareAccount,
//         service.cost * 100, // since square takes amount in cents
//         customer,
//         savedAppointment,
//       );
//
//     const savedPaymentTransaction =
//       await this.saveSeamlessSlotPaymentTransaction(
//         result,
//         linkedSquareAccount,
//         customer,
//         paymentMethod,
//         savedAppointment,
//       );
//
//     const associatedLocation =
//       await this.repoFactory.locationRepository.findById(
//         appointment.location as number,
//       );
//
//     await Promise.all([
//       this.sendAppointmentConfirmedEmail(customer, savedAppointment, service),
//       this.sendPaymentReceiptEmail(
//         business,
//         customer,
//         savedAppointment,
//         service,
//         paymentMethod,
//         savedPaymentTransaction,
//       ),
//       this.sendConfirmationSms(customer, savedAppointment, associatedLocation),
//     ]);
//
//     this.repoFactory.notificationRepository.save({
//       isActive: true,
//       isMarkedRead: false,
//       title: `Appointment Booked By ${customer.firstName} ${customer.lastName} `,
//       appointmentStartTime: savedAppointment.startTime,
//       createdBy: 0,
//       customerName: customer.firstName + ' ' + customer.lastName,
//       deletedBy: 0,
//       updatedBy: 0,
//       location: appointment.location as number,
//     });
//
//     this.webSocketService.server.emit(
//       CONSTANTS.WEBSOCKETS_EVENTS.PUBLIC_APPOINTMENT_CREATED,
//       { location: appointment.location as number },
//     );
//
//     const admins: User[] =
//       await this.repoFactory.userRepository.findAllAdminsByLocation(
//         associatedLocation.id,
//       );
//
//     admins.forEach((admin) => {
//       this.sendAdminEmail(
//         admin.email,
//         associatedLocation,
//         customer,
//         savedAppointment,
//         service,
//       );
//     });
//
//     if (this.configService.get('NODE_ENV') === 'production') {
//       this.sendAdminEmail(
//         `rizwan.malik@seamlessideas.co.uk`,
//         associatedLocation,
//         customer,
//         savedAppointment,
//         service,
//       );
//     }
//
//     // return appoiintment with service and customer and payment
//     return this.repoFactory.appointmentRepository.findAppointmentByIdWithServiceLocationPayment(
//       savedAppointment.id,
//     );
//   }
//
//   async sendConfirmationSms(
//     customer: Customer,
//     savedAppointment: Appointment,
//     location: Location,
//   ) {
//     return this.smsService.sendSms(
//       customer.phoneNo,
//       '+447462428776',
//       `Hi ${customer.firstName + ' ' + customer.lastName}, thanks for booking with us at Night and Day Dentist. Your appointment is confirmed for ${this.timeZoneService.formatISOInSpecifiedTimeZone(
//         savedAppointment.startTime as string,
//         'EEEE dd MMM yyyy',
//         this.securityContext.getTimeZone() || 'Europe/London',
//       )} at ${this.timeZoneService.formatISOInSpecifiedTimeZone(
//         savedAppointment.startTime as string,
//         'hh:mm a',
//         this.securityContext.getTimeZone() || 'Europe/London',
//       )}.See you then! Any questions? Call us at ${location.telephone}.`,
//     );
//   }
//
//   async saveSeamlessSlotPaymentTransaction(
//     result: ApiResponse<CreatePaymentResponse>,
//     linkedSquareAccount: PaymentAccount,
//     customer: Customer,
//     paymentMethod: SupportedPaymentMethods,
//     savedAppointment: Appointment,
//   ) {
//     const paymentTrasnaction: SquarePaymentTransaction = {
//       date: new Date().toISOString(),
//       status: 'Paid',
//       amount: Number(result?.result?.payment?.amountMoney?.amount),
//       companyBalance: Number(result?.result?.payment?.amountMoney?.amount),
//       currency:
//         (result?.result?.payment?.amountMoney?.currency as Currency) ||
//         ('' as Currency),
//       cardDetails: result?.result?.payment?.cardDetails?.card?.last4 || '',
//       squareTransactionId: result?.result?.payment?.id || '',
//       merchantId: linkedSquareAccount.squareDefaultLocationId,
//       squareCreatedAt: result?.result?.payment?.createdAt || '',
//       squareType: 'payment',
//       squareProduct:
//         result?.result?.payment?.applicationDetails?.squareProduct || '',
//       squareAddressLine1:
//         result?.result?.payment?.billingAddress?.addressLine1 || '',
//       squareAddressLine2:
//         result?.result?.payment?.billingAddress?.addressLine2 || '',
//       squareCountry: result?.result?.payment?.billingAddress?.country || '',
//       squareCustomerFirstName: customer.firstName,
//       squareCustomerLastNameName: customer.lastName,
//       squarePostalCode:
//         result?.result?.payment?.billingAddress?.postalCode || '',
//       squareLocality: result?.result?.payment?.billingAddress?.locality || '',
//       squareBuyerEmailAddress: customer.email,
//       squareAuthResultCode:
//         result?.result?.payment?.cardDetails?.authResultCode || '',
//       squareAvsStatus: result?.result?.payment?.cardDetails?.avsStatus || '',
//       squareBin: result?.result?.payment?.cardDetails?.card?.bin || '',
//       squareCardBrand:
//         result?.result?.payment?.cardDetails?.card?.cardBrand || '',
//       squareCardType:
//         result?.result?.payment?.cardDetails?.card?.cardType || '',
//       squareCardMonthExpiry: Number(
//         result.result.payment.cardDetails.card.expMonth,
//       ),
//       squareCardYearExpiry: Number(
//         result.result.payment.cardDetails.card.expYear,
//       ),
//       squareFingerPrint:
//         result?.result?.payment?.cardDetails?.card?.fingerprint || '',
//       squareCardLast4: Number(result.result.payment.cardDetails.card.last4),
//       squarePaymentAccountReference:
//         result?.result?.payment?.cardDetails?.card?.referenceId || '',
//       squarePerpaidType:
//         result?.result?.payment?.cardDetails?.card?.prepaidType || '',
//       squareReceiptURL: result?.result?.payment?.receiptUrl || '',
//       squareSourceType: result?.result?.payment?.sourceType || '',
//       squareStatus: result?.result?.payment?.status || '',
//       squareUpdatedAt: result?.result?.payment?.updatedAt || '',
//       method: paymentMethod,
//       note: 'Charged For Seamless Slot Appointment',
//       type: 'Credit Card',
//       appointment: savedAppointment.id,
//       isActive: true,
//       createdBy: 0,
//       updatedBy: 0,
//       deletedBy: 0,
//       deletedAt: null,
//     };
//
//     return await this.repoFactory.paymentTransactionRepository.save(
//       paymentTrasnaction,
//     );
//   }
//
//   async makeSquarePayment(
//     squareSourceId: string,
//     linkedSquareAccount: PaymentAccount,
//     amount: number,
//     customer: Customer,
//     savedAppointment: Appointment,
//   ): Promise<ApiResponse<CreatePaymentResponse>> {
//     try {
//       return await this.squareEnvService
//         .getSquareClientWithAccessToken(linkedSquareAccount.accessToken)
//         .paymentsApi.createPayment({
//           sourceId: squareSourceId,
//           idempotencyKey: randomUUID().toString(),
//           autocomplete: true,
//           locationId: linkedSquareAccount.squareDefaultLocationId,
//           amountMoney: {
//             amount: BigInt(amount),
//             currency: 'GBP',
//           },
//           note: `paid by ${customer.firstName + ' ' + customer.lastName} (SeamlessSlot) `,
//         });
//     } catch (error) {
//       await this.repoFactory.appointmentRepository.hardDelete(
//         savedAppointment.id,
//       );
//       throw new HttpException(
//         {
//           code: 0,
//           message: this.handleSquarePaymentFailedException(error.errors),
//           data: this.handleSquarePaymentFailedException(error.errors),
//         } as BaseResponse<string>,
//         HttpStatus.OK,
//       );
//     }
//   }
//
//   async sendPaymentReceiptEmail(
//     business: Business,
//     customer: Customer,
//     savedAppointment: Appointment,
//     service: Service,
//     paymentMethod: SupportedPaymentMethods,
//     paymentTransaction: SquarePaymentTransaction,
//   ) {
//     return this.emailGateway.sendEmailFromInfo({
//       title: business.name,
//       to: customer.email,
//       subject: 'Payment Receipt',
//       html: getPaymentReceiptTemplate({
//         businessName: '',
//         discount: '0',
//         payerName: customer.firstName + ' ' + customer.lastName,
//         paymentDate: this.timeZoneService.formatISOInSpecifiedTimeZone(
//           savedAppointment.startTime,
//           'dd MMM EEEE ',
//           this.securityContext.getTimeZone() || 'Europe/London',
//         ),
//         paymentMethod: paymentMethod,
//         serviceAmount: service.cost.toString(),
//         subTotal: service.cost.toString(),
//         total: service.cost.toString(),
//         serviceTitle: service.title,
//         transactionId: paymentTransaction.squareTransactionId,
//       }),
//     });
//   }
//
//   async sendAppointmentConfirmedEmail(
//     customer: Customer,
//     savedAppointment: Appointment,
//     service: Service,
//   ) {
//     return this.emailGateway.sendEmailFromInfo({
//       to: customer.email,
//       subject: 'Appointment Booked',
//       html: getAppointmentConfirmedTemplate({
//         businessName: '',
//         fullName: customer.firstName + ' ' + customer.lastName,
//         bookingId: savedAppointment.id.toString(),
//         service: service.title,
//         duration: service.durationInMinutes.toString(),
//         cost: service.cost.toString(),
//         dateTimeOfAppointment:
//           this.timeZoneService.formatISOInSpecifiedTimeZone(
//             savedAppointment.startTime as string,
//             'EEEE dd MMM yyyy hh:mm a',
//             this.securityContext.getTimeZone() || 'Europe/London',
//           ) +
//           '-' +
//           this.timeZoneService.formatISOInSpecifiedTimeZone(
//             savedAppointment.endTime as string,
//             'hh:mm a',
//             this.securityContext.getTimeZone() || 'Europe/London',
//           ),
//         customerName: customer.firstName + ' ' + customer.lastName,
//         customerEmail: customer.email,
//         customerPhone: customer.phoneNo,
//         amountCharged: service.cost.toString(),
//       }),
//     });
//   }
//
//   async sendAdminEmail(
//     to: string,
//     location: Location,
//     customer: Customer,
//     savedAppointment: Appointment,
//     service: Service,
//   ) {
//     return this.emailGateway.sendEmailFromInfo({
//       to,
//       subject: 'Seamless Slot (Appointment Booked)',
//       html: getAppointmentCreatedAdminEmailTemplate({
//         businessName: '',
//         location: location.name,
//         bookingId: savedAppointment.id.toString(),
//         service: service.title,
//         duration: service.durationInMinutes.toString(),
//         cost: service.cost.toString(),
//         dateTimeOfAppointment:
//           this.timeZoneService.formatISOInSpecifiedTimeZone(
//             savedAppointment.startTime as string,
//             'EEEE dd MMM yyyy hh:mm a',
//             this.securityContext.getTimeZone() || 'Europe/London',
//           ) +
//           '-' +
//           this.timeZoneService.formatISOInSpecifiedTimeZone(
//             savedAppointment.endTime as string,
//             'hh:mm a',
//             this.securityContext.getTimeZone() || 'Europe/London',
//           ),
//         customerName: customer.firstName + ' ' + customer.lastName,
//         customerEmail: customer.email,
//         customerPhone: customer.phoneNo,
//         amountCharged: service.cost.toString(),
//       }),
//     });
//   }
//
//   handleSquarePaymentFailedException(errors: Error[]): string {
//     let errorMessages = '';
//     errors.forEach((err: Error) => {
//       switch (err.code) {
//         case 'GENERIC_DECLINE': {
//           errorMessages +=
//             "Square is declining the customer's payment method because the issuing bank is declining to authorize the card\n";
//           break;
//         }
//         case 'PAYMENT_METHOD_ERROR': {
//           errorMessages += 'The payment method is invalid.\n';
//           break;
//         }
//         case 'CARD_DECLINED': {
//           errorMessages += 'The card was declined.\n';
//           break;
//         }
//         case 'INSUFFICIENT_FUNDS': {
//           errorMessages +=
//             'We are sorry, but your transaction could not be completed because your account has insufficient funds. \n';
//           break;
//         }
//         case 'CVV_FAILURE': {
//           errorMessages += 'The CVV provided is incorrect.\n';
//           break;
//         }
//         case 'ADDRESS_VERIFICATION_FAILURE': {
//           errorMessages += 'The address verification failed.\n';
//           break;
//         }
//         case 'EXPIRATION_FAILURE': {
//           errorMessages += 'The card is expired.\n';
//           break;
//         }
//         case 'INVALID_CARD': {
//           errorMessages += 'The card is invalid.\n';
//           break;
//         }
//         case 'DELAYED_TRANSACTION_TIMEOUT': {
//           errorMessages += 'The delayed transaction timed out.\n';
//           break;
//         }
//         case 'PROCESSING_ERROR': {
//           errorMessages += 'There was an error processing the payment.\n';
//           break;
//         }
//         case 'DECLINED_CARD': {
//           errorMessages += 'The card was declined.\n';
//           break;
//         }
//         default: {
//           errorMessages += err.detail + '\n';
//         }
//       }
//     });
//
//     return errorMessages;
//   }
// }
