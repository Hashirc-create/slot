import { Injectable } from '@nestjs/common';
import { Appointment } from '@seamlessslot/core';
import { RepositoryFactory } from '@seamlessslot/database';
import { UpdateAppointmentUseCase } from '@seamlessslot/core';

@Injectable()
export class UpdateAppointmentUseCaseImpl implements UpdateAppointmentUseCase {
  constructor(private readonly repoFactory: RepositoryFactory) {}
  execute(
    id: number,
    appointment: Appointment,
  ): Promise<Readonly<Appointment>> {
    const updated = this.repoFactory.appointmentRepository.update(
      id,
      appointment,
    );
    return updated;
  }
}
