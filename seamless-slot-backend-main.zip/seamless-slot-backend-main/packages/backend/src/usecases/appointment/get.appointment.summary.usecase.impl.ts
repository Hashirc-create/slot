import { Injectable } from '@nestjs/common';
import { RepositoryFactory } from '@seamlessslot/database';
import { Appointment } from '@seamlessslot/core';
import { GetAppointmentSummaryByBookingIdUseCase } from '@seamlessslot/core';

@Injectable()
export class GetAppointmentSummaryByBookingIdUseCaseImpl
  implements GetAppointmentSummaryByBookingIdUseCase
{
  constructor(private readonly repoFactory: RepositoryFactory) {}
  async execute(appointmentId: number): Promise<Appointment> {
    const appointment =
      await this.repoFactory.appointmentRepository.findAppointmentByIdWithServiceLocationPayment(
        appointmentId,
      );

    return appointment;
  }
}
