/* eslint-disable*/
import { Test, TestingModule } from '@nestjs/testing';
import { RepositoryFactory } from '@seamlessslot/database';
import { TimeZoneService } from '../../shared/utils/timezone.util';
import { format, isBefore, parse } from 'date-fns';
import { toZonedTime } from 'date-fns-tz';
import { GetAvaliableTimeSlotsUseCaseImpl } from './get.avaliable.timeslots.impl.usecase';
import { Appointment } from '@seamlessslot/core';

describe('GetAvaliableTimeSlotsUseCaseImpl', () => {
  let useCase: GetAvaliableTimeSlotsUseCaseImpl;
  let repoFactoryMock: any;
  let timeZoneServiceMock: any;

  beforeEach(async () => {
    repoFactoryMock = {
      workingDayRepository: {
        findByLocationAndDay: jest.fn(),
      },
      serviceRepository: {
        findById: jest.fn(),
      },
      locationRepository: {
        findById: jest.fn(),
      },
      appointmentRepository: {
        findAllByLocationServiceAndDate: jest.fn(),
      },
    };

    timeZoneServiceMock = {};

    const module: TestingModule = await Test.createTestingModule({
      providers: [
        GetAvaliableTimeSlotsUseCaseImpl,
        {
          provide: RepositoryFactory,
          useValue: repoFactoryMock,
        },
        {
          provide: TimeZoneService,
          useValue: timeZoneServiceMock,
        },
      ],
    }).compile();

    useCase = module.get<GetAvaliableTimeSlotsUseCaseImpl>(
      GetAvaliableTimeSlotsUseCaseImpl,
    );
  });

  it('should generate correct time slots for a given date', async () => {
    const from = '1996-06-10T08:00:00.000Z';
    const to = '1996-06-10T16:00:00.000Z';
    const date = '2023-08-30';
    const locationId = 1;
    const serviceId = 1;
    const timeZone = 'Europe/London';
    const durationInMinutes = 30;
    const bufferTimeInMinutes = 10;

    repoFactoryMock.workingDayRepository.findByLocationAndDay.mockResolvedValue(
      {
        from: from,
        to: to,
      },
    );

    repoFactoryMock.serviceRepository.findById.mockResolvedValue({
      bufferTimeInMinutes,
      durationInMinutes,
    });

    repoFactoryMock.locationRepository.findById.mockResolvedValue({
      timeZone,
    });

    repoFactoryMock.appointmentRepository.findAllByLocationServiceAndDate.mockResolvedValue(
      [
        {
          startTime: new Date('2023-08-30T08:00:00.000Z'),
          endTime: new Date('2023-08-30T08:30:00.000Z'),
          status: 'Confirmed',
        },
      ],
    );

    const expectedSlots = [
      // '09:00 am - 09:30 am', This slot must be overlapped hence should be removed
      '09:40 AM - 10:10 AM',
      '10:20 AM - 10:50 AM',
      '11:00 AM - 11:30 AM',
      '11:40 AM - 12:10 PM',
      '12:20 PM - 12:50 PM',
      '01:00 PM - 01:30 PM',
      '01:40 PM - 02:10 PM',
      '02:20 PM - 02:50 PM',
      '03:00 PM - 03:30 PM',
      '03:40 PM - 04:10 PM',
      '04:20 PM - 04:50 PM',
    ];

    const slots = await useCase.execute(serviceId, date, locationId);

    console.log(slots);
    expect(slots).toEqual(expectedSlots);
  });

  it('should ignore past slots if the date is today', async () => {
    const from = '1996-06-10T08:00:00.000Z';
    const to = '1996-06-10T16:00:00.000Z';
    const today = format(new Date(), 'yyyy-MM-dd');
    const locationId = 1;
    const serviceId = 1;
    const timeZone = 'Europe/London';
    const durationInMinutes = 30;
    const bufferTimeInMinutes = 10;

    repoFactoryMock.workingDayRepository.findByLocationAndDay.mockResolvedValue(
      {
        from: from,
        to: to,
      },
    );

    repoFactoryMock.serviceRepository.findById.mockResolvedValue({
      bufferTimeInMinutes,
      durationInMinutes,
    });

    repoFactoryMock.locationRepository.findById.mockResolvedValue({
      timeZone,
    });

    repoFactoryMock.appointmentRepository.findAllByLocationServiceAndDate.mockResolvedValue(
      [
        {
          startTime: new Date('1996-06-10T12:00:00'),
          endTime: new Date('1996-06-10T12:30:00'),
          status: 'Confirmed',
        },
      ],
    );

    const slots = await useCase.execute(serviceId, today, locationId);

    const currentTime = toZonedTime(new Date(), timeZone);

    slots.forEach((slot) => {
      const [start, end] = slot
        .split(' - ')
        .map((time) => parse(time, 'hh:mm aa', new Date()));
      expect(isBefore(currentTime, start)).toBeTruthy();
    });
  });
});
