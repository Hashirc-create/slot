import { HttpException, HttpStatus, Injectable } from '@nestjs/common';
import { RepositoryFactory } from '@seamlessslot/database';
import { CheckIfSlotBookedUseCase } from '@seamlessslot/core/dist/use-cases/appointment/check.if.slot.booked';
import { RestrictDoubleBooking } from '../rules/restrict.double.booking';
import { BaseResponse } from '../../shared/interceptor/response.interceptor';

@Injectable()
export class CheckIfSlotBookedUseCaseImpl implements CheckIfSlotBookedUseCase {
  constructor(private readonly repoFactory: RepositoryFactory) {}

  async execute(startTime: Date, endTime: Date): Promise<void> {



    await new RestrictDoubleBooking(
      startTime,
      endTime,
      this.repoFactory,
    ).restrictDoubleBooking();

    throw new HttpException(
      {
        code: 0,
        message: '',
        data: null,
      } as BaseResponse<null>,
      HttpStatus.OK,
    );
  }
}
