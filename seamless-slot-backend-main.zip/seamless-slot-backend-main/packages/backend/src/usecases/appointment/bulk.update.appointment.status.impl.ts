import { Injectable } from '@nestjs/common';
import { AppointmentStatus, BulkUpdateStatusUseCase } from '@seamlessslot/core';
import { RepositoryFactory } from '@seamlessslot/database';
import { SecurityContext } from '../../shared/auth/context/security.context';

@Injectable()
export class BulkUpdateAppointmentStatusImpl
  implements BulkUpdateStatusUseCase
{
  constructor(
    private readonly repoFactory: RepositoryFactory,
    private readonly securityContext: SecurityContext,
  ) {}

  async execute(
    payload: {
      id: number;
      status: AppointmentStatus;
    }[],
  ): Promise<string> {
    const result = payload.map(async (item) => {
      return await this.repoFactory.appointmentRepository.updateAppointmentStatus(
        item.id,
        this.securityContext.getId(),
        item.status,
      );
    });

    await Promise.all(result);

    return 'successfully updated all the appointments';
  }
}
