import { Injectable, Logger } from '@nestjs/common';
import { RepositoryFactory } from '@seamlessslot/database';
import {
  Break,
  GetAvaliableTimeSlotsUseCase,
  TimeOff,
} from '@seamlessslot/core';
import { parse, format, isAfter, isToday } from 'date-fns';

import { WeekDays } from '@seamlessslot/core';
import { Appointment } from '@seamlessslot/core';
import { TimeZoneService } from '../../shared/utils/timezone.util';
import { toZonedTime } from 'date-fns-tz';

@Injectable()
export class GetAvaliableTimeSlotsUseCaseImpl
  implements GetAvaliableTimeSlotsUseCase
{
  private logger: Logger = new Logger(GetAvaliableTimeSlotsUseCaseImpl.name);
  private globalDateFormat: string = 'yyyy-MM-dd';

  constructor(
    private readonly repoFactory: RepositoryFactory,
    private readonly timeZoneService: TimeZoneService,
  ) {}

  async execute(
    serviceId: number,
    date: string,
    locationId: number,
  ): Promise<Readonly<string[]>> {
    const { to, from } =
      await this.repoFactory.workingDayRepository.findByLocationAndDay(
        locationId,
        this.getDayForGivenDate(date, this.globalDateFormat),
      );

    const { bufferTimeInMinutes, durationInMinutes } =
      await this.repoFactory.serviceRepository.findById(serviceId);

    const { timeZone } =
      await this.repoFactory.locationRepository.findById(locationId);

    const appointments =
      await this.repoFactory.appointmentRepository.findConfirmedAndFollowUpAppointmentsByLocationServiceAndDate(
        locationId,
        serviceId,
        date,
      );

    const breaks =
      await this.repoFactory.breakRepository.findAllByLocationAndDay(
        locationId,
        this.getDayForGivenDate(date, this.globalDateFormat),
      );

    const timeOffs = (
      await this.repoFactory.timeOffRepository.findAllByLocationAndDate(
        locationId,
        date,
      )
    ).filter((timeOff) => !timeOff.allDay);

    const generatedSlots = this.generateTimeSlots(
      from as Date,
      to as Date,
      date,
      durationInMinutes,
      bufferTimeInMinutes,
      appointments,
      breaks,
      timeOffs,
    );

    const filteredSlots = this.filterPastSlots(generatedSlots, timeZone);

    return this.isDateToday(date) ? filteredSlots : generatedSlots;
  }

  getDayForGivenDate(date: string, dateFormat: string): WeekDays {
    const parsedDate = parse(date, dateFormat, new Date());
    return format(parsedDate, 'EEEE') as WeekDays;
  }

  isDateToday(dateString: string): boolean {
    const givenDate = parse(dateString, this.globalDateFormat, new Date());
    return isToday(givenDate);
  }

  formatTimeUTC(date: Date) {
    let hours = date.getUTCHours(); // Get hours in UTC
    const minutes = date.getUTCMinutes(); // Get minutes in UTC
    const ampm = hours >= 12 ? 'PM' : 'AM';
    hours = hours % 12 || 12; // Convert to 12-hour format
    return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')} ${ampm}`;
  }

  generateTimeSlots(
    from: Date,
    to: Date,
    date: string,
    slotDuration: number,
    bufferDuration: number,
    // timeZone: SupportedTimeZones,
    appointments: Appointment[],
    breaks: readonly Break[],
    timeOffs: readonly TimeOff[],
  ): string[] {
    const slots = [];

    const current = new Date(from); // Clone the start date to avoid modifying the original
    let isFirstSlot = true;

    while (current < to) {
      if (!isFirstSlot) {
        // Add buffer time only starting from the second slot
        current.setUTCMinutes(current.getUTCMinutes() + bufferDuration);
      }
      const slotStart = new Date(current); // Start of the time slot
      current.setUTCMinutes(current.getUTCMinutes() + slotDuration); // Increment in UTC
      const slotEnd = new Date(current); // End of the time slot

      let isAppointmentOverlapping = false;
      let isBreakOverlapping = false;
      let isTimeOffsOverLapping = false;

      // Only add the slot if the end time does not exceed the given range
      if (slotEnd <= to) {
        // Remove Already Booked Appointments
        for (const appointment of appointments) {
          isAppointmentOverlapping = this.isTimeOverlapping(
            slotStart,
            slotEnd,
            appointment.startTime as Date,
            appointment.endTime as Date,
          );

          if (isAppointmentOverlapping) {
            break;
          }
        }

        // Remove Breaks
        for (const breakItem of breaks) {
          isBreakOverlapping = this.isTimeOverlapping(
            slotStart,
            slotEnd,
            breakItem.startTime as Date,
            breakItem.endTime as Date,
          );

          if (isBreakOverlapping) {
            break;
          }
        }

        // Remove TimeOffs
        for (const timeoff of timeOffs) {
          isTimeOffsOverLapping = this.isTimeOverlapping(
            slotStart,
            slotEnd,
            timeoff.startDateTime as Date,
            timeoff.endDateTime as Date,
          );

          if (isTimeOffsOverLapping) {
            break;
          }
        }

        if (
          !isAppointmentOverlapping &&
          !isBreakOverlapping &&
          !isTimeOffsOverLapping
        ) {
          slots.push(
            `${this.formatTimeUTC(slotStart)} - ${this.formatTimeUTC(slotEnd)}`,
          );
        }
      }

      isFirstSlot = false; // Mark the first slot as processed
    }

    console.log(slots);

    return slots;
  }

  isTimeOverlapping(
    slotStart: Date,
    slotEnd: Date,
    appointmentStart: Date,
    appointmentEnd: Date,
  ) {
    // Helper function to extract just the time portion (hours + minutes) of a Date object
    const getTimeValue = (date: Date) =>
      date.getUTCHours() * 60 + date.getUTCMinutes();

    // Extract time values for all dates
    const slotStartTime = getTimeValue(slotStart);
    const slotEndTime = getTimeValue(slotEnd);
    const appointmentStartTime = getTimeValue(appointmentStart);
    const appointmentEndTime = getTimeValue(appointmentEnd);

    // Perform comparisons using only the time values
    return (
      // Case 1: Slot overlaps at the beginning of the appointment
      (slotStartTime < appointmentEndTime &&
        slotStartTime > appointmentStartTime) ||
      // Case 2: Slot overlaps at the end of the appointment
      (slotEndTime > appointmentStartTime &&
        slotEndTime < appointmentEndTime) ||
      // Case 3: Slot fully encloses the appointment
      (slotStartTime <= appointmentStartTime &&
        slotEndTime >= appointmentEndTime)
    );
  }

  filterPastSlots(slots: string[], timeZone: string): string[] {
    // Get the current date-time in the specific timezone
    const nowInTimeZone = toZonedTime(new Date(), timeZone);

    // Extract only the time part of the current time
    const nowFormatted = format(nowInTimeZone, 'hh:mm a'); // e.g., "10:15 AM"

    console.log('now', nowFormatted);

    return slots.filter((slot) => {
      const [start] = slot.split(' - '); // Extract the start time of the slot

      // Parse the start time of the slot using the same day (arbitrary, only time comparison matters)
      const currentTime = parse(nowFormatted, 'hh:mm a', nowInTimeZone); // Current time in Date object
      const slotTime = parse(start, 'hh:mm a', nowInTimeZone); // Slot start time in Date object

      // Keep only slots whose start time is after or equal to the current time
      return (
        isAfter(slotTime, currentTime) ||
        slotTime.getTime() === currentTime.getTime()
      );
    });
  }
}
