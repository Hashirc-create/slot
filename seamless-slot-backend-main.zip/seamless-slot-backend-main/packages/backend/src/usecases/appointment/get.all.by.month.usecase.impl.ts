import { Injectable } from '@nestjs/common';
import { RepositoryFactory } from '@seamlessslot/database';
import { Appointment } from '@seamlessslot/core';
import { GetAllAppointmentByMonthUseCase } from '@seamlessslot/core';

@Injectable()
export class GetAllAppointmentByMonthUseCaseImpl
  implements GetAllAppointmentByMonthUseCase
{
  constructor(private readonly repoFactory: RepositoryFactory) {}

  async execute(
    year: number,
    month: number,
    locationId: number,
  ): Promise<readonly Appointment[]> {
    return await this.repoFactory.appointmentRepository.findAppointmentsByMonth(
      year,
      month,
      locationId,
    );
  }
}
