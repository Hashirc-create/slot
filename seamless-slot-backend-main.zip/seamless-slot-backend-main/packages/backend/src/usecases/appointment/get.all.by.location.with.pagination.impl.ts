import { Injectable } from '@nestjs/common';
import { RepositoryFactory } from '@seamlessslot/database';
import {
  Appointment,
  GetAllAppointmentsByLocationWithPaginationUseCase,
} from '@seamlessslot/core';
import { TimeZoneService } from '../../shared/utils/timezone.util';
import { SecurityContext } from '../../shared/auth/context/security.context';

@Injectable()
export class GetAllAppointmentByLocationWithPaginationUseCaseImpl
  implements GetAllAppointmentsByLocationWithPaginationUseCase
{
  constructor(
    private readonly repoFactory: RepositoryFactory,
    private readonly timeZoneService: TimeZoneService,
    private readonly securityContext: SecurityContext,
  ) {}

  async execute(
    locationId: number,
    page: number,
    perPage: number,
    startDate: string,
    endDate: string,
  ): Promise<
    Readonly<{
      prev: number;
      next: number;
      last: number;
      pages: number;
      total: number;
      data: Appointment[];
    }>
  > {
    if (startDate === '' && endDate === '')
      return await this.repoFactory.appointmentRepository.findAllByLocationWithPagination(
        locationId,
        page,
        perPage,
      );

    return await this.repoFactory.appointmentRepository.findAllWithDateRangeByLocationWithPagination(
      locationId,
      page,
      perPage,
      startDate,
      endDate,
    );
  }
}
