import { Injectable } from '@nestjs/common';
import { RepositoryFactory } from '@seamlessslot/database';
import {
  GetAvaliableDatesUseCase,
  TimeOff,
  WorkingDay,
} from '@seamlessslot/core';
import {
  addDays,
  eachDayOfInterval,
  startOfDay,
  parse,
  format,
  getDay,
} from 'date-fns';
import { WeekDays } from '@seamlessslot/core';
import { TimeZoneService } from '../../shared/utils/timezone.util';

@Injectable()
export class GetAvaliableDatesUseCaseImpl implements GetAvaliableDatesUseCase {
  private globalDateFormat: string = 'dd MMM yyyy';

  constructor(
    private readonly repoFactory: RepositoryFactory,
    private readonly timeZoneService: TimeZoneService,
  ) {}

  async execute(locationId?: number): Promise<Readonly<string[]>> {
    const allDates = this.getDatesForNextDays(
      await this.getScheduleWindowSize(locationId),
    );

    const workingDays = (
      await this.repoFactory.workingDayRepository.findAllByLocation(locationId)
    )
      .filter((day: WorkingDay) => day.isClosed !== true)
      .map((workingDay: WorkingDay) => {
        if ((workingDay.day as WeekDays) === 'Monday') return 1;
        if ((workingDay.day as WeekDays) === 'Tuesday') return 2;
        if ((workingDay.day as WeekDays) === 'Wednesday') return 3;
        if ((workingDay.day as WeekDays) === 'Thursday') return 4;
        if ((workingDay.day as WeekDays) === 'Friday') return 5;
        if ((workingDay.day as WeekDays) === 'Saturday') return 6;
        if ((workingDay.day as WeekDays) === 'Sunday') return 0;
      });

    const timeOffs = (
      await this.repoFactory.timeOffRepository.findAllByLocation(locationId)
    )
      .filter((timeOff) => timeOff.allDay)
      .map((timeOff: TimeOff) => {
        const isoDateTime = this.timeZoneService.formatDatePreservingUTC(
          timeOff.startDateTime as Date,
          this.globalDateFormat,
        );

        return format(isoDateTime, this.globalDateFormat);
      });

    //removing weekend like sunday or saturday based on location working days
    const afterRemovingNonWorkingDays = this.removeNonWorkingDates(
      workingDays,
      allDates,
    );

    // removing time offs which are marked as complete day
    const removedTimeOffDates = afterRemovingNonWorkingDays.filter(
      (item) => !timeOffs.includes(item),
    );

    return removedTimeOffDates;
  }

  async getScheduleWindowSize(locationId: number) {
    const { scheduleSize, scheduleSizeUnits } =
      await this.repoFactory.locationRepository.findById(locationId);

    if (scheduleSizeUnits === 'days') {
      return scheduleSize;
    }
    if (scheduleSizeUnits === 'months') {
      return scheduleSize * 30;
    }

    return 10;
  }

  getDatesForNextDays(days: number): string[] {
    const now = new Date();
    const futureDate = addDays(now, days);

    const dates = eachDayOfInterval({
      start: startOfDay(now),
      end: startOfDay(futureDate),
    });

    return dates.map((date) => format(date, this.globalDateFormat));
  }

  removeNonWorkingDates(workingDays: number[], dates: string[]): string[] {
    return dates
      .map((date) => parse(date, this.globalDateFormat, new Date())) // Parse each date string to a Date object
      .filter((date) => workingDays.includes(getDay(date))) // Filter out non-weekdays
      .map((date) => format(date, this.globalDateFormat)); // Format Date objects back to strings
  }
}
