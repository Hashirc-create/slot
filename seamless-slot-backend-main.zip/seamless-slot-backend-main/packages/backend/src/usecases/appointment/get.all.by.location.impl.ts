import { Injectable } from '@nestjs/common';
import { RepositoryFactory } from '@seamlessslot/database';
import { Appointment } from '@seamlessslot/core';
import { GetAllAppointmentsByLocationUseCase } from '@seamlessslot/core';

@Injectable()
export class GetAllAppointmentByLocationUseCaseImpl
  implements GetAllAppointmentsByLocationUseCase
{
  constructor(private readonly repoFactory: RepositoryFactory) {}
  async execute(locationId: number): Promise<Readonly<Appointment[]>> {
    const appointments =
      await this.repoFactory.appointmentRepository.findAllByLocation(
        locationId,
      );

    return appointments;
  }
}
