import {
  IBulkUpdateStatusUseCase,
  IChangeAppointmentDataTimeUseCase,
} from '@seamlessslot/core';
import { IChangeAppointmentStatusUseCase } from '@seamlessslot/core';
import { ICreateAppointmentUseCase } from '@seamlessslot/core';
import { IDeleteAppointmentUseCase } from '@seamlessslot/core';
import { IGetAllAppointmentsByLocationUseCase } from '@seamlessslot/core';
import { IGetAllAppointmentsByLocationWithPaginationUseCase } from '@seamlessslot/core';
import { IGetAppointmentSummaryByBookingIdUseCase } from '@seamlessslot/core';
import { IGetAvaliableDatesUseCase } from '@seamlessslot/core';
import { IGetAvaliableTimeSlotsUseCase } from '@seamlessslot/core';
import { IGetByIdAppointmentUseCase } from '@seamlessslot/core';
import { IUpdateAppointmentUseCase } from '@seamlessslot/core';
import { ChangeAppointmentDateTimeUseCaseImpl } from './change.appointment.date.time.usecase.impl';
import { ChangeAppointmentStatusUseCaseImpl } from './change.appointment.status.usecase.impl';
import { CreateAppointmentUseCaseImpl } from './create.impl';
import { DeleteAppointmentUseCaseImpl } from './delete.impl';
import { GetAllAppointmentByLocationUseCaseImpl } from './get.all.by.location.impl';
import { GetAllAppointmentByLocationWithPaginationUseCaseImpl } from './get.all.by.location.with.pagination.impl';
import { GetAppointmentSummaryByBookingIdUseCaseImpl } from './get.appointment.summary.usecase.impl';
import { GetAvaliableDatesUseCaseImpl } from './get.avaliable.dates.impl.usecase';
import { GetAvaliableTimeSlotsUseCaseImpl } from './get.avaliable.timeslots.impl.usecase';
import { GetByIdAppointmentUseCaseImpl } from './get.by.id.impl';
import { UpdateAppointmentUseCaseImpl } from './update.impl';
import { IGetAllAppointmentByMonthUseCase } from '@seamlessslot/core';
import { GetAllAppointmentByMonthUseCaseImpl } from './get.all.by.month.usecase.impl';
import { ICreatePublicAppointmentWithoutPaymentUseCase } from '@seamlessslot/core';
import { CreatePublicAppointmentWithoutPaymentUsecaseImpl } from './create.public.appointment.without.payment.usecase.impl';
import { ITakePaymentPublicAppointmentUseCase } from '@seamlessslot/core';
import { TakePaymentPublicAppointmentUsecaseImpl } from './take.payment.public.appointment.usecase.impl';
import { ISearchAppointmentsWithPaginationUseCase } from '@seamlessslot/core';
import { SearchAppointmentsWithPaginationUseCaseImpl } from './search.appointments.with.pagination.usecase.impl';
import { ICheckAppointmentDetailUseCase } from '@seamlessslot/core/dist/use-cases/appointment/check.appointment.detail';
import { CheckAppointmentDetailImpl } from './check.appointment.detail.impl';
import { BulkUpdateAppointmentStatusImpl } from './bulk.update.appointment.status.impl';
import { ICheckIfSlotBookedUseCase } from '@seamlessslot/core/dist/use-cases/appointment/check.if.slot.booked';
import { CheckIfSlotBookedUseCaseImpl } from './check.if.slot.booked.usecase.impl';

export const APPOINTMENT_USECASES = [
  {
    provide: IBulkUpdateStatusUseCase,
    useClass: BulkUpdateAppointmentStatusImpl,
  },
  {
    provide: ICheckIfSlotBookedUseCase,
    useClass: CheckIfSlotBookedUseCaseImpl,
  },
  {
    provide: ICheckAppointmentDetailUseCase,
    useClass: CheckAppointmentDetailImpl,
  },
  {
    provide: IGetAllAppointmentByMonthUseCase,
    useClass: GetAllAppointmentByMonthUseCaseImpl,
  },
  {
    provide: IChangeAppointmentDataTimeUseCase,
    useClass: ChangeAppointmentDateTimeUseCaseImpl,
  },
  {
    provide: IGetAllAppointmentsByLocationWithPaginationUseCase,
    useClass: GetAllAppointmentByLocationWithPaginationUseCaseImpl,
  },
  {
    provide: IChangeAppointmentStatusUseCase,
    useClass: ChangeAppointmentStatusUseCaseImpl,
  },
  {
    provide: IGetAppointmentSummaryByBookingIdUseCase,
    useClass: GetAppointmentSummaryByBookingIdUseCaseImpl,
  },
  {
    provide: ICreateAppointmentUseCase,
    useClass: CreateAppointmentUseCaseImpl,
  },
  {
    provide: ICreateAppointmentUseCase,
    useClass: CreateAppointmentUseCaseImpl,
  },
  {
    provide: IDeleteAppointmentUseCase,
    useClass: DeleteAppointmentUseCaseImpl,
  },
  {
    provide: IUpdateAppointmentUseCase,
    useClass: UpdateAppointmentUseCaseImpl,
  },
  {
    provide: IGetByIdAppointmentUseCase,
    useClass: GetByIdAppointmentUseCaseImpl,
  },

  {
    provide: IGetAllAppointmentsByLocationUseCase,
    useClass: GetAllAppointmentByLocationUseCaseImpl,
  },
  {
    provide: IGetAvaliableDatesUseCase,
    useClass: GetAvaliableDatesUseCaseImpl,
  },
  {
    provide: IGetAvaliableTimeSlotsUseCase,
    useClass: GetAvaliableTimeSlotsUseCaseImpl,
  },
  {
    provide: ICreatePublicAppointmentWithoutPaymentUseCase,
    useClass: CreatePublicAppointmentWithoutPaymentUsecaseImpl,
  },
  {
    provide: ITakePaymentPublicAppointmentUseCase,
    useClass: TakePaymentPublicAppointmentUsecaseImpl,
  },
  {
    provide: IDeleteAppointmentUseCase,
    useClass: DeleteAppointmentUseCaseImpl,
  },
  {
    provide: ISearchAppointmentsWithPaginationUseCase,
    useClass: SearchAppointmentsWithPaginationUseCaseImpl,
  },
];
