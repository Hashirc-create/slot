import { Injectable } from '@nestjs/common';
import { Appointment, GetByIdAppointmentUseCase } from '@seamlessslot/core';
import { RepositoryFactory } from '@seamlessslot/database';

@Injectable()
export class GetByIdAppointmentUseCaseImpl
  implements GetByIdAppointmentUseCase
{
  constructor(private readonly repoFactory: RepositoryFactory) {}

  async execute(id: number): Promise<Appointment> {
    return await this.repoFactory.appointmentRepository.findByIdIncludingLocationServiceCustomerAndTransaction(
      id,
    );
  }
}
