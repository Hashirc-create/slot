import {
  HttpException,
  HttpStatus,
  Inject,
  Injectable,
  Logger,
} from '@nestjs/common';
import { Appointment } from '@seamlessslot/core';
import { RepositoryFactory } from '@seamlessslot/database';
import { Customer } from '@seamlessslot/core';

import { WebSocketService } from '../../shared/websocket/websocket.service';
import { CONSTANTS } from '../../shared/utils/constants';
import { CreatePublicAppointmentWithoutPaymentUseCase } from '@seamlessslot/core';
import { ISquareApi, SquareApi } from '../../shared/square/square.api.service';
import {
  AppointmentScheduleJob,
  IAppointmentScheduleJob,
} from '../../shared/jobs/appointment.job';
import { BaseResponse } from '../../shared/interceptor/response.interceptor';
import { ConfigService } from '@nestjs/config';
import { TimeZoneService } from '../../shared/utils/timezone.util';
import { UTILS } from '../../shared/utils/utils.util';

@Injectable()
export class CreatePublicAppointmentWithoutPaymentUsecaseImpl
  implements CreatePublicAppointmentWithoutPaymentUseCase
{
  private readonly logger: Logger = new Logger(
    CreatePublicAppointmentWithoutPaymentUsecaseImpl.name,
  );

  constructor(
    private readonly repoFactory: RepositoryFactory,
    private readonly webSocketService: WebSocketService,
    @Inject(ISquareApi)
    private readonly squareApiService: SquareApi,
    @Inject(IAppointmentScheduleJob)
    private readonly appointmentScheduleService: AppointmentScheduleJob,
    private readonly configService: ConfigService,
    private readonly timeZoneService: TimeZoneService,
  ) {}

  async execute(
    appointment: Appointment,
    customer: Customer,
  ): Promise<Readonly<Appointment>> {
    let foundCustomer =
      await this.repoFactory.customerRepository.findCustomerByEmail(
        customer.email,
      );

    const location = await this.repoFactory.locationRepository.findById(
      appointment.location as number,
    );

    const business = await this.repoFactory.businessRepository.findById(
      location.business as number,
    );

    if (foundCustomer === null) {
      customer.location = appointment.location;
      foundCustomer = await this.repoFactory.customerRepository.save(customer);
    } else {
      await this.repoFactory.customerRepository.bindNewLocationWithCustomer(
        appointment.location as number,
        foundCustomer.id,
      );
    }

    this.logger.error('This is the associated Location ' + location);

    const service = await this.repoFactory.serviceRepository.findById(
      appointment.service as number,
    );

    const squarePaymentAccount =
      await this.repoFactory.paymentAccountRepository.findPaymentAccountByLocationAndType(
        'Square-Pay',
        appointment.location as number,
      );

    if (!squarePaymentAccount) {
      throw new HttpException(
        {
          message: 'Payment Account Not Linked',
          data: 'Payment Account Not Linked',
          code: 0,
        } as BaseResponse<string>,
        HttpStatus.OK,
      );
    }

    // for webhook to update the status later
    appointment.squareOrderId = '';
    appointment.status = 'Pending';
    appointment.customer = foundCustomer.id;
    appointment.business = business.id;

    const savedAppointment =
      await this.repoFactory.appointmentRepository.save(appointment);

    const paymentLink: string = UTILS.getPaymentLinkShortURL(
      savedAppointment.id.toString(),
    );
    // Scheduling Jobs For 5 minutes
    if (this.configService.get('NODE_ENV') !== 'development')
      this.appointmentScheduleService.schedulePaymentEmailAndSmsJob(
        savedAppointment.id,
        paymentLink,
        customer,
        savedAppointment,
        service,
        location,
        business,
      );

    this.webSocketService.server.emit(
      CONSTANTS.WEBSOCKETS_EVENTS.PUBLIC_APPOINTMENT_CREATED,
      {
        location: appointment.location as number,
      },
    );

    savedAppointment.customer = foundCustomer.id;
    return savedAppointment;
  }
}
