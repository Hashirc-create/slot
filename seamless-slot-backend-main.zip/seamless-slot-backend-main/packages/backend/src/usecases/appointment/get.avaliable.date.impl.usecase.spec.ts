import { Test } from '@nestjs/testing';
import { RepositoryFactory } from '@seamlessslot/database';
import { GetAvaliableDatesUseCaseImpl } from './get.avaliable.dates.impl.usecase';
import { SupportedTimeZones } from '@seamlessslot/core';
import { TimeZoneService } from '../../shared/utils/timezone.util';

function createRepositoryFactoryMock() {
  return {
    workingDayRepository: {
      findAllByLocation: jest.fn(),
    },
    timeOffRepository: {
      findAllByLocation: jest.fn(),
    },
    locationRepository: {
      findById: jest.fn(),
    },
  } as unknown as RepositoryFactory;
}

describe('GetAvaliableDatesUseCaseImpl', () => {
  let useCase: GetAvaliableDatesUseCaseImpl;
  let repoFactoryMock: RepositoryFactory;

  beforeEach(async () => {
    const moduleRef = await Test.createTestingModule({
      providers: [
        TimeZoneService,
        GetAvaliableDatesUseCaseImpl,
        {
          provide: RepositoryFactory,
          useValue: createRepositoryFactoryMock(),
        },
      ],
    }).compile();

    useCase = moduleRef.get<GetAvaliableDatesUseCaseImpl>(
      GetAvaliableDatesUseCaseImpl,
    );
    repoFactoryMock = moduleRef.get<RepositoryFactory>(RepositoryFactory);
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  it('should return available dates excluding working days and time offs', async () => {
    // Mock repository responses
    const locationId = 1;
    const mockWorkingDays = [
      {
        day: 'Monday',
        isClosed: false,
      },
      {
        day: 'Tuesday',
        isClosed: false,
      }, // Closed day
      {
        day: 'Wednesday',
        isClosed: true,
      },
      {
        day: 'Thursday',
        isClosed: false,
      },
      {
        day: 'Friday',
        isClosed: false,
      },
      {
        day: 'Saturday',
        isClosed: true,
      },
      {
        day: 'Sunday',
        isClosed: true,
      },
    ];
    const mockTimeOffs = [
      {
        startDateTime: '2024-06-13T00:00:00.000Z',
        endDateTime: '2024-06-18T00:00:00.000Z',
      },
    ];

    jest
      .spyOn(repoFactoryMock.workingDayRepository, 'findAllByLocation')
      //eslint-disable-next-line
      // @ts-ignore
      .mockResolvedValue(mockWorkingDays);
    jest
      .spyOn(repoFactoryMock.timeOffRepository, 'findAllByLocation')
      //eslint-disable-next-line
      // @ts-ignore
      .mockResolvedValue(mockTimeOffs);

    jest
      .spyOn(repoFactoryMock.locationRepository, 'findById')
      //eslint-disable-next-line
      // @ts-ignore
      .mockResolvedValue({
        timeZone: 'Europe/London' as SupportedTimeZones,
      });

    // Mock implementation of getDatesForNextDays for predictable results
    jest
      .spyOn(useCase, 'getDatesForNextDays')
      .mockReturnValue([
        '13 Jun 2024',
        '14 Jun 2024',
        '15 Jun 2024',
        '16 Jun 2024',
        '17 Jun 2024',
        '18 Jun 2024',
        '19 Jun 2024',
        '20 Jun 2024',
        '21 Jun 2024',
        '22 Jun 2024',
      ]);

    const result = await useCase.execute(locationId);

    // Assert the result
    expect(result).toEqual(['20 Jun 2024', '21 Jun 2024']);
  });

  // Add more test cases for edge cases, error scenarios, etc.
});
