import {
  HttpException,
  HttpStatus,
  Inject,
  Injectable,
  Logger,
} from '@nestjs/common';
import {
  Appointment,
  Business,
  PaymentMethod,
  SquarePaymentWithUnderScore,
  User,
} from '@seamlessslot/core';
import { RepositoryFactory } from '@seamlessslot/database';
import { ApiError, ApiResponse, CreatePaymentResponse, Error } from 'square';
import { SquareEnvService } from '../../shared/square/square.env.service';
import { randomUUID } from 'crypto';
import { SquarePaymentTransaction } from '@seamlessslot/core';
import { Currency, SupportedPaymentMethods } from '@seamlessslot/core';
import { Customer } from '@seamlessslot/core';
import {
  EmailGateway,
  IEmailGateway,
} from '../../shared/gateways/email/email.gateway';
import { getAppointmentConfirmedTemplate } from '../../shared/gateways/templates/appointmentConfirmed';
import { TimeZoneService } from '../../shared/utils/timezone.util';
import { getPaymentReceiptTemplate } from '../../shared/gateways/templates/paymentReceipt';
import { Service } from '@seamlessslot/core';
import { PaymentAccount } from '@seamlessslot/core';
import { Location } from '@seamlessslot/core';
import { WebSocketService } from '../../shared/websocket/websocket.service';
import { CONSTANTS } from '../../shared/utils/constants';
import { getAppointmentCreatedAdminEmailTemplate } from '../../shared/gateways/templates/publicAppointmentCreated';
import { TakePaymentPublicAppointmentUseCase } from '@seamlessslot/core';
import {
  AppointmentScheduleJob,
  IAppointmentScheduleJob,
} from '../../shared/jobs/appointment.job';
import { BaseResponse } from '../../shared/interceptor/response.interceptor';
import { SecurityContext } from '../../shared/auth/context/security.context';
import { ConfigService } from '@nestjs/config';
import {
  ISmsServiceSeamlessSlot,
  SmsServiceSeamlessSlot,
} from '@seamlessslot/sms/dist/src/sms.service';
import { format } from 'date-fns';
import { RestrictDoubleBooking } from '../rules/restrict.double.booking';

@Injectable()
export class TakePaymentPublicAppointmentUsecaseImpl
  implements TakePaymentPublicAppointmentUseCase
{
  private readonly logger: Logger = new Logger(
    'TakePaymentPublicAppointmentUseCaseImpl',
  );

  constructor(
    private readonly repoFactory: RepositoryFactory,
    private readonly squareEnvService: SquareEnvService,
    @Inject(IEmailGateway)
    private readonly emailGateway: EmailGateway,
    private readonly timeZoneService: TimeZoneService,
    @Inject(ISmsServiceSeamlessSlot)
    private readonly smsService: SmsServiceSeamlessSlot,
    private readonly webSocketService: WebSocketService,
    @Inject(IAppointmentScheduleJob)
    private readonly appointmentSchedulerJob: AppointmentScheduleJob,
    private readonly securityContext: SecurityContext,
    private readonly configService: ConfigService,
  ) {}

  async execute(
    appointmentId: number,
    locationId: number,
    customerId: number,
    serviceId: number,
    squareSourceId: string,
    squareBuyerId: string,
    paymentMethod: SupportedPaymentMethods,
  ): Promise<Readonly<Appointment>> {
    //check square account linked ?
    const linkedSquareAccount = await this.isSquareAccountLinked(locationId);

    // TODO CHECK IF ALREADY PAID AND ALSO IF SLOT ALREADY BOOKED

    const appointmentFound =
      await this.repoFactory.appointmentRepository.findById(appointmentId);

    if (appointmentFound.status === 'Confirmed')
      throw new HttpException(
        {
          code: 0,
          message: 'Appointment is already paid',
        } as BaseResponse<null>,
        HttpStatus.OK,
      );

    await new RestrictDoubleBooking(
      appointmentFound.startTime as Date,
      appointmentFound.endTime as Date,
      this.repoFactory,
    ).restrictDoubleBooking();

    const [service, appointment, customer, location] = await Promise.all([
      this.repoFactory.serviceRepository.findById(serviceId),
      this.repoFactory.appointmentRepository.findById(appointmentId),
      this.repoFactory.customerRepository.findById(customerId),
      this.repoFactory.locationRepository.findById(locationId),
    ]);

    const business = await this.repoFactory.businessRepository.findById(
      location.business as number,
    );

    //make square payment
    const result: ApiResponse<CreatePaymentResponse> =
      await this.makeSquarePayment(
        squareSourceId,
        squareBuyerId,
        linkedSquareAccount,
        BigInt(Math.round(parseFloat(service.cost) * 100)), // since square takes amount in cents
        customer,
        appointment,
      );

    const savedPaymentTransaction =
      await this.saveSeamlessSlotPaymentTransaction(
        result,
        linkedSquareAccount,
        customer,
        paymentMethod,
        appointment.id,
        business.id,
      );

    await this.repoFactory.paymentLogRepository.save({
      last4Digits: result.result.payment.cardDetails.card.last4,
      transactionId: result.result.payment.id,
      orderId: result.result.payment.orderId,
      status: 'Paid',
      paymentMethod: result.result.payment.sourceType as PaymentMethod,
      failedReason: 'none',
      appointment: appointment.id,
      errorCode: 'none',
      errorDetail: 'none',
      errorCategory: 'none',
      amount: Number(result.result.payment.amountMoney.amount),
      currency: result.result.payment.amountMoney.currency,
      cardBrand: result.result.payment.cardDetails.card.cardBrand,
      cardExpMonth: result.result.payment.cardDetails.card.expMonth.toString(),
      cardExpYear: result.result.payment.cardDetails.card.expYear.toString(),
      cardType: result.result.payment.cardDetails.card.cardType,
      entryMethod: result.result.payment.cardDetails.entryMethod,
      cvvStatus: result.result.payment.cardDetails.cvvStatus,
      avsStatus: result.result.payment.cardDetails.avsStatus,
      fullPayload: result.result.payment,
      isActive: true,
      createdBy: 0,
      updatedBy: 0,
      deletedBy: 0,
    });

    await this.repoFactory.appointmentRepository.updateAppointmentStatus(
      appointment.id,
      0,
      'Confirmed',
    );

    try {
      //stop the scheduler
      this.appointmentSchedulerJob.deleteSchedulePaymentLinkEmailJob(
        appointment.squareOrderId,
      );
    } catch (e) {
      console.log(e);
    }

    await Promise.all([
      this.sendAppointmentConfirmedEmail(
        business,
        location,
        customer,
        appointment,
        service,
      ),
      this.sendPaymentReceiptEmail(
        business,
        customer,
        appointment,
        service,
        paymentMethod,
        savedPaymentTransaction,
      ),
      this.sendConfirmationSms(business, customer, appointment, location),
    ]);

    this.repoFactory.notificationRepository.save({
      isActive: true,
      isMarkedRead: false,
      title: `Appointment Booked By ${customer.firstName} ${customer.lastName} `,
      appointmentStartTime: appointment.startTime,
      createdBy: 0,
      customerName: customer.firstName + ' ' + customer.lastName,
      deletedBy: 0,
      updatedBy: 0,
      location: appointment.location as number,
    });

    this.webSocketService.server.emit(
      CONSTANTS.WEBSOCKETS_EVENTS.PUBLIC_APPOINTMENT_CREATED,
      {
        location: appointment.location as number,
      },
    );

    const admins =
      await this.repoFactory.userRepository.findAllAdminsByLocation(
        location.id,
      );

    admins.forEach((admin: User) => {
      this.sendAdminEmail(
        admin.email,
        business,
        location,
        customer,
        appointment,
        service,
      );
    });

    if (this.configService.get('NODE_ENV') === 'production') {
      this.sendAdminEmail(
        `rizwan.malik@seamlessideas.co.uk`,
        business,
        location,
        customer,
        appointment,
        service,
      );

      this.sendAdminEmail(
        `tosif.khan@seamlessideas.co.uk`,
        business,
        location,
        customer,
        appointment,
        service,
      );
    }

    return this.repoFactory.appointmentRepository.findAppointmentByIdWithServiceLocationPayment(
      appointment.id,
    );
  }

  private async isSquareAccountLinked(
    locationId: number,
  ): Promise<PaymentAccount> {
    const linkedSquareAccount =
      await this.repoFactory.paymentAccountRepository.findPaymentAccountByLocationAndType(
        'Square-Pay',
        locationId,
      );

    if (linkedSquareAccount === null)
      throw new HttpException(
        {
          code: 0,
          message:
            'Square Payment Account not linked for the provided location',
          data: 'Square Payment Account not linked for the provided location',
        } as BaseResponse<string>,
        HttpStatus.OK,
      );

    return linkedSquareAccount;
  }

  async sendConfirmationSms(
    business: Business,
    customer: Customer,
    savedAppointment: Appointment,
    location: Location,
  ) {
    this.smsService.sendAppointmentPaymentConfirmationSms({
      to: customer.phoneNo,
      customerFirstName: customer.firstName,
      customerLastName: customer.lastName,
      businessName: business.name,
      locationName: location.name,
      locationAddress: location.address,
      appointmentDate: this.timeZoneService.formatDatePreservingUTC(
        savedAppointment.startTime as Date,
        'EEEE dd MMM yyyy',
      ),
      appointmentStartTime: this.timeZoneService.formatDatePreservingUTC(
        savedAppointment.startTime as Date,
        'hh:mm a',
      ),
      telephone: location.telephone,
    });
  }

  async saveSeamlessSlotPaymentTransaction(
    result: ApiResponse<CreatePaymentResponse>,
    linkedSquareAccount: PaymentAccount,
    customer: Customer,
    paymentMethod: SupportedPaymentMethods,
    appointmentId: number,
    businessId: number,
  ) {
    const paymentTrasnaction: SquarePaymentTransaction = {
      date: new Date().toISOString(),
      status: 'Paid',
      amount: Number(result?.result?.payment?.amountMoney?.amount).toString(),
      companyBalance: Number(
        result?.result?.payment?.amountMoney?.amount,
      ).toString(),
      currency:
        (result?.result?.payment?.amountMoney?.currency as Currency) ||
        ('' as Currency),
      cardDetails: result?.result?.payment?.cardDetails?.card?.last4 || '',
      squareTransactionId: result?.result?.payment?.id || '',
      merchantId: linkedSquareAccount.squareDefaultLocationId,
      squareCreatedAt: result?.result?.payment?.createdAt || '',
      squareType: 'payment',
      squareProduct:
        result?.result?.payment?.applicationDetails?.squareProduct || '',
      squareAddressLine1:
        result?.result?.payment?.billingAddress?.addressLine1 || '',
      squareAddressLine2:
        result?.result?.payment?.billingAddress?.addressLine2 || '',
      squareCountry: result?.result?.payment?.billingAddress?.country || '',
      squareCustomerFirstName: customer.firstName,
      squareCustomerLastNameName: customer.lastName,
      squarePostalCode:
        result?.result?.payment?.billingAddress?.postalCode || '',
      squareLocality: result?.result?.payment?.billingAddress?.locality || '',
      squareBuyerEmailAddress: customer.email,
      squareAuthResultCode:
        result?.result?.payment?.cardDetails?.authResultCode || '',
      squareAvsStatus: result?.result?.payment?.cardDetails?.avsStatus || '',
      squareBin: result?.result?.payment?.cardDetails?.card?.bin || '',
      squareCardBrand:
        result?.result?.payment?.cardDetails?.card?.cardBrand || '',
      squareCardType:
        result?.result?.payment?.cardDetails?.card?.cardType || '',
      squareCardMonthExpiry: Number(
        result.result.payment.cardDetails.card.expMonth,
      ),
      squareCardYearExpiry: Number(
        result.result.payment.cardDetails.card.expYear,
      ),
      squareFingerPrint:
        result?.result?.payment?.cardDetails?.card?.fingerprint || '',
      squareCardLast4: Number(result.result.payment.cardDetails.card.last4),
      squarePaymentAccountReference:
        result?.result?.payment?.cardDetails?.card?.referenceId || '',
      squarePerpaidType:
        result?.result?.payment?.cardDetails?.card?.prepaidType || '',
      squareReceiptURL: result?.result?.payment?.receiptUrl || '',
      squareSourceType: result?.result?.payment?.sourceType || '',
      squareStatus: result?.result?.payment?.status || '',
      squareUpdatedAt: result?.result?.payment?.updatedAt || '',
      method: paymentMethod,
      note: 'Charged For Seamless Slot Appointment',
      type: 'Credit Card',
      appointment: appointmentId,
      business: businessId,
      isActive: true,
      createdBy: 0,
      updatedBy: 0,
      deletedBy: 0,
      deletedAt: null,
    };

    return await this.repoFactory.paymentTransactionRepository.save(
      paymentTrasnaction,
    );
  }

  async makeSquarePayment(
    squareSourceId: string,
    squareBuyerId: string,
    linkedSquareAccount: PaymentAccount,
    amount: bigint,
    customer: Customer,
    savedAppointment: Appointment,
  ): Promise<ApiResponse<CreatePaymentResponse>> {
    let response;
    try {
      response = await this.squareEnvService
        .getSquareClientWithAccessToken(linkedSquareAccount.accessToken)
        .paymentsApi.createPayment({
          sourceId: squareSourceId,
          verificationToken: squareBuyerId,
          idempotencyKey: randomUUID().toString(),
          autocomplete: true,
          locationId: linkedSquareAccount.squareDefaultLocationId,
          amountMoney: {
            amount: amount,
            currency: 'GBP',
          },
          note: `paid by ${customer.firstName + ' ' + customer.lastName} (SeamlessSlot) `,
        });

      return response;
    } catch (error: unknown) {
      this.logger.error(error);
      const { result } = error as ApiError;
      const { errors, payment } = result as CreatePaymentResponse;
      const paymentUnderScore = payment as SquarePaymentWithUnderScore;

      await this.repoFactory.paymentLogRepository.save({
        transactionId: paymentUnderScore.id,
        orderId: paymentUnderScore.order_id,
        appointment: savedAppointment.id,
        errorCode: errors[0].code,
        errorDetail: errors[0].detail,
        errorCategory: errors[0].category,
        amount: Number(paymentUnderScore.amount_money.amount),
        currency: paymentUnderScore.amount_money.currency,
        cardBrand: paymentUnderScore.card_details.card.card_brand,
        cardExpMonth: paymentUnderScore.card_details.card.exp_month.toString(),
        cardExpYear: paymentUnderScore.card_details.card.exp_year.toString(),
        cardType: paymentUnderScore.card_details.card.card_type,
        entryMethod: paymentUnderScore.card_details.entry_method,
        cvvStatus: paymentUnderScore.card_details.cvv_status,
        avsStatus: paymentUnderScore.card_details.avs_status,
        fullPayload: payment,
        paymentMethod: paymentUnderScore.source_type as PaymentMethod,
        last4Digits: paymentUnderScore.card_details.card.last_4,
        status: 'Failed',
        failedReason: this.handleSquarePaymentFailedException(errors),
        isActive: true,
        createdBy: 0,
        updatedBy: 0,
        deletedBy: 0,
      });

      this.logger.error(
        'Failed to make payment against appointment id : ' +
          savedAppointment.id,
      );

      throw new HttpException(
        {
          code: 0,
          message: this.handleSquarePaymentFailedException(errors),
          data: this.handleSquarePaymentFailedException(errors),
        } as BaseResponse<string>,
        HttpStatus.OK,
      );
    }
  }

  async sendPaymentReceiptEmail(
    business: Business,
    customer: Customer,
    savedAppointment: Appointment,
    service: Service,
    paymentMethod: SupportedPaymentMethods,
    paymentTransaction: SquarePaymentTransaction,
  ) {
    // dd MMM EEEE
    return this.emailGateway.sendEmailFromInfo({
      title: business.name,
      to: customer.email,
      subject: 'Payment Receipt',
      html: getPaymentReceiptTemplate({
        businessName: business.name,
        discount: '0',
        payerName: customer.firstName + ' ' + customer.lastName,
        paymentDate: format(new Date(), 'dd MMM EEEE'),
        paymentMethod: paymentMethod,
        serviceAmount: service.cost.toString(),
        subTotal: service.cost.toString(),
        total: service.cost.toString(),
        serviceTitle: service.title,
        transactionId: paymentTransaction.squareTransactionId,
      }),
    });
  }

  async sendAppointmentConfirmedEmail(
    business: Business,
    location: Location,
    customer: Customer,
    savedAppointment: Appointment,
    service: Service,
  ) {
    return this.emailGateway.sendEmailFromInfo({
      title: business.name,
      to: customer.email,
      subject: 'Appointment Booked',
      html: getAppointmentConfirmedTemplate({
        businessName: business.name,
        fullName: customer.firstName + ' ' + customer.lastName,
        bookingId: savedAppointment.id.toString(),
        service: service.title,
        duration: service.durationInMinutes.toString(),
        cost: service.cost.toString(),
        dateTimeOfAppointment:
          this.timeZoneService.formatDatePreservingUTC(
            savedAppointment.startTime as Date,
            'EEEE dd MMM yyyy hh:mm a',
          ) +
          '-' +
          this.timeZoneService.formatDatePreservingUTC(
            savedAppointment.endTime as Date,
            'hh:mm a',
          ),
        customerName: customer.firstName + ' ' + customer.lastName,
        customerEmail: customer.email,
        customerPhone: customer.phoneNo,
        amountCharged: service.cost.toString(),
        locationAddress: location.address,
        gmapUrl: location.googleMapUrl,
      }),
    });
  }

  async sendAdminEmail(
    to: string,
    business: Business,
    location: Location,
    customer: Customer,
    savedAppointment: Appointment,
    service: Service,
  ) {
    return this.emailGateway.sendEmailFromInfo({
      title: business.name,
      to,
      subject: 'Seamless Slot (Appointment Booked)',
      html: getAppointmentCreatedAdminEmailTemplate({
        businessName: business.name,
        location: location.name,
        bookingId: savedAppointment.id.toString(),
        service: service.title,
        duration: service.durationInMinutes.toString(),
        cost: service.cost.toString(),
        dateTimeOfAppointment:
          this.timeZoneService.formatDatePreservingUTC(
            savedAppointment.startTime as Date,
            'EEEE dd MMM yyyy hh:mm a',
          ) +
          '-' +
          this.timeZoneService.formatDatePreservingUTC(
            savedAppointment.endTime as Date,
            'hh:mm a',
          ),
        customerName: customer.firstName + ' ' + customer.lastName,
        customerEmail: customer.email,
        customerPhone: customer.phoneNo,
        amountCharged: service.cost.toString(),
      }),
    });
  }

  handleSquarePaymentFailedException(errors: Error[]): string {
    let errorMessages = '';
    errors.forEach((err: Error) => {
      switch (err.code) {
        case 'GENERIC_DECLINE': {
          errorMessages +=
            "Square is declining the customer's payment method because the issuing bank is declining to authorize the card\n";
          break;
        }
        case 'PAYMENT_METHOD_ERROR': {
          errorMessages += 'The payment method is invalid.\n';
          break;
        }
        case 'CARD_DECLINED': {
          errorMessages += 'The card was declined.\n';
          break;
        }
        case 'INSUFFICIENT_FUNDS': {
          errorMessages +=
            'We are sorry, but your transaction could not be completed because your account has insufficient funds. \n';
          break;
        }
        case 'CVV_FAILURE': {
          errorMessages += 'The CVV provided is incorrect.\n';
          break;
        }
        case 'ADDRESS_VERIFICATION_FAILURE': {
          errorMessages += 'The address verification failed.\n';
          break;
        }
        case 'EXPIRATION_FAILURE': {
          errorMessages += 'The card is expired.\n';
          break;
        }
        case 'INVALID_CARD': {
          errorMessages += 'The card is invalid.\n';
          break;
        }
        case 'DELAYED_TRANSACTION_TIMEOUT': {
          errorMessages += 'The delayed transaction timed out.\n';
          break;
        }
        case 'PROCESSING_ERROR': {
          errorMessages += 'There was an error processing the payment.\n';
          break;
        }
        case 'DECLINED_CARD': {
          errorMessages += 'The card was declined.\n';
          break;
        }
        default: {
          errorMessages += err.detail + '\n';
        }
      }
    });

    return errorMessages;
  }
}
