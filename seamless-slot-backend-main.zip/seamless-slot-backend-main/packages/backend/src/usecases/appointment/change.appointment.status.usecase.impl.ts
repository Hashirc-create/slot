import { HttpException, HttpStatus, Inject, Injectable } from '@nestjs/common';
import {
  Appointment,
  Business,
  CancellationTimeUnits,
  SupportedTimeZones,
} from '@seamlessslot/core';
import { RepositoryFactory } from '@seamlessslot/database';
import { ChangeAppointmentStatusUseCase } from '@seamlessslot/core';
import { AppointmentStatus } from '@seamlessslot/core';
import {
  EmailGateway,
  IEmailGateway,
} from '../../shared/gateways/email/email.gateway';
import { Customer } from '@seamlessslot/core';
import { getAppointmentCancelledTemplate } from '../../shared/gateways/templates/appointmentCancelled';
import { Service } from '@seamlessslot/core';
import { TimeZoneService } from '../../shared/utils/timezone.util';
import { SecurityContext } from '../../shared/auth/context/security.context';
import { Location } from '@seamlessslot/core';
import { BaseResponse } from '../../shared/interceptor/response.interceptor';
import { toZonedTime } from 'date-fns-tz';
import {
  ISmsServiceSeamlessSlot,
  SmsServiceSeamlessSlot,
} from '@seamlessslot/sms/dist/src/sms.service';

//import { ap } from 'ramda';

@Injectable()
export class ChangeAppointmentStatusUseCaseImpl
  implements ChangeAppointmentStatusUseCase
{
  constructor(
    private readonly repoFactory: RepositoryFactory,
    @Inject(IEmailGateway)
    private readonly email: EmailGateway,
    private readonly timeZoneService: TimeZoneService,
    @Inject(ISmsServiceSeamlessSlot)
    private readonly smsService: SmsServiceSeamlessSlot,
    private readonly securityContext: SecurityContext,
  ) {}

  async execute(
    id: number,
    status: AppointmentStatus,
  ): Promise<Readonly<Appointment>> {
    const appointment =
      await this.repoFactory.appointmentRepository.findAppointmentByIdWithServiceLocationPayment(
        id,
      );

    const business = await this.repoFactory.businessRepository.findById(
      (appointment.location as Location).business as number,
    );

    if (
      status === 'Cancelled' &&
      (appointment.location as Location).isCancellationPolicyEnabled
    ) {
      this.verifyCancellationPolicy(appointment);
    }

    const updateAppointmentStatus =
      await this.repoFactory.appointmentRepository.updateAppointmentStatus(
        id,
        this.securityContext.getId(),
        status,
      );

    if (updateAppointmentStatus.status === 'Cancelled') {
      await Promise.all([
        this.sendCancellationEmail(
          appointment.location as Location,
          appointment,
          business,
        ),
        this.sendCancellationSms(business, appointment),
      ]);
    }

    return appointment;
  }

  verifyCancellationPolicy(appointment: Appointment) {
    const location = appointment.location as Location;
    const cancellationTime = location.cancellationTime; // Number value
    const cancellationTimeUnit = location.cancellationTimeUnit;
    const totalHours = this.getTotalHours(
      cancellationTimeUnit,
      cancellationTime,
    );

    const appointmentStartTime = toZonedTime(
      appointment.startTime,
      location.timeZone as SupportedTimeZones,
    );

    const hoursUntilAppointmentStart = this.calculateHoursToAppointment(
      location.timeZone as SupportedTimeZones,
      appointmentStartTime,
    );

    if (totalHours >= hoursUntilAppointmentStart)
      this.throwAppointmentCancellationPolicyViolation();
  }

  calculateHoursToAppointment(
    timeZone: SupportedTimeZones,
    appointmentStartTime: Date,
  ): number {
    const currentTime = toZonedTime(new Date(), timeZone);
    const timeDifferenceInMilliseconds =
      appointmentStartTime.getTime() - currentTime.getTime();

    // Convert milliseconds to hours
    const hoursDifference = timeDifferenceInMilliseconds / (1000 * 60 * 60);

    // Return rounded result to 2 decimal places (or customize as needed)
    return parseFloat(hoursDifference.toFixed(2));
  }

  getTotalHours(unit: CancellationTimeUnits, value: number): number {
    const hoursInADay = 24;
    const daysInAMonth = 30; // Approximation; you can adjust this as needed.

    switch (unit) {
      case 'months':
        return value * daysInAMonth * hoursInADay;
      case 'days':
        return value * hoursInADay;
      case 'hours':
        return value;
      default:
        throw new Error(
          'Invalid unit. Supported units are months, days, and hours.',
        );
    }
  }

  // calculateCancellationWindowEndTime(
  //   appointmentStartTime: Date,
  //   cancellationTime: number,
  //   cancellationTimeUnit: CancellationTimeUnits,
  // ): Date {
  //   switch (cancellationTimeUnit) {
  //     case 'months':
  //       return new Date(
  //         new Date(appointmentStartTime).setMonth(
  //           new Date(appointmentStartTime).getMonth() + cancellationTime,
  //         ),
  //       );
  //     case 'days':
  //       return new Date(
  //         new Date(appointmentStartTime).getTime() +
  //           cancellationTime * 24 * 60 * 60 * 1000,
  //       );
  //     case 'hours':
  //       return new Date(
  //         new Date(appointmentStartTime).getTime() +
  //           cancellationTime * 60 * 60 * 1000,
  //       );
  //     default:
  //       throw new Error(`Unknown time unit: ${cancellationTimeUnit}`);
  //   }
  // }

  sendCancellationSms(business: Business, appointment: Appointment) {
    const customer = appointment.customer as Customer;
    const location = appointment.location as Location;

    this.smsService.sendAppointmentStatusUpdateSms({
      to: customer.phoneNo,
      customerFirstName: customer.firstName,
      customerLastName: customer.lastName,
      businessName: business.name,
      locationName: location.name,
      locationAddress: location.address,
      appointmentDate: this.timeZoneService.formatDatePreservingUTC(
        appointment.startTime as Date,
        'EEEE dd MMM yyyy',
      ),
      appointmentStartTime: this.timeZoneService.formatDatePreservingUTC(
        appointment.startTime as Date,
        'hh:mm a',
      ),
      locationTelephone: location.telephone,
    });
  }

  sendCancellationEmail(
    location: Location,
    appointment: Appointment,
    business: Business,
  ) {
    this.email.sendEmailFromInfo({
      title: business.name,
      to: (appointment.customer as Customer).email,
      subject: 'Appointment Status',
      html: getAppointmentCancelledTemplate({
        businessName: business.name,
        bookingId: appointment.id.toString(),
        service: (appointment.service as Service).title,
        duration: (appointment.service as Service).durationInMinutes.toString(),
        cost: (appointment.service as Service).cost.toString(),
        dateTimeOfAppointment:
          this.timeZoneService.formatDatePreservingUTC(
            appointment.startTime as Date,
            'EEEE dd MMM yyyy hh:mm a',
          ) +
          '-' +
          this.timeZoneService.formatDatePreservingUTC(
            appointment.endTime as Date,
            'hh:mm a',
          ),
        customerName:
          (appointment.customer as Customer).firstName +
          '' +
          (appointment.customer as Customer).lastName,
        customerEmail: (appointment.customer as Customer).email,
        customerPhone: (appointment.customer as Customer).phoneNo,
        amountCharged: (appointment.service as Service).cost.toString(),
        locationAddress: location.address,
        googleMapUrl: location.googleMapUrl,
      }),
    });
  }

  throwAppointmentCancellationPolicyViolation() {
    throw new HttpException(
      {
        code: 0,
        message: 'Cancellation Policy Violated',
        data: 'Cancellation Policy Violated',
      } as BaseResponse<string>,
      HttpStatus.OK,
    );
  }
}
