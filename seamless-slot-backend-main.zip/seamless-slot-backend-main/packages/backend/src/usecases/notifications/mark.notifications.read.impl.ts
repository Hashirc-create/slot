import { Injectable } from '@nestjs/common';
import { RepositoryFactory } from '@seamlessslot/database';
import { MarkNotificationsReadUseCase } from '@seamlessslot/core';

@Injectable()
export class MarkNotificationsReadUseCaseImpl
  implements MarkNotificationsReadUseCase
{
  constructor(private readonly repoFactory: RepositoryFactory) {}
  async execute(ids: number[]): Promise<number> {
    return this.repoFactory.notificationRepository.markNotificationsRead(ids);
  }
}
