import { IGetAllNotificationByLocationUseCase } from '@seamlessslot/core';
import { IMarkNotificationsReadUseCase } from '@seamlessslot/core';
import { GetAllNotificationsByUseCaseImpl } from './get.all.by.location.impl';
import { MarkNotificationsReadUseCaseImpl } from './mark.notifications.read.impl';

export const NOTIFICATION_USECASES = [
  {
    provide: IGetAllNotificationByLocationUseCase,
    useClass: GetAllNotificationsByUseCaseImpl,
  },
  {
    provide: IMarkNotificationsReadUseCase,
    useClass: MarkNotificationsReadUseCaseImpl,
  },
];
