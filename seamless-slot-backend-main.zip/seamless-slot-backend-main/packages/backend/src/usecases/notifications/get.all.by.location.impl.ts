import { Injectable } from '@nestjs/common';
import { RepositoryFactory } from '@seamlessslot/database';
import { GetAllNotificationByLocationUseCase } from '@seamlessslot/core';
import { Notifications } from '@seamlessslot/core';

@Injectable()
export class GetAllNotificationsByUseCaseImpl
  implements GetAllNotificationByLocationUseCase
{
  constructor(private readonly repoFactory: RepositoryFactory) {}
  async execute(locationId: number): Promise<readonly Notifications[]> {
    return this.repoFactory.notificationRepository.findAllNotificationsByLocation(
      locationId,
    );
  }
}
