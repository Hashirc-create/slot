import { IGetAllWorkingDaysHistoryByLocationUseCase } from '@seamlessslot/core';
import { GetAllWorkingDaysHistoryByLocationUseCaseImpl } from './get.all.by.location.impl';

export const WORKING_DAYS_HISTORY_USECASES = [
  {
    provide: IGetAllWorkingDaysHistoryByLocationUseCase,
    useClass: GetAllWorkingDaysHistoryByLocationUseCaseImpl,
  },
];
