import { Injectable } from '@nestjs/common';
import { RepositoryFactory } from '@seamlessslot/database';
import {
  GetAllWorkingDaysHistoryByLocationUseCase,
  WorkingDayHistory,
} from '@seamlessslot/core';

@Injectable()
export class GetAllWorkingDaysHistoryByLocationUseCaseImpl
  implements GetAllWorkingDaysHistoryByLocationUseCase
{
  constructor(private readonly repoFactory: RepositoryFactory) {}

  async execute(locationId: number): Promise<WorkingDayHistory[]> {
    return await this.repoFactory.workingDayHistoryRepo.findAllByLocation({
      locationId,
    });
  }
}
