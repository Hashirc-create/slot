import { Controller, HttpCode, HttpStatus, Get, Inject } from '@nestjs/common';
import { ApiOperation, ApiTags } from '@nestjs/swagger';
import { encrypt } from './shared/utils/encrypt.util';
import { UseCaseFactory } from './usecases/usecase.factory';
import {
  EmailGateway,
  IEmailGateway,
} from './shared/gateways/email/email.gateway';

//import { CONSTANTS } from './shared/utils/constants';

@Controller('seeder')
@ApiTags('Seeders')
export class SeederController {
  constructor(
    private readonly useCaseFactory: UseCaseFactory,
    @Inject(IEmailGateway)
    private readonly email: EmailGateway,
  ) {}

  @Get('/debug-sentry')
  @HttpCode(HttpStatus.CREATED)
  @ApiOperation({
    description: 'Test',
    summary: 'test',
  })
  async test() {
    // await this.email.sendEmailFromInfo({
    //   to: 'afaq.javed@seamlessideas.co.uk',
    //   subject: 'Follow-Up on Provisional Booking',
    //   html: getAppointmentCancelledTemplate({
    //     bookingId: 'BK1234', // Unique booking ID
    //     service: 'Massage', // Random service
    //     duration: '60 mins', // Duration of service
    //     cost: '$80.00', // Cost of the service
    //     dateTimeOfAppointment: '2025-01-15T10:30:00Z', // Appointment date and time
    //     customerName: 'Jane Smith', // Customer's name
    //     customerEmail: 'jane.smith@example.com', // Customer's email
    //     customerPhone: '+1234567890', // Customer's phone number
    //     amountCharged: '$80.00', // Amount charged
    //     businessName: 'Rehman Dental Service', // Business name
    //   }),
    // });

    await this.email.sendEmailFromInfo({
      title: 'Night And Day',
      to: 'afaqjavedofficial@gmail.com',
      html: `<h1>This is test</h1>`,
      subject: 'Test is test',
    });

    return 'success';
    // throw new HttpException('Ignore this error', HttpStatus.OK);
  }

  @Get('/addLocation')
  @HttpCode(HttpStatus.CREATED)
  @ApiOperation({
    description: 'Create Demo Location',
    summary: 'Create Demo Location',
  })
  async create() {
    // const location = await this.useCaseFactory.registerLocationUseCase.execute({
    //   name: 'Manchester Night And Day',
    //   address: 'Manchester London ,UK',
    //   email: 'manchester@seamlessslot.com',
    //   isActive: true,
    //   site: 'www.demo.com',
    //   timeZone: 'Europe/London',
    //   telephone: '1234567890',
    //   country: 'UK',
    //   town: 'Manchester',
    //   conferenceCall: '1234567890',
    //   about: 'Demo Location',
    //   scheduleSize: 10,
    //   scheduleSizeUnits: 'days',
    //   cancellationTimeInHours: 'any time',
    //   latitude: 0,
    //   longitude: 0,
    //   createdBy: 0,
    //   updatedBy: 0,
    //   deletedBy: 0,
    // });

    return `Base Location Created Against Id ${0}`;
  }

  @Get('/addSuperAdmin')
  @HttpCode(HttpStatus.CREATED)
  @ApiOperation({
    description: 'Create SuperAdmin',
    summary: 'Create SuperAdmin',
  })
  async createSuperadmin() {
    const superadmin = await this.useCaseFactory.registerUserUseCase.execute({
      firstName: 'Super',
      lastName: 'Admin',
      email: 'superadmin@seamlessslot.com',
      password: await encrypt('admin'),
      phoneNo: '1234567890',
      companyName: 'Demo Company',
      address: 'Manchester London, UK',
      tokenVersion: 0,
      role: 'Super Admin',
      isActive: true,
      location: 1,
      createdBy: 0,
      updatedBy: 0,
      deletedBy: 0,
    });

    return `SuperAdmin Created Against Id ${superadmin.id}`;
  }

  @Get('/addService')
  @HttpCode(HttpStatus.CREATED)
  @ApiOperation({
    description: 'Create Service',
    summary: 'Create Service',
  })
  async createService() {
    const service = await this.useCaseFactory.createServiceUseCase.execute({
      bufferTimeInMinutes: 10,
      cost: '100',
      durationInMinutes: 10,
      title: 'Demo Service',
      venue: 'Demo Venue',
      order: 1,
      isLive: true,
      isActive: true,
      location: 1,
      createdBy: 0,
      updatedBy: 0,
      deletedBy: 0,
    });

    return `Service Created Against Id ${service.id}`;
  }
}
