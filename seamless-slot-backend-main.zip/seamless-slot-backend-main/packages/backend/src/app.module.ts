import {
  MiddlewareConsumer,
  Module,
  NestModule,
  OnModuleInit,
} from '@nestjs/common';
import { PresentationModule } from './presentation/presentation.module';
import { GatewayModule } from './shared/gateways/gateway.module';
import { AuthModule } from './shared/auth/auth.module';
import { AccessTokenMiddlware } from './shared/auth/middleware/accesstoken.middleware';
import { SeamlessSlotDatabaseModule } from '@seamlessslot/database';
import { UtilsModule } from './shared/utils/utils.module';
import { SeederController } from './seeder.controller';
import { SquareApiModule } from './shared/square/square.module';
import { JobsModule } from './shared/jobs/jobs.module';
import { WebSocketModule } from './shared/websocket/websocket.module';
import { SentryGlobalFilter, SentryModule } from '@sentry/nestjs/setup';
import { APP_FILTER } from '@nestjs/core';
import { LoggingMiddleware } from './shared/middleware/logging';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { ScheduleModule } from '@nestjs/schedule';
import { AwsModule } from './shared/aws/aws.module';
import { UseCaseModule } from './usecases/usecase.module';
import { SeamlessSlotSmsModule } from '@seamlessslot/sms';

@Module({
  imports: [
    ConfigModule.forRoot({
      isGlobal: true,
      envFilePath: '.env',
    }),
    SentryModule.forRoot(),
    ScheduleModule.forRoot(),
    SeamlessSlotDatabaseModule,
    UseCaseModule,
    AwsModule,
    PresentationModule,
    GatewayModule,
    AuthModule,
    SquareApiModule,
    // SmsModule,
    SeamlessSlotSmsModule,
    UtilsModule,
    JobsModule,
    WebSocketModule,
  ],
  controllers: [SeederController],
  providers: [
    {
      provide: APP_FILTER,
      useClass: SentryGlobalFilter,
    },
    LoggingMiddleware,
  ],
})
export class AppModule implements NestModule, OnModuleInit {
  constructor(private readonly configService: ConfigService) {}

  onModuleInit() {}

  configure(consumer: MiddlewareConsumer) {
    consumer.apply(AccessTokenMiddlware).forRoutes('*');

    if (this.configService.get('NODE_ENV') !== 'development')
      consumer.apply(LoggingMiddleware).forRoutes('*');
  }
}
