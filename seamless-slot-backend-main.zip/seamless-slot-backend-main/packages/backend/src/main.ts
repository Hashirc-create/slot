import './instrument'; // Sentry Integration

import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import { BaseResponseInterceptor } from './shared/interceptor/response.interceptor';
import { DocumentBuilder, SwaggerModule } from '@nestjs/swagger';
import { ValidationPipe } from '@nestjs/common';
import cookieParser from 'cookie-parser';
import { apiReference } from '@scalar/nestjs-api-reference';
import { ClusterService } from './cluster.service';
import {
  utilities as nestWinstonModuleUtilities,
  WinstonModule,
} from 'nest-winston';
import * as winston from 'winston';
import CloudWatchTransport from 'winston-cloudwatch';
import { AllExceptionsFilter } from './shared/exceptions/all.exception.filter';

function getProductionLogger() {
  if (process.env.NODE_ENV === 'development') return {};

  return {
    logger: WinstonModule.createLogger({
      format: winston.format.uncolorize(),
      transports: [
        new winston.transports.Console({
          format: winston.format.combine(
            winston.format.timestamp(),
            winston.format.ms(),
            nestWinstonModuleUtilities.format.nestLike(),
          ),
        }),
        new CloudWatchTransport({
          name: 'CloudWatch Logs',
          logGroupName: `${process.env.NODE_ENV}-group`,
          logStreamName: `backend`,
          // awsAccessKeyId: process.env.AWS_ACCESS_KEY,
          // awsSecretKey: process.env.AWS_KEY_SECRET,
          awsRegion: process.env.CLOUDWATCH_AWS_REGION,
          messageFormatter: function (item) {
            return (
              item.level + ': ' + item.message + ' ' + JSON.stringify(item.meta)
            );
          },
        }),
      ],
    }),
  };
}

export async function bootstrap() {
  const app = await NestFactory.create(AppModule, getProductionLogger());

  // app.enableCors({
  //   origin: [
  //     'http://localhost:5173',
  //     'https://www.nightandday.seamlessslot.co.uk',
  //     'https://nightandday.seamlessslot.co.uk',
  //     'https://staging.seamlessslot.co.uk',
  //     'https://www.staging.seamlessslot.co.uk',
  //   ],
  //   credentials: true,
  // });

  const allowedOrigins = [
    'http://localhost:5173',
    'http://localhost:3000',
    '*.staging.seamlessslot.co.uk',
    '*.seamlessslot.co.uk',
    'seamlessslot.co.uk',
  ];

  app.enableCors({
    origin: (origin, callback) => {
      console.log('Origin:', origin);
      const isAllowed = allowedOrigins.some((allowedOrigin) => {
        if (allowedOrigin.includes('*')) {
          const regex = new RegExp(
            `^https:\/\/([a-zA-Z0-9-]+)\.${allowedOrigin.split('*')[1]}`,
          );
          return regex.test(origin);
        }
        return origin === allowedOrigin;
      });

      if (isAllowed || origin === undefined) {
        callback(null, true); // Allow the request
      } else {
        callback(new Error('Not allowed by CORS')); // Reject the request
      }
    },
    credentials: true, // Allow credentials (cookies, authorization headers, etc.)
  });

  app.use(cookieParser());
  app.useGlobalInterceptors(new BaseResponseInterceptor());
  app.useGlobalPipes(new ValidationPipe());

  const config = new DocumentBuilder()
    .setTitle('Seamless Slot')
    .setDescription('Swagger Rest Api Documentation For Seamless Slot')
    .setVersion('1.0')
    .addBearerAuth()
    .build();

  const document = SwaggerModule.createDocument(app, config);

  if (process.env.NODE_ENV !== 'production')
    app.use(
      '/api',
      apiReference({
        spec: {
          content: document,
        },
      }),
    );

  //Prisma Error Handling
  app.useGlobalFilters(new AllExceptionsFilter());
  await app.listen(3000);
}

process.env.NODE_ENV === 'development'
  ? bootstrap()
  : ClusterService.startWithCluster(bootstrap);
