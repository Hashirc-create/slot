import { Global, Module } from '@nestjs/common';
import { AwsServiceImpl, IAwsService } from './aws.service';

@Global()
@Module({
  providers: [
    {
      provide: IAwsService,
      useClass: AwsServiceImpl,
    },
  ],
  exports: [
    {
      provide: IAwsService,
      useClass: AwsServiceImpl,
    },
  ],
})
export class AwsModule {}
