import { HttpException, HttpStatus, Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import {
  ChangeResourceRecordSetsCommand,
  Route53Client,
} from '@aws-sdk/client-route-53';
import { BaseResponse } from '../interceptor/response.interceptor';
import * as Sentry from '@sentry/nestjs';

export const IAwsService = Symbol.for('AwsService');

export interface AwsService {
  createSubdomain(
    parentDomain: string,
    subdomain: string,
    ipAddress: string,
  ): Promise<unknown>;
}

@Injectable()
export class AwsServiceImpl implements AwsService {
  private readonly clientRouteS3Region: string = '';
  private readonly hostedZoneId: string = '';
  private readonly logger: Logger = new Logger(AwsServiceImpl.name);

  constructor(private readonly configService: ConfigService) {
    this.hostedZoneId = this.configService.get('HOSTED_ZONE_ID');
    this.clientRouteS3Region = this.configService.get(
      'AWS_CLIENT_ROUTE_REGION',
    );

    if (this.hostedZoneId === '' || this.clientRouteS3Region === '')
      this.logger.error('Failed to load aws route S3 env variables');
    else
      this.logger.log(
        `Env Loaded for Aws Router S3 Region: ${this.clientRouteS3Region} HostedZone: ${this.hostedZoneId}`,
      );
  }

  async createSubdomain(
    parentDomain: string,
    subdomain: string,
    ipAddress: string,
  ): Promise<unknown> {
    const clientRoute = new Route53Client({
      region: this.clientRouteS3Region,
    });

    try {
      const command = new ChangeResourceRecordSetsCommand({
        HostedZoneId: this.hostedZoneId, // ID of your hosted zone for the parent domain
        ChangeBatch: {
          Changes: [
            {
              Action: 'CREATE', // 'CREATE' for new records, 'UPSERT' to update existing
              ResourceRecordSet: {
                Name: `${subdomain}.${parentDomain}`, // Full subdomain name
                Type: 'A', // Record type (A, CNAME, etc.)
                TTL: 300, // Time-to-live in seconds
                ResourceRecords: [
                  {
                    Value: ipAddress, // IP or target value
                  },
                ],
              },
            },
          ],
          Comment: `Creating subdomain ${subdomain}.${parentDomain}`,
        },
      });
      const result = await clientRoute.send(command);
      this.logger.log(
        `Subdomain Created successfully ${subdomain}.${parentDomain} Result ${result}`,
      );
      return result;
    } catch (error) {
      Sentry.captureException(error);
      throw new HttpException(
        {
          code: 0,
          message: `failed to create subdomain ${error}`,
          data: null,
        } as BaseResponse<string>,
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }
}
