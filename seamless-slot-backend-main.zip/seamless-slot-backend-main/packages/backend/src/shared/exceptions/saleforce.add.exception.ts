import { HttpException, HttpStatus } from '@nestjs/common';

export class SaleForceAddObjectException extends HttpException {
  constructor(
    objectName: string,
    payload: Record<string, string | number | boolean | object>,
  ) {
    super(
      `Saleforce Failed To Insert Record in ${objectName} which the following Body ${payload}`,
      HttpStatus.NOT_FOUND,
    );
  }
}
