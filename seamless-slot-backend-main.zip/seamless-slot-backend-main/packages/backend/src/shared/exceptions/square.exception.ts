import { HttpException, HttpStatus } from '@nestjs/common';
import * as Sentry from '@sentry/nestjs';
import { BaseResponse } from '../interceptor/response.interceptor';

export class SquareApiException extends HttpException {
  constructor(error: string) {
    super(
      {
        code: 0,
        message: error,
        data: error,
      } as BaseResponse<string>,
      HttpStatus.OK,
    );
    Sentry.setTag('square', 'square-api');
    Sentry.captureException(error);
  }
}
