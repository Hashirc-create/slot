import {
  ExceptionFilter,
  Catch,
  ArgumentsHost,
  HttpException,
  HttpStatus,
  Logger,
  BadRequestException,
} from '@nestjs/common';
import * as Sentry from '@sentry/nestjs';
import { BaseResponse } from '../interceptor/response.interceptor';
import { Response } from 'express';
import { CONSTANTS } from '../utils/constants';
import process from 'process';
import { isPrismaException } from '@seamlessslot/database';
import { DatabaseError } from '@seamlessslot/database';

@Catch()
export class AllExceptionsFilter implements ExceptionFilter {
  private logger: Logger = new Logger('AllExceptionsFilter');

  catch(exception: unknown, host: ArgumentsHost) {
    const ctx = host.switchToHttp();
    const response = ctx.getResponse();
    const request = ctx.getRequest();
    const isHttpException = exception instanceof HttpException;
    const isBadRequestException = exception instanceof BadRequestException;

    if (isPrismaException(exception)) {
      this.handlePrismaException(exception, host);
      return;
    }

    if (isBadRequestException) {
      this.handleValidationException(exception, host);
      return;
    }

    if (isHttpException) {
      this.handleHttpException(exception, host);
      return;
    }

    // Capture the exception with Sentry
    Sentry.setTag('all', 'exception');
    Sentry.captureException(exception);

    this.logger.error(
      `${(exception as Error).stack} - ${(exception as Error).message}`,
    );

    response.status(HttpStatus.INTERNAL_SERVER_ERROR).json({
      statusCode: HttpStatus.INTERNAL_SERVER_ERROR,
      timestamp: new Date().toISOString(),
      path: request.url,
      message: `Internal Server Error : ${(exception as Error).message}`,
      code: 0,
      data: null,
      stack: (exception as Error).stack,
    });
  }

  handleHttpException(exception: unknown, host: ArgumentsHost) {
    const ctx = host.switchToHttp();
    const response = ctx.getResponse();
    const request = ctx.getRequest();

    // Capture the exception with Sentry
    Sentry.setTag('http', 'exception');
    Sentry.captureException(exception);

    const httpException = exception as HttpException;
    const status = httpException.getStatus();
    const payload: BaseResponse<string> =
      httpException.getResponse() as BaseResponse<string>;

    response.status(status).json({
      statusCode: status,
      timestamp: new Date().toISOString(),
      path: request.url,
      message: payload.message,
      code: payload.code,
      data: payload.data,
    });
  }

  handleValidationException(
    exception: BadRequestException,
    host: ArgumentsHost,
  ) {
    const ctx = host.switchToHttp();
    const response = ctx.getResponse();
    const request = ctx.getRequest();
    const exceptionResponse = exception.getResponse();
    let responseMessage = '';

    if (typeof exceptionResponse === 'string') {
      responseMessage += exceptionResponse;
    }

    if (typeof exceptionResponse === 'object') {
      // eslint-disable-next-line
      //@ts-ignore
      (exceptionResponse as unknown).message.forEach(
        (val: string) => (responseMessage += `${val} \n`),
      );
    }

    response.status(HttpStatus.BAD_REQUEST).json({
      statusCode: HttpStatus.BAD_REQUEST,
      timestamp: new Date().toISOString(),
      path: request.url,
      message: responseMessage,
    });
  }

  handlePrismaException(exception: DatabaseError, host: ArgumentsHost) {
    const ctx = host.switchToHttp();
    const response = ctx.getResponse<Response>();
    const message = exception.message.replace(/\n/g, '');

    Sentry.setTag('prisma', 'Prisma Exception');
    Sentry.captureException(exception);

    console.log(exception);

    switch (exception.code) {
      case CONSTANTS.POSTGRES_ERRORS.UNIQUE_CONSTRAINT_VIOLATION: {
        const status = HttpStatus.BAD_REQUEST;
        response.status(status).json({
          statusCode: status,
          message: `${exception.meta.target.toString()} should be unique while creating ${exception.meta.modelName}`,
          error: process.env.NODE_ENV === 'development' ? message : '',
        });
        break;
      }
      case CONSTANTS.POSTGRES_ERRORS.NOT_FOUND: {
        const status = HttpStatus.BAD_REQUEST;
        response.status(status).json({
          statusCode: status,
          message: 'Resource not found',
          error: process.env.NODE_ENV === 'development' ? message : '',
        });
        break;
      }
      case CONSTANTS.POSTGRES_ERRORS.UNIQUE_RELATION_VIOLATED: {
        const status = HttpStatus.BAD_REQUEST;
        response.status(status).json({
          statusCode: status,
          message: 'Unique Relation Constraint Violation',
          error: process.env.NODE_ENV === 'development' ? message : '',
        });
        break;
      }

      default:
        response.status(HttpStatus.INTERNAL_SERVER_ERROR).json({
          statusCode: HttpStatus.INTERNAL_SERVER_ERROR,
          message: 'Prisma Database Error (Handle Exception)',
        });
        break;
    }
  }
}
