import { HttpException, HttpStatus } from '@nestjs/common';
import * as Sentry from '@sentry/nestjs';
import { BaseResponse } from '../interceptor/response.interceptor';

export class ResourceNotFoundException extends HttpException {
  constructor(resourceName: string, resourceId: number) {
    super(
      {
        code: 0,
        message: `Requested ${resourceName} Not Found Against Id ${resourceId}`,
        data: null,
      } as BaseResponse<null>,
      HttpStatus.OK,
    );
    Sentry.setTag('prisma', 'Prisma Exception');
    Sentry.captureException(
      `Requested ${resourceName} Not Found Against Id ${resourceId}`,
    );
  }
}
