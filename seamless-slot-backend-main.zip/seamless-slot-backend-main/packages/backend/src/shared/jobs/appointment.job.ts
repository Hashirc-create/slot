import { Inject, Injectable, Logger } from '@nestjs/common';
import { SchedulerRegistry } from '@nestjs/schedule';
import { CronJob } from 'cron';
import {
  Business,
  Customer,
  CustomerReminderTimeUnit,
} from '@seamlessslot/core';
import { Appointment } from '@seamlessslot/core';
import { Location } from '@seamlessslot/core';
import { SecurityContext } from '../auth/context/security.context';
import { Service } from '@seamlessslot/core';
import { AppointmentWithPendingPaymentPayload } from '@seamlessslot/core';
import { getAppointmentWithPendingStatusTemplate } from '../gateways/templates/appointmentPaymentPending';
import { EmailGateway, IEmailGateway } from '../gateways/email/email.gateway';
import { TimeZoneService } from '../utils/timezone.util';
import { getFollowUpCustomerEmailTemplate } from '../gateways/templates/followUpCustomer';
import { RepositoryFactory } from '@seamlessslot/database';
import {
  ISmsServiceSeamlessSlot,
  SmsServiceSeamlessSlot,
} from '@seamlessslot/sms/dist/src/sms.service';

export interface AppointmentScheduleJob {
  schedulePaymentEmailAndSmsJob(
    appointmentId: number,
    paymentLink: string,
    customer: Customer,
    appointment: Appointment,
    service: Service,
    location: Location,
    business: Business,
  ): void;

  deleteSchedulePaymentLinkEmailJob(orderId: string): void;
}

export const IAppointmentScheduleJob = Symbol('AppointmentScheduleJob');

@Injectable()
export class AppointmentScheduleJobImpl implements AppointmentScheduleJob {
  private readonly logger = new Logger(AppointmentScheduleJobImpl.name);

  constructor(
    private schedulerRegistry: SchedulerRegistry,
    @Inject(IEmailGateway)
    private readonly emailService: EmailGateway,
    private readonly timeZoneService: TimeZoneService,
    private readonly repoFactory: RepositoryFactory,
    private readonly securityContext: SecurityContext,
    @Inject(ISmsServiceSeamlessSlot)
    private readonly smsService: SmsServiceSeamlessSlot,
  ) {}

  async execute(
    appointmentId: number,
    paymentLink: string,
    appointment: Appointment,
    customer: Customer,
    service: Service,
    location: Location,
    business: Business,
  ) {
    const currentAppointment =
      await this.repoFactory.appointmentRepository.findById(appointment.id);

    const admins =
      await this.repoFactory.userRepository.findAllAdminsByLocation(
        location.id,
      );

    if (currentAppointment.status === 'Pending') {
      this.sendPaymentLinkEmail(
        business,
        location,
        customer,
        paymentLink,
        appointment,
        service,
      );
      this.sendPaymentLinkSms(
        business,
        customer,
        paymentLink,
        appointment,
        location,
      );
      for (const admin of admins) {
        this.sendFollowUpEmailToAdmin(
          business,
          admin.email,
          customer,
          location,
        );
      }
      this.logger.warn(
        `Appointment Pending Hence Job for order ${appointmentId} executed and payment link and provisional email sent`,
      );
    } else {
      this.logger.warn(
        `Appointment confirmed Hence Job for order ${appointmentId} only deleted`,
      );
    }
  }

  schedulePaymentEmailAndSmsJob(
    appointmentId: number,
    paymentLink: string,
    customer: Customer,
    appointment: Appointment,
    service: Service,
    location: Location,
    business: Business,
  ) {
    const calculatedCronTime = this.convertMinutesToCronTime(
      location.customerReminderTime,
      location.customerReminderTimeUnit,
    );

    const job: CronJob = new CronJob(
      calculatedCronTime,
      async () => {
        await this.execute(
          appointmentId,
          paymentLink,
          appointment,
          customer,
          service,
          location,
          business,
        );
        this.deleteSchedulePaymentLinkEmailJob(appointmentId.toString());
      },
      null,
      true,
      'UTC',
    );

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    this.schedulerRegistry.addCronJob(appointmentId.toString(), job as any);
    job.start();
    this.logger.warn(
      `Scheduler Job for order ${appointmentId} added and started.`,
    );
  }

  private convertMinutesToCronTime(
    value: number,
    unit: CustomerReminderTimeUnit,
  ) {
    let minutes = 0;
    if (unit === 'minutes') minutes = value;
    else if (unit === 'hours') minutes = value * 60;
    const afterMinutes = new Date(Date.now() + minutes * 60 * 1000);
    return `${afterMinutes.getUTCMinutes()} ${afterMinutes.getUTCHours()} * * *`;
  }

  deleteSchedulePaymentLinkEmailJob(orderId: string) {
    const job = this.schedulerRegistry.getCronJob(orderId);
    if (job) {
      job.stop();
      this.schedulerRegistry.deleteCronJob(orderId);
      this.logger.warn(
        `Scheduler Job for order ${orderId} successfully deleted`,
      );
    } else {
      this.logger.warn(`Scheduler Job for order ${orderId} not found.`);
    }
  }

  private async sendPaymentLinkSms(
    business: Business,
    customer: Customer,
    paymentLink: string,
    appointment: Appointment,
    location: Location,
  ) {
    this.smsService.sendPaymentLinkSms({
      to: customer.phoneNo,
      customerFirstName: customer.firstName,
      customerLastName: customer.lastName,
      businessName: business.name,
      locationName: location.name,
      locationAddress: location.address,
      appointmentDate: this.timeZoneService.formatDatePreservingUTC(
        appointment.startTime as Date,
        'EEEE dd MMM yyyy',
      ),
      appointmentStartTime: this.timeZoneService.formatDatePreservingUTC(
        appointment.startTime as Date,
        'hh:mm a',
      ),
      paymentLink: paymentLink,
    });
  }

  private async sendPaymentLinkEmail(
    business: Business,
    location: Location,
    customer: Customer,
    paymentLink: string,
    appointment: Appointment,
    service: Service,
  ) {
    // EEEE dd MMMM yyyy hh:mm aa
    const templatePayload: AppointmentWithPendingPaymentPayload = {
      businessName: business.name,
      fullName: customer.firstName + ' ' + customer.lastName,
      paymentLink: paymentLink,
      bookingId: appointment.id.toString(),
      service: service.title,
      duration: service.durationInMinutes.toString(),
      cost: service.cost.toString(),
      dateTimeOfAppointment:
        this.timeZoneService.formatDatePreservingUTC(
          appointment.startTime as Date,
          'EEEE dd MMMM yyyy hh:mm aa',
        ) +
        ' - ' +
        this.timeZoneService.formatDatePreservingUTC(
          appointment.endTime as Date,
          'hh:mm aa',
        ),
      customerName: customer.firstName + ' ' + customer.lastName,
      customerEmail: customer.email,
      customerPhone: customer.phoneNo,
      amountCharged: service.cost.toString(),
      locationAddress: location.address,
      gmapUrl: location.googleMapUrl,
    };

    await this.emailService.sendEmailFromInfo({
      title: business.name,
      to: customer.email,
      subject: 'Seamless Slot Appointment Booking (Pending Payment)',
      bcc: '',
      html: getAppointmentWithPendingStatusTemplate(templatePayload),
    });
  }

  private async sendFollowUpEmailToAdmin(
    business: Business,
    to: string,
    customer: Customer,
    location: Location,
  ) {
    await this.emailService.sendEmailFromInfo({
      title: business.name,
      to,
      subject: 'Follow-Up on Provisional Booking',
      html: getFollowUpCustomerEmailTemplate({
        businessName: business.name,
        name: customer.firstName + ' ' + customer.lastName,
        phone: customer.phoneNo,
        email: customer.email,
        locationName: location.name,
      }),
    });
  }
}
