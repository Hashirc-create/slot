import { Inject, Injectable, Logger } from '@nestjs/common';
import { Cron } from '@nestjs/schedule';
import { ISquareApi, SquareApi } from '../square/square.api.service';
import { Location } from '@seamlessslot/core';
import * as Sentry from '@sentry/nestjs';
import { RepositoryFactory } from '@seamlessslot/database';

@Injectable()
export class SquarePayRefreshTokensCronJob {
  private readonly logger = new Logger(SquarePayRefreshTokensCronJob.name);

  constructor(
    private readonly repoFactory: RepositoryFactory,
    @Inject(ISquareApi)
    private readonly squareApi: SquareApi,
  ) {}

  // @Cron('*/10 * * * * *')
  // @Cron('* * * * *')
  @Cron('0 */8 * * *')
  async handleCron() {
    this.logger.log('Starting Cron Job Square Pay');
    const allPaymentsAccounts =
      await this.repoFactory.paymentAccountRepository.findAllPaymentAccountsByType(
        'Square-Pay',
      );

    for (const paymentAccount of allPaymentsAccounts) {
      const response = await this.squareApi.getNewTokens(
        paymentAccount.accessToken,
        paymentAccount.refreshToken,
      );

      if (response) {
        await this.repoFactory.paymentAccountRepository.update(
          paymentAccount.id,
          {
            ...paymentAccount,
            location: (paymentAccount.location as Location).id,
            refreshToken: response.refreshToken,
            accessToken: response.accessToken,
          },
        );

        this.logger.log(
          `Square pay token refreshed successfully for location : ${(paymentAccount.location as Location).name}`,
        );
      } else {
        this.logger.error(
          `Square pay token refreshing failed for location : ${(paymentAccount.location as Location).name}`,
        );
        Sentry.captureMessage(
          `Failed to refresh Square Pay Access Tokens for Location: ${(paymentAccount.location as Location).name}
              with errors ${JSON.stringify(response.errors)}`,
          'error',
        );
      }
    }
    this.logger.log('Ending Cron Job Square Pay');
  }
}
