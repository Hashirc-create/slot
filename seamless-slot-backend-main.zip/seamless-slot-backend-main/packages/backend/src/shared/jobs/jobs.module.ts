import { Global, Module } from '@nestjs/common';
import { SquarePayRefreshTokensCronJob } from './square.pay';
import {
  AppointmentScheduleJobImpl,
  IAppointmentScheduleJob,
} from './appointment.job';

@Global()
@Module({
  providers: [
    SquarePayRefreshTokensCronJob,
    {
      provide: IAppointmentScheduleJob,
      useClass: AppointmentScheduleJobImpl,
    },
  ],
  exports: [
    {
      provide: IAppointmentScheduleJob,
      useClass: AppointmentScheduleJobImpl,
    },
    SquarePayRefreshTokensCronJob,
  ],
})
export class JobsModule {}
