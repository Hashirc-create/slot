import {
  Injectable,
  NestInterceptor,
  ExecutionContext,
  CallHandler,
} from '@nestjs/common';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
export interface BaseResponse<T> {
  code: number;
  message: string;
  data: T;
}

@Injectable()
export class BaseResponseInterceptor<T>
  implements NestInterceptor<T, BaseResponse<T>>
{
  async intercept(
    context: ExecutionContext,
    next: CallHandler,
  ): Promise<Observable<BaseResponse<T>>> {
    return next.handle().pipe(
      map((data) => ({
        code: 0,
        message: 'success',
        data: data,
      })),
    );
  }
}
