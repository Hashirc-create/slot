import { Global, Logger, Module, OnModuleInit } from '@nestjs/common';
import { WebSocketService } from './websocket.service';

@Global()
@Module({
  providers: [WebSocketService],
  exports: [WebSocketService],
})
export class WebSocketModule implements OnModuleInit {
  onModuleInit() {
    new Logger('WebsocketModule').debug('WebSocketModule Injected');
  }
}
