import { Logger } from '@nestjs/common';
import {
  WebSocketGateway,
  WebSocketServer,
  SubscribeMessage,
  MessageBody,
  OnGatewayInit,
  OnGatewayConnection,
  OnGatewayDisconnect,
} from '@nestjs/websockets';
import { Server } from 'socket.io';

// usage
// this.socket.server.emit('message', currentChatSaved);

@WebSocketGateway(parseInt(process.env.SOCKETIO_PORT) || 3001, {
  cors: {
    origin: '*',
  },
})
export class WebSocketService
  implements OnGatewayInit, OnGatewayConnection, OnGatewayDisconnect
{
  @WebSocketServer()
  server: Server;

  @SubscribeMessage('message')
  handleMessage(
    @MessageBody()
    data: string,
  ): void {
    this.server.emit('message', data);
  }

  public handleConnection() {
    new Logger('Connection').debug('Connected');
  }

  public handleDisconnect() {
    new Logger('Connection').debug('Diconnected');
  }

  public afterInit() {
    new Logger('Connection').debug('After Init');
  }
}
