import { hash, genSalt, compareSync } from 'bcrypt';

export async function encrypt(plainPassword: string) {
  const salt = await genSalt(10);
  return await hash(plainPassword, salt);
}

export function comparePassword(plainPassword: string, hashedPassword: string) {
  return compareSync(plainPassword, hashedPassword);
}
