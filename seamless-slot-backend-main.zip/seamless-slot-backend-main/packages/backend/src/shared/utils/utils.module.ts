import { Global, Module } from '@nestjs/common';
import { TimeZoneService } from './timezone.util';

@Global()
@Module({
  providers: [TimeZoneService],
  exports: [TimeZoneService],
})
export class UtilsModule {}
