export const CONSTANTS = {
  NIGHT_AND_DAY: 'Night and Day Emergency Dentist',
  DEV: 'development',
  PROD: 'production',
  STAGING: 'statging',
  TEST: 'test',
  ENV: 'NODE_ENV',
  UTC_CHECK_REGEX: /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z$/, //`1996-06-10T09:00:00Z`
  SALEFORCE: 'SALEFORCE',
  BASE_ERR_MESSAGES: {
    TOKEN_EXPIRED: 'Token expired',
    INVALID_TOKEN: 'Invalid Token',
  },
  POSTGRES_ERRORS: {
    UNIQUE_CONSTRAINT_VIOLATION: 'P2002',
    NOT_FOUND: 'P2025',
    UNIQUE_RELATION_VIOLATED: 'P2014',
  },
  WEBSOCKETS_EVENTS: {
    PUBLIC_APPOINTMENT_CREATED: 'PUBLIC_APPOINTMENT_CREATED',
  },
  WEEKDAYS: [
    'Monday',
    'Tuesday',
    'Wednesday',
    'Thursday',
    'Friday',
    'Saturday',
    'Sunday',
  ],
};

export type BROKER_QUEUE = 'saleforce';
