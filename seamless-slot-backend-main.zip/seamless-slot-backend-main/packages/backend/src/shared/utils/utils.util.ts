import { Appointment } from '@seamlessslot/core';

export const UTILS = {
  getClassFromStatus(domain: Appointment): string {
    if (domain.status === 'Complete') return 'completed text-white';

    if (domain.status === 'Pending') return 'pending text-white';

    if (domain.status === 'No Show') return 'no-show text-white';

    if (domain.status === 'Confirmed') return 'confirmed text-white';

    if (domain.status === 'Paid') return 'confirmed text-white';

    if (domain.status === 'Cancelled') return 'cancelled text-white';

    if (domain.status === 'Follow Up') return 'follow-up text-white';
  },
  getDefaultWorkingDays() {
    return [
      {
        day: 'Monday',
        from: '1996-06-10T09:00:00Z',
        to: '1996-06-10T17:00:00Z',
        isClosed: false,
      },
      {
        day: 'Tuesday',
        from: '1996-06-10T09:00:00Z',
        to: '1996-06-10T17:00:00Z',
        isClosed: false,
      },
      {
        day: 'Wednesday',
        from: '1996-06-10T09:00:00Z',
        to: '1996-06-10T17:00:00Z',
        isClosed: false,
      },
      {
        day: 'Thursday',
        from: '1996-06-10T09:00:00Z',
        to: '1996-06-10T17:00:00Z',
        isClosed: false,
      },
      {
        day: 'Friday',
        from: '1996-06-10T09:00:00Z',
        to: '1996-06-10T17:00:00Z',
        isClosed: false,
      },
      {
        day: 'Saturday',
        from: '1996-06-10T09:00:00Z',
        to: '1996-06-10T17:00:00Z',
        isClosed: true,
      },
      {
        day: 'Sunday',
        from: '1996-06-10T09:00:00Z',
        to: '1996-06-10T17:00:00Z',
        isClosed: true,
      },
    ];
  },
  getPaymentLinkShortURL(bookingId: string) {
    const protocol: string =
      process.env.NODE_ENV === 'development' ? 'http' : 'https';
    const parentDomain: string = process.env.PARENT_DOMAIN;

    return `${protocol}://payments.${parentDomain}/pay/${bookingId}`;
  },
};
