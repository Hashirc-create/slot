import { Injectable } from '@nestjs/common';
import { SupportedTimeZones } from '@seamlessslot/core';
import { formatInTimeZone, toZonedTime } from 'date-fns-tz';
import { SecurityContext } from '../auth/context/security.context';
import { CONSTANTS } from './constants';
import { format } from 'date-fns';

@Injectable()
export class TimeZoneService {
  private responseDateTimeFormat = 'yyyy-MM-dd hh:mm:ssXXX';

  constructor(private readonly securityContext: SecurityContext) {}

  /**
   * Converts the given UTC date string to the specified time zone and formats it according to the provided format string.
   *
   * @param {string} dateString - A string representing the UTC date and time in a valid format. Accepted formats: ISO 8601
   * (e.g., "1996-06-10T12:00:00Z").
   * @param {SupportedTimeZones} timeZone - The target time zone to which the date and time should be converted.
   * @param {string} format - The desired format for the output date and time string.
   * @return {string} The date and time string converted to the specified time zone and formatted as per the given format.
   * @throws {Error} Throws an error if the provided date string is not a valid UTC date-time string.
   */
  convertUTCToSpecifiedTimeZone(
    dateString: string,
    timeZone: SupportedTimeZones,
    format: string,
  ) {
    if (!CONSTANTS.UTC_CHECK_REGEX.test(dateString)) {
      throw new Error(
        'Invalid UTC Date Time String Provided. Accepted formats: ISO 8601 (e.g., "1996-06-10T12:00:00Z").',
      );
    }

    return formatInTimeZone(new Date(dateString), timeZone, format);
  }

  /**
   * Converts a simple date string to UTC format by appending the 'Z' character.
   *
   * @param {string} dateString - The date string to convert to UTC format.
   * @return {string} The converted date string in UTC format.
   * @throws {Error} Throws an error if the date string is not in the format 'yyyy-MM-ddThh:mm:ss'.
   */
  convertSimpleDateStringToUTC(dateString: string) {
    const DATE_TIME_REGEX = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}$/;
    if (!DATE_TIME_REGEX.test(dateString)) {
      throw new Error(
        "Invalid date format. Accepted format: 'yyyy-MM-ddThh:mm:ss' (e.g., '1996-06-10T09:00:00'). provided " +
          dateString,
      );
    }
    return dateString + 'Z';
  }

  formatDatePreservingUTC(dateObject: Date, formatString: string) {
    const keepUTC = toZonedTime(dateObject, 'UTC'); // this will make sure the date object remains in utc
    return format(keepUTC, formatString);
  }
}
