import { Injectable, Scope } from '@nestjs/common';
import { Role, SupportedTimeZones } from '@seamlessslot/core';

@Injectable({
  scope: Scope.REQUEST,
})
export class SecurityContext {
  private nameOfUser: string;
  private role: Role;
  private email: string;
  private id: number;
  private locationId: number;
  private businessId: number;
  private timeZone: SupportedTimeZones;

  // Getters for each property
  getNameOfUser(): string {
    return this.nameOfUser;
  }

  getBusinessId(): number {
    return this.businessId;
  }

  getRole(): Role {
    return this.role;
  }

  getEmail(): string {
    return this.email;
  }

  getId(): number {
    return this.id;
  }

  getLocationId(): number {
    return this.locationId;
  }

  getTimeZone(): SupportedTimeZones {
    return this.timeZone;
  }

  // A single method to set all properties
  setSecurityContext(
    nameOfUser: string,
    role: Role,
    email: string,
    id: number,
    locationId: number,
    businessId: number,
    timeZone: SupportedTimeZones,
  ): void {
    this.nameOfUser = nameOfUser;
    this.role = role;
    this.email = email;
    this.id = id;
    this.locationId = locationId;
    this.businessId = businessId;
    this.timeZone = timeZone;
  }

  // Setters for each property
  setNameOfUser(nameOfUser: string): void {
    this.nameOfUser = nameOfUser;
  }

  setRole(role: Role): void {
    this.role = role;
  }

  setEmail(email: string): void {
    this.email = email;
  }

  setId(id: number): void {
    this.id = id;
  }

  setLocationId(locationId: number): void {
    this.locationId = locationId;
  }

  setBusinessId(businessId: number): void {
    this.businessId = businessId;
  }

  setTimeZone(timeZone: SupportedTimeZones): void {
    this.timeZone = timeZone;
  }
}
