import {
  HttpException,
  HttpStatus,
  Injectable,
  NestMiddleware,
} from '@nestjs/common';
import { Request, Response, NextFunction } from 'express';
import { CustomJwtService } from '../service/jwt.service';
import { JWTPayLoad } from '../types';
import { SecurityContext } from '../context/security.context';
import { SupportedTimeZones } from '@seamlessslot/core';
import { BaseResponse } from '../../interceptor/response.interceptor';

@Injectable()
export class AccessTokenMiddlware implements NestMiddleware {
  public readonly pathsToExclude: string[] = [
    '/api',
    '/app/*',
    '/seeder/*',
    '/dev',
    '/location/findAll',
    '/location/findById/*',
    '/location/findCancellationPolicy/*',
    '/app/sendEmail/*',
    '/user/logout',
    '/user/refresh',
    '/user/login',
    '/service-category',
    '/service/findAllByLocation/*',
    '/appointment/getAvaliableDates/*',
    '/appointment/getAvaliableSlotsByDate',
    '/appointment/public/create',
    '/appointment/public/create/no-payment',
    '/appointment/public/take-payment',
    '/appointment/public/appointmentSummary',
    '/appointment/checkIfSlotBooked',
    '/payment-accounts/square',
    '/square-oauth/login/sandbox',
    '/square-oauth/callback/sandbox',
    '/square/webhook',
    '/google-analytics/findByLocation/*',
    '/google-tag-manager/findByLocation/*',
    '/revoke/*',
    // '/customer/add',
    '/business/findBySubdomain/*',
    '/pay/*',
    // '/dashboard/*',
  ];

  constructor(
    private readonly jwtService: CustomJwtService,
    private readonly securityContext: SecurityContext,
  ) {}

  use(req: Request, res: Response, next: NextFunction) {
    const isAllowed = this.pathsToExclude.some((urlPattern: string) => {
      return req.originalUrl.startsWith(urlPattern.replace('*', ''));
    });

    console.log(isAllowed, req.originalUrl);
    if (isAllowed) {
      return next();
    }

    const header = req.headers.authorization;

    if (!header) {
      throw new HttpException(
        {
          code: 0,
          message: 'UnAuthorized',
          data: 'UnAuthorized',
        } as BaseResponse<string>,
        HttpStatus.UNAUTHORIZED,
      );
    }

    const token = header.split(' ')[1];

    const payload: JWTPayLoad = this.jwtService.verifyAccessToken(token);

    this.securityContext.setBusinessId(payload.businessId);
    this.securityContext.setLocationId(payload.locationId);
    this.securityContext.setRole(payload.role);
    this.securityContext.setEmail(payload.email);
    this.securityContext.setId(payload.id);
    this.securityContext.setTimeZone(payload.timeZone as SupportedTimeZones);
    this.securityContext.setNameOfUser(
      payload.firstName + ' ' + payload.lastName,
    );
    next();
  }
}
