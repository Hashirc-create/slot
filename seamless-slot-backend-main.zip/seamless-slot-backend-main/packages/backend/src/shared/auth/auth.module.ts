import { Global, Module } from '@nestjs/common';
import { CustomJwtService } from './service/jwt.service';
import { SecurityContext } from './context/security.context';
import { RoleGuard } from './guard/jwt.guard';

@Global()
@Module({
  imports: [],
  providers: [CustomJwtService, SecurityContext, RoleGuard],
  exports: [CustomJwtService, SecurityContext],
})
export class AuthModule {}
