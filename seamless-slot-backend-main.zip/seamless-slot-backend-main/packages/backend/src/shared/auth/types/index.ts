import { Role } from '@seamlessslot/core';

export interface JWTPayLoad {
  id?: number;
  firstName: string;
  lastName: string;
  email: string;
  role: Role;
  timeZone: string;
  locationId: number;
  businessId: number;
}

export interface RefreshPayload {
  userId: number;
  tokenVersion: number;
  role: Role;
}
