import { Injectable, UnauthorizedException } from '@nestjs/common';
import { TokenExpiredError, sign, verify } from 'jsonwebtoken';
import { ConfigService } from '@nestjs/config';
import { JWTPayLoad, RefreshPayload } from '../types';
import { CONSTANTS } from '../../utils/constants';

@Injectable()
export class CustomJwtService {
  constructor(private readonly configService: ConfigService) {}
  public async generateAccessToken(
    payload: JWTPayLoad,
    expiry?: string,
  ): Promise<string> {
    return sign(
      payload,
      this.configService.get('JWT_ACCESS_TOKEN_SECRETE_KEY'),
      {
        expiresIn: expiry || this.configService.get('JWT_ACCESS_TOKEN_EXPIRY'),
      },
    );
  }

  public async generateRefreshToken(
    payload: RefreshPayload,
    expiry?: string,
  ): Promise<string> {
    return sign(
      payload,
      this.configService.get('JWT_REFRESH_TOKEN_SECRETE_KEY'),
      {
        expiresIn: expiry || this.configService.get('JWT_REFRESH_TOKEN_EXPIRY'),
      },
    );
  }

  public verifyAccessToken(token: string): JWTPayLoad {
    try {
      const payload = verify(
        token,
        this.configService.get('JWT_ACCESS_TOKEN_SECRETE_KEY'),
      );
      return payload as JWTPayLoad;
    } catch (error) {
      this.handleJwtError(error);
    }
  }

  public handleJwtError(error: unknown) {
    if (error instanceof TokenExpiredError) {
      throw new UnauthorizedException(
        CONSTANTS.BASE_ERR_MESSAGES.TOKEN_EXPIRED,
      );
    }

    throw new UnauthorizedException(CONSTANTS.BASE_ERR_MESSAGES.INVALID_TOKEN);
  }

  public verfiyRefreshToken(token: string): RefreshPayload {
    try {
      const payload = verify(
        token,
        this.configService.get('JWT_REFRESH_TOKEN_SECRETE_KEY'),
      );
      return payload as RefreshPayload;
    } catch (error) {
      this.handleJwtError(error);
    }
  }
}
