import { Reflector } from '@nestjs/core';
import { Role } from '@seamlessslot/core';

export const Roles = Reflector.createDecorator<Role[]>();
