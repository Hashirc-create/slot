import { NestMiddleware, Logger, Injectable } from '@nestjs/common';
import { Request, Response, NextFunction } from 'express';

@Injectable()
export class LoggingMiddleware implements NestMiddleware {
  private readonly logger = new Logger(LoggingMiddleware.name);

  use(req: Request, res: Response, next: NextFunction): void {
    const { method, originalUrl, body } = req;
    const startTime = Date.now();
    const chunks: Buffer[] = [];

    // Log incoming request
    this.logger.log(
      `Incoming Request: ${method} ${originalUrl} ${JSON.stringify(body)}`,
    );

    // Capture response data
    const originalWrite = res.write;
    const originalEnd = res.end;

    res.write = (chunk: unknown, ...args: unknown[]) => {
      // eslint-disable-next-line
      // @ts-ignore
      chunks.push(Buffer.from(chunk));
      return originalWrite.apply(res, [chunk, ...args]);
    };

    res.end = (chunk: unknown, ...args: unknown[]) => {
      if (chunk) {
        // eslint-disable-next-line
        // @ts-ignore
        chunks.push(Buffer.from(chunk));
      }

      const responseBody = Buffer.concat(chunks).toString('utf8');
      const { statusCode } = res;
      const responseTime = Date.now() - startTime;

      // Log outgoing response with body
      this.logger.log(
        `Outgoing Response: ${method} ${originalUrl} - Status: ${statusCode} - Response Time: ${responseTime}ms - Body: ${responseBody}`,
      );

      return originalEnd.apply(res, [chunk, ...args]);
    };

    next();
  }
}
