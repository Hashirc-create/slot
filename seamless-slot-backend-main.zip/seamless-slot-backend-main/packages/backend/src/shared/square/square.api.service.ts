import { HttpException, HttpStatus, Injectable, Logger } from '@nestjs/common';
import { SquareEnvService } from './square.env.service';
import {
  ApiError,
  CreatePaymentLinkRequest,
  Location,
  ObtainTokenResponse,
  PaymentLink,
  RefundPaymentResponse,
  RevokeTokenResponse,
} from 'square';
import { SquareApiException } from '../exceptions/square.exception';
import { uuid } from 'uuidv4';
import { BaseResponse } from '../interceptor/response.interceptor';

export const ISquareApi = Symbol('SquareApi');

export interface SquareApi {
  getAllSquareLocations(accessToken: string): Promise<readonly Location[]>;

  createSquarePaymentLink(
    accessToken: string,
    payload: CreatePaymentLinkRequest,
  ): Promise<Readonly<PaymentLink>>;

  revokeAccessToken(
    accessToken: string,
  ): Promise<Readonly<RevokeTokenResponse>>;

  refundSquareTransaction(
    accessToken: string,
    squareTranscationId: string,
    amount: number,
  ): Promise<Readonly<RefundPaymentResponse>>;

  getNewTokens(
    accessToken: string,
    refreshToken: string,
  ): Promise<Readonly<ObtainTokenResponse>>;
}

@Injectable()
export class SquareApiImpl implements SquareApi {
  private readonly logger: Logger = new Logger(SquareApiImpl.name);

  constructor(private readonly squareEnvService: SquareEnvService) {}

  async getNewTokens(
    accessToken: string,
    refreshToken: string,
  ): Promise<Readonly<ObtainTokenResponse>> {
    const client =
      this.squareEnvService.getSquareClientWithAccessToken(accessToken);

    try {
      const response = await client.oAuthApi.obtainToken({
        clientId: this.squareEnvService.getClientId(),
        clientSecret: this.squareEnvService.getClientSecret(),
        grantType: 'refresh_token',
        refreshToken: refreshToken,
      });

      return response.result;
    } catch (error) {
      this.handleRefreshTokenError(error);
    }
  }

  async refundSquareTransaction(
    accessToken: string,
    squareTranscationId: string,
    amount: number,
  ): Promise<Readonly<RefundPaymentResponse>> {
    const client =
      this.squareEnvService.getSquareClientWithAccessToken(accessToken);

    try {
      const response = await client.refundsApi.refundPayment({
        amountMoney: {
          amount: BigInt(amount),
          currency: 'GBP',
        },
        idempotencyKey: uuid(),
        paymentId: squareTranscationId,
        unlinked: false,
      });
      return response.result;
    } catch (error) {
      this.handleSquareError(error);
    }
  }

  async revokeAccessToken(
    accessToken: string,
  ): Promise<Readonly<RevokeTokenResponse>> {
    const client =
      this.squareEnvService.getSquareClientWithAccessToken(accessToken);

    try {
      const response = await client.oAuthApi.revokeToken(
        {
          accessToken,
          clientId: this.squareEnvService.getClientId(),
          revokeOnlyAccessToken: false,
        },
        'Client ' + this.squareEnvService.getClientSecret(),
      );
      return response.result;
    } catch (error) {
      this.handleSquareError(error);
    }
  }

  async createSquarePaymentLink(
    accessToken: string,
    payload: CreatePaymentLinkRequest,
  ): Promise<Readonly<PaymentLink>> {
    const client =
      this.squareEnvService.getSquareClientWithAccessToken(accessToken);

    try {
      const response = await client.checkoutApi.createPaymentLink(payload);
      return response.result.paymentLink;
    } catch (error) {
      this.handleSquareError(error);
    }
  }

  async getAllSquareLocations(
    accessToken: string,
  ): Promise<readonly Location[]> {
    const client =
      this.squareEnvService.getSquareClientWithAccessToken(accessToken);

    try {
      const locations = await client.locationsApi.listLocations();
      return locations.result.locations;
    } catch (error) {
      this.handleSquareError(error);
    }
  }

  public handleSquareError(error: unknown) {
    if (error instanceof ApiError) {
      console.log(JSON.stringify(error));
      const errors = error.errors.map((err) => err.detail);
      throw new SquareApiException(errors?.toString() || 'Square Api Error');
    }

    throw new HttpException(
      {
        code: 0,
        message: 'Square Api Unknown Error',
        data: 'Square Api Unknown Error',
      } as BaseResponse<string>,
      HttpStatus.OK,
    );
  }

  public handleRefreshTokenError(error: unknown) {
    if (error instanceof ApiError) {
      console.log(JSON.stringify(error));
      const errors = error.errors.map((err) => err.detail);
      this.logger.error('Failed To Refresh Token : ' + errors);
    }
    this.logger.error('Failed To Refresh Token');
  }
}
