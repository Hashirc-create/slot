import { Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { Client, Environment } from 'square';

@Injectable()
export class SquareEnvService {
  private readonly basePath: string;
  private readonly clientId: string;
  private readonly clientSecret: string;
  private readonly frontendRedirectURL: string;
  private readonly enviornment: Environment;

  constructor(private readonly configService: ConfigService) {
    const isSandbox: boolean =
      this.configService.get('NODE_ENV') === 'development';

    if (isSandbox) {
      this.basePath = 'https://connect.squareupsandbox.com';
      this.clientId = this.configService.get<string>(
        'SQUARE_PAY_CLIENT_ID_SANDBOX',
      );
      this.clientSecret = this.configService.get<string>(
        'SQUARE_PAY_CLIENT_SECRETE_SANDBOX',
      );
      this.frontendRedirectURL = this.configService.get<string>(
        'SQUARE_PAY_FRONT_END_REDIRECT_URL_SANDBOX',
      );
      this.enviornment = Environment.Sandbox;
    } else {
      this.basePath = 'https://connect.squareup.com';
      this.clientId = this.configService.get<string>(
        'SQUARE_PAY_CLIENT_ID_PROD',
      );
      this.clientSecret = this.configService.get<string>(
        'SQUARE_PAY_CLIENT_SECRETE_PROD',
      );
      this.frontendRedirectURL = this.configService.get<string>(
        'SQUARE_PAY_FRONT_END_REDIRECT_URL_PROD',
      );
      this.enviornment = Environment.Production;
    }

    this.logVariables();
  }

  logVariables() {
    console.log('Base Path : ', this.basePath);
    console.log('ClientId : ', this.clientId);
    console.log('ClientSecrete : ', this.clientSecret);
    console.log('Square Env : ', this.enviornment);
  }

  getBasePath() {
    return this.basePath;
  }

  getClientId() {
    return this.clientId;
  }

  getClientSecret() {
    return this.clientSecret;
  }

  getFrontendRedirectURL() {
    return this.frontendRedirectURL;
  }

  getEnviornment() {
    return this.enviornment;
  }

  getSquareClient(): Client {
    const client = new Client({
      environment: this.getEnviornment(),
    });

    return client;
  }

  getSquareClientWithAccessToken(accessToken: string): Client {
    const client = new Client({
      environment: this.getEnviornment(),
      accessToken,
    });

    return client;
  }
}
