import { Global, Module } from '@nestjs/common';
import { SquareEnvService } from './square.env.service';
import { ISquareApi, SquareApiImpl } from './square.api.service';

@Global()
@Module({
  providers: [
    SquareEnvService,
    {
      provide: ISquareApi,
      useClass: SquareApiImpl,
    },
  ],
  exports: [
    {
      provide: ISquareApi,
      useClass: SquareApiImpl,
    },
    SquareEnvService,
  ],
})
export class SquareApiModule {}
