import { Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';

@Injectable()
export class DentallyEnvService {
  private readonly baseURL: string;
  private readonly clientId: string;
  private readonly clientSecret: string;
  private readonly frontEndURL: string;

  constructor(private readonly configService: ConfigService) {
    const isSandBox: boolean = JSON.parse(
      this.configService.get('DENTALLY_SANDBOX'),
    );

    if (isSandBox) {
      this.baseURL = 'https://api.sandbox.dentally.co';
      this.clientId = this.configService.get('DENTALLY_CLIENT_ID_SANDBOX');
      this.clientSecret = this.configService.get(
        'DENTALLY_CLIENT_SECRETE_SANDBOX',
      );
      this.frontEndURL = this.configService.get(
        'DENTALLY_FRONT_END_REDIRECT_URL_SANDBOX',
      );
    } else {
      this.baseURL = 'https://api.dentally.co';
      this.clientId = this.configService.get('DENTALLY_CLIENT_ID_PROD');
      this.clientSecret = this.configService.get(
        'DENTALLY_CLIENT_SECRETE_PROD',
      );
      this.frontEndURL = this.configService.get(
        'DENTALLY_FRONT_END_REDIRECT_URL_PROD',
      );
    }
  }

  public getBaseUrl() {
    return this.baseURL;
  }

  public getClientId() {
    return this.clientId;
  }

  public getClientSecret() {
    return this.clientSecret;
  }

  public getFrontendRedirectURL() {
    return this.frontEndURL;
  }
}
