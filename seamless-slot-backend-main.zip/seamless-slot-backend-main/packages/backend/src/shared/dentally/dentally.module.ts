import { Global, Module } from '@nestjs/common';
import { DentallyEnvService } from './dentally.env.service';
import {
  DentallyApiServiceImpl,
  IDentallyApiService,
} from './dentally.api.service';

@Global()
@Module({
  providers: [
    DentallyEnvService,
    {
      provide: IDentallyApiService,
      useClass: DentallyApiServiceImpl,
    },
  ],
  exports: [
    {
      provide: IDentallyApiService,
      useClass: DentallyApiServiceImpl,
    },
  ],
})
export class DentallyModule {}
