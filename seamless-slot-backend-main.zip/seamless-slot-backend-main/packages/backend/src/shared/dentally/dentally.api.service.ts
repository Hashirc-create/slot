import { Injectable } from '@nestjs/common';
import { DentallyEnvService } from './dentally.env.service';

export const IDentallyApiService = Symbol('DentallyApiService');

export interface DentallyApiService {}

@Injectable()
export class DentallyApiServiceImpl implements DentallyApiService {
  constructor(private readonly dentallyEnvService: DentallyEnvService) {}
}
