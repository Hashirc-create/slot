import { MailerService } from '@nestjs-modules/mailer';
import { Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';

export type EmailObject = {
  title: string;
  to: string;
  subject: string;
  html: string;
  bcc?: string;
};

export const IEmailGateway = Symbol('EmailGateway');

export interface EmailGateway {
  sendEmailFromInfo(email: EmailObject): Promise<void>;
}

@Injectable()
export class EmailGatewayImpl implements EmailGateway {
  constructor(
    private readonly mailerService: MailerService,
    private readonly configService: ConfigService,
  ) {}

  async sendEmailFromInfo({
    subject,
    to,
    bcc,
    html,
    title,
  }: EmailObject): Promise<void> {
    const partsOfEmail = to.split('.');
    const isStaging = partsOfEmail[partsOfEmail.length - 1] === 'staging';

    if (isStaging) return;

    try {
      await this.mailerService.sendMail({
        to,
        from: `"${title}" ${this.configService.get('SMTP_SENDER_DOMAIN')}`,
        bcc,
        subject,
        html,
      });
    } catch (error) {
      throw new Error('Error Sendisng Email : ' + JSON.stringify(error));
    }
  }
}
