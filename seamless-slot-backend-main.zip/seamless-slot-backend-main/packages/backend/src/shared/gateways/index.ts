import { EmailGatewayImpl, IEmailGateway } from './email/email.gateway';
import { IImageUploadService, ImageUploadServiceImpl } from './s3/s3.gateway';

export const GATEWAYS = [
  {
    provide: IEmailGateway,
    useClass: EmailGatewayImpl,
  },
  {
    provide: IImageUploadService,
    useClass: ImageUploadServiceImpl,
  },
];
