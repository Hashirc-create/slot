import { GATEWAYS } from './index';
import { IEmailGateway, EmailGatewayImpl } from './email/email.gateway';
import { IImageUploadService, ImageUploadServiceImpl } from './s3/s3.gateway';

describe('GATEWAYS', () => {
  it('should contain EmailGateway provider', () => {
    const emailGatewayProvider = GATEWAYS.find(
      (provider) => provider.provide === IEmailGateway,
    );
    expect(emailGatewayProvider).toBeDefined();
    expect(emailGatewayProvider.useClass).toEqual(EmailGatewayImpl);
  });

  it('should contain Image Upload provider', () => {
    const imageGatewayProvider = GATEWAYS.find(
      (provider) => provider.provide === IImageUploadService,
    );
    expect(imageGatewayProvider).toBeDefined();
    expect(imageGatewayProvider.useClass).toEqual(ImageUploadServiceImpl);
  });
});
