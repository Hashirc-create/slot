import { AppointmentCreatedWithOutPaymentAdminTemplatePayload } from '@seamlessslot/core';

export const getAppointmentCreatedAdminWithOutPaymentEmailTemplate = ({
  location,
  bookingId,
  service,
  duration,
  cost,
  dateTimeOfAppointment,
  customerName,
  customerEmail,
  customerPhone,
}: AppointmentCreatedWithOutPaymentAdminTemplatePayload) => {
  return `<!doctype html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Appointment Created</title>
  <style>
      * {
          margin: 0px;
          padding: 0px;
      }

      .container {
          padding: 20px;
      }

      .bg-red {
          background-color: red;
      }

      .font-500 {
          font-weight: 500;
          font-size: 21px;
          color: black;
          line-height: 25px;
          text-align: center;
          font-family: 'Helvetica';
      }

      .font-400 {
          font-weight: 400;
          font-size: 16px;
          color: black;
          line-height: 22.4px;
          font-family: 'Helvetica';
      }

      @media only screen and (min-width: 600px) {
          body {
              margin: auto;
              width: 100%;
          }
      }

      @media only screen and (min-width: 900px) {
          body {
              margin: auto;
              width: 70%;
          }
      }
  </style>
</head>

<body>
<div class="container">
  <img
    src="https://museumfutures.s3.eu-west-2.amazonaws.com/Seamless+Slot+Logo.png"
    alt=""
  />
</div>
<div class="container" style="padding-top: 40px; padding-bottom: 40px">
  <p class="font-500">
    You have received a new appointment from
    <b>${customerName}</b>, with email
    <b>${customerEmail}!</b>
  </p>
</div>
<div style="padding: 40px">
  <p class="font-400"><b>Status:</b> <span style="color : #fb832c">Payment Pending</span></p>
  <p class="font-400"><b>Practice:</b> ${location}</p>
  <p class="font-400"><b>Booking ID:</b> ${bookingId}</p>
  <p class="font-400">
    <b>Service:</b> ${service + ' | ' + duration + 'min' + '.' + '£' + cost}
  </p>
  <p class="font-400"><b>Date:</b> ${dateTimeOfAppointment}</p>
  <p class="font-400"><b>Name:</b> ${customerName}</p>
  <p class="font-400"><b>Email:</b> ${customerEmail}</p>
  <p class="font-400"><b>Telephone:</b> ${customerPhone}</p>
</div>
<div class="container" style="padding: 40px">
  <p class="font-400" style="text-align: center">
    To manage this appointment go to the
    <a
      href="https://nightandday.seamlessslot.co.uk/adminAppointment"
      style="color: black; font-weight: bold"
    >appointment details panel.</a
    >
  </p>
</div>
<div
  style="
        border-top: 1px solid black;
        margin: auto;
        width: 90%;
        opacity: 0.3;
      "
></div>
<div class="container" style="padding: 40px">
  <p class="font-400" style="text-align: center; opacity: 0.3">
    © 2024 Seamless Slot. All rights reserved.
  </p>
</div>
</body>
</html>
`;
};
