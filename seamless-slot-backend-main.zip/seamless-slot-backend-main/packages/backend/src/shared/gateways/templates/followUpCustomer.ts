import { CONSTANTS } from '../../utils/constants';

export const getFollowUpCustomerEmailTemplate = ({
  name,
  phone,
  email,
  locationName,
  businessName,
}: {
  name: string;
  phone: string;
  email: string;
  locationName: string;
  businessName: string;
}) => {
  return `<!doctype html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Document</title>

  <!-- Rubik 300 -->
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link
    href="https://fonts.googleapis.com/css2?family=Rubik:ital,wght@0,300..900;1,300..900&display=swap"
    rel="stylesheet"
  />

  <style>
      * {
          margin: 0px;
          padding: 0px;
      }

      .rubik-300 {
          font-family: 'Rubik', Helvetica, sans-serif;
          font-optical-sizing: auto;
          font-weight: 300;
          font-size: 20px;
          line-height: 28px;
          color: black;
      }

      .rubik-400 {
          font-family: 'Rubik', Helvetica, sans-serif;
          font-optical-sizing: auto;
          font-weight: 400;
          font-size: 16px;
          line-height: 22.4px;
          color: black;
      }

      .rubik-700 {
          font-family: 'Rubik', Helvetica, sans-serif;
          font-optical-sizing: auto;
          font-weight: 700;
          font-size: 23px;
          line-height: 21px;
          color: black;
      }
      
      .rubik-800 {
        font-family: 'Rubik', Helvetica, sans-serif;
        font-optical-sizing: auto;
        font-weight: 800;
        font-size: 30px;
        line-height: 21px;
        color: black;
      }


      .rubik-700-heading {
          font-family: 'Rubik', Helvetica, sans-serif;
          font-optical-sizing: auto;
          font-weight: 700;
          font-size: 16px;
          line-height: 27px;
          color: black;
      }

      .border-appointment {
          border: 1px solid black;
          border-radius: 8px;
      }

      .border-line {
          border-bottom: 1px solid #1f1f1f;
          border-radius: 8px;
          margin-top: 20px;
      }
  </style>
</head>
<body>
<div
  style="
        display: flex;
        justify-content: center;
        align-items: center;
        padding-left: 108px;
        padding-right: 108px;
        padding-top: 26px;
        padding-bottom: 26px;
      "
>
  ${
    businessName === CONSTANTS.NIGHT_AND_DAY
      ? `<img
        style="margin-left: auto; margin-right: auto"
        width="158px"
        height="38px"
        src="https://museumfutures.s3.eu-west-2.amazonaws.com/image.png"
        alt=""
      />`
      : `<h1 style="margin-left: auto;margin-right: auto" class="rubik-800">${businessName}</h1>`
  }
</div>
<main
  style="
        margin-left: 12px;
        margin-right: 12px;
        margin-top: 40px;
        margin-bottom: 40px;
      "
>
  <p
    style="
          margin-left: 12px;
          margin-right: 12px;
          margin-top: 40px;
          margin-bottom: 40px;
        "
    class="rubik-300"
  >
    Please follow up with this patient to confirm their pending appointment.
  </p>
  <p></p>
</main>

<div
  style="
        margin-left: 12px;
        margin-right: 12px;
        padding-left: 12px;
        padding-right: 12px;
        padding-top: 20px;
        padding-bottom: 20px;
        margin-bottom: 20px;
      "
  class="border-appointment"
>
  <p class="rubik-700" style="margin-bottom: 20px">Patient Details</p>
  <p style="margin-top: 5px" class="rubik-400">Name : ${name}</p>
  <p style="margin-top: 5px" class="rubik-400">Phone : ${phone}</p>
  <p style="margin-top: 5px" class="rubik-400">Email : ${email}</p>
  <p style="margin-top: 5px" class="rubik-400">Appointment Location : ${locationName}</p>
</div>
</body>
</html>
`;
};
