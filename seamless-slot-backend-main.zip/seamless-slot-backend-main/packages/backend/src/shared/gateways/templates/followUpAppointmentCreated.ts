import { FollowUpAppointmentCreatedEmail } from '@seamlessslot/core';

export const getFollowUpAppointmentCreatedTemplate = (
  payload: FollowUpAppointmentCreatedEmail,
) => {
  return `
    <!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Document</title>

    <!-- Rubik 300 -->
    <link rel="preconnect" href="https://fonts.googleapis.com"/>
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin/>
    <link
            href="https://fonts.googleapis.com/css2?family=Rubik:ital,wght@0,300..900;1,300..900&display=swap"
            rel="stylesheet"
    />

    <style>
        * {
            margin: 0px;
            padding: 0px;
        }

        .rubik-300 {
            font-family: 'Rubik', Helvetica, sans-serif;
            font-optical-sizing: auto;
            font-weight: 300;
            font-size: 20px;
            line-height: 28px;
            color: black;
        }

        .rubik-400 {
            font-family: 'Rubik', Helvetica, sans-serif;
            font-optical-sizing: auto;
            font-weight: 400;
            font-size: 16px;
            line-height: 22.4px;
            color: black;
        }

        .rubik-700 {
            font-family: 'Rubik', Helvetica, sans-serif;
            font-optical-sizing: auto;
            font-weight: 700;
            font-size: 23px;
            line-height: 21px;
            color: black;
        }

        .rubik-700-heading {
            font-family: 'Rubik', Helvetica, sans-serif;
            font-optical-sizing: auto;
            font-weight: 700;
            font-size: 16px;
            line-height: 27px;
            color: black;
        }

        .border-appointment {
            border: 1px solid black;
            border-radius: 8px;
        }

        .border-line {
            border-bottom: 1px solid #1f1f1f;
            border-radius: 8px;
            margin-top: 20px;
        }
    </style>
</head>
<body>
<div
        style="
        display: flex;
        justify-content: center;
        align-items: center;
        padding-left: 108px;
        padding-right: 108px;
        padding-top: 26px;
        padding-bottom: 26px;
      "
>
    <img
            style="margin-left: auto; margin-right: auto"
            width="158px"
            height="38px"
            src="https://museumfutures.s3.eu-west-2.amazonaws.com/image.png"
            alt=""
    />
</div>
<main
        style="
        margin-left: 12px;
        margin-right: 12px;
        margin-top: 40px;
        margin-bottom: 40px;
      "
>
    <h3 class="rubik-300" style="
          margin-left: 12px;
          margin-right: 12px;
          margin-top: 40px;
        ">Dear ${payload.patientFullName},</h3>
    <p
            style="
          margin-left: 12px;
          margin-right: 12px;
          margin-top: 10px;
          margin-bottom: 40px;
        "
            class="rubik-300"
    >
        Your followup appointment at ${payload.businessName} ${payload.locationName} has been confirmed and scheduled.
    </p>
    <p></p>
</main>

<div
        style="
        margin-left: 12px;
        margin-right: 12px;
        padding-left: 12px;
        padding-right: 12px;
        padding-top: 20px;
        padding-bottom: 20px;
        margin-bottom: 20px;
      "
        class="border-appointment"
>
    <p class="rubik-700" style="margin-bottom: 20px">Patient Details</p>
    <p style="margin-top: 5px" class="rubik-400">Name : ${payload.patientFullName}</p>
    <p style="margin-top: 5px" class="rubik-400">Phone : ${payload.patientPhone}</p>
    <p style="margin-top: 5px" class="rubik-400">Appointment Date : ${payload.appointmentDate}</p>
    <p style="margin-top: 5px" class="rubik-400">Appointment Time : ${payload.appointmentTime}</p>

    <div>
        <div class="border-line"></div>
          <p style="margin-top: 20px" class="rubik-700-heading">Appointment Venue</p>
          <div style="display: flex;flex-direction: row;">
            <p style="margin-top: 5px" class="rubik-400">${payload.locationAddress}</p>
            ${
              payload.gmapUrl !== ''
                ? `<p style="margin-top: 5px;margin-left: auto" class="rubik-400">

            <a style="text-decoration: underline; cursor: pointer; color: #4285f4" href="${payload.gmapUrl}">
            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="currentColor" class="bi bi-geo-alt"
               viewBox="0 0 16 16">
            <path
              d="M12.166 8.94c-.524 1.062-1.234 2.12-1.96 3.07A32 32 0 0 1 8 14.58a32 32 0 0 1-2.206-2.57c-.726-.95-1.436-2.008-1.96-3.07C3.304 7.867 3 6.862 3 6a5 5 0 0 1 10 0c0 .862-.305 1.867-.834 2.94M8 16s6-5.686 6-10A6 6 0 0 0 2 6c0 4.314 6 10 6 10" />
            <path d="M8 8a2 2 0 1 1 0-4 2 2 0 0 1 0 4m0 1a3 3 0 1 0 0-6 3 3 0 0 0 0 6" />
            </svg>Click for Directions</a></p>`
                : ''
            }
        </div>
     </div>
</div>
</body>
</html>

    
    `;
};
