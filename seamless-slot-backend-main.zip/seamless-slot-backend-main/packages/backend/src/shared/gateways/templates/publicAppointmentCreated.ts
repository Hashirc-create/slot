import { AppointmentCreateAdminTemplatePayload } from '@seamlessslot/core';
import { CONSTANTS } from '../../utils/constants';

export const getAppointmentCreatedAdminEmailTemplate = ({
  location,
  bookingId,
  service,
  duration,
  cost,
  dateTimeOfAppointment,
  customerName,
  customerEmail,
  customerPhone,
  amountCharged,
  businessName,
}: AppointmentCreateAdminTemplatePayload) => {
  return `<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Appointment Created</title>
    <style>
    * {
      margin: 0px;
      padding: 0px;
    }
    .container {
      padding: 20px;
    }

    .bg-red {
      background-color: red;
    }
    
      .rubik-800 {
        font-family: 'Rubik', Helvetica, sans-serif;
        font-optical-sizing: auto;
        font-weight: 800;
        font-size: 30px;
        line-height: 21px;
        color: black;
      }


    .font-500 {
      font-weight: 500;
      font-size: 21px;
      color: black;
      line-height: 25px;
      text-align: center;
      font-family: 'Helvetica';
    }

    .font-400 {
      font-weight: 400;
      font-size: 16px;
      color: black;
      line-height: 22.4px;
      font-family: 'Helvetica';
    }
  </style>
  </head>


  <body>
    <div class="container">
      ${
        businessName === CONSTANTS.NIGHT_AND_DAY
          ? `<img
        style="margin-left: auto; margin-right: auto"
        width="158px"
        height="38px"
        src="https://museumfutures.s3.eu-west-2.amazonaws.com/image.png"
        alt=""
      />`
          : `<h1 style="margin-left: auto;margin-right: auto" class="rubik-800">${businessName}</h1>`
      }
    </div>
    <div class="container" style="padding-top: 40px; padding-bottom: 40px">
      <p class="font-500">
        You have received a new appointment from
        <b>${customerName}</b>, with email
        <b>${customerEmail}!</b>
      </p>
    </div>
    <div style="padding: 40px">
      <p class="font-400"><b>Practice:</b> ${location}</p>
      <p class="font-400"><b>Booking ID:</b> ${bookingId}</p>
      <p class="font-400"><b>Service:</b> ${service + ' | ' + duration + 'min' + '.' + '£' + cost}</p>
      <p class="font-400"><b>Date:</b> ${dateTimeOfAppointment}</p>
      <p class="font-400"><b>Name:</b> ${customerName}</p>
      <p class="font-400"><b>Email:</b> ${customerEmail}</p>
      <p class="font-400"><b>Telephone:</b> ${customerPhone}</p>
      <p class="font-400"><b>Charges:</b> ${'£' + amountCharged}</p>
    </div>
    <div class="container" style="padding: 40px">
      <p class="font-400" style="text-align: center">
        To manage this appointment go to the
        <a
          href="https://nightandday.seamlessslot.co.uk/adminAppointment"
          style="color: black; font-weight: bold"
          >appointment details panel.</a
        >
      </p>
    </div>
    <div
      style="
        border-top: 1px solid black;
        margin: auto;
        width: 90%;
        opacity: 0.3;
      "
    ></div>
    <div class="container" style="padding: 40px">
      <p class="font-400" style="text-align: center; opacity: 0.3">
        © 2024 Seamless Slot. All rights reserved.
      </p>
    </div>
  </body>
</html>
`;
};
