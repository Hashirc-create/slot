import { PaymentReceiptPayload } from '@seamlessslot/core';
import { CONSTANTS } from '../../utils/constants';

export const getPaymentReceiptTemplate = ({
  discount,
  payerName,
  serviceAmount,
  subTotal,
  total,
  paymentDate,
  paymentMethod,
  serviceTitle,
  transactionId,
  businessName,
}: PaymentReceiptPayload) => {
  return `<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Document</title>

    <!-- Rubik 300 -->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
      href="https://fonts.googleapis.com/css2?family=Rubik:ital,wght@0,300..900;1,300..900&display=swap"
      rel="stylesheet"
    />

    <style>
      * {
        margin: 0px;
        padding: 0px;
      }

      .rubik-300 {
        font-family: 'Rubik', Helvetica, sans-serif;
        font-optical-sizing: auto;
        font-weight: 300;
        font-size: 20px;
        line-height: 28px;
        color: black;
      }

      .rubik-400 {
        font-family: 'Rubik', Helvetica, sans-serif;
        font-optical-sizing: auto;
        font-weight: 400;
        font-size: 16px;
        line-height: 22.4px;
        color: black;
      }

      .rubik-700 {
        font-family: 'Rubik', Helvetica, sans-serif;
        font-optical-sizing: auto;
        font-weight: 700;
        font-size: 23px;
        line-height: 21px;
        color: black;
      }
      
       .rubik-800 {
        font-family: 'Rubik', Helvetica, sans-serif;
        font-optical-sizing: auto;
        font-weight: 800;
        font-size: 30px;
        line-height: 21px;
        color: black;
      }

      .rubik-700-heading {
        font-family: 'Rubik', Helvetica, sans-serif;
        font-optical-sizing: auto;
        font-weight: 700;
        font-size: 16px;
        line-height: 27px;
        color: black;
      }

      .border-appointment {
        border: 1px solid black;
        border-radius: 8px;
      }

      .border-line {
        border-bottom: 1px solid #1f1f1f;
        border-radius: 8px;
        margin-top: 20px;
      }
    </style>
  </head>

  <body>
    <div
      style="
        display: flex;
        justify-content: center;
        align-items: center;
        padding-left: 108px;
        padding-right: 108px;
        padding-top: 26px;
        padding-bottom: 26px;
      "
    >
       ${
         businessName === CONSTANTS.NIGHT_AND_DAY
           ? `<img
        style="margin-left: auto; margin-right: auto"
        width="158px"
        height="38px"
        src="https://museumfutures.s3.eu-west-2.amazonaws.com/image.png"
        alt=""
      />`
           : `<h1 style="margin-left: auto;margin-right: auto" class="rubik-800">${businessName}</h1>`
       }
    </div>
    <main
      style="
        margin-left: 12px;
        margin-right: 12px;
        margin-top: 40x;
        margin-bottom: 40px;
      "
    >
      <p
        style="
          margin-left: 12px;
          margin-right: 12px;
          margin-top: 40x;
          margin-bottom: 40px;
        "
        class="rubik-300"
      >
        Thank you for your payment. We have successfully received it. <br />Here
        is your receipt.
      </p>
      <p></p>
    </main>

    <div
      style="
        margin-left: 12px;
        margin-right: 12px;
        padding-left: 12px;
        padding-right: 12px;
        padding-top: 20px;
        padding-bottom: 20px;
        margin-bottom: 20px;
      "
      class="border-appointment"
    >
      <p class="rubik-700">Payment receipt</p>
      <div class="border-line"></div>
      <p class="rubik-700-heading" style="margin-top: 20px">Payment receipt</p>
      <!-- First -->
      <div>
        <div style="display: flex; width: 100%">
          <p style="margin-top: 5px" class="rubik-400">Payer name</p>
          <p style="margin-top: 5px; margin-left: auto" class="rubik-400">
            ${payerName}
          </p>
        </div>
      </div>
      <!-- Second -->
      <div>
        <div style="display: flex; width: 100%">
          <p style="margin-top: 5px" class="rubik-400">Transaction ID</p>
          <p style="margin-top: 5px; margin-left: auto" class="rubik-400">
            ${transactionId}
          </p>
        </div>
      </div>
      <!-- Third -->
      <div>
        <div style="display: flex; width: 100%">
          <p style="margin-top: 5px" class="rubik-400">Payment method</p>
          <p style="margin-top: 5px; margin-left: auto" class="rubik-400">
            ${paymentMethod}
          </p>
        </div>
      </div>

      <!-- Fourth -->
      <div>
        <div style="display: flex; width: 100%">
          <p style="margin-top: 5px" class="rubik-400">Payment Date</p>
          <p style="margin-top: 5px; margin-left: auto" class="rubik-400">
            ${paymentDate}
          </p>
        </div>
      </div>

      <!-- Border -->
      <div class="border-line"></div>

      <p class="rubik-700-heading" style="margin-top: 20px">Purchase(s)</p>

      <!-- FIRST -->
      <div>
        <div style="display: flex; width: 100%">
          <p style="margin-top: 5px" class="rubik-400">${serviceTitle}</p>
          <p style="margin-top: 5px; margin-left: auto" class="rubik-400">
            £${serviceAmount}
          </p>
        </div>
      </div>
      <!-- SECOND -->
      <div>
        <div style="display: flex; width: 100%">
          <p style="margin-top: 5px" class="rubik-400">Subtotal</p>
          <p style="margin-top: 5px; margin-left: auto" class="rubik-400">
            £${subTotal}
          </p>
        </div>
      </div>
      <!-- THIRD -->
      <div>
        <div style="display: flex; width: 100%">
          <p style="margin-top: 5px" class="rubik-400">Discount</p>
          <p style="margin-top: 5px; margin-left: auto" class="rubik-400">
            £${discount}
          </p>
        </div>
      </div>
      <!-- FOURTH -->
      <div>
        <div style="display: flex; width: 100%">
          <p style="margin-top: 5px; font-weight: bold" class="rubik-400">
            Total
          </p>
          <p
            style="margin-top: 5px; font-weight: bold; margin-left: auto"
            class="rubik-400"
          >
            £${total}
          </p>
        </div>
      </div>
    </div>
  </body>
</html>

`;
};
