import { Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { uuid } from 'uuidv4';
import { Readable } from 'node:stream';
import { Upload } from '@aws-sdk/lib-storage';
import { GetObjectCommand, S3Client } from '@aws-sdk/client-s3';
import { getSignedUrl } from '@aws-sdk/s3-request-presigner';

export interface ImageUploadService {
  uploadImage(file: Express.Multer.File): Promise<string>;
  getImageUrl(key: string): Promise<string>;
}

export const IImageUploadService = Symbol('ImageUploadService');

@Injectable()
export class ImageUploadServiceImpl implements ImageUploadService {
  private readonly s3: S3Client;

  constructor(private readonly configService: ConfigService) {
    this.s3 = new S3Client({
      credentials: {
        accessKeyId: configService.get('AWS_ACCESS_KEY_ID'),
        secretAccessKey: configService.get('AWS_SECRET_ACCESS_KEY'),
      },
      region: this.configService.get('AWS_REGION'),
    });
  }

  async getImageUrl(key: string): Promise<string> {
    const command = new GetObjectCommand({
      Bucket: this.configService.get('S3_BUCKET_NAME'),
      Key: key,
    });

    return await getSignedUrl(this.s3, command, {
      expiresIn: this.configService.get<number>('S3_EXPIRY'),
    });
  }

  async uploadImage(file: Express.Multer.File): Promise<string> {
    const key: string = uuid();
    const finalName = file.originalname.split('.')[0];
    const extension = file.originalname.split('.').pop();

    const { Key } = await new Upload({
      client: this.s3,
      params: {
        Bucket: this.configService.get('S3_BUCKET_NAME'),
        Key: `${finalName}-${key}.${extension}`, // path to in s3 where this file need to be uploaded,
        Body: Readable.from(file.buffer),
        // ACL: 'public-read',
        ContentType: file.mimetype,
      },
    }).done();

    return Key;
  }
}
