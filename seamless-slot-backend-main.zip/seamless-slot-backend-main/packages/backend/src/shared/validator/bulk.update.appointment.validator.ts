import {
  registerDecorator,
  ValidationOptions,
  ValidationArguments,
} from 'class-validator';
import { AppointmentStatus } from '@seamlessslot/core';

const validStatuses: AppointmentStatus[] = [
  'Pending',
  'Paid',
  'No Show',
  'Confirmed',
  'Complete',
  'Cancelled',
  'Follow Up',
];

export function IsValidAppointmentsArray(
  validationOptions?: ValidationOptions,
) {
  return function (object: unknown, propertyName: string) {
    registerDecorator({
      name: 'IsValidAppointmentsArray',
      target: object.constructor,
      propertyName: propertyName,
      options: validationOptions,
      validator: {
        validate(value: unknown) {
          // Ensure it's an array
          if (!Array.isArray(value)) {
            return false;
          }

          // Validate each item in the array
          return value.every(
            (item) =>
              typeof item.id === 'number' &&
              validStatuses.includes(item.status),
          );
        },
        defaultMessage(args: ValidationArguments) {
          return `${args.property} must be an array of objects with \n 
          { id: number, status: ('Pending','Paid','No Show','Confirmed','Complete','Cancelled','Follow Up',) }`;
        },
      },
    });
  };
}
