import {
  ValidatorConstraint,
  ValidatorConstraintInterface,
} from 'class-validator';

@ValidatorConstraint({ async: false })
export class IsISO8601DateWithUTCConstraint
  implements ValidatorConstraintInterface
{
  validate(dateString: string) {
    const iso8601Pattern = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d+)?Z$/;
    return typeof dateString === 'string' && iso8601Pattern.test(dateString);
  }

  defaultMessage() {
    return 'Date ($value) must be in ISO 8601 format with UTC indicated by "Z".';
  }
}
