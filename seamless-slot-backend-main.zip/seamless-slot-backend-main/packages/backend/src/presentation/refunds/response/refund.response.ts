export interface RefundResponseWithAppointmentAndPatient {
  id: number;
  refundSquareId: string;
  status: string;
  amount: string;
  remaningBalance: string;
  currency: string;
  squareTransactionId: string;
  paymentId: number;
  orderId: string;
  locationId: string;
  reason: string;
  appointmentId: number;
  patientName: string;
  createdAt: string;
}

export interface RefundResponse {
  id: number;
  refundSquareId: string;
  status: string;
  amount: string;
  remaningBalance: string;
  currency: string;
  squareTransactionId: string;
  paymentId: number;
  orderId: string;
  locationId: string;
  reason: string;
  createdAt: string;
}
