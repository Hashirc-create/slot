import { ApiProperty } from '@nestjs/swagger';
import { IsNumber, IsString } from 'class-validator';

export class IssueRefundDto {
  @ApiProperty({
    description:
      'Payment Transaction Id Against which the refund will be issued',
    example: 0,
  })
  @IsNumber(
    {},
    {
      message: 'payment transaction is required in number type',
    },
  )
  paymentTransaction: number;

  @ApiProperty({
    description: 'Amount To Refund',
    example: 0,
  })
  @IsString({
    message: 'Amount should be a string and includes decimal',
  })
  amount: string;
}
