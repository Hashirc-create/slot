import { Module } from '@nestjs/common';
import { RefundsController } from './refund.controller';

@Module({
  providers: [],
  controllers: [RefundsController],
})
export class RefundModule {}
