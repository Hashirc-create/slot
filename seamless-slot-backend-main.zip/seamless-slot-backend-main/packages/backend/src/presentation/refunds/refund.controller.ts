import {
  Controller,
  HttpCode,
  HttpStatus,
  UseGuards,
  Post,
  Body,
  Get,
  Param,
  Query,
} from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiTags } from '@nestjs/swagger';
import { RoleGuard } from '../../shared/auth/guard/jwt.guard';
import { IssueRefundDto } from './dto/issue.refund.dto';
import { UseCaseFactory } from '../../usecases/usecase.factory';
import { PresentationMapperFactory } from '../mapper/mapper.factory';
import { Roles } from '../../shared/auth/decorator/role.decorator';
import { SearchAppointmentsDto } from '../appointment/dto/search.appointments.dto';

@Controller('refund')
@ApiTags('Refunds')
@ApiBearerAuth()
export class RefundsController {
  constructor(
    private readonly useCaseFactory: UseCaseFactory,
    private mapper: PresentationMapperFactory,
  ) {}

  @Post('/issue')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    description: 'Issue Refund Against Payment Transaction',
    summary: 'Issue Refund Against Payment Transaction',
  })
  @Roles(['Super Admin', 'Admin'])
  @UseGuards(RoleGuard)
  async issueRefund(
    @Body()
    payload: IssueRefundDto,
  ) {
    await this.useCaseFactory.issueRefundUseCase.execute(
      payload.paymentTransaction,
      payload.amount,
    );

    return 'refund issued successfully!!';
  }

  @Get('/findAllByPaymentTransaction/:paymentTransactionId')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    description: 'Get all refunds against payment transaction id',
    summary: 'Get all refunds against payment transaction id',
  })
  @Roles(['Super Admin', 'Admin'])
  @UseGuards(RoleGuard)
  async getAllRefunds(
    @Param('paymentTransactionId')
    paymentTransactionId: string,
  ) {
    if (isNaN(+paymentTransactionId)) {
      return [];
    }

    const refunds =
      await this.useCaseFactory.getAllRefundsByPaymentTransactionUseCase.execute(
        +paymentTransactionId,
      );

    return refunds.map((refund) =>
      this.mapper.refundPresentationMapper.domainToResponse(refund),
    );
  }

  @Get('/findAllByLocation')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    description: 'Get All Refunds By Pagination By Location',
    summary: 'Get All Refunds By Pagination By Location',
  })
  @Roles(['Super Admin', 'Admin'])
  @UseGuards(RoleGuard)
  async getAllRefundsByLocationWithPagination(
    @Query('locationId')
    locationId: string,
    @Query('page')
    page: string,
    @Query('perPage')
    perPage: string,
    @Query('startDate')
    startDate: string,
    @Query('endDate')
    endDate: string,
  ) {
    const data =
      await this.useCaseFactory.findAllRefundsByLocationWithPaginationUseCase.execute(
        +locationId,
        +page,
        +perPage,
        startDate,
        endDate,
      );

    return {
      prev: data.prev,
      next: data.next,
      last: data.last,
      pages: data.pages,
      totalRecords: data.total,
      data: data.data.map((paymentLog) =>
        this.mapper.refundPresentationMapper.domainToResponseWithAppointmentAndPatient(
          paymentLog,
        ),
      ),
    };
  }

  @Post('/searchWithPagination')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    description: 'Search Refunds By Pagination',
    summary: 'Search Refunds By Pagination',
  })
  @Roles(['Super Admin', 'Admin'])
  @UseGuards(RoleGuard)
  async searchRefundsWithPagination(
    @Body()
    dto: SearchAppointmentsDto,
  ) {
    const data =
      await this.useCaseFactory.searchRefundsByLocationWithPaginationUseCase.execute(
        dto.locationId,
        dto.searchString,
        dto.page,
        dto.limit,
      );

    return {
      prev: data.prev,
      next: data.next,
      last: data.last,
      pages: data.pages,
      totalRecords: data.total,
      data: data.data.map((paymentLog) =>
        this.mapper.refundPresentationMapper.domainToResponseWithAppointmentAndPatient(
          paymentLog,
        ),
      ),
    };
  }
}
