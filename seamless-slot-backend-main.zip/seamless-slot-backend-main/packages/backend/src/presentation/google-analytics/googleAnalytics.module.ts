import { Module } from '@nestjs/common';
import { GoogleAnalyticsController } from './google.analytics.controller';

@Module({
  controllers: [GoogleAnalyticsController],
})
export class GoogleAnalyticsModule {}
