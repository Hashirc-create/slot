import { ApiProperty, PartialType } from '@nestjs/swagger';
import { IsNumber } from 'class-validator';
import { CreateGoogleAnalyticsDto } from './create.google.analytics.dto';

export class EditGoogleAnalyticsDto extends PartialType(
  CreateGoogleAnalyticsDto,
) {
  @ApiProperty({
    description: 'Id',
    example: 0,
  })
  @IsNumber(
    {},
    {
      message: 'Google Analytics Id required',
    },
  )
  id: number;
}
