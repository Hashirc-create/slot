import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsNumber, IsString } from 'class-validator';

export class CreateGoogleAnalyticsDto {
  @ApiProperty({
    description: 'LocationId',
    example: 0,
  })
  @IsNumber(
    {},
    {
      message: 'Location Id is required',
    },
  )
  locationId: number;

  @ApiProperty({
    description: 'Google Analytics Measurement Id',
    example: 'GTM-XXXXXXX',
  })
  @IsNotEmpty({
    message: 'Google Analytics Measurement Id Can Not be Empty',
  })
  @IsString({
    message: 'Google Analytics Measurement Id Is Required',
  })
  measurementId: string;
}
