import {
  Controller,
  Post,
  Body,
  HttpCode,
  HttpStatus,
  UseGuards,
  Patch,
  Param,
  Get,
  HttpException,
} from '@nestjs/common';
import { ApiOperation, ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { RoleGuard } from '../../shared/auth/guard/jwt.guard';
import { UseCaseFactory } from '../../usecases/usecase.factory';
import { CreateGoogleAnalyticsDto } from './dto/create.google.analytics.dto';
import { EditGoogleAnalyticsDto } from './dto/edit.google.analytics.dto';
import { PresentationMapperFactory } from '../mapper/mapper.factory';
import { BaseResponse } from '../../shared/interceptor/response.interceptor';
import { Roles } from '../../shared/auth/decorator/role.decorator';

@Controller('google-analytics')
@ApiTags('Google Analytics')
export class GoogleAnalyticsController {
  constructor(
    private readonly useCaseFactory: UseCaseFactory,
    private readonly mapperFactory: PresentationMapperFactory,
  ) {}

  @Get('/findByLocation/:locationId')
  @HttpCode(HttpStatus.CREATED)
  @ApiOperation({
    description: 'Find Google Analytics Account By Location',
    summary: 'Find Google Analytics Account By Location',
  })
  @ApiBearerAuth()
  async findByLocation(
    @Param('locationId')
    locationId: string,
  ) {
    const response =
      await this.useCaseFactory.findGoogleAnalyticsByLocationUseCase.execute(
        +locationId,
      );

    if (!response)
      throw new HttpException(
        {
          code: 0,
          message: 'Account Not Linked',
          data: 'Account Not Linked',
        } as BaseResponse<string>,
        HttpStatus.OK,
      );

    return this.mapperFactory.googleAnalyticsMapper.domainToResponse(response);
  }

  @Post('/create')
  @HttpCode(HttpStatus.CREATED)
  @ApiOperation({
    description: 'Register a new Google Analytics Account Against Location',
    summary: 'Register a new Google Analytics Account Against Location',
  })
  @ApiBearerAuth()
  @Roles(['Super Admin', 'Admin'])
  @UseGuards(RoleGuard)
  async create(
    @Body()
    dto: CreateGoogleAnalyticsDto,
  ) {
    await this.useCaseFactory.createGoogleAnalyticsUseCase.execute({
      measurementId: dto.measurementId,
      locationId: dto.locationId,
    });

    return 'Google Analytics Account Registered Successfully Against Location';
  }

  @Patch('/edit')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    description: 'Edit Google Analytics Account Against Location',
    summary: 'Edit Google Analytics Account Against Location',
  })
  @ApiBearerAuth()
  @Roles(['Super Admin', 'Admin'])
  @UseGuards(RoleGuard)
  async edit(
    @Body()
    dto: EditGoogleAnalyticsDto,
  ) {
    await this.useCaseFactory.editGoogleAnalyticsUseCase.execute(
      dto.id,
      dto.locationId,
      dto.measurementId,
    );

    return 'Google Analytics Edited Successfully';
  }
}
