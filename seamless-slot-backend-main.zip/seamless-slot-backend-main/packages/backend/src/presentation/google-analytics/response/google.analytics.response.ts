export interface GoogleAnalyticsResponse {
  id: number;
  measurementId: string;
}
