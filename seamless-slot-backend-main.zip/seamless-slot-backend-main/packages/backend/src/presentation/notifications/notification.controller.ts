import {
  Controller,
  Get,
  Post,
  Body,
  Param,
  HttpCode,
  HttpStatus,
  UseGuards,
} from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiTags } from '@nestjs/swagger';
import { RoleGuard } from '../../shared/auth/guard/jwt.guard';
import { UseCaseFactory } from '../../usecases/usecase.factory';
import { MarkAllNotificationsReadDto } from './dto/MarkAllNotifications.dto';
import { TimeZoneService } from '../../shared/utils/timezone.util';
import { SecurityContext } from '../../shared/auth/context/security.context';
import { Roles } from '../../shared/auth/decorator/role.decorator';

@Controller('notifications')
@ApiTags('Notifications')
@ApiBearerAuth()
export class NotificationController {
  constructor(
    private readonly useCaseFactory: UseCaseFactory,
    private readonly timeZoneService: TimeZoneService,
    private readonly securityContext: SecurityContext,
  ) {}

  @Get('/findAllByLocation/:locationId')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    description: 'Get All Notifications By Locations (Not Read)',
    summary: 'Get All Notifications By Locations (Not Read)',
  })
  @Roles(['Super Admin', 'Admin'])
  @UseGuards(RoleGuard)
  async getAllNotificationsByLocation(
    @Param('locationId')
    locationId: string,
  ) {
    const response =
      await this.useCaseFactory.getAllNotificationsByLocationUseCase.execute(
        +locationId,
      );

    return response.map((res) => {
      return {
        id: res.id,
        title: res.title,
        customerName: res.customerName,
        isRead: res.isMarkedRead,
        bookingTime: this.timeZoneService.formatDatePreservingUTC(
          res.appointmentStartTime as Date,
          'yyyy-MM-dd HH:mm:ss a',
        ),
      };
    });
  }

  @Post('/markAllRead')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    description: 'Mark All The Notifications Read By Ids Array [1,2,3]',
    summary: 'Mark All The Notifications Read By Ids Array [1,2,3]',
  })
  @ApiBearerAuth()
  @Roles(['Super Admin', 'Admin'])
  @UseGuards(RoleGuard)
  async markAllNotificationsAsRead(
    @Body()
    dto: MarkAllNotificationsReadDto,
  ) {
    await this.useCaseFactory.getMarkNotificationsReadUseCase.execute(dto.ids);

    return 'success';
  }
}
