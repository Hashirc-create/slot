import { IsArray } from 'class-validator';

export class MarkAllNotificationsReadDto {
  @IsArray({
    message: 'Should be array of numbers',
  })
  ids: number[];
}
