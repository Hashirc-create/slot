import { ApiProperty } from '@nestjs/swagger';
import { IsEmail, IsNotEmpty, IsNumber, IsString } from 'class-validator';

export class RegisterUserDto {
  @ApiProperty({
    description: 'Email of User ',
    example: 'user@seamless.co.uk',
  })
  @IsNotEmpty({
    message: 'Email of User Can not Be Empty',
  })
  @IsEmail(
    {},
    {
      message: 'email is required and must be a valid email',
    },
  )
  email: string;

  @ApiProperty({
    description: 'First Name of User ',
    example: 'John',
  })
  @IsNotEmpty({
    message: 'First Name of User Can not Be Empty',
  })
  @IsString({
    message: 'first name is required and must be a string',
  })
  firstName: string;

  @ApiProperty({
    description: 'Last Name of User ',
    example: 'Doe',
  })
  @IsNotEmpty({
    message: 'Last Name of User Can not Be Empty',
  })
  @IsString({
    message: 'last name is required and must be a string',
  })
  lastName: string;

  @ApiProperty({
    description: 'Password of User ',
    example: 'user1234',
  })
  @IsNotEmpty({
    message: 'Password of User Can not Be Empty',
  })
  @IsString({
    message: 'password is required',
  })
  password: string;

  @ApiProperty({
    description: 'Default Location',
    example: 'location default',
  })
  @IsNumber(
    {},
    {
      message: 'default location id is required',
    },
  )
  locationId: number;

  @ApiProperty({
    description: 'Business Id',
    example: 0,
  })
  @IsNumber(
    {},
    {
      message: 'business id is required',
    },
  )
  businessId: number;

  @ApiProperty({
    description: 'Phone no of User ',
    example: '+92..',
  })
  @IsNotEmpty({
    message: 'Phone No of User Can not Be Empty',
  })
  @IsString({
    message:
      'phone no of user is required and must be a valid phone number of type string',
  })
  phoneNumber: string;
}
