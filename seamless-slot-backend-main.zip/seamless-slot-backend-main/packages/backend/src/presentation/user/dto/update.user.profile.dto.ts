import { ApiProperty } from '@nestjs/swagger';
import { IsEmail, IsNotEmpty, IsNumber, IsString } from 'class-validator';

export class UpdateUserProfileDto {
  @ApiProperty({
    description: 'Id of the record which need to be updated',
    example: 0,
  })
  @IsNumber(
    {},
    {
      message: 'id is required and must not be empty',
    },
  )
  id: number;

  @ApiProperty({
    description: 'Email of User ',
    example: 'user@seamless.co.uk',
  })
  @IsNotEmpty({
    message: 'Email of User Can not Be Empty',
  })
  @IsEmail(
    {},
    {
      message: 'email is required and must be a valid email',
    },
  )
  email: string;

  @ApiProperty({
    description: 'First Name of User ',
    example: 'John',
  })
  @IsNotEmpty({
    message: 'First Name of User Can not Be Empty',
  })
  @IsString({
    message: 'first name is required and must be a string',
  })
  firstName: string;

  @ApiProperty({
    description: 'Last Name of User ',
    example: 'Doe',
  })
  @IsString({
    message: 'last name is required and must be a string',
  })
  lastName: string;

  @ApiProperty({
    description: 'Password of User ',
    example: 'user1234',
  })
  @IsString({
    message: 'password is required',
  })
  password: string;

  @ApiProperty({
    description: 'Confirm Password of User ',
    example: 'user1234',
  })
  @IsString({
    message: 'confirm password is required',
  })
  confirmPassword: string;

  @ApiProperty({
    description: 'Phone No of User ',
    example: '+44....',
  })
  @IsNotEmpty({
    message: 'Phone No of User Can not Be Empty',
  })
  @IsString({
    message: 'Phone No is required and must be a string',
  })
  phoneNo: string;
}
