import { ApiProperty, PartialType } from '@nestjs/swagger';
import { IsNumber } from 'class-validator';
import { RegisterUserDto } from './register-user.dto';

export class UpdateUserDto extends PartialType(RegisterUserDto) {
  @ApiProperty({
    description: 'Id of the record which need to be updated',
    example: 0,
  })
  @IsNumber(
    {},
    {
      message: 'id is required and must not be empty',
    },
  )
  id: number;
}
