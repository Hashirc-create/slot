import { ApiProperty } from '@nestjs/swagger';
import { IsEmail, IsNotEmpty, IsString } from 'class-validator';

export class LoginUserDto {
  @ApiProperty({
    description: 'Email of User ',
    example: 'superadmin@seamlessslot.com',
  })
  @IsNotEmpty({
    message: 'Email of User Can not Be Empty',
  })
  @IsEmail(
    {},
    {
      message: 'email is required and must be a valid email',
    },
  )
  email: string;

  @ApiProperty({
    description: 'Password of User ',
    example: 'admin',
  })
  @IsNotEmpty({
    message: 'Password of User Can not Be Empty',
  })
  @IsString({
    message: 'password is required',
  })
  password: string;
}
