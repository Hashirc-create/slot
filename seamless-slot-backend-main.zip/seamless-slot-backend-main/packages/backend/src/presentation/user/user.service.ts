import { Injectable } from '@nestjs/common';
import { UseCaseFactory } from '../../usecases/usecase.factory';
import { PresentationMapperFactory } from '../mapper/mapper.factory';
import { encrypt } from '../../shared/utils/encrypt.util';
import { LoginUserDto } from './dto/login-user.dto';
import { RegisterUserDto } from './dto/register-user.dto';
import { UpdateUserDto } from './dto/update-user.dto';
import { User } from '@seamlessslot/core';
import { BlockUserDto } from './dto/block-user.dto';
import { UpdateUserProfileDto } from './dto/update.user.profile.dto';

@Injectable()
export class UserService {
  constructor(
    private readonly useCaseFactory: UseCaseFactory,
    private readonly presentationMapperFactory: PresentationMapperFactory,
  ) {}

  async updateUserProfile(id: number, dto: UpdateUserProfileDto) {
    const updatedUser =
      await this.useCaseFactory.updateUserProfileUseCase.execute(dto.id, {
        firstName: dto.firstName,
        lastName: dto.lastName,
        email: dto.email,
        phoneNo: dto.phoneNo,
        password: dto.password,
        confirmPassword: dto.confirmPassword,
      });

    return `${updatedUser.firstName} ${updatedUser.lastName} Profile Updated Successfully `;
  }

  async registerAdmin(registerUserDto: RegisterUserDto): Promise<string> {
    registerUserDto.password = await encrypt(registerUserDto.password);
    const savedUser = await this.useCaseFactory.registerUserUseCase.execute(
      this.presentationMapperFactory.userPresentationMapper.dtoToDomain(
        registerUserDto,
        'Admin',
        0,
      ),
    );

    return `Customer Has Been Registered Against Id : ${savedUser.id}`;
  }

  async getAllAdminsByLocation(locationId: number) {
    const admins =
      await this.useCaseFactory.getAllAdminsByLocationUseCase.execute(
        locationId,
      );

    return admins.map((admin) =>
      this.presentationMapperFactory.userPresentationMapper.domainToResponse(
        admin,
      ),
    );
  }

  async login(loginUserDto: LoginUserDto) {
    const { accessToken, refreshToken } =
      await this.useCaseFactory.loginUserUseCase.execute(
        loginUserDto.email,
        loginUserDto.password,
      );

    return {
      accessToken,
      refreshToken,
    };
  }

  async refreshToken(oldRefreshToken: string) {
    const { user, accessToken, refreshToken } =
      await this.useCaseFactory.refreshTokenUseCase.execute(oldRefreshToken);

    return {
      user,
      accessToken,
      refreshToken,
    };
  }

  async findAll(page: number, limit: number) {
    const { totalRecords, data } =
      await this.useCaseFactory.getAllUsersUseCase.execute(page, limit);

    const allUsers = data.map((user: User) =>
      this.presentationMapperFactory.userPresentationMapper.domainToResponse(
        user,
      ),
    );

    return {
      totalRecords: totalRecords,
      users: allUsers,
    };
  }

  async findOne(id: number) {
    const userFound = await this.useCaseFactory.getUserByIdUseCase.execute(id);

    return this.presentationMapperFactory.userPresentationMapper.domainToResponse(
      userFound,
    );
  }

  async update(updateUserDto: UpdateUserDto) {
    const updatedUser = await this.useCaseFactory.updateUserUseCase.execute(
      updateUserDto.id,
      this.presentationMapperFactory.userPresentationMapper.dtoToDomain(
        updateUserDto,
      ),
    );

    return `User has be updated successfully Against Id : ${updatedUser.id}`;
  }

  async block(blockUserDto: BlockUserDto) {
    const blockedUser = await this.useCaseFactory.blockUserUseCase.execute(
      blockUserDto.id,
    );

    return `User has be blocked successfully Against Id : ${blockedUser.id}`;
  }

  async hardDeleteAdmin(id: number) {
    const deltedAdmin =
      await this.useCaseFactory.hardDeleteUserUseCase.execute(id);

    return (
      'User has been deleted successfully deleted Against Id : ' +
      deltedAdmin.id
    );
  }
}
