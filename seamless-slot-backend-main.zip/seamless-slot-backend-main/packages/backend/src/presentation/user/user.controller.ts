import {
  Controller,
  Post,
  HttpCode,
  HttpStatus,
  Body,
  Res,
  UseGuards,
  Get,
  Param,
  Patch,
  Req,
  Delete,
} from '@nestjs/common';
import { UserService } from './user.service';
import {
  ApiTags,
  ApiOperation,
  ApiBearerAuth,
  ApiCookieAuth,
} from '@nestjs/swagger';
import { RegisterUserDto } from './dto/register-user.dto';
import { LoginUserDto } from './dto/login-user.dto';
import { BaseResponse } from '../../shared/interceptor/response.interceptor';
import { Request, Response } from 'express';
import { RoleGuard } from '../../shared/auth/guard/jwt.guard';
import { UpdateUserDto } from './dto/update-user.dto';
import { BlockUserDto } from './dto/block-user.dto';
import { ConfigService } from '@nestjs/config';
import { UpdateUserProfileDto } from './dto/update.user.profile.dto';
import { Roles } from '../../shared/auth/decorator/role.decorator';

@Controller('user')
@ApiTags('User')
export class UserController {
  constructor(
    private readonly userService: UserService,
    private readonly configService: ConfigService,
  ) {}

  @Post('/register/admin')
  @HttpCode(HttpStatus.CREATED)
  @ApiOperation({
    description: 'Register a new User',
    summary: 'Register a new User',
  })
  @ApiBearerAuth()
  @Roles(['Super Admin'])
  @UseGuards(RoleGuard)
  async registerAdmin(
    @Body()
    dto: RegisterUserDto,
  ) {
    return await this.userService.registerAdmin(dto);
  }

  @Get('/findAllAdminsByLocation/:locationId')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    description: 'Get All Admins By Location',
    summary: 'Get All Admin By Location',
  })
  @ApiBearerAuth()
  @Roles(['Super Admin'])
  @UseGuards(RoleGuard)
  findAllAdminsByLocation(
    @Param('locationId')
    locationId: string,
  ) {
    return this.userService.getAllAdminsByLocation(+locationId);
  }

  @Post('/login')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    description: 'Login a User',
    summary: 'Logn a User',
  })
  async login(
    @Body()
    dto: LoginUserDto,
    @Res()
    response: Response,
  ) {
    const { accessToken, refreshToken } = await this.userService.login(dto);

    const jsonResponse: BaseResponse<{
      accessToken: string;
    }> = {
      code: 200,
      message: 'Login Successfully',
      data: {
        accessToken,
      },
    };

    const oneDayInMs = 24 * 60 * 60 * 1000;
    // const expires = new Date(Date.now() + oneDayInMs);

    response.status(200).cookie('jid', refreshToken, {
      httpOnly: true,
      secure: true,
      sameSite: true,
      maxAge: oneDayInMs,
    });

    return response.json(jsonResponse);
  }

  @Post('/refresh')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    description: 'Refresh Access Token',
    summary: 'Refresh Access Token',
  })
  @ApiCookieAuth('jid')
  async refreshAccessToken(
    @Req()
    request: Request,
    @Res()
    response: Response,
  ) {
    const oldRefreshToken = request.cookies['jid'];

    const { accessToken, refreshToken } =
      await this.userService.refreshToken(oldRefreshToken);

    const jsonResponse: BaseResponse<{
      accessToken: string;
    }> = {
      code: 200,
      message: 'Login Successfully',
      data: {
        accessToken,
      },
    };

    const oneDayInMs = 24 * 60 * 60 * 1000;

    response
      .cookie('jid', refreshToken, {
        httpOnly: true,
        secure: true,
        sameSite: true,
        maxAge: oneDayInMs,
      })
      .json(jsonResponse);
  }

  @Get('/logout')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    description: 'Logout user from the application',
    summary: 'Logout user from the application',
  })
  async logoutUserFromTheApplication(
    @Res()
    response: Response,
  ) {
    const jsonResponse: BaseResponse<string> = {
      code: 200,
      message: 'Logout Sucess!!',
      data: 'Logout Sucess!!',
    };
    response
      .status(200)
      .cookie('jid', '', {
        httpOnly: true,
        secure: true,
        sameSite: true,
        expires: new Date(0),
      })
      .json(jsonResponse);
  }

  @Get('/findAll/:page/:limit')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    description: 'Get All Users By Page And Limit',
    summary: 'Get All Users By Page And Limit',
  })
  @ApiBearerAuth()
  @Roles(['Super Admin'])
  @UseGuards(RoleGuard)
  async getAllUsersByPageAndLimit(
    @Param('page')
    page: string,
    @Param('limit')
    limit: string,
  ) {
    return await this.userService.findAll(+page, +limit);
  }

  @Get('/profile/:id')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    description: 'Get Users By Id',
    summary: 'Get Users By Id',
  })
  @ApiBearerAuth()
  @Roles(['Super Admin', 'Admin'])
  @UseGuards(RoleGuard)
  async getUserById(
    @Param('id')
    id: string,
  ) {
    return await this.userService.findOne(+id);
  }

  @Patch('/profile/update')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    description: 'Update User By Id',
    summary: 'Update User By Id',
  })
  @ApiBearerAuth()
  @Roles(['Super Admin', 'Admin'])
  @UseGuards(RoleGuard)
  update(
    @Body()
    updateUserDto: UpdateUserDto,
  ) {
    return this.userService.update(updateUserDto);
  }

  @Patch('/block/:id')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    description: 'Block User By Id',
    summary: 'Block User By Id',
  })
  @ApiBearerAuth()
  @Roles(['Super Admin'])
  @UseGuards(RoleGuard)
  block(
    @Body()
    blockUserDto: BlockUserDto,
  ) {
    return this.userService.block(blockUserDto);
  }

  @Patch('/updateProfile')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    description: 'Update user profile ',
    summary: 'Update user profile',
  })
  @ApiBearerAuth()
  @Roles(['Super Admin', 'Admin'])
  @UseGuards(RoleGuard)
  updateProfile(
    @Body()
    updateProfile: UpdateUserProfileDto,
  ) {
    return this.userService.updateUserProfile(updateProfile.id, updateProfile);
  }

  @Delete('/delete/:id')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    description: 'Delete Admin By Id',
    summary: 'Delete Admin By Id',
  })
  @ApiBearerAuth()
  @Roles(['Super Admin'])
  @UseGuards(RoleGuard)
  deleteAdmin(
    @Param('id')
    id: string,
  ) {
    return this.userService.hardDeleteAdmin(+id);
  }
}
