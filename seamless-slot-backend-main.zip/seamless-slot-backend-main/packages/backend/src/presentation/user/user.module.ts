import { Module } from '@nestjs/common';
import { UserService } from './user.service';
import { UserController } from './user.controller';
import { UserDevController } from './user.dev.controller';

@Module({
  controllers: [UserController, UserDevController],
  providers: [UserService],
})
export class UserModule {}
