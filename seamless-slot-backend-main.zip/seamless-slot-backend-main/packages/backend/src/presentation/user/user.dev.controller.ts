import {
  Controller,
  Post,
  HttpCode,
  HttpStatus,
  Body,
  Param,
} from '@nestjs/common';
import { UserService } from './user.service';
import { ApiTags, ApiOperation } from '@nestjs/swagger';
import { LoginUserDto } from './dto/login-user.dto';
import { ConfigService } from '@nestjs/config';

@Controller('dev')
@ApiTags('Login Dev')
export class UserDevController {
  constructor(
    private readonly userService: UserService,
    private readonly configService: ConfigService,
  ) {}

  @Post('/login')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    description: 'Login a User',
    summary: 'Logn a User',
  })
  async login(
    @Body()
    dto: LoginUserDto,
  ) {
    const { accessToken, refreshToken } = await this.userService.login(dto);

    if (this.configService.get('NODE_ENV') === 'production')
      return 'These routes are not supported in Production';

    return {
      accessToken,
      refreshToken,
    };
  }

  @Post('/refresh/:refreshToken')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    description: 'Refresh Access Token',
    summary: 'Refresh Access Token',
  })
  async refreshAccessToken(
    @Param('refreshToken')
    refreshTokenIncoming: string,
  ) {
    const { accessToken, refreshToken } =
      await this.userService.refreshToken(refreshTokenIncoming);

    if (this.configService.get('NODE_ENV') === 'production')
      return 'These routes are not supported in Production';

    return {
      accessToken,
      refreshToken,
    };
  }
}
