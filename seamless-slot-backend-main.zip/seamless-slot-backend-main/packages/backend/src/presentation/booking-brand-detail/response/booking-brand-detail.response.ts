export interface BookingBrandDetailResponse {
  id: number;
  about: string;
  address: string;
  brand: string;
  country: string;
  currency: string;
  email: string;
  industry: string;
  telephone: string;
  town: string;
}
