import { ApiProperty, PartialType } from '@nestjs/swagger';
import { CreateBookingBrandDetailDto } from './create-booking-brand-detail.dto';
import { IsNotEmpty, IsNumber } from 'class-validator';

export class UpdateBookingBrandDetailDto extends PartialType(
  CreateBookingBrandDetailDto,
) {
  @ApiProperty({
    description: 'Id of the record which needs to be updated',
    example: 0,
  })
  @IsNumber(
    {},
    {
      message: 'Id of the record which needs to be updated',
    },
  )
  @IsNotEmpty({
    message: 'Id of Booking Brand Detail Can not Be Empty',
  })
  id: number;
}
