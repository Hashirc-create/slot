import { ApiProperty } from '@nestjs/swagger';
import { IsEmail, IsNotEmpty, IsNumber, IsString } from 'class-validator';

export class CreateBookingBrandDetailDto {
  @ApiProperty({
    description: 'About of Booking Brand Detail ',
    example: 'about',
  })
  @IsNotEmpty({
    message: 'About of Booking Brand Detail Can not Be Empty',
  })
  @IsString({
    message: 'About is required and must be a valid string',
  })
  about: string;
  @ApiProperty({
    description: 'Address of Booking Brand Detail ',
    example: 'address',
  })
  @IsNotEmpty({
    message: 'Address of Booking Brand Detail Can not Be Empty',
  })
  @IsString({
    message: 'Address is required and must be a valid string',
  })
  address: string;
  @ApiProperty({
    description: 'Brand of Booking Brand Detail ',
    example: 'brand',
  })
  @IsNotEmpty({
    message: 'Brand of Booking Brand Detail Can not Be Empty',
  })
  @IsString({
    message: 'Brand is required and must be a valid string',
  })
  brand: string;
  @ApiProperty({
    description: 'Country of Booking Brand Detail ',
    example: 'country',
  })
  @IsNotEmpty({
    message: 'Country of Booking Brand Detail Can not Be Empty',
  })
  @IsString({
    message: 'Country is required and must be a valid string',
  })
  country: string;
  @ApiProperty({
    description: 'Currency of Booking Brand Detail ',
    example: 'currency',
  })
  @IsNotEmpty({
    message: 'Currency of Booking Brand Detail Can not Be Empty',
  })
  @IsString({
    message: 'Currency is required and must be a valid string',
  })
  currency: string;
  @ApiProperty({
    description: 'Email of Booking Brand Detail ',
    example: 'email',
  })
  @IsNotEmpty({
    message: 'Email of Booking Brand Detail Can not Be Empty',
  })
  @IsEmail(
    {},
    {
      message: 'Email is required and must be a valid email',
    },
  )
  email: string;
  @ApiProperty({
    description: 'Industry of Booking Brand Detail ',
    example: 'industry',
  })
  @IsNotEmpty({
    message: 'Industry of Booking Brand Detail Can not Be Empty',
  })
  @IsString({
    message: 'Industry is required and must be a valid email',
  })
  industry: string;
  @ApiProperty({
    description: 'Telephone of Booking Brand Detail ',
    example: 'telephone',
  })
  @IsNotEmpty({
    message: 'Telephone of Booking Brand Detail Can not Be Empty',
  })
  @IsString({
    message: 'Telephone is required and must be a valid email',
  })
  telephone: string;
  @ApiProperty({
    description: 'Town of Booking Brand Detail ',
    example: 'town',
  })
  @IsNotEmpty({
    message: 'Town of Booking Brand Detail Can not Be Empty',
  })
  @IsString({
    message: 'Town is required and must be a valid email',
  })
  town: string;
  @ApiProperty({
    description: 'Location of Booking Brand Detail',
    example: 1,
  })
  @IsNotEmpty({
    message: 'Location of Booking Brand Detail Can not Be Empty',
  })
  @IsNumber(
    {},
    {
      message:
        'Location of Booking Brand Detail is required and must of type number',
    },
  )
  location: number;
}
