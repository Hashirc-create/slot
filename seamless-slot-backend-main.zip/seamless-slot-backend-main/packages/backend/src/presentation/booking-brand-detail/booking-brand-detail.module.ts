import { Module } from '@nestjs/common';
import { BookingBrandDetailService } from './booking-brand-detail.service';
import { BookingBrandDetailController } from './booking-brand-detail.controller';

@Module({
  controllers: [BookingBrandDetailController],
  providers: [BookingBrandDetailService],
  exports: [],
})
export class BookingBrandDetailModule {}
