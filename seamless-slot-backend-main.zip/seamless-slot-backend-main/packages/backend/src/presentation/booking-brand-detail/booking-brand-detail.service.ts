import { Injectable } from '@nestjs/common';
import { CreateBookingBrandDetailDto } from './dto/create-booking-brand-detail.dto';
import { UpdateBookingBrandDetailDto } from './dto/update-booking-brand-detail.dto';
import { UseCaseFactory } from '../../usecases/usecase.factory';
import { PresentationMapperFactory } from '../mapper/mapper.factory';
import { SecurityContext } from '../../shared/auth/context/security.context';

@Injectable()
export class BookingBrandDetailService {
  constructor(
    private readonly useCaseFactory: UseCaseFactory,
    private readonly presentationMapperFactory: PresentationMapperFactory,
    private readonly securityContext: SecurityContext,
  ) {}

  async create(createBookingBrandDetailDto: CreateBookingBrandDetailDto) {
    const savedBookingBrandDetail =
      await this.useCaseFactory.registerBookingBrandDetailUseCase.execute(
        this.presentationMapperFactory.bookingBrandDetailPresentationMapper.dtoToDomain(
          createBookingBrandDetailDto,
        ),
      );

    return `BookingBrandDetail Has Been Registered Against Id : ${savedBookingBrandDetail.id}`;
  }

  async findByLocation(locationId?: number) {
    const bookingBrandDetails =
      await this.useCaseFactory.getBookingBrandDetailsByLocationUseCase.execute(
        locationId || this.securityContext.getLocationId(),
      );

    return this.presentationMapperFactory.bookingBrandDetailPresentationMapper.domainToResponse(
      bookingBrandDetails,
    );
  }

  async update(updateBookingBrandDetailDto: UpdateBookingBrandDetailDto) {
    await this.useCaseFactory.updateBookingBrandDetailUseCase.execute(
      this.presentationMapperFactory.bookingBrandDetailPresentationMapper.dtoToDomain(
        updateBookingBrandDetailDto,
      ),
    );
    return `Booking Brand Details have been updated successfully against ID: ${updateBookingBrandDetailDto.id}.`;
  }
}
