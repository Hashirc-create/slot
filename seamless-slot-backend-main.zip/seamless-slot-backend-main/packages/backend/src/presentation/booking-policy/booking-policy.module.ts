import { Module } from '@nestjs/common';
import { BookingPolicyService } from './booking-policy.service';
import { BookingPolicyController } from './booking-policy.controller';

@Module({
  controllers: [BookingPolicyController],
  providers: [BookingPolicyService],
  exports: [],
})
export class BookingPolicyModule {}
