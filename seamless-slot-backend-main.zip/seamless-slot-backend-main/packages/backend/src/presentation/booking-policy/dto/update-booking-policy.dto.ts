import { ApiProperty, PartialType } from '@nestjs/swagger';
import { CreateBookingPolicyDto } from './create-booking-policy.dto';
import { IsNotEmpty, IsNumber } from 'class-validator';

export class UpdateBookingPolicyDto extends PartialType(
  CreateBookingPolicyDto,
) {
  @ApiProperty({
    description: 'Id of the record which needs to be updated',
    example: 0,
  })
  @IsNumber(
    {},
    {
      message: 'Id of the record which needs to be updated',
    },
  )
  @IsNotEmpty({
    message: 'Id of Booking Brand Detail Can not Be Empty',
  })
  id: number;
}
