import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsNumber, IsString } from 'class-validator';

export class CreateBookingPolicyDto {
  @ApiProperty({
    description: 'Lead Time of Booking Policy',
    example: 10,
  })
  @IsNotEmpty({
    message: 'leadTime of Booking Policy Can not Be Empty',
  })
  @IsNumber(
    {},
    {
      message: 'leadTime is required and must be a valid email',
    },
  )
  leadTime: number;
  @ApiProperty({
    description: 'Lead Time Type of Booking Policy',
    example: 'leadTimeType',
  })
  @IsNotEmpty({
    message: 'leadTimeType of Booking Policy Can not Be Empty',
  })
  @IsString({
    message: 'leadTimeType is required and must be a valid email',
  })
  leadTimeType: string;
  @ApiProperty({
    description: 'Slot Size of Booking Policy',
    example: 10,
  })
  @IsNotEmpty({
    message: 'slotSize of Booking Policy Can not Be Empty',
  })
  @IsNumber(
    {},
    {
      message: 'slotSize is required and must be a valid email',
    },
  )
  slotSize: number;
  @ApiProperty({
    description: 'Slot Size Type of Booking Policy',
    example: 'slotSizeType',
  })
  @IsNotEmpty({
    message: 'slotSizeType of Booking Policy Can not Be Empty',
  })
  @IsString({
    message: 'slotSizeType is required and must be a valid email',
  })
  slotSizeType: string;
  @ApiProperty({
    description: 'Scheduling Window of Booking Policy',
    example: 10,
  })
  @IsNotEmpty({
    message: 'schedulingWindow of Booking Policy Can not Be Empty',
  })
  @IsNumber(
    {},
    {
      message: 'schedulingWindow is required and must be a valid number',
    },
  )
  schedulingWindow: number;
  @ApiProperty({
    description: 'Scheduling Window Type of Booking Policy',
    example: 'schedulingWindowType',
  })
  @IsNotEmpty({
    message: 'schedulingWindowType of Booking Policy Can not Be Empty',
  })
  @IsString({
    message: 'schedulingWindowType is required and must be a valid string',
  })
  schedulingWindowType: string;
  @ApiProperty({
    description: 'Cancellation Policy of Booking Policy',
    example: 'cancellationPolicy',
  })
  @IsNotEmpty({
    message: 'cancellationPolicy of Booking Policy Can not Be Empty',
  })
  @IsString({
    message: 'cancellationPolicy is required and must be a valid string',
  })
  cancellationPolicy: string;

  @ApiProperty({
    description: 'Location of Booking Policy',
    example: 1,
  })
  @IsNotEmpty({
    message: 'Location of Booking Policy Can not Be Empty',
  })
  @IsNumber(
    {},
    {
      message: 'Location of Booking Policy is required and must of type number',
    },
  )
  location: number;
}
