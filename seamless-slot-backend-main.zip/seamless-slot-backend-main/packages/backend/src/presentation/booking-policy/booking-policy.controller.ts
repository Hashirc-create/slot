import {
  Controller,
  Get,
  Body,
  Param,
  HttpCode,
  HttpStatus,
  Patch,
  UseGuards,
} from '@nestjs/common';
import { BookingPolicyService } from './booking-policy.service';
import { ApiBearerAuth, ApiOperation, ApiTags } from '@nestjs/swagger';
import { UpdateBookingPolicyDto } from './dto/update-booking-policy.dto';
import { RoleGuard } from '../../shared/auth/guard/jwt.guard';
import { Roles } from '../../shared/auth/decorator/role.decorator';

@Controller('booking-policy')
@ApiTags('BookingPolicies')
@ApiBearerAuth()
export class BookingPolicyController {
  constructor(private readonly bookingPolicyService: BookingPolicyService) {}

  @Get('/findAllByLocation/:locationId')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    description: 'Get All Services By Location',
    summary: 'Get All Services By Location',
  })
  @Roles(['Super Admin', 'Admin'])
  @UseGuards(RoleGuard)
  findByLocation(
    @Param('locationId')
    locationId: string,
  ) {
    return this.bookingPolicyService.findByLocation(+locationId);
  }

  @Patch('/update')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    description: 'Update BookingPolicy By Id',
    summary: 'Update BookingPolicy By Id',
  })
  @Roles(['Super Admin', 'Admin'])
  @UseGuards(RoleGuard)
  update(
    @Body()
    updateBookingPolicyDto: UpdateBookingPolicyDto,
  ) {
    return this.bookingPolicyService.update(updateBookingPolicyDto);
  }
}
