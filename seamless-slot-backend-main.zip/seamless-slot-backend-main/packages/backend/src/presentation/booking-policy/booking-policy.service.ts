import { Injectable } from '@nestjs/common';
import { CreateBookingPolicyDto } from './dto/create-booking-policy.dto';
import { UpdateBookingPolicyDto } from './dto/update-booking-policy.dto';
import { UseCaseFactory } from '../../usecases/usecase.factory';
import { PresentationMapperFactory } from '../mapper/mapper.factory';
import { SecurityContext } from '../../shared/auth/context/security.context';

@Injectable()
export class BookingPolicyService {
  constructor(
    private readonly useCaseFactory: UseCaseFactory,
    private readonly presentationMapperFactory: PresentationMapperFactory,
    private readonly securityContext: SecurityContext,
  ) {}

  async create(createBookingPolicyDto: CreateBookingPolicyDto) {
    const savedBookingPolicy =
      await this.useCaseFactory.registerBookingPolicyUseCase.execute(
        this.presentationMapperFactory.bookingPolicyPresentationMapper.dtoToDomain(
          createBookingPolicyDto,
        ),
      );

    return `BookingPolicy Has Been Registered Against Id : ${savedBookingPolicy.id}`;
  }

  async findByLocation(locationId?: number) {
    const bookingPolicies =
      await this.useCaseFactory.getBookingPoliciesByLocationUseCase.execute(
        locationId || this.securityContext.getLocationId(),
      );

    return this.presentationMapperFactory.bookingPolicyPresentationMapper.domainToResponse(
      bookingPolicies,
    );
  }

  async update(updateBookingPolicyDto: UpdateBookingPolicyDto) {
    await this.useCaseFactory.updateBookingPolicyUseCase.execute(
      this.presentationMapperFactory.bookingPolicyPresentationMapper.dtoToDomain(
        updateBookingPolicyDto,
      ),
    );
    return `Booking Brand Details have been updated successfully against ID: ${updateBookingPolicyDto.id}.`;
  }
}
