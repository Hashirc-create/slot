export interface BookingPolicyResponse {
  id: number;
  leadTime: number;
  leadTimeType: string;
  slotSize: number;
  slotSizeType: string;
  schedulingWindow: number;
  schedulingWindowType: string;
  cancellationPolicy: string;
}
