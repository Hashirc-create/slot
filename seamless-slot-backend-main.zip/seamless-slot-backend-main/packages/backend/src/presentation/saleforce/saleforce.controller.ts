import {
  Controller,
  HttpCode,
  HttpStatus,
  Post,
  UseGuards,
} from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiTags } from '@nestjs/swagger';
import { RoleGuard } from '../../shared/auth/guard/jwt.guard';
import { Roles } from '../../shared/auth/decorator/role.decorator';

@Controller('saleforce')
@ApiTags('SaleForce')
export class SaleforceController {
  constructor() {}

  @Post('/saveObject/:objectName')
  @HttpCode(HttpStatus.CREATED)
  @ApiOperation({
    description: 'Save Object into SaleForce',
    summary: 'Save Object into SaleForce',
  })
  @ApiBearerAuth()
  @Roles(['Super Admin', 'Admin'])
  @UseGuards(RoleGuard)
  async saveSaleForceObject() {
    return 'Sale force not integrated yet';
  }
}
