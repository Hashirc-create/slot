import { Module } from '@nestjs/common';
import { SaleforceController } from './saleforce.controller';

@Module({
  controllers: [SaleforceController],
})
export class SaleforceModule {}
