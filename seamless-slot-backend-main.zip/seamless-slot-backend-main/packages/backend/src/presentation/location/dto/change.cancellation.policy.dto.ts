import { ApiProperty } from '@nestjs/swagger';
import { IsBoolean, IsNumber, IsString } from 'class-validator';
import { CancellationTimeUnits } from '@seamlessslot/core';

export class ChangeCancellationPolicyDto {
  @ApiProperty({
    description: 'Location Id',
    example: 0,
  })
  @IsNumber(
    {},
    {
      message: 'Location Id must be a number and is required',
    },
  )
  locationId: number;

  @ApiProperty({
    description: 'Cancellation Policy in hours',
    example: '',
  })
  @IsNumber(
    {},
    {
      message: 'Cancellation Policy required and must be integer',
    },
  )
  cancellationPolicyValue: number;

  @ApiProperty({
    description: 'Cancellation Policy in hours',
    example: '',
  })
  @IsString({
    message: 'should be of type days hours and months',
  })
  cancellationPolicyUnit: CancellationTimeUnits;

  @ApiProperty({
    description: 'Cancellation Policy in hours',
    example: '',
  })
  @IsBoolean({
    message: 'isCancellationPolicy policy boolean required',
  })
  isCancellationPolicyEnabled: boolean;
}
