import { ApiProperty, PartialType } from '@nestjs/swagger';
import { CreateLocationDto } from './create-location.dto';
import { IsIn, IsNotEmpty, IsNumber, IsString } from 'class-validator';
import { Status } from '@seamlessslot/core';

export class UpdateLocationDto extends PartialType(CreateLocationDto) {
  @ApiProperty({
    description: 'Id of the record which needs to be updated',
    example: 0,
  })
  @IsNumber(
    {},
    {
      message: 'Id of the record which needs to be updated',
    },
  )
  id: number;

  @ApiProperty({
    description: 'Status of Location',
    example: '+9243..',
  })
  @IsNotEmpty({
    message: 'Status of location required and must be not empty string',
  })
  @IsString({
    message: 'Status of location required and must be not empty string',
  })
  @IsIn(['Active', 'Inactive', 'Freeze'] as Status[], {
    message:
      'Status must be one of the following values: Active, Inactive, Freeze',
  })
  status: string;
}
