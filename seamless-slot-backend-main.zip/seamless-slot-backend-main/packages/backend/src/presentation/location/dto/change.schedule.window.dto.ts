import { ApiProperty } from '@nestjs/swagger';
import { IsNumber, IsString } from 'class-validator';
import { ScheduleSizeUnits } from '@seamlessslot/core';

export class ChangeScheduleWindowSizeDto {
  @ApiProperty({
    description: 'Location Id',
    example: 0,
  })
  @IsNumber(
    {},
    {
      message: 'Location Id must be a number and is required',
    },
  )
  locationId: number;

  @ApiProperty({
    description: 'Schedule Window Size',
    example: 0,
  })
  @IsNumber(
    {},
    {
      message: 'Schedule Window Size',
    },
  )
  scheduleWindowSize: number;

  @ApiProperty({
    description: 'Schedule Window Size Unit',
    example: '',
  })
  @IsString({
    message: 'Schedule Window Size Unit',
  })
  scheduleWindowSizeUnit: ScheduleSizeUnits;
}
