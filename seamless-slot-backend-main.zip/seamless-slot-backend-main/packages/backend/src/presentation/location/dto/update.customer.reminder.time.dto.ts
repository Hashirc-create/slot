import { ApiProperty } from '@nestjs/swagger';
import { IsIn, IsNotEmpty, IsNumber, IsString } from 'class-validator';
import { CustomerReminderTimeUnit } from '@seamlessslot/core';

export class UpdateCustomerReminderTimeDto {
  @ApiProperty({
    description: 'Location Id',
    example: 0,
  })
  @IsNumber(
    {},
    {
      message: 'Location Id must be a number and is required',
    },
  )
  locationId: number;

  @ApiProperty({
    description: 'Customer reminder Time',
    example: 0,
  })
  @IsNumber(
    {},
    {
      message: 'Customer reminder Time must be a number and is required',
    },
  )
  customerReminderTime: number;

  @ApiProperty({
    description: 'Customer Reminder Time Unit',
    example: 'minutes|hours',
  })
  @IsNotEmpty({
    message: 'Customer Reminder Time Unit Can not Be Empty',
  })
  @IsString({
    message: 'Customer Reminder Time Unit is required and must of type string',
  })
  @IsIn(['minutes', 'hours'], {
    message: 'Customer Reminder Time Unit must be either "minutes" or "hours"',
  })
  customerReminderTimeUnit: CustomerReminderTimeUnit;
}
