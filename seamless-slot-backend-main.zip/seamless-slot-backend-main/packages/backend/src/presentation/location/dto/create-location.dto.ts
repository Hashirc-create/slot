import { ApiProperty } from '@nestjs/swagger';
import { IsEmail, IsNotEmpty, IsNumber, IsString } from 'class-validator';
import { IsTimezone } from '../../../shared/validator/timezone.validator';

export class CreateLocationDto {
  @ApiProperty({
    description: 'Business Id',
    example: 0.0,
  })
  @IsNumber(
    {},
    {
      message: 'Business Id is required and must of type number',
    },
  )
  businessId: number;

  @ApiProperty({
    description: 'Name of Location',
    example: 'Manchester',
  })
  @IsNotEmpty({
    message: 'Name of Location Can not Be Empty',
  })
  @IsString({
    message: 'Name of Location is required and must of type string',
  })
  name: string;

  @ApiProperty({
    description: 'Google Map URL of Location',
    example: 'https://www.google.maps.com',
  })
  @IsString({
    message: 'Google Map URL of Location and must of type string',
  })
  googleMapUrl: string;

  @ApiProperty({
    description: 'Time Zone of Location',
    example: 'America/Los_Angeles',
  })
  @IsNotEmpty({
    message: 'Time Zone of Location Can not Be Empty',
  })
  @IsTimezone({
    message: 'Please provide a valid timezone',
  })
  timeZone: string;

  @ApiProperty({
    description: 'Email of Location',
    example: 'test@test.com',
  })
  @IsNotEmpty({
    message: 'Email of Location Can not Be Empty',
  })
  @IsEmail(
    {},
    {
      message: 'Email of Location is required and must of type string',
    },
  )
  email: string;

  @ApiProperty({
    description: 'Site of Location',
    example: 'Manchester',
  })
  @IsNotEmpty({
    message: 'Site of Location Can not Be Empty',
  })
  @IsString({
    message: 'Site of Location is required and must of type string',
  })
  site: string;

  @ApiProperty({
    description: 'Address of Location',
    example: 'Manchester',
  })
  @IsNotEmpty({
    message: 'Address of Location Can not Be Empty',
  })
  @IsString({
    message: 'Address of Location is required and must of type string',
  })
  address: string;

  @ApiProperty({
    description: 'Latitude of Location',
    example: 0.0,
  })
  @IsNotEmpty({
    message: 'Latitude of Location Can not Be Empty',
  })
  @IsNumber(
    {},
    {
      message: 'Latitude of Location is required and must of type number',
    },
  )
  latitude: number;

  @ApiProperty({
    description: 'Longitude of Location',
    example: 0.0,
  })
  @IsNotEmpty({
    message: 'Longitude of Location Can not Be Empty',
  })
  @IsNumber(
    {},
    {
      message: 'Longitude of Location is required and must of type number',
    },
  )
  longitude: number;

  @ApiProperty({
    description: 'Telephone of Location',
    example: '+9233223234',
  })
  @IsString({
    message: 'Telephone of Location is required and must of type string',
  })
  telephone: string;

  @ApiProperty({
    description: 'Country of Location',
    example: 'Pakistan',
  })
  @IsString({
    message: 'Country of Location is required and must of type string',
  })
  country: string;

  @ApiProperty({
    description: 'Town of Location',
    example: 'Manchester',
  })
  @IsString({
    message: 'Town of Location is required and must of type string',
  })
  town: string;

  @ApiProperty({
    description: 'ConferenceCall of Location',
    example: 'Manchester',
  })
  @IsString({
    message: 'Conference Call of Location is required and must of type string',
  })
  conferenceCall: string;

  @ApiProperty({
    description: 'About of Location',
    example: 'Manchester',
  })
  @IsString({
    message: 'About of Location is required and must of type string',
  })
  about: string;
}
