import {
  CancellationTimeInHours,
  CancellationTimeUnits,
  CustomerReminderTimeUnit,
  ScheduleSizeUnits,
  Status,
} from '@seamlessslot/core';

export interface LocationResponse {
  id: number;
  name: string;
  email: string;
  site: string;
  address: string;
  timeZone: string;
  latitude: number;
  longitude: number;
  telephone: string;
  country: string;
  town: string;
  status: Status;
  googleMapUrl: string;
  scheduleWindowSize: number;
  scheduleWindowSizeUnit: ScheduleSizeUnits;
  cacellationPolicyTimeInHours: CancellationTimeInHours;
  isCancellationPolicyEnabled: boolean;
  cancellationTime: number;
  cancellationTimeUnits: CancellationTimeUnits;
  conferenceCall: string;
  about: string;

  businessName?: string;
  createdBy?: string;
  createdAt?: string;
  updatedBy?: string;
  updatedAt?: string;
}

export interface LocationResponseWithBusiness {
  id: number;
  name: string;
  email: string;
  site: string;
  address: string;
  timeZone: string;
  latitude: number;
  longitude: number;
  telephone: string;
  country: string;
  town: string;
  status: Status;
  googleMapUrl: string;
  scheduleWindowSize: number;
  scheduleWindowSizeUnit: ScheduleSizeUnits;
  cacellationPolicyTimeInHours: CancellationTimeInHours;
  isCancellationPolicyEnabled: boolean;
  cancellationTime: number;
  cancellationTimeUnits: CancellationTimeUnits;
  conferenceCall: string;
  about: string;

  businessName: string;
  customerReminderTime: number;
  customerReminderTimeUnit: CustomerReminderTimeUnit;
}
