import { Injectable } from '@nestjs/common';
import { CreateLocationDto } from './dto/create-location.dto';
import { UpdateLocationDto } from './dto/update-location.dto';
import { UseCaseFactory } from '../../usecases/usecase.factory';
import { PresentationMapperFactory } from '../mapper/mapper.factory';
import { ChangeScheduleWindowSizeDto } from './dto/change.schedule.window.dto';
import { ChangeCancellationPolicyDto } from './dto/change.cancellation.policy.dto';
import { UpdateCustomerReminderTimeDto } from './dto/update.customer.reminder.time.dto';

@Injectable()
export class LocationService {
  constructor(
    private readonly useCaseFactory: UseCaseFactory,
    private readonly presentationMapperFactory: PresentationMapperFactory,
  ) {}

  async deleteLocationService(locationId: number) {
    const response =
      await this.useCaseFactory.deleteLocationUseCase.execute(locationId);
    return `Location has be Deleted successfully Against Id : ${response.id}`;
  }

  async getCancellationPolicy(locationId: number) {
    return this.useCaseFactory.getCancellationPolicyUseCase.execute(locationId);
  }

  async changeCancellationPolicy(dto: ChangeCancellationPolicyDto) {
    await this.useCaseFactory.changeLocationCancellationPolicy.execute(
      dto.locationId,
      dto.cancellationPolicyValue,
      dto.cancellationPolicyUnit,
      dto.isCancellationPolicyEnabled,
    );
    return `Cancellation Policy Has Been Changed Successfully`;
  }

  async changeLocationWindowSize(dto: ChangeScheduleWindowSizeDto) {
    await this.useCaseFactory.changeLocationScheduleWindowUseCase.execute(
      dto.locationId,
      dto.scheduleWindowSize,
      dto.scheduleWindowSizeUnit,
    );
    return `Schedule Window Size Has Been Changed Successfully`;
  }

  async create(createLocationDto: CreateLocationDto) {
    const savedLocation =
      await this.useCaseFactory.registerLocationUseCase.execute(
        this.presentationMapperFactory.locationPresentationMapper.dtoToDomain(
          createLocationDto,
        ),
      );

    return `Location Has Been Registered Against Id : ${savedLocation.id}`;
  }

  async findAllWithPagination(page: number, limit: number) {
    const { totalRecords, data } =
      await this.useCaseFactory.getAllLocationWithPaginationUseCase.execute(
        page,
        limit,
      );

    const allLocations = data.map((location) =>
      this.presentationMapperFactory.locationPresentationMapper.domainToResponse(
        location,
      ),
    );

    return {
      totalRecords: totalRecords,
      locations: allLocations,
    };
  }

  async findAll() {
    const data = await this.useCaseFactory.getAllLocationUseCase.execute();

    const allLocations = data.map((location) =>
      this.presentationMapperFactory.locationPresentationMapper.domainToResponse(
        location,
      ),
    );

    return allLocations;
  }

  async findOne(id: number) {
    const locationFound =
      await this.useCaseFactory.getByIdLocationUseCase.execute(id);

    return this.presentationMapperFactory.locationPresentationMapper.domainToResponseWithBusiness(
      locationFound,
    );
  }

  async update(updateLocationDto: UpdateLocationDto) {
    const updatedLocation =
      await this.useCaseFactory.updateLocationUseCase.execute(
        updateLocationDto.id,
        this.presentationMapperFactory.locationPresentationMapper.dtoToDomainForUpdate(
          updateLocationDto,
        ),
      );

    return `Location has be updated successfully Against Id : ${updatedLocation.id}`;
  }

  async updateCustomerReminderTimeService(
    updateCustomerReminderTimeDto: UpdateCustomerReminderTimeDto,
  ) {
    const updatedLocation =
      await this.useCaseFactory.updateCustomerReminderTimeUseCase.execute(
        updateCustomerReminderTimeDto.locationId,
        updateCustomerReminderTimeDto.customerReminderTime,
        updateCustomerReminderTimeDto.customerReminderTimeUnit,
      );

    return `Location Customer Reminder Time has be updated successfully Against Location : ${updatedLocation.name}`;
  }
}
