import {
  Controller,
  Get,
  Post,
  Body,
  Param,
  HttpCode,
  HttpStatus,
  Patch,
  UseGuards,
  Delete,
} from '@nestjs/common';
import { LocationService } from './location.service';
import { CreateLocationDto } from './dto/create-location.dto';
import { ApiBearerAuth, ApiOperation, ApiTags } from '@nestjs/swagger';
import { UpdateLocationDto } from './dto/update-location.dto';
import { RoleGuard } from '../../shared/auth/guard/jwt.guard';
import { ChangeScheduleWindowSizeDto } from './dto/change.schedule.window.dto';
import { ChangeCancellationPolicyDto } from './dto/change.cancellation.policy.dto';
import { Roles } from '../../shared/auth/decorator/role.decorator';
import { UpdateCustomerReminderTimeDto } from './dto/update.customer.reminder.time.dto';

@Controller('location')
@ApiTags('Locations')
@ApiBearerAuth()
export class LocationController {
  constructor(private readonly locationService: LocationService) {}

  @Post('/add')
  @HttpCode(HttpStatus.CREATED)
  @ApiOperation({
    description: 'Register New Location',
    summary: 'Register New Location',
  })
  @ApiBearerAuth()
  @Roles(['Super Admin'])
  @UseGuards(RoleGuard)
  async registerNewLocation(
    @Body()
    dto: CreateLocationDto,
  ) {
    return await this.locationService.create(dto);
  }

  @Get('/findAll')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    description: 'Get All Locations By Page And Limit',
    summary: 'Get All Locations By Page And Limit',
  })
  async getAllLocations() {
    return await this.locationService.findAll();
  }

  @Get('/findCancellationPolicy/:locationId')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    description: 'Get Cancellation Policy By Location Id',
    summary: 'Get Cancellation Policy By Location Id',
  })
  async findCancellationPolicy(
    @Param('locationId')
    locationId: string,
  ) {
    return await this.locationService.getCancellationPolicy(+locationId);
  }

  @Post('/changeScheduleWidowSize')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    description: 'Change Schedule Window Size of Location',
    summary: 'Change Schedule Window Size of Location',
  })
  @ApiBearerAuth()
  @Roles(['Super Admin', 'Admin'])
  @UseGuards(RoleGuard)
  async changeScheduleWindowSize(
    @Body()
    dto: ChangeScheduleWindowSizeDto,
  ) {
    return await this.locationService.changeLocationWindowSize(dto);
  }

  @Post('/changeCancellationPolicy')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    description: 'Change Cancellation Policy of Location',
    summary: 'Change Cancellation Policy of Location',
  })
  @ApiBearerAuth()
  @Roles(['Super Admin', 'Admin'])
  @UseGuards(RoleGuard)
  async changeCancellationPolicy(
    @Body()
    dto: ChangeCancellationPolicyDto,
  ) {
    return await this.locationService.changeCancellationPolicy(dto);
  }

  @Get('/findAll/:page/:limit')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    description: 'Get All Locations By Page And Limit',
    summary: 'Get All Locations By Page And Limit',
  })
  @ApiBearerAuth()
  @Roles(['Super Admin', 'Admin'])
  @UseGuards(RoleGuard)
  async getAllLocationsByPageAndLimit(
    @Param('page')
    page: string,
    @Param('limit')
    limit: string,
  ) {
    return await this.locationService.findAllWithPagination(+page, +limit);
  }

  @Get('/findById/:id')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    description: 'Get Locations By Id',
    summary: 'Get Locations By Id',
  })
  async getLocationById(
    @Param('id')
    id: string,
  ) {
    return await this.locationService.findOne(+id);
  }

  @Patch('/update')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    description: 'Update Location By Id',
    summary: 'Update Location By Id',
  })
  update(
    @Body()
    updateLocationDto: UpdateLocationDto,
  ) {
    return this.locationService.update(updateLocationDto);
  }

  @Post('/updateCustomerReminderTime')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    description: 'Update Customer Reminder Time By Location Id',
    summary: 'Update Customer Reminder Time By Location Id',
  })
  updateCustomerReminderTime(
    @Body()
    updateCustomerReminderTimeDto: UpdateCustomerReminderTimeDto,
  ) {
    return this.locationService.updateCustomerReminderTimeService(
      updateCustomerReminderTimeDto,
    );
  }

  @Delete('/delete/:locationId')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    description: 'Delete Location By Id',
    summary: 'Delete Location By Id',
  })
  @ApiBearerAuth()
  @Roles(['Super Admin', 'Admin'])
  @UseGuards(RoleGuard)
  deleteLocation(
    @Param('locationId')
    locationId: string,
  ) {
    return this.locationService.deleteLocationService(+locationId);
  }
}
