import { ApiProperty, PartialType } from '@nestjs/swagger';
import { CreateTimeOffDto } from './create-time-off.dto';
import { IsNumber } from 'class-validator';

export class UpdateTimeOffDto extends PartialType(CreateTimeOffDto) {
  @ApiProperty({
    description: 'Id of the record which need to be updated',
    example: 0,
  })
  @IsNumber(
    {},
    {
      message: 'id is required and must not be empty',
    },
  )
  id: number;
}
