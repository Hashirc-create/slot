import { ApiProperty } from '@nestjs/swagger';
import {
  IsBoolean,
  IsDateString,
  IsNotEmpty,
  IsOptional,
  IsString,
} from 'class-validator';

export class CreateTimeOffDto {
  @ApiProperty({
    description: 'Title of Time Off',
    example: 'urgent work',
  })
  @IsNotEmpty({
    message: 'Title of Time Off Can not Be Empty',
  })
  @IsString({
    message: 'title is required and is of type string',
  })
  title: string;

  @ApiProperty({
    description: 'Start Date Time',
    example: '2024-06-01T09:00:00',
  })
  @IsNotEmpty({
    message: 'Start Date Time Can not be empty',
  })
  @IsDateString(
    {
      strict: true,
      strictSeparator: true,
    },
    {
      message:
        'Date Time must be a valid Date Time String (yyyy-MM-ddTHH:mm:ss)',
    },
  )
  startDateTime: string;

  @ApiProperty({
    description: 'End Date Time',
    example: '2024-06-01T09:00:00',
  })
  @IsNotEmpty({
    message: 'End Date Time Can not be empty',
  })
  @IsDateString(
    {
      strict: true,
      strictSeparator: true,
    },
    {
      message:
        'Date Time must be a valid Date Time String (yyyy-MM-ddTHH:mm:ss)',
    },
  )
  endDateTime: string;

  @ApiProperty({
    description: 'Location Id which is optional',
    example: 0,
  })
  @IsOptional({
    message: 'Location Id which is optional',
  })
  locationId: number;

  @ApiProperty({
    description: 'All Day is Required',
    example: false,
  })
  @IsBoolean({
    message: 'All Day is required and is of type boolean ',
  })
  allDay: boolean;
}
