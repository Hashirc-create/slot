export interface TimeOffResponse {
  id: number;
  title: string;
  startDateTime: string;
  endDateTime: string;
  allDay: boolean;
  startDateOnly: string;
  startTimeOnly: string;
  endDateOnly: string;
  endTimeOnly: string;

  createdBy: string;
  createdAt: string;
  updatedBy: string;
  updatedAt: string;
}
