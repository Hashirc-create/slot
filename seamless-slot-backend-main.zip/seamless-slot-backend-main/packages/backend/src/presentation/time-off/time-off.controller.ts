import {
  Controller,
  Get,
  Post,
  Body,
  Patch,
  Param,
  Delete,
  HttpCode,
  HttpStatus,
  UseGuards,
} from '@nestjs/common';
import { TimeOffService } from './time-off.service';
import { CreateTimeOffDto } from './dto/create-time-off.dto';
import { UpdateTimeOffDto } from './dto/update-time-off.dto';
import { ApiBearerAuth, ApiOperation, ApiTags } from '@nestjs/swagger';
import { RoleGuard } from '../../shared/auth/guard/jwt.guard';
import { Roles } from '../../shared/auth/decorator/role.decorator';

@Controller('time-off')
@ApiTags('Time Offs')
@ApiBearerAuth()
export class TimeOffController {
  constructor(private readonly timeOffService: TimeOffService) {}

  @Post('/add')
  @HttpCode(HttpStatus.CREATED)
  @ApiOperation({
    description: 'Create New Time Off',
    summary: 'Create New Time Off',
  })
  @Roles(['Super Admin', 'Admin'])
  @UseGuards(RoleGuard)
  create(
    @Body()
    createTimeOffDto: CreateTimeOffDto,
  ) {
    return this.timeOffService.create(createTimeOffDto);
  }

  @Get('/findAll/:locationId')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    description: 'Get All Time Offs By Page And Limit And Location Id',
    summary: 'Get All Time Offs By Page And Limit And Location Id',
  })
  @Roles(['Super Admin', 'Admin'])
  @UseGuards(RoleGuard)
  findAll(
    @Param('locationId')
    locationId: string,
  ) {
    return this.timeOffService.findAllByLocationId(+locationId);
  }

  @Patch('/update')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    description: 'Update Time Off By Id',
    summary: 'Update Time Off By Id',
  })
  @Roles(['Super Admin', 'Admin'])
  @UseGuards(RoleGuard)
  update(
    @Body()
    updateTimeOffDto: UpdateTimeOffDto,
  ) {
    return this.timeOffService.update(updateTimeOffDto);
  }

  @Delete('/delete/:id')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    description: 'Delete Time Off By Id',
    summary: 'Delete Time Off By Id',
  })
  @Roles(['Super Admin', 'Admin'])
  @UseGuards(RoleGuard)
  remove(
    @Param('id')
    id: string,
  ) {
    return this.timeOffService.remove(+id);
  }
}
