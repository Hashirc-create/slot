import { Injectable } from '@nestjs/common';
import { CreateTimeOffDto } from './dto/create-time-off.dto';
import { UpdateTimeOffDto } from './dto/update-time-off.dto';
import { UseCaseFactory } from '../../usecases/usecase.factory';
import { PresentationMapperFactory } from '../mapper/mapper.factory';
import { TimeOff } from '@seamlessslot/core';

@Injectable()
export class TimeOffService {
  constructor(
    private readonly useCaseFactory: UseCaseFactory,
    private mapper: PresentationMapperFactory,
  ) {}

  async create(createTimeOffDto: CreateTimeOffDto) {
    const timeOff: TimeOff =
      this.mapper.timeOffPresentationMapper.dtoToDomain(createTimeOffDto);

    const savedTimeOff =
      await this.useCaseFactory.createTimeOffUseCase.execute(timeOff);

    return `Time Off Has Been Saved Against Id : ${savedTimeOff.id}`;
  }

  async findAllByLocationId(locationId: number) {
    const timeOffs =
      await this.useCaseFactory.getAllTimeOffsByLocationUseCase.execute(
        locationId,
      );

    return await Promise.all(
      timeOffs.map(
        async (timeOff) =>
          await this.mapper.timeOffPresentationMapper.domainToResponse(
            timeOff,
            this.useCaseFactory.getUserByIdUseCase,
          ),
      ),
    );
  }

  async update(updateTimeOffDto: UpdateTimeOffDto) {
    const updatedTimeOff =
      await this.useCaseFactory.updateTimeOffUseCase.execute(
        updateTimeOffDto.id,
        this.mapper.timeOffPresentationMapper.dtoToDomain(updateTimeOffDto),
      );
    return `Time Off Update Sucessfully Against Id ${updatedTimeOff.id}`;
  }

  async remove(id: number) {
    const deletedTimeOff =
      await this.useCaseFactory.deleteTimeOffUseCase.execute(id);
    return `Time Off Delete Sucessfully Against Id ${deletedTimeOff.id}`;
  }
}
