import { Module } from '@nestjs/common';
import { GoogleTagManagerController } from './google.tag.manager.controller';

@Module({
  controllers: [GoogleTagManagerController],
})
export class GoogleTagManagerModule {}
