import { ApiProperty, PartialType } from '@nestjs/swagger';
import { IsNumber } from 'class-validator';
import { CreateGoogleTagManagerDto } from './create.google.tag.manager.dto';

export class EditGoogleTagManagerDto extends PartialType(
  CreateGoogleTagManagerDto,
) {
  @ApiProperty({
    description: 'Id',
    example: 0,
  })
  @IsNumber(
    {},
    {
      message: 'Google Tag Manager Id required',
    },
  )
  id: number;
}
