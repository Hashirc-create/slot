import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsNumber, IsString } from 'class-validator';

export class CreateGoogleTagManagerDto {
  @ApiProperty({
    description: 'LocationId',
    example: 0,
  })
  @IsNumber(
    {},
    {
      message: 'Location Id is required',
    },
  )
  locationId: number;

  @ApiProperty({
    description: 'BusinessId',
    example: 0,
  })
  @IsNumber(
    {},
    {
      message: 'BusinessId is required',
    },
  )
  businessId: number;

  @ApiProperty({
    description: 'Google Tag Manager Container Id',
    example: 'GTM-XXXXXXX',
  })
  @IsNotEmpty({
    message: 'Google Tag Manager Container Id Can Not be Empty',
  })
  @IsString({
    message: 'Google Tag Manager Container Id Is Required',
  })
  containerId: string;
}
