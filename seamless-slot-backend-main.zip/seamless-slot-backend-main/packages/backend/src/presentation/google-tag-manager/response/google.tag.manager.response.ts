export interface GoogleTagManagerResponse {
  id: number;
  containerId: string;
}
