import {
  Controller,
  Post,
  Body,
  HttpCode,
  HttpStatus,
  UseGuards,
  Patch,
  Param,
  Get,
  HttpException,
} from '@nestjs/common';
import { ApiOperation, ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { RoleGuard } from '../../shared/auth/guard/jwt.guard';
import { UseCaseFactory } from '../../usecases/usecase.factory';
import { CreateGoogleTagManagerDto } from './dto/create.google.tag.manager.dto';
import { EditGoogleTagManagerDto } from './dto/edit.google.tag.manager.dto';
import { PresentationMapperFactory } from '../mapper/mapper.factory';
import { BaseResponse } from '../../shared/interceptor/response.interceptor';
import { Roles } from '../../shared/auth/decorator/role.decorator';

@Controller('google-tag-manager')
@ApiTags('Google Tag Manager')
export class GoogleTagManagerController {
  constructor(
    private readonly useCaseFactory: UseCaseFactory,
    private readonly mapperFactory: PresentationMapperFactory,
  ) {}

  @Get('/findByLocation/:locationId')
  @HttpCode(HttpStatus.CREATED)
  @ApiOperation({
    description: 'Find Google Tag Manager Account By Location',
    summary: 'Find Google Tag Manager Account By Location',
  })
  @ApiBearerAuth()
  async findByLocation(
    @Param('locationId')
    locationId: string,
  ) {
    if (locationId === 'null' || locationId === null)
      return 'please provide a valid location id';

    const response =
      await this.useCaseFactory.findGoogleTagManagerByLocationUseCase.execute(
        +locationId,
      );

    if (!response)
      throw new HttpException(
        {
          code: 0,
          message: 'Account Not Linked',
          data: 'Account Not Linked',
        } as BaseResponse<string>,
        HttpStatus.OK,
      );

    return this.mapperFactory.googleTagManagerMapper.domainToResponse(response);
  }

  @Post('/create')
  @HttpCode(HttpStatus.CREATED)
  @ApiOperation({
    description: 'Register a new Google Tag Manager Account Against Location',
    summary: 'Register a new Google Tag Manager Against Location',
  })
  @ApiBearerAuth()
  @Roles(['Super Admin', 'Admin'])
  @UseGuards(RoleGuard)
  async create(
    @Body()
    dto: CreateGoogleTagManagerDto,
  ) {
    await this.useCaseFactory.createGoogleTagManagerUseCase.execute({
      containerId: dto.containerId,
      locationId: dto.locationId,
      businessId: dto.businessId,
    });

    return 'Google Tag Manager Registered Successfully Against Location';
  }

  @Patch('/edit')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    description: 'Edit Google Tag Manager Against Location',
    summary: 'Edit Google Tag Manager Against Location',
  })
  @ApiBearerAuth()
  @Roles(['Super Admin', 'Admin'])
  @UseGuards(RoleGuard)
  async edit(
    @Body()
    dto: EditGoogleTagManagerDto,
  ) {
    await this.useCaseFactory.editGoogleTagManagerUseCase.execute(
      dto.id,
      dto.containerId,
      dto.locationId,
    );

    return 'Google Tag Manager Edited Successfully Against Location';
  }

  @Get('/isGoogleTagManagerConnected/:locationId')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    description: 'Is Google Tag Manager Connected To Location',
    summary: 'Is Google Tag Manager Connected To Location',
  })
  @ApiBearerAuth()
  @Roles(['Super Admin', 'Admin'])
  @UseGuards(RoleGuard)
  async isGoogleTagManagerConnected(
    @Param('locationId')
    locationId: string,
  ) {
    return this.useCaseFactory.isGoogleTagManagerConnectedUseCase.execute(
      +locationId,
    );
  }
}
