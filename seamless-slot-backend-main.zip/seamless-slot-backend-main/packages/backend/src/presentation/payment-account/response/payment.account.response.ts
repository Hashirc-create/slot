export interface PaymentAccountResponse {
  id: number;
  type: string;
  accessToken: string;
  refreshToken: string;
  squareLocationId: string;
}
