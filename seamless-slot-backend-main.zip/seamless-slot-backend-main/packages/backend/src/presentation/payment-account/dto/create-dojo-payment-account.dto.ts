import { ApiProperty } from '@nestjs/swagger';
import { IsEnum, IsNotEmpty, IsNumber, IsString } from 'class-validator';
import { PaymentAccountType } from '@seamlessslot/core';

enum AccountType {
  DOJO = 'Dojo',
  SQUARE_PAY = 'Square-Pay',
}
export class CreateDojoPaymentAccountDto {
  @ApiProperty({
    description: 'Type of Payment Account',
    example: 'Square Pay',
  })
  @IsNotEmpty({
    message: 'Type of Payment Account Can not Be Empty',
  })
  @IsEnum(AccountType, {
    message: 'Type must be either Dojo or Square-Pay',
  })
  type: PaymentAccountType;

  @ApiProperty({
    description: 'Access Token of Payment Account',
    example: '12qw23we',
  })
  @IsNotEmpty({
    message: 'Access Token of Payment Account Can not Be Empty',
  })
  @IsString({
    message: 'access Token is required and is of type string',
  })
  accessToken: string;

  @ApiProperty({
    description: 'Location Id is required',
    example: 1,
  })
  @IsNotEmpty({
    message: 'Location Id Can not be empty',
  })
  @IsNumber(
    {},
    {
      message: 'location Id should be a number',
    },
  )
  locationId: number;
}
