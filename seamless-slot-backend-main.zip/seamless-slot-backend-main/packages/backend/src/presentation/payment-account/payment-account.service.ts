import { Injectable } from '@nestjs/common';
import { CreateDojoPaymentAccountDto } from './dto/create-dojo-payment-account.dto';
import { UpdatePaymentAccountDto } from './dto/update-payment-account.dto';
import { UseCaseFactory } from '../../usecases/usecase.factory';
import { PresentationMapperFactory } from '../mapper/mapper.factory';
import { SecurityContext } from '../../shared/auth/context/security.context';

@Injectable()
export class PaymentAccountService {
  constructor(
    private readonly useCaseFactory: UseCaseFactory,
    private mapper: PresentationMapperFactory,
    private readonly securityContext: SecurityContext,
  ) {}

  async isSquareConnected(locationId: number) {
    return this.useCaseFactory.isSquareConnectedUseCase.execute(locationId);
  }

  async createDojoPaymentAccount(dto: CreateDojoPaymentAccountDto) {
    const savedDojoAccount =
      await this.useCaseFactory.createDojoPaymentAccountUseCase.execute({
        type: dto.type,
        accessToken: dto.accessToken,
        location: dto.locationId as number,
        squareDefaultLocationId: '',
        refreshToken: '',
        createdBy: this.securityContext.getId(),
        deletedBy: 0,
        isActive: true,
        updatedBy: 0,
      });

    return `Dojo Payment Account Has Been Saved Against Id : ${savedDojoAccount.id}`;
  }

  async findOne(id: number) {
    const paymentAccountFound =
      await this.useCaseFactory.getPaymentAccountByIdUseCase.execute(id);

    return this.mapper.paymentAccountPresentationMapper.domainToResponse(
      paymentAccountFound,
    );
  }

  async checkPaymentAccountsLinked(locationId: number) {
    return await this.useCaseFactory.checkPaymentAccountExsistsUseCase.execute(
      locationId,
    );
  }

  async bindSquareLocation(squareLocation: string, locationId: number) {
    const paymentAccountFound =
      await this.useCaseFactory.bindSquareLocationIdUseCase.execute(
        squareLocation,
        locationId,
      );

    return this.mapper.paymentAccountPresentationMapper.domainToResponse(
      paymentAccountFound,
    );
  }

  // async findByLocationId(locationId: number) {
  // }

  async update(updatePaymentAccountDto: UpdatePaymentAccountDto) {
    const updatedPaymentAccount =
      await this.useCaseFactory.updatePaymentAccountUseCase.execute(
        updatePaymentAccountDto.id,
        this.mapper.paymentAccountPresentationMapper.dtoToDomain(
          updatePaymentAccountDto,
        ),
      );
    return `Payment Account Updated Sucessfully Against Id ${updatedPaymentAccount.id}`;
  }

  async remove(id: number) {
    const deletedPaymentAccount =
      await this.useCaseFactory.deletePaymentAccountUseCase.execute(id);
    return `Payment Account Deleted Sucessfully Against Id ${deletedPaymentAccount.id}`;
  }

  async deleteSquarePayAccount(locationId: number) {
    const deletedPaymentAccount =
      await this.useCaseFactory.deleteSquarePaymentAccountUseCase.execute(
        locationId,
      );
    return `Square Payment Account Deleted Sucessfully Against Id ${deletedPaymentAccount.id}`;
  }
}
