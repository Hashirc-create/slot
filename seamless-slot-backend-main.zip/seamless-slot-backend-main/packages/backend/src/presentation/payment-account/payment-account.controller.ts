import {
  Controller,
  Post,
  Body,
  Patch,
  Param,
  Delete,
  HttpCode,
  HttpStatus,
  UseGuards,
  Get,
} from '@nestjs/common';
import { PaymentAccountService } from './payment-account.service';
import { CreateDojoPaymentAccountDto } from './dto/create-dojo-payment-account.dto';
import { UpdatePaymentAccountDto } from './dto/update-payment-account.dto';
import { ApiBearerAuth, ApiOperation, ApiTags } from '@nestjs/swagger';
import { RoleGuard } from '../../shared/auth/guard/jwt.guard';
import { Roles } from '../../shared/auth/decorator/role.decorator';

@Controller('payment-accounts')
@ApiTags('Payment Accounts')
@ApiBearerAuth()
export class PaymentAccountController {
  constructor(private readonly paymentAccountService: PaymentAccountService) {}

  @Post('/dojo/add')
  @HttpCode(HttpStatus.CREATED)
  @ApiOperation({
    description: 'Create New Dojo Payment Account',
    summary: 'Create New Dojo Payment Account',
  })
  @Roles(['Super Admin', 'Admin'])
  @UseGuards(RoleGuard)
  createDojoPaymentAccount(
    @Body()
    dto: CreateDojoPaymentAccountDto,
  ) {
    return this.paymentAccountService.createDojoPaymentAccount(dto);
  }

  @Get('/findById/:id')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    description: 'Get Payment Account By Id',
    summary: 'Get Payment Account By Id',
  })
  @Roles(['Super Admin', 'Admin'])
  @UseGuards(RoleGuard)
  async getPaymentAccountById(
    @Param('id')
    id: string,
  ) {
    return await this.paymentAccountService.findOne(+id);
  }

  @Get('/isSquareConnected/:locationId')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    description: 'Check if square is connected  by location Id',
    summary: 'Check if square is connected  by location Id',
  })
  @Roles(['Super Admin', 'Admin'])
  @UseGuards(RoleGuard)
  async isSquareConnected(
    @Param('locationId')
    id: string,
  ) {
    return await this.paymentAccountService.isSquareConnected(+id);
  }

  @Get('/checkPaymentConnectivity/:locationId')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    description: 'Check if Square or Dojo is Connected Against locationId',
    summary: 'Check if  Square or Dojo is Connected Against LocationsId',
  })
  @Roles(['Super Admin', 'Admin'])
  @UseGuards(RoleGuard)
  async checkIfSquareIsConnected(
    @Param('locationId')
    locationId: string,
  ) {
    return await this.paymentAccountService.checkPaymentAccountsLinked(
      +locationId,
    );
  }

  @Get('/bind-square-location/:squareLocationId/:locationId')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    description: 'Bind Square Location Id With Payment Account',
    summary: 'Bind Square Location Id With Payment Account',
  })
  @Roles(['Super Admin', 'Admin'])
  @UseGuards(RoleGuard)
  async bindSquareLocationWithPaymentAccount(
    @Param('squareLocationId')
    squareLocation: string,
    @Param('locationId')
    locationId: string,
  ) {
    return await this.paymentAccountService.bindSquareLocation(
      squareLocation,
      +locationId,
    );
  }

  @Patch('/update')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    description: 'Update Payment Account By Id',
    summary: 'Update Payment Account By Id',
  })
  @Roles(['Super Admin', 'Admin'])
  @UseGuards(RoleGuard)
  update(
    @Body()
    updatePaymentAccountDto: UpdatePaymentAccountDto,
  ) {
    return this.paymentAccountService.update(updatePaymentAccountDto);
  }

  @Delete('/delete/:id')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    description: 'Delete Payment Account By Id',
    summary: 'Delete Payment Account By Id',
  })
  @Roles(['Super Admin', 'Admin'])
  @UseGuards(RoleGuard)
  remove(
    @Param('id')
    id: string,
  ) {
    return this.paymentAccountService.remove(+id);
  }

  @Delete('/deleteSquareAccount/:locationId')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    description: 'Delete Square Payment Account By Id',
    summary: 'Delete Square Payment Account By Id',
  })
  @Roles(['Super Admin', 'Admin'])
  @UseGuards(RoleGuard)
  deleteSquarePaymentAccount(
    @Param('locationId')
    locationId: string,
  ) {
    return this.paymentAccountService.deleteSquarePayAccount(+locationId);
  }
}
