import {
  Body,
  Controller,
  Get,
  HttpCode,
  HttpStatus,
  Param,
  Post,
  UseGuards,
} from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiTags } from '@nestjs/swagger';
import { RoleGuard } from '../../shared/auth/guard/jwt.guard';
import { SquareService } from './square.service';
import { Roles } from '../../shared/auth/decorator/role.decorator';
import { SquarePayRefreshTokensCronJob } from '../../shared/jobs/square.pay';

@Controller('/square')
@ApiTags('Square Api')
export class SquareController {
  constructor(
    private readonly squareService: SquareService,
    private readonly squarePayRefreshTokenCronService: SquarePayRefreshTokensCronJob,
  ) {}

  @Get('/findAllSquareLocations/:locationId')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    description: 'Get All Square Locations',
    summary: 'Get All Square Locations',
  })
  @ApiBearerAuth()
  @Roles(['Super Admin', 'Admin'])
  @UseGuards(RoleGuard)
  async getAllSquareLocations(
    @Param('locationId')
    locationId: string,
  ) {
    return this.squareService.getSquareLocatins(+locationId);
  }

  @Post('/webhook')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    description: 'Square Webhook',
    summary: 'Square Webhook',
  })
  @ApiBearerAuth()
  async squareWebhook(
    @Body()
    body: unknown,
  ) {
    await this.squareService.squareWebhookService(body);
    return 'Webhook Received';
  }

  @Get('/refreshAllToken')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    description: 'Refresh All Square Token Manually',
    summary: 'Refresh All Square Token Manually',
  })
  @ApiBearerAuth()
  @Roles(['Super Admin', 'Admin'])
  @UseGuards(RoleGuard)
  async refreshAllSquareTokens() {
    await this.squarePayRefreshTokenCronService.handleCron();

    return 'Tokens Refreshed';
  }
}
