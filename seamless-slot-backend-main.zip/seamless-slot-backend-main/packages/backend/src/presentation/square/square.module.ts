import { Module } from '@nestjs/common';
import { SquareService } from './square.service';
import { SquareController } from './square.controller';

@Module({
  providers: [SquareService],
  controllers: [SquareController],
})
export class SquareModule {}
