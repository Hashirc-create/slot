import { Injectable, Logger } from '@nestjs/common';
import { UseCaseFactory } from '../../usecases/usecase.factory';
import {
  SquarePaymentUpdatedWebhookResponse,
  SquareRefundUpdatedWebhookResponse,
} from '@seamlessslot/core';

@Injectable()
export class SquareService {
  private readonly logger: Logger = new Logger(SquareService.name);

  constructor(private readonly useCaseFactory: UseCaseFactory) {}

  async getSquareLocatins(locationId: number) {
    const locations =
      await this.useCaseFactory.getAllSquareLocations.execute(locationId);

    return locations.map((location) => {
      return {
        name: location.name,
        locationId: location.id,
        merchantId: location.merchantId,
        businessName: location.businessName,
        currency: location.currency,
      };
    });
  }

  async squareWebhookService(body: unknown): Promise<string> {
    const squareWebhook = body as
      | SquarePaymentUpdatedWebhookResponse
      | SquareRefundUpdatedWebhookResponse;

    this.logger.warn('\n' + `SQUARE WEBHOOK RECEIVED : ${squareWebhook.type}`);
    this.logger.warn(
      '\n' +
        `SQUARE WEBHOOK PAYLOAD : ${JSON.stringify(squareWebhook.data, null, 2)}`,
    );

    switch (squareWebhook.type) {
      case 'payment.updated': {
        this.logger.warn('\n' + 'Execute Confirm Payment UseCase');
        const response =
          await this.useCaseFactory.confirmAppointmentOnPaymentUseCase.execute(
            squareWebhook as SquarePaymentUpdatedWebhookResponse,
          );
        this.logger.warn('\n Result (payment.updated): ' + response);
        break;
      }
      case 'refund.updated': {
        this.logger.warn('\n' + 'Execute Refund Payment UseCase');
        const response =
          await this.useCaseFactory.updateRefundStatusUseCase.execute(
            squareWebhook as SquareRefundUpdatedWebhookResponse,
          );
        this.logger.warn('\n Result (refund.updated): ' + response);
      }
      default: {
        this.logger.warn('\n' + 'Unhandled Square Webhook Type');
      }
    }

    return 'done';
  }
}
