import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsNumber, IsString } from 'class-validator';

export class SearchPaymentLogDto {
  @ApiProperty({
    description: 'Search String',
    example: 'john',
  })
  @IsNotEmpty({
    message: 'Search String',
  })
  @IsString({
    message: 'Search String Required',
  })
  searchString: string;

  @ApiProperty({
    description: 'Location Id is required',
    example: 1,
  })
  @IsNotEmpty({
    message: 'LocationId Can not be empty',
  })
  @IsNumber(
    {},
    {
      message: 'locationId should be a number',
    },
  )
  locationId: number;

  @ApiProperty({
    description: 'Page',
    example: 1,
  })
  @IsNotEmpty({
    message: 'Page',
  })
  @IsNumber(
    {},
    {
      message: 'Page',
    },
  )
  page: number;

  @ApiProperty({
    description: 'Limit Per Page',
    example: 1,
  })
  @IsNotEmpty({
    message: 'Limit Per Page',
  })
  @IsNumber(
    {},
    {
      message: 'Limit Per Page',
    },
  )
  limit: number;
}
