export interface PaymentLogResponseWithAppointmentAndPatient {
  id: number;
  createdAt: string;
  transactionId: string;
  status: string;
  paymentMethod: string;
  failedReason: string;
  errorCode: string;
  errorDetail: string;
  errorCategory: string;
  amount: number;
  currency: string;
  cardBrand: string;
  last4Digits: string;
  cardExpMonth: string;
  cardExpYear: string;
  cardType: string;
  entryMethod: string;
  cvvStatus: string;
  avsStatus: string;
  fullPayload: unknown;
  appointmentId: number;
  paymentId?: number;
  patientName: string;
}

export interface PaymentLogResponse {
  id: number;
  createdAt: string;
  transactionId: string;
  status: string;
  paymentMethod: string;
  failedReason: string;
  errorCode: string;
  errorDetail: string;
  errorCategory: string;
  amount: number;
  currency: string;
  cardBrand: string;
  last4Digits: string;
  cardExpMonth: string;
  cardExpYear: string;
  cardType: string;
  entryMethod: string;
  cvvStatus: string;
  avsStatus: string;
  fullPayload: unknown;
}
