import {
  Body,
  Controller,
  Get,
  HttpCode,
  HttpStatus,
  Param,
  Post,
  Query,
  UseGuards,
} from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiTags } from '@nestjs/swagger';
import { RoleGuard } from '../../shared/auth/guard/jwt.guard';
import { Roles } from '../../shared/auth/decorator/role.decorator';
import { UseCaseFactory } from '../../usecases/usecase.factory';
import { PresentationMapperFactory } from '../mapper/mapper.factory';
import { SearchPaymentLogDto } from './dto/search.payment.log.dto';

@Controller('/paymentLog')
@ApiTags('Payment Logs')
export class PaymentLogController {
  constructor(
    private readonly useCaseFactory: UseCaseFactory,
    private readonly mapper: PresentationMapperFactory,
  ) {}

  @Get('/findAllByAppointment/:appointmentId')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    description: 'Get All Payment Logs By Appointment Id',
    summary: 'Get All Payment Logs By Appointment Id',
  })
  @ApiBearerAuth()
  @Roles(['Super Admin', 'Admin'])
  @UseGuards(RoleGuard)
  async getAllPaymentLogsByAppointmentId(
    @Param('appointmentId')
    appointmentId: string,
  ) {
    const records =
      await this.useCaseFactory.findPaymentLogByAppointmentId.execute(
        +appointmentId,
      );

    return records.map((record) => {
      return this.mapper.paymentLogPresentationMapper.domainToResponse(record);
    });
  }

  @Get('/findAllByLocation')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    description: 'Get All Payment Logs By Pagination By Location',
    summary: 'Get All Payment Logs By Pagination By Location',
  })
  @Roles(['Super Admin', 'Admin'])
  @UseGuards(RoleGuard)
  async getAllPaymentLogsByLocationWithPagination(
    @Query('locationId')
    locationId: string,
    @Query('page')
    page: string,
    @Query('perPage')
    perPage: string,
    @Query('startDate')
    startDate: string,
    @Query('endDate')
    endDate: string,
  ) {
    const data =
      await this.useCaseFactory.findAllPaymentLogByLocationIdWithPagination.execute(
        +locationId,
        +page,
        +perPage,
        startDate,
        endDate,
      );

    return {
      prev: data.prev,
      next: data.next,
      last: data.last,
      pages: data.pages,
      totalRecords: data.total,
      data: data.data.map((paymentLog) =>
        this.mapper.paymentLogPresentationMapper.domainToResponseWithAppointmentAndPatient(
          paymentLog,
        ),
      ),
    };
  }

  @Post('/searchWithPagination')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    description: 'Search Payment Logs By Pagination',
    summary: 'Search Payment Logs By Pagination',
  })
  @Roles(['Super Admin', 'Admin'])
  @UseGuards(RoleGuard)
  async searchPaymentLogsByLocationIdWithPagination(
    @Body()
    dto: SearchPaymentLogDto,
  ) {
    const data =
      await this.useCaseFactory.searchPaymentLogByLocationIdWithPagination.execute(
        dto.locationId,
        dto.searchString,
        dto.page,
        dto.limit,
      );

    return {
      prev: data.prev,
      next: data.next,
      last: data.last,
      pages: data.pages,
      totalRecords: data.total,
      data: data.data.map((paymentLog) =>
        this.mapper.paymentLogPresentationMapper.domainToResponseWithAppointmentAndPatient(
          paymentLog,
        ),
      ),
    };
  }
}
