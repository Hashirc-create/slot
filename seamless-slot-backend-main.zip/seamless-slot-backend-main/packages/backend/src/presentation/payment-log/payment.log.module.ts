import { Module } from '@nestjs/common';
import { PaymentLogController } from './payment.log.controller';

@Module({
  controllers: [PaymentLogController],
})
export class PaymentLogModule {}
