import { Global, Module } from '@nestjs/common';
import { LocationModule } from './location/location.module';
import { PresentationMapperFactory } from './mapper/mapper.factory';
import { PRESENTATION_MAPPERS } from './mapper';
import { UserModule } from './user/user.module';
import { ServiceModule } from './service/service.module';
import { CustomerModule } from './customer/customer.module';
import { WorkingDayModule } from './working-day/working-day.module';
import { TimeOffModule } from './time-off/time-off.module';
import { BreakModule } from './break/break.module';
import { PaymentAccountModule } from './payment-account/payment-account.module';
import { SaleforceModule } from './saleforce/saleforce.module';
import { AppointmentModule } from './appointment/appointment.module';
import { SquareOAuthModule } from './square-oauth/square-oauth.module';
import { SquareModule } from './square/square.module';
import { BookingBrandDetailModule } from './booking-brand-detail/booking-brand-detail.module';
import { PaymentTransactionModule } from './payment-transaction/payment.transaction.module';
import { BookingPolicyModule } from './booking-policy/booking-policy.module';
import { RefundModule } from './refunds/refund.module';
import { NotificationsModule } from './notifications/notifications.module';
import { GoogleAnalyticsModule } from './google-analytics/googleAnalytics.module';
import { GoogleTagManagerModule } from './google-tag-manager/google.tag.manager.module';
import { BusinessModule } from './business/business.module';
import { PaymentLogModule } from './payment-log/payment.log.module';
import { PaymentLinkShortenerModule } from './payment-link-shortener/payment.link.shortener.module';
import { DashboardModule } from './appointment/dashboard/dashboard.module';
import { WorkingDayHistoryModule } from './working-day-history/working.day.history.module';

@Global()
@Module({
  controllers: [],
  providers: [...PRESENTATION_MAPPERS, PresentationMapperFactory],
  exports: [...PRESENTATION_MAPPERS, PresentationMapperFactory],
  imports: [
    LocationModule,
    ServiceModule,
    UserModule,
    CustomerModule,
    WorkingDayModule,
    TimeOffModule,
    BreakModule,
    PaymentAccountModule,
    SaleforceModule,
    AppointmentModule,
    SquareOAuthModule,
    SquareModule,
    BookingBrandDetailModule,
    PaymentTransactionModule,
    BookingPolicyModule,
    RefundModule,
    NotificationsModule,
    GoogleAnalyticsModule,
    GoogleTagManagerModule,
    BusinessModule,
    PaymentLogModule,
    PaymentLinkShortenerModule,
    DashboardModule,
    WorkingDayHistoryModule,
  ],
})
export class PresentationModule {}
