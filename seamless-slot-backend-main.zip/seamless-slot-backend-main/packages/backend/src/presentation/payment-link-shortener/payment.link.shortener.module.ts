import { Module } from '@nestjs/common';
import { PaymentLinkShortenerController } from './payment.link.shortener.controller';

@Module({
  controllers: [PaymentLinkShortenerController],
})
export class PaymentLinkShortenerModule {}
