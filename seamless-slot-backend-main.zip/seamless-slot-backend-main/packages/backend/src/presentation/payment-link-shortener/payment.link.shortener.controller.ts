import {
  Controller,
  Param,
  HttpCode,
  HttpStatus,
  Get,
  Res,
} from '@nestjs/common';
import { ApiOperation, ApiTags } from '@nestjs/swagger';
import { UseCaseFactory } from '../../usecases/usecase.factory';
import { Response } from 'express';

@Controller('pay')
@ApiTags('Payment Link Shortener')
export class PaymentLinkShortenerController {
  constructor(private readonly useCaseFactory: UseCaseFactory) {}

  @Get('/:bookingId')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    description: 'Redirect to main Payment Link',
    summary: 'Redirect to main Payment Link',
  })
  async getMainPaymentLink(
    @Param('bookingId')
    bookingId: string,
    @Res() res: Response,
  ) {
    res.redirect(
      await this.useCaseFactory.paymentLinkShortenerUseCase.execute(+bookingId),
    );
  }
}
