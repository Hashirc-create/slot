import { Injectable } from '@nestjs/common';
import { UseCaseFactory } from '../../usecases/usecase.factory';
import { PresentationMapperFactory } from '../mapper/mapper.factory';
import { encrypt } from '../../shared/utils/encrypt.util';
import { CreateCustomerDto } from './dto/create-customer.dto';
import { UpdateCustomerDto } from './dto/update-customer.dto';

@Injectable()
export class CustomerService {
  constructor(
    private readonly useCaseFactory: UseCaseFactory,
    private readonly presentationMapperFactory: PresentationMapperFactory,
  ) {}

  async searchCustomerWithPaginationService(
    locationId: number,
    searchString: string,
    page: number,
    limit: number,
  ) {
    const response =
      await this.useCaseFactory.searchCustomerWithPaginationUseCase.execute(
        locationId,
        searchString,
        page,
        limit,
      );

    return {
      prev: response.prev,
      next: response.next,
      last: response.last,
      pages: response.pages,
      totalRecords: response.total,
      data: response.data.map((customer) =>
        this.presentationMapperFactory.customerPresentationMapper.domainToResponse(
          customer,
        ),
      ),
    };
  }

  async registerCustomer(dto: CreateCustomerDto) {
    dto.password = await encrypt(dto.password);

    const savedUser = await this.useCaseFactory.registerCustomerUseCase.execute(
      this.presentationMapperFactory.customerPresentationMapper.dtoToDomain(
        dto,
      ),
    );

    return {
      message: `Customer Has Been Registered Against Id : ${savedUser.id}`,
      id: savedUser.id,
    };
  }

  async findAll(locationId: number) {
    const allCustomers =
      await this.useCaseFactory.getAllCustomerByLocationUseCase.execute(
        locationId,
      );

    return allCustomers.map((customer) =>
      this.presentationMapperFactory.customerPresentationMapper.domainToResponse(
        customer,
      ),
    );
  }

  async findAllByLocationWithPagination(
    locationId: number,
    page: number,
    perPage: number,
  ) {
    const response =
      await this.useCaseFactory.getAllCustomerByLocationWithPaginationUseCase.execute(
        locationId,
        page,
        perPage,
      );

    return {
      prev: response.prev,
      next: response.next,
      last: response.last,
      pages: response.pages,
      totalRecords: response.total,
      data: response.data.map((customer) =>
        this.presentationMapperFactory.customerPresentationMapper.domainToResponse(
          customer,
        ),
      ),
    };
  }

  async findOne(id: number, locationId: number) {
    const customerFound =
      await this.useCaseFactory.getCustomerByIdUseCase.execute(id, locationId);

    return await this.presentationMapperFactory.customerPresentationMapper.domainToResponseWithExtras(
      customerFound,
      this.useCaseFactory.getUserByIdUseCase,
    );
  }

  async update(updateUserDto: UpdateCustomerDto) {
    const updatedUser = await this.useCaseFactory.updateCustomerUseCase.execute(
      updateUserDto.id,
      this.presentationMapperFactory.customerPresentationMapper.dtoToDomain(
        updateUserDto,
      ),
    );

    return `Customer has be updated successfully Against Id : ${updatedUser.id}`;
  }

  async deleteCustomerService(id: number) {
    const deletedCustomer =
      await this.useCaseFactory.deleteCustomerUseCase.execute(id);

    return `Customer has be Deleted successfully Against Id : ${deletedCustomer.id}`;
  }
}
