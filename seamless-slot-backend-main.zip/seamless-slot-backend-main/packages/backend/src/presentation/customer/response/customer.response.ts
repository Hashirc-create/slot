export interface AppointmentsForCustomer {
  id: number;
  day: string;
  hour: string;
  serviceName: string;
  serviceCost: string;
  serviceDurationInMins: number;
  location: string;
}

export interface CustomerResponse {
  id: number;
  firstName: string;
  lastName: string;
  fullName: string;
  email: string;
  phoneNo: string;
  companyName: string;
  address: string;
  notes: string;
  appointments: AppointmentsForCustomer[];
}

export interface CustomerResponseWithExtras {
  id: number;
  firstName: string;
  lastName: string;
  fullName: string;
  email: string;
  phoneNo: string;
  companyName: string;
  address: string;
  notes: string;
  createdAt: string;
  updatedAt: string;
  createdBy: string;
  updatedBy: string;
  appointments: AppointmentsForCustomer[];
}
