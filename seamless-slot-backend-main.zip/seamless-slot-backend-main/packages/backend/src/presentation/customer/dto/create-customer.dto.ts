import { ApiProperty } from '@nestjs/swagger';
import {
  IsEmail,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
} from 'class-validator';

export class CreateCustomerDto {
  @ApiProperty({
    description: 'Email of Customer ',
    example: 'Customer@seamless.co.uk',
  })
  @IsNotEmpty({
    message: 'Email of Customer Can not Be Empty',
  })
  @IsEmail(
    {},
    {
      message: 'email is required and must be a valid email',
    },
  )
  email: string;

  @ApiProperty({
    description: 'First Name of Customer ',
    example: 'John',
  })
  @IsNotEmpty({
    message: 'First Name of Customer Can not Be Empty',
  })
  @IsString({
    message: 'first name is required and must be a string',
  })
  firstName: string;

  @ApiProperty({
    description: 'Last Name of Customer ',
    example: 'Doe',
  })
  @IsOptional({
    message: 'last name is optional and must be a string',
  })
  lastName: string;

  @ApiProperty({
    description: 'Password of Customer ',
    example: 'Customer1234',
  })
  @IsNotEmpty({
    message: 'Password of Customer Can not Be Empty',
  })
  @IsString({
    message: 'password is required',
  })
  password: string;

  @ApiProperty({
    description: 'Company Name of Customer ',
    example: 'Customer1234',
  })
  companyName: string;

  @ApiProperty({
    description: 'Address is Required',
    example: 'Customer1234',
  })
  address: string;

  @ApiProperty({
    description: 'PhoneNo of Customer',
    example: 'Customer1234',
  })
  @IsNotEmpty({
    message: 'PhoneNo of Customer Can not Be Empty',
  })
  @IsString({
    message: 'PhoneNo is required',
  })
  phoneNo: string;

  @ApiProperty({
    description: 'PhoneNo of Customer',
    example: 'Customer1234',
  })
  @IsOptional()
  @IsString({
    message: 'Notes must be of type string',
  })
  notes: string;

  @ApiProperty({
    description: 'LocationId',
    example: 0,
  })
  @IsNumber(
    {},
    {
      message: 'Location id is required',
    },
  )
  locationId: number;

  @ApiProperty({
    description: 'BusinessId',
    example: 0,
  })
  @IsNumber(
    {},
    {
      message: 'BusinessId is required',
    },
  )
  businessId: number;
}
