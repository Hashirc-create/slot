import { ApiProperty } from '@nestjs/swagger';
import { IsNumber, IsString } from 'class-validator';

export class SearchCustomerWithPaginationDto {
  @ApiProperty({
    description: 'String to be Searched',
    example: 'John',
  })
  @IsString({
    message: 'String to be Searched is Required',
  })
  searchString: string;

  @ApiProperty({
    description: 'LocationId',
    example: 0,
  })
  @IsNumber(
    {},
    {
      message: 'Location id is required',
    },
  )
  locationId: number;

  @ApiProperty({
    description: 'Page No',
    example: 1,
  })
  @IsNumber(
    {},
    {
      message: 'Page No',
    },
  )
  page: number;

  @ApiProperty({
    description: 'limit per page',
    example: 10,
  })
  @IsNumber(
    {},
    {
      message: 'limit per page',
    },
  )
  limit: number;
}
