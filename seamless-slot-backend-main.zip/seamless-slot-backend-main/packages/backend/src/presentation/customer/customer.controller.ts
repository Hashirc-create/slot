import {
  Controller,
  Get,
  Post,
  Body,
  Patch,
  Param,
  Delete,
  HttpCode,
  HttpStatus,
  UseGuards,
  Query,
} from '@nestjs/common';
import { CustomerService } from './customer.service';
import { CreateCustomerDto } from './dto/create-customer.dto';
import { UpdateCustomerDto } from './dto/update-customer.dto';
import { ApiOperation, ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { RoleGuard } from '../../shared/auth/guard/jwt.guard';
import { SearchCustomerWithPaginationDto } from './dto/search.customer.with.pagination.dto';
import { Roles } from '../../shared/auth/decorator/role.decorator';

@Controller('customer')
@ApiTags('Customers')
export class CustomerController {
  constructor(private readonly customerService: CustomerService) {}

  @Post('/add')
  @HttpCode(HttpStatus.CREATED)
  @ApiOperation({
    description: 'Register a new Customer',
    summary: 'Register a new Customer',
  })
  @Roles(['Super Admin', 'Admin'])
  @UseGuards(RoleGuard)
  create(
    @Body()
    createCustomerDto: CreateCustomerDto,
  ) {
    return this.customerService.registerCustomer(createCustomerDto);
  }

  @Post('/searchWithPagination')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    description: 'Search Customer With Pagination',
    summary: 'Search Customer With Pagination',
  })
  @Roles(['Super Admin', 'Admin'])
  @UseGuards(RoleGuard)
  searchCustomerWithPaginationUseCase(
    @Body()
    dto: SearchCustomerWithPaginationDto,
  ) {
    return this.customerService.searchCustomerWithPaginationService(
      dto.locationId,
      dto.searchString,
      dto.page,
      dto.limit,
    );
  }

  @Get('/findAllWithPagination')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    description: 'Get All Customers By Location With Pagination',
    summary: 'Get All Customers By Location With Pagination',
  })
  @ApiBearerAuth()
  @Roles(['Super Admin', 'Admin'])
  @UseGuards(RoleGuard)
  findAllByLocationWithPagination(
    @Query('locationId')
    locationId: string,
    @Query('page')
    page: string,
    @Query('perPage')
    perPage: string,
  ) {
    return this.customerService.findAllByLocationWithPagination(
      +locationId,
      +page,
      +perPage,
    );
  }

  @Get('/findAll/:locationId')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    description: 'Get All Customers By Location',
    summary: 'Get All Customers By Location',
  })
  @ApiBearerAuth()
  @Roles(['Super Admin', 'Admin'])
  @UseGuards(RoleGuard)
  findAll(
    @Param('locationId')
    locationId: string,
  ) {
    return this.customerService.findAll(+locationId);
  }

  @Get('/findById/:id/:locationId')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    description: 'Get Customer By Id',
    summary: 'Get Customer By Id',
  })
  @ApiBearerAuth()
  @Roles(['Super Admin', 'Admin'])
  @UseGuards(RoleGuard)
  findOne(
    @Param('id')
    id: string,
    @Param('locationId')
    locationId: string,
  ) {
    return this.customerService.findOne(+id, +locationId);
  }

  @Patch('/update')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    description: 'Update Customer By Id',
    summary: 'Update Customer By Id',
  })
  @ApiBearerAuth()
  @Roles(['Super Admin', 'Admin'])
  @UseGuards(RoleGuard)
  update(
    @Body()
    updateCustomerDto: UpdateCustomerDto,
  ) {
    return this.customerService.update(updateCustomerDto);
  }

  @Delete('/delete/:id')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    description: 'Delete Customer By Id',
    summary: 'Delete Customer By Id',
  })
  @ApiBearerAuth()
  @Roles(['Super Admin', 'Admin'])
  @UseGuards(RoleGuard)
  remove(
    @Param('id')
    id: string,
  ) {
    return this.customerService.deleteCustomerService(+id);
  }
}
