import { Status } from '@seamlessslot/core';
import { LocationResponse } from '../../location/response/location.response';

export interface BusinessWithLocationResponse {
  id: number;
  name: string;
  subdomain: string;
  phoneNo: string;
  email: string;
  status: Status;
  locations: {
    id: number;
    name: string;
  }[];
}

export interface BusinessResponseWithCompleteLocations {
  id: number;
  name: string;
  contact: string;
  address: string;
  phoneNo: string;
  email: string;
  subdomain: string;
  status: Status;
  createdAt: string;
  updatedAt: string;
  createdBy: string;
  updatedBy: string;
  locations: LocationResponse[];
}
