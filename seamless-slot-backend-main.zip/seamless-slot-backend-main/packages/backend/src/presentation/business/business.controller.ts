import {
  Body,
  Controller,
  Delete,
  Get,
  HttpCode,
  HttpStatus,
  Param,
  Patch,
  Post,
  UseGuards,
} from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiTags } from '@nestjs/swagger';
import { RoleGuard } from '../../shared/auth/guard/jwt.guard';
import { Roles } from '../../shared/auth/decorator/role.decorator';
import { UseCaseFactory } from '../../usecases/usecase.factory';
import { PresentationMapperFactory } from '../mapper/mapper.factory';
import { CreateBusinessDto } from './dto/create.business.dto';
import { Location } from '@seamlessslot/core';
import { UpdateBusinessDto } from './dto/updateBusinessDto';

@Controller('business')
@ApiTags('Business')
@ApiBearerAuth()
export class BusinessController {
  constructor(
    private readonly useCaseFactory: UseCaseFactory,
    private readonly presentationMapperFactory: PresentationMapperFactory,
  ) {}

  @Post('/registerNew')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    description: 'Register New Business',
    summary: 'Register New Business',
  })
  @Roles(['Super Admin'])
  @UseGuards(RoleGuard)
  async registerNewBusiness(
    @Body()
    dto: CreateBusinessDto,
  ) {
    const response = await this.useCaseFactory.addBusinessUseCase.execute(
      this.presentationMapperFactory.businessPresentationMapper.dtoToDomain(
        dto,
      ),
    );
    return `Business has been successfully registered against id ${response.id}`;
  }

  @Get('/findAllWithLocations')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    description: 'Get All Business With Locations',
    summary: 'Get All Business With Locations',
  })
  @Roles(['Super Admin', 'Admin'])
  @UseGuards(RoleGuard)
  async getAllBusinessWithLocations() {
    const response =
      await this.useCaseFactory.getAllBusinessWithLocationUseCase.execute();

    return response.map((business) =>
      this.presentationMapperFactory.businessPresentationMapper.domainToResponseWithLocation(
        business,
      ),
    );
  }

  @Get('/findBySubdomain/:subdomain')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    description: 'Get Business With Locations By Subdomain',
    summary: 'Get Business With Locations By Subdomain',
  })
  async getBusinessWithLocations(
    @Param('subdomain')
    subdomain: string,
  ) {
    const response =
      await this.useCaseFactory.getBusinessWithLocationBySubdomainUseCase.execute(
        subdomain,
      );

    return {
      businessId: response.id,
      businessName: response.name,
      locations: (response.locations as Location[])
        .map((location: Location) => {
          return {
            id: location.id,
            name: location.name,
            address: location.address,
            squareLocationId: location.paymentAccount
              ? location.paymentAccount.squareDefaultLocationId
              : '',
          };
        })
        .sort((a, b) => a.id - b.id),
    };
  }

  @Get('/findById/:id')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    description: 'Get Business With Id',
    summary: 'Get Business With Id',
  })
  @Roles(['Super Admin', 'Admin'])
  @UseGuards(RoleGuard)
  async getBusinessWithId(
    @Param('id')
    id: string,
  ) {
    const response =
      await this.useCaseFactory.getBusinessByIdUseCase.execute(+id);

    return await this.presentationMapperFactory.businessPresentationMapper.domainToResponseIncludingLocation(
      response,
      this.useCaseFactory.getUserByIdUseCase,
    );
  }

  @Delete('/delete/:id')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    description: 'Delete Business With Id',
    summary: 'Delete Business With Id',
  })
  @Roles(['Super Admin'])
  @UseGuards(RoleGuard)
  async deleteBusinessById(
    @Param('id')
    id: string,
  ) {
    const response =
      await this.useCaseFactory.deleteBusinessUseCase.execute(+id);

    return `Business with Id: ${response.id} has been deleted successfully.`;
  }

  @Patch('/update')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    description: 'Update Business With Id',
    summary: 'Update Business With Id',
  })
  @Roles(['Super Admin', 'Admin'])
  @UseGuards(RoleGuard)
  async updateBusinessById(
    @Body()
    dto: UpdateBusinessDto,
  ) {
    const updateBusiness =
      await this.useCaseFactory.updateBusinessUseCase.execute(
        this.presentationMapperFactory.businessPresentationMapper.dtoToDomainForUpdate(
          dto,
        ),
      );

    return `Business with Id: ${updateBusiness.id} has been updated successfully.`;
  }
}
