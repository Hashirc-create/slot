import { ApiProperty } from '@nestjs/swagger';
import { IsEmail, IsIn, IsNotEmpty, IsNumber, IsString } from 'class-validator';
import { Status } from '@seamlessslot/core';

export class UpdateBusinessDto {
  @ApiProperty({
    description: 'BusinessId',
    example: 0,
  })
  @IsNumber(
    {},
    {
      message: 'BusinessId is required',
    },
  )
  businessId: number;

  @ApiProperty({
    description: 'Name of Business',
    example: 'Night and Day',
  })
  @IsNotEmpty({
    message: 'Name of business required and must be not empty string',
  })
  @IsString({
    message: 'Name of business required and must be not empty string',
  })
  name: string;

  @ApiProperty({
    description: 'Contact of Business',
    example: '+9243..',
  })
  @IsNotEmpty({
    message: 'Contact of business required and must be not empty string',
  })
  @IsString({
    message: 'Contact of business required and must be not empty string',
  })
  contact: string;

  @ApiProperty({
    description: 'Address of Business',
    example: '+9243..',
  })
  @IsNotEmpty({
    message: 'Address of business required and must be not empty string',
  })
  @IsString({
    message: 'Address of business required and must be not empty string',
  })
  address: string;

  @ApiProperty({
    description: 'Subdomain of Business',
    example: '+9243..',
  })
  @IsNotEmpty({
    message: 'subdomain of Business required and must be not empty string',
  })
  @IsString({
    message: 'subdomain of Business required and must be not empty string',
  })
  subdomain: string;

  @ApiProperty({
    description: 'Phone of Business',
    example: '+9243..',
  })
  @IsNotEmpty({
    message: 'Phone of business required and must be not empty string',
  })
  @IsString({
    message: 'Phone of business required and must be not empty string',
  })
  phoneNo: string;

  @ApiProperty({
    description: 'Status of Business',
    example: '+9243..',
  })
  @IsNotEmpty({
    message: 'Status of business required and must be not empty string',
  })
  @IsString({
    message: 'Status of business required and must be not empty string',
  })
  @IsIn(['Active', 'Inactive', 'Freeze'] as Status[], {
    message:
      'Status must be one of the following values: Active, Inactive, Freeze',
  })
  status: string;

  @ApiProperty({
    description: 'Business Email ',
    example: 'superadmin@seamlessslot.com',
  })
  @IsNotEmpty({
    message: 'Business email must not be empty',
  })
  @IsEmail(
    {},
    {
      message: 'email is required and must be a valid email',
    },
  )
  email: string;
}
