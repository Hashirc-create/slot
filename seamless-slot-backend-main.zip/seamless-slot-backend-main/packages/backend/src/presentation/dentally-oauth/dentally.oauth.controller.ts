// import {
//   Controller,
//   Get,
//   HttpCode,
//   HttpStatus,
//   Query,
//   Req,
//   Res,
// } from '@nestjs/common';
// import { ApiOperation, ApiTags } from '@nestjs/swagger';
// import { Response, Request } from 'express';
// import { UseCaseFactory } from '../../usecases/usecase.factory';
// import { CustomJwtService } from '../../shared/auth/service/jwt.service';
// import { DentallyEnvService } from '../../shared/dentally/dentally.env.service';
// import axios from 'axios';
// import { DentallyResponse } from '@seamlessslot/core';
// import { DentallyRequest } from '@seamlessslot/core';
//
// @Controller('dentally-oauth')
// @ApiTags('Square OAuth Sandbox')
// export class DentallyOauthController {
//   constructor(
//     private readonly dentallyEnvService: DentallyEnvService,
//     private readonly useCaseFactory: UseCaseFactory,
//     private readonly jwtService: CustomJwtService,
//   ) {}
//
//   @Get('/login')
//   @HttpCode(HttpStatus.OK)
//   @ApiOperation({
//     description: 'Start OAuth Flow',
//     summary: 'Start OAuth Flow',
//   })
//   loginOauth(
//     @Res() response: Response,
//     // @Query('jid') accessToken: string,
//     @Query('locationId') locationId: string,
//   ) {
//     // verfiy access
//     // this.jwtService.verifyAccessToken(accessToken);
//
//     const locationIdParsed = Number(locationId);
//     const baseUrl = this.dentallyEnvService.getBaseUrl();
//     const clientId = this.dentallyEnvService.getClientId();
//
//     console.log('Location Id Passsed', locationIdParsed);
//
//     const scopes = ['appointment', 'patient'];
//
//     const state = locationIdParsed;
//     const redirect_uri = 'https://stating.seamlessslot.co.uk/callback';
//
//     const url = `${baseUrl}/oauth/authorize?client_id=${clientId}&scope=${scopes.join(
//       '%20',
//     )}&response_type=code&state=${state}&session=false&redirect_uri=${redirect_uri}`;
//
//     const oneDayInMs = 24 * 60 * 60 * 1000;
//
//     response
//       .cookie('Auth_State_Dentally', state, { maxAge: oneDayInMs })
//       .redirect(url);
//   }
//
//   @Get('/callback')
//   @HttpCode(HttpStatus.OK)
//   @ApiOperation({
//     description: 'Callback OAuth Flow',
//     summary: 'Callback OAuth',
//   })
//   async callBackDentallyOAuth(
//     @Req() request: Request,
//     @Res() response: Response,
//     @Query('code') code: string,
//     @Query('state') state: string,
//     @Query('error') error: string,
//     @Query('error_description') errorDescription: string,
//     @Query('response_type') responseType: string,
//   ) {
//     if (request.cookies['Auth_State_Dentally'] !== state)
//       response.redirect(
//         `${this.dentallyEnvService.getFrontendRedirectURL()}/callback?error=true&message=${encodeURIComponent('Invalid State')}`,
//       );
//
//     if (error) {
//       if (error === 'access_denied' && errorDescription === 'user_denied')
//         response.redirect(
//           `${this.dentallyEnvService.getFrontendRedirectURL()}/callback?error=true&message=${'Authorization Denied, You chose to deny access to the app.'}`,
//         );
//       else
//         response.redirect(
//           `${this.dentallyEnvService.getFrontendRedirectURL()}/callback?error=true&message=${encodeURIComponent(error + ' - ' + errorDescription)}`,
//         );
//     }
//
//     if (responseType === 'code') {
//       try {
//         const apiResponse =
//           await axios.post<DentallyResponse.AccessTokenResponse>(
//             this.dentallyEnvService.getBaseUrl() + '/oauth/token',
//             {
//               client_id: this.dentallyEnvService.getClientId(),
//               client_secret: this.dentallyEnvService.getClientSecret(),
//               redirect_uri: 'https://staging.seamlessslot.co.uk/callback',
//               code,
//               grant_type: 'authorization_code',
//             } as DentallyRequest.AccessTokenPayload,
//           );
//
//         console.log(
//           '================ This is the token ' +
//             JSON.stringify(apiResponse.data),
//         );
//
//         response.redirect(
//           `${this.dentallyEnvService.getFrontendRedirectURL()}/callback?error=false&message=${encodeURIComponent('Dentally has been successfully connected with SeamlessSlot')}`,
//         );
//       } catch (error) {
//         console.log(JSON.stringify(error));
//         response.redirect(
//           `${this.dentallyEnvService.getFrontendRedirectURL()}/callback?error=true&message=${encodeURIComponent('some thing went wrong : ' + JSON.stringify(error))}`,
//         );
//       }
//     }
//   }
// }
