import { UseCaseFactory } from '../../../usecases/usecase.factory';

import {
  Controller,
  Get,
  Param,
  HttpCode,
  HttpStatus,
  UseGuards,
} from '@nestjs/common';
import { ApiOperation, ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { RoleGuard } from '../../../shared/auth/guard/jwt.guard';
import { Roles } from '../../../shared/auth/decorator/role.decorator';

@Controller('dashboard')
@ApiTags('Dashboard')
export class DashboardController {
  constructor(private readonly useCaseFactory: UseCaseFactory) {}

  @Get('/forLocation/:locationId')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    description: 'Get All Customers By Location',
    summary: 'Get All Customers By Location',
  })
  @ApiBearerAuth()
  @Roles(['Super Admin', 'Admin'])
  @UseGuards(RoleGuard)
  getDashboardForLocation(
    @Param('locationId')
    locationId: string,
  ) {
    return this.useCaseFactory.getDashboardForLocation.execute(+locationId);
  }
}
