import {
  Body,
  Controller,
  Delete,
  Get,
  HttpCode,
  HttpException,
  HttpStatus,
  Param,
  Patch,
  Post,
  Query,
  UseGuards,
} from '@nestjs/common';
import { AppointmentService } from './appointment.service';
import { CreateAppointmentDto } from './dto/create-appointment.dto';
import { ApiBearerAuth, ApiOperation, ApiTags } from '@nestjs/swagger';
import { RoleGuard } from '../../shared/auth/guard/jwt.guard';
import { GetSlotsDto } from './dto/get.slots.dto';
import { AppointmentStatus } from '@seamlessslot/core';
import { ChangeAppointmentDateTimeDto } from './dto/change.appointment.date.time.dto';
import { CreatePublicAppointmentWithoutPaymentDto } from './dto/create-public-appointment-without-payment.dto';
import { TakePaymentAppointmentDto } from './dto/take.payment.appointment.dto';
import { SearchAppointmentsDto } from './dto/search.appointments.dto';
import { BaseResponse } from '../../shared/interceptor/response.interceptor';
import { Roles } from '../../shared/auth/decorator/role.decorator';
import { BulkUpdateAppointmentDto } from './dto/bulk.update.dto';
import { UseCaseFactory } from '../../usecases/usecase.factory';

@Controller('appointment')
@ApiTags('Appointments')
@ApiBearerAuth()
export class AppointmentController {
  constructor(
    private readonly appointmentService: AppointmentService,
    private readonly useCaseFactory: UseCaseFactory,
  ) {}

  @Post('/public/create/no-payment')
  @HttpCode(HttpStatus.CREATED)
  @ApiOperation({
    description: 'Create New Appointment WithOut Payment Public EndPoint',
    summary: 'Create New Appointment WithOut Payment Public EndPoint',
  })
  createPublicAppointmentWithOutPayment(
    @Body()
    createAppointmentDto: CreatePublicAppointmentWithoutPaymentDto,
  ) {
    return this.appointmentService.createPublicAppointmentWithOutPayment(
      createAppointmentDto,
    );
  }

  @Post('/public/take-payment')
  @HttpCode(HttpStatus.CREATED)
  @ApiOperation({
    description: 'Take Payment For The Appointment',
    summary: 'Take Payment For The Appointment',
  })
  takePaymentForPublicAppointment(
    @Body()
    dto: TakePaymentAppointmentDto,
  ) {
    return this.appointmentService.takePaymentForPublicAppointment(dto);
  }

  @Get('/findAllByYearMonth/:year/:month/:locationId')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    description: 'Get All Appointments By Year Month And Location',
    summary: 'Get All Appointments By Year Month And Location',
  })
  @Roles(['Super Admin', 'Admin'])
  @UseGuards(RoleGuard)
  async getAllAppointmentByMonthYearAndLocation(
    @Param('locationId')
    locationId: string,
    @Param('year')
    year: string,
    @Param('month')
    month: string,
  ) {
    const appointments = await Promise.all(
      await this.appointmentService.getAllAppointmentsByMonthYearAndLocation(
        +year,
        +month,
        +locationId,
      ),
    );

    const breaks = await this.useCaseFactory.getAllBreaksByLocation.execute(
      +locationId,
      +year,
    );

    const timeOffs =
      await this.useCaseFactory.getAllTimeOffsByLocationForCalendarUseCase.execute(
        +locationId,
      );

    return {
      appointments,
      breaks,
      timeOffs,
    };
  }

  @Get('/checkIfSlotBooked')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    description: 'check if slot is already booked',
    summary: 'check if slot is already booked',
  })
  async checkIfAppointmentSlotBooked(
    @Query('startTime')
    startTime: string,
    @Query('endTime')
    endTime: string,
  ) {
    await this.useCaseFactory.checkIfSlotBookedUseCase.execute(
      new Date(startTime + 'Z'),
      new Date(endTime + 'Z'),
    );
  }

  @Get('/checkDetails/:appointmentId')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    description: 'Check Appointment Details for the Appointment',
    summary: 'Check Appointment Details for the Appointment',
  })
  @Roles(['Super Admin', 'Admin'])
  @UseGuards(RoleGuard)
  async checkAppointmentDetails(
    @Param('appointmentId')
    appointmentId: string,
  ) {
    return await this.appointmentService.checkAppointmentDetails(
      +appointmentId,
    );
  }

  @Get('/getAllByLocationWithPagination')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    description: 'Get All Appointments By Pagination By Location',
    summary: 'Get All Appointments By Pagination By Location',
  })
  @Roles(['Super Admin', 'Admin'])
  @UseGuards(RoleGuard)
  async getAllAppointmentByLocationWithPagination(
    @Query('locationId')
    locationId: string,
    @Query('page')
    page: string,
    @Query('perPage')
    perPage: string,
    @Query('startDate')
    startDate: string, // iso formated date string expected
    @Query('endDate')
    endDate: string, // iso formated date string expected
  ) {
    const response =
      await this.appointmentService.getAllAppointmentsByLocationWithPaginationService(
        +locationId,
        +page,
        +perPage,
        startDate,
        endDate,
      );

    return {
      ...response,
      data: await Promise.all(response.data),
    };
  }

  @Post('/change-status/:appointmentId/:status')
  @HttpCode(HttpStatus.CREATED)
  @ApiOperation({
    description: 'Change Appointment Status',
    summary: 'Change Appointment Status',
  })
  @Roles(['Super Admin', 'Admin'])
  @UseGuards(RoleGuard)
  changeAppointmentStatus(
    @Param('appointmentId')
    appointmentId: string,
    @Param('status')
    status: AppointmentStatus,
  ) {
    const array: AppointmentStatus[] = [
      'Pending',
      'Complete',
      'No Show',
      'Paid',
      'Cancelled',
      'Confirmed',
    ];

    if (!array.includes(status))
      throw new HttpException(
        {
          data: 'Invalid Status Received',
          message: 'Invalid Status Received',
          code: 0,
        } as BaseResponse<string>,
        HttpStatus.BAD_REQUEST,
      );

    return this.appointmentService.changeAppointmentStatus(
      +appointmentId,
      status,
    );
  }

  @Get('/public/appointmentSummary/:bookingId')
  @HttpCode(HttpStatus.CREATED)
  @ApiOperation({
    description: 'Get Appointment Summary By Booking Id',
    summary: 'Get Appointment Summary By Booking Id',
  })
  getAppointmentSummaryByBookingId(
    @Param('bookingId')
    bookingId: string,
  ) {
    return this.appointmentService.getAppointmentSummray(+bookingId);
  }

  @Post('/add')
  @HttpCode(HttpStatus.CREATED)
  @ApiOperation({
    description: 'Create New Appointment',
    summary: 'Create New Appointment',
  })
  @Roles(['Super Admin', 'Admin'])
  @UseGuards(RoleGuard)
  create(
    @Body()
    createAppointmentDto: CreateAppointmentDto,
  ) {
    return this.appointmentService.create(createAppointmentDto);
  }

  @Get('/findById/:id')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    description: 'Get Appointment By Id',
    summary: 'Get Appointment By Id',
  })
  @Roles(['Super Admin', 'Admin'])
  @UseGuards(RoleGuard)
  async getAppointmentById(
    @Param('id')
    id: string,
  ) {
    return await this.appointmentService.findOne(+id);
  }

  @Get('/findAllByLocation/:locationId')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    description: 'Get All Appointments By Location',
    summary: 'Get All Appointments By Location',
  })
  @Roles(['Super Admin', 'Admin'])
  @UseGuards(RoleGuard)
  findAllByLocation(
    @Param('locationId')
    locationId: string,
  ) {
    return this.appointmentService.findAllByLocation(+locationId);
  }

  @Patch('/update')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    description: 'Update Appointment By Id',
    summary: 'Update Appointment By Id',
  })
  @Roles(['Super Admin', 'Admin'])
  @UseGuards(RoleGuard)
  update(
    @Body()
    dto: ChangeAppointmentDateTimeDto,
  ) {
    return this.appointmentService.changeAppointmentDateTime(dto);
  }

  @Patch('/bulkUpdateStatus')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    description: 'Bulk Update Appointment Status By Id',
    summary: 'Bulk Update Appointment Status By Id',
  })
  @Roles(['Super Admin', 'Admin'])
  @UseGuards(RoleGuard)
  bulkUpdate(
    @Body()
    dto: BulkUpdateAppointmentDto,
  ) {
    return this.appointmentService.bulkUpdateAppointmentStatus(dto.payload);
  }

  @Delete('/delete/:id')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    description: 'Delete Appointment By Id',
    summary: 'Delete Appointment By Id',
  })
  @Roles(['Super Admin', 'Admin'])
  @UseGuards(RoleGuard)
  remove(
    @Param('id')
    id: string,
  ) {
    return this.appointmentService.remove(+id);
  }

  @Get('/getAvaliableDates/:locationId')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    description: 'Get All the Avaliable Dates For Booking Appointment',
    summary: 'Get All the Avaliable Dates For Booking Appointment',
  })
  async getAllAvaliableDates(
    @Param('locationId')
    locationId: string,
  ) {
    return await this.appointmentService.getAvaliableDates(+locationId);
  }

  @Post('/getAvaliableSlotsByDate')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    description: 'Get All the Avaliable Slots By Date For Booking Appointment',
    summary: 'Get All the Avaliable Slots By Date For Booking Appointment',
  })
  async getAvaliableTimeSlots(
    @Body()
    dto: GetSlotsDto,
  ) {
    return await this.appointmentService.getAvaliableTimeSlots(
      dto.date,
      dto.serviceId,
      dto.locationId,
    );
  }

  @Delete('/delete/:appointmentId')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    description: 'Delete Appointment By using appointment Id',
    summary: 'Delete Appointment By using appointment Id',
  })
  @Roles(['Super Admin', 'Admin'])
  @UseGuards(RoleGuard)
  async deleteAppointmentById(
    @Param('appointmentId')
    appointmentId: string,
  ) {
    return await this.appointmentService.remove(+appointmentId);
  }

  @Post('/searchWithPagination')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    description: 'Search Appointment By Pagination',
    summary: 'Search Appointment By Pagination',
  })
  @Roles(['Super Admin', 'Admin'])
  @UseGuards(RoleGuard)
  async searchAppointmentsWithPagination(
    @Body()
    dto: SearchAppointmentsDto,
  ) {
    const response =
      await this.appointmentService.searchAppointmentsWithPagination(
        dto.locationId,
        dto.searchString,
        dto.page,
        dto.limit,
      );

    return {
      ...response,
      data: await Promise.all(response.data),
    };
  }
}
