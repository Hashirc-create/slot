import { Injectable } from '@nestjs/common';
import { CreateAppointmentDto } from './dto/create-appointment.dto';
import { UseCaseFactory } from '../../usecases/usecase.factory';
import { PresentationMapperFactory } from '../mapper/mapper.factory';
import {
  Appointment,
  AppointmentStatus,
  Customer,
  SupportedPaymentMethods,
} from '@seamlessslot/core';
import { ChangeAppointmentDateTimeDto } from './dto/change.appointment.date.time.dto';
import { CreatePublicAppointmentWithoutPaymentDto } from './dto/create-public-appointment-without-payment.dto';
import { TakePaymentAppointmentDto } from './dto/take.payment.appointment.dto';
import { TimeZoneService } from '../../shared/utils/timezone.util';

@Injectable()
export class AppointmentService {
  constructor(
    private readonly useCaseFactory: UseCaseFactory,
    private mapper: PresentationMapperFactory,
    private readonly timeZoneService: TimeZoneService,
  ) {}

  async checkAppointmentDetails(appointmentId: number) {
    return await this.useCaseFactory.checkAppointmentDetailUseCase.execute(
      appointmentId,
    );
  }

  async searchAppointmentsWithPagination(
    locationId: number,
    searchString: string,
    page: number,
    limit: number,
  ) {
    const data =
      await this.useCaseFactory.searchAppointmentsWithPaginationUseCase.execute(
        locationId,
        searchString,
        page,
        limit,
      );

    return {
      prev: data.prev,
      next: data.next,
      last: data.last,
      pages: data.pages,
      totalRecords: data.total,
      data: data.data.map(async (appointment) => {
        return await this.mapper.appointmentPresentationMapper.domainToResponseWithLocationAndCustomer(
          appointment,
          this.useCaseFactory.getUserByIdUseCase,
        );
      }),
    };
  }

  async getAllAppointmentsByMonthYearAndLocation(
    year: number,
    month: number,
    locationId: number,
  ) {
    const appointments =
      await this.useCaseFactory.getAppointmentByMonthUseCase.execute(
        year,
        month,
        locationId,
      );

    return appointments.map(async (appointment) => {
      return await this.mapper.appointmentPresentationMapper.domainToResponseWithLocationAndCustomer(
        appointment,
        this.useCaseFactory.getUserByIdUseCase,
      );
    });
  }

  async create(createAppointmentDto: CreateAppointmentDto) {
    const appointment: Appointment =
      this.mapper.appointmentPresentationMapper.dtoToDomain(
        createAppointmentDto,
      );

    const savedAppointment =
      await this.useCaseFactory.createAppointmentUseCase.execute(appointment);

    return `Appointment has been created successfully against booking id ${savedAppointment.id}.`;
  }

  async getAllAppointmentsByLocationWithPaginationService(
    locationId: number,
    page: number,
    perPage: number,
    startDate: string,
    endDate: string,
  ) {
    const data =
      await this.useCaseFactory.getAllAppointmentsByLocationWithPaginationUseCase.execute(
        locationId,
        page,
        perPage,
        startDate,
        endDate,
      );

    return {
      prev: data.prev,
      next: data.next,
      last: data.last,
      pages: data.pages,
      totalRecords: data.total,
      data: data.data.map(
        async (appointment) =>
          await this.mapper.appointmentPresentationMapper.domainToResponseWithLocationAndCustomer(
            appointment,
            this.useCaseFactory.getUserByIdUseCase,
          ),
      ),
    };
  }

  async getAppointmentSummray(appointmentId: number) {
    const appointmentSummary =
      await this.useCaseFactory.getAppointmentSummaryByBookingIdUseCase.execute(
        appointmentId,
      );

    return this.mapper.appointmentPresentationMapper.domainToResponseWithLocationCustomerServiceAndTransaction(
      appointmentSummary,
    );
  }

  async changeAppointmentStatus(id: number, status: AppointmentStatus) {
    const updatedAppointment =
      await this.useCaseFactory.changeAppointmentStatusUseCase.execute(
        id,
        status,
      );

    return `Appointment Status Changed Successfully Against Id : ${updatedAppointment.id}`;
  }

  async createPublicAppointmentWithOutPayment(
    createAppointmentDto: CreatePublicAppointmentWithoutPaymentDto,
  ) {
    const appointment: Appointment =
      this.mapper.appointmentPresentationMapper.dtoToDomainForPublic(
        createAppointmentDto,
      );

    const customer: Customer =
      this.mapper.customerPresentationMapper.dtoToDomainFromPublicAppointment(
        createAppointmentDto,
      );

    const savedAppointment =
      await this.useCaseFactory.createPublicAppointmentWithoutPaymentUseCase.execute(
        appointment,
        customer,
      );

    return {
      message:
        'Appointment Booked Successfully Against Booking Id : ' +
        savedAppointment.id,
      bookingId: savedAppointment.id,
      customerId: savedAppointment.customer as number,
    };
  }

  async takePaymentForPublicAppointment(dto: TakePaymentAppointmentDto) {
    const appointmentPaid =
      await this.useCaseFactory.takePaymentPublicAppointmentUseCase.execute(
        dto.appointmentId,
        dto.locationId,
        dto.customerId,
        dto.serviceId,
        dto.squareSourceId,
        dto.squareBuyerId,
        dto.method as SupportedPaymentMethods,
      );

    return {
      message:
        'Payment Taken SuccessFully For Appointment With Id' +
        appointmentPaid.id,
      appointmentId: appointmentPaid.id,
    };
  }

  async getAvaliableDates(locationId: number) {
    const dates =
      await this.useCaseFactory.getAvaliableDatesUseCase.execute(locationId);
    return dates;
  }

  async getAvaliableTimeSlots(
    date: string,
    serviceId: number,
    locationId: number,
  ) {
    const slots =
      await this.useCaseFactory.getAvaliableTimeSlotsUseCase.execute(
        serviceId,
        date,
        locationId,
      );

    return slots;
  }

  async findOne(id: number) {
    const appointmentFound =
      await this.useCaseFactory.getAppointmentByIdUseCase.execute(id);

    return this.mapper.appointmentPresentationMapper.domainToResponseWithLocationAndCustomerWithExtras(
      appointmentFound,
      this.useCaseFactory.getUserByIdUseCase,
    );
  }

  async bulkUpdateAppointmentStatus(
    payload: {
      id: number;
      status: AppointmentStatus;
    }[],
  ) {
    return this.useCaseFactory.bulkUpdateStatusUseCase.execute(payload);
  }

  async changeAppointmentDateTime(
    updateAppointmentDto: ChangeAppointmentDateTimeDto,
  ) {
    const updatedAppointment =
      await this.useCaseFactory.changeAppointmentDateTimeUseCase.execute(
        updateAppointmentDto.id,
        this.timeZoneService.convertSimpleDateStringToUTC(
          updateAppointmentDto.startTime,
        ),
        this.timeZoneService.convertSimpleDateStringToUTC(
          updateAppointmentDto.startTime,
        ),
      );

    return `Appointment Date Time Changed Sucessfully Against Id ${updatedAppointment.id}`;
  }

  async remove(id: number) {
    const deletedAppointment =
      await this.useCaseFactory.deleteAppointmentUseCase.execute(id);
    return `Appointment Deleted Successfully Against Id ${deletedAppointment.id}`;
  }

  async findAllByLocation(locationId: number) {
    const appointments =
      await this.useCaseFactory.getAllAppointmentsByLocationUseCase.execute(
        locationId,
      );

    return appointments.map(async (appointment: Appointment) =>
      this.mapper.appointmentPresentationMapper.domainToResponseWithLocationAndCustomer(
        appointment,
        this.useCaseFactory.getUserByIdUseCase,
      ),
    );
  }
}
