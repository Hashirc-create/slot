import { ApiProperty, PartialType } from '@nestjs/swagger';
import { CreateAppointmentDto } from './create-appointment.dto';
import { IsDateString, IsNotEmpty, IsNumber } from 'class-validator';

export class UpdateAppointmentDto extends PartialType(CreateAppointmentDto) {
  @ApiProperty({
    description: 'Id of the record which need to be updated',
    example: 0,
  })
  @IsNumber(
    {},
    {
      message: 'id is required and must not be empty',
    },
  )
  id: number;

  @ApiProperty({
    description: 'Start Time',
    example: '2024-06-11T09:00:00',
  })
  @IsNotEmpty({
    message: 'Start Time Can not be empty',
  })
  @IsDateString(
    {
      strict: true,
      strictSeparator: true,
    },
    {
      message: 'Date must be a valid Date String',
    },
  )
  startTime: string;

  @ApiProperty({
    description: 'End Time',
    example: '2024-06-11T09:00:00',
  })
  @IsNotEmpty({
    message: 'End Time Can not be empty',
  })
  @IsDateString(
    {
      strict: true,
      strictSeparator: true,
    },
    {
      message: 'Date must be a valid Date String',
    },
  )
  endTime: string;
}
