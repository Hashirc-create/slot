import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsNumber, IsString } from 'class-validator';

export class TakePaymentAppointmentDto {
  @ApiProperty({
    description: 'Appointment Id',
    example: 0,
  })
  @IsNumber(
    {},
    {
      message: 'Appointment Id',
    },
  )
  appointmentId: number;

  @ApiProperty({
    description: 'Customer Id',
    example: 0,
  })
  @IsNumber(
    {},
    {
      message: 'Customer Id',
    },
  )
  customerId: number;

  @ApiProperty({
    description: 'Service Id',
    example: 0,
  })
  @IsNumber(
    {},
    {
      message: 'Service Id',
    },
  )
  serviceId: number;

  @ApiProperty({
    description: 'Location Id',
    example: 0,
  })
  @IsNumber(
    {},
    {
      message: 'Location Id',
    },
  )
  locationId: number;

  @ApiProperty({
    description: 'Square Source Id',
    example: 'cron:asdfadsfaesfsdfadfes',
  })
  @IsNotEmpty({
    message: 'Square Source Id Can not Be Empty',
  })
  @IsString({
    message: 'Square Source Id is required and is of type string',
  })
  squareSourceId: string;

  @ApiProperty({
    description: 'Square Buyer Id for buyer verification 3D Secure',
    example: '****',
  })
  @IsNotEmpty({
    message: 'Square Buyer Id Can not Be Empty',
  })
  @IsString({
    message: 'Square Buyer Id is required and is of type string',
  })
  squareBuyerId: string;

  @ApiProperty({
    description: 'Payment Method',
    example: 'Card',
  })
  @IsNotEmpty({
    message: 'Payment Method Can not be empty',
  })
  @IsString({
    message: 'Payment Method is required and is of type string',
  })
  method: string;
}
