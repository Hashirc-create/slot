import { ApiProperty } from '@nestjs/swagger';
import { IsDateString, IsNotEmpty, IsNumber } from 'class-validator';

export class GetSlotsDto {
  @ApiProperty({
    description: 'Date',
    example: '2024-06-11',
  })
  @IsNotEmpty({
    message: 'Date Can not be empty',
  })
  @IsDateString(
    {
      strict: true,
      strictSeparator: true,
    },
    {
      message: 'Date must be a valid Date String',
    },
  )
  date: string;

  @ApiProperty({
    description: 'Location Id is required',
    example: 1,
  })
  @IsNotEmpty({
    message: 'LocationId Can not be empty',
  })
  @IsNumber(
    {},
    {
      message: 'locationId should be a number',
    },
  )
  locationId: number;

  @ApiProperty({
    description: 'Service Id is required',
    example: 1,
  })
  @IsNotEmpty({
    message: 'ServiceId Can not be empty',
  })
  @IsNumber(
    {},
    {
      message: 'serviceId should be a number',
    },
  )
  serviceId: number;
}
