import { ApiProperty } from '@nestjs/swagger';
import {
  IsDateString,
  IsEmail,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
} from 'class-validator';

export class CreatePublicAppointmentWithoutPaymentDto {
  @ApiProperty({
    description: 'Date',
    example: '2024-06-11',
  })
  @IsNotEmpty({
    message: 'Date Can not be empty',
  })
  @IsDateString(
    {
      strict: true,
      strictSeparator: true,
    },
    {
      message: 'Date must be a valid Date String',
    },
  )
  date: string;

  @ApiProperty({
    description: 'Address',
    example: '2nd Floor 1st Street Old Town',
  })
  @IsOptional()
  @IsString({
    message: 'Address must be a valid String',
  })
  address: string;

  @ApiProperty({
    description: 'Start Time',
    example: '2024-06-11T09:00:00',
  })
  @IsNotEmpty({
    message: 'Start Time Can not be empty',
  })
  @IsDateString(
    {
      strict: true,
      strictSeparator: true,
    },
    {
      message: 'Date must be a valid Date String',
    },
  )
  startTime: string;

  @ApiProperty({
    description: 'Start Time',
    example: '2024-06-11T09:00:00',
  })
  @IsNotEmpty({
    message: 'End Time Can not be empty',
  })
  @IsDateString(
    {
      strict: true,
      strictSeparator: true,
    },
    {
      message: 'Date must be a valid Date String',
    },
  )
  endTime: string;

  @ApiProperty({
    description: 'Email of Customer ',
    example: 'Customer@seamless.co.uk',
  })
  @IsNotEmpty({
    message: 'Email of Customer Can not Be Empty',
  })
  @IsEmail(
    {},
    {
      message: 'email is required and must be a valid email',
    },
  )
  customerEmail: string;

  @ApiProperty({
    description: 'First Name of Customer ',
    example: 'John',
  })
  @IsNotEmpty({
    message: 'First Name of Customer Can not Be Empty',
  })
  @IsString({
    message: 'first name is required and must be a string',
  })
  firstNameCustomer: string;

  @ApiProperty({
    description: 'Last Name of Customer ',
    example: 'Doe',
  })
  @IsOptional({
    message: 'last name is optional and must be a string',
  })
  lastNameCustomer: string;

  @ApiProperty({
    description: 'Password of Customer ',
    example: 'Customer1234',
  })
  @IsNotEmpty({
    message: 'Password of Customer Can not Be Empty',
  })
  @IsString({
    message: 'password is required',
  })
  passwordCustomer: string;

  @ApiProperty({
    description: 'Address is Required',
    example: 'Customer1234',
  })
  @IsOptional({
    message: 'Address of Customer Is optional',
  })
  customerAddress: string;

  @ApiProperty({
    description: 'PhoneNo of Customer',
    example: 'Customer1234',
  })
  @IsNotEmpty({
    message: 'PhoneNo of Customer Can not Be Empty',
  })
  @IsString({
    message: 'PhoneNo is required',
  })
  phoneNoCustomer: string;

  @ApiProperty({
    description: 'PhoneNo of Customer',
    example: 'Customer1234',
  })
  @IsOptional()
  @IsString({
    message: 'Notes must be of type string',
  })
  notes: string;

  @ApiProperty({
    description: 'Location Id is required',
    example: 1,
  })
  @IsNotEmpty({
    message: 'LocationId Can not be empty',
  })
  @IsNumber(
    {},
    {
      message: 'locationId should be a number',
    },
  )
  locationId: number;

  @ApiProperty({
    description: 'Service Id is required',
    example: 1,
  })
  @IsNotEmpty({
    message: 'ServiceId Can not be empty',
  })
  @IsNumber(
    {},
    {
      message: 'serviceId should be a number',
    },
  )
  serviceId: number;
}
