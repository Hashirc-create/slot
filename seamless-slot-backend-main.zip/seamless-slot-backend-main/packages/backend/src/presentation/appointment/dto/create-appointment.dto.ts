import { ApiProperty } from '@nestjs/swagger';
import {
  IsDateString,
  IsIn,
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
} from 'class-validator';
import { AppointmentStatus } from '@seamlessslot/core';

export class CreateAppointmentDto {
  @ApiProperty({
    description: 'Date',
    example: '2024-06-11',
  })
  @IsNotEmpty({
    message: 'Date Can not be empty',
  })
  @IsDateString(
    {
      strict: true,
      strictSeparator: true,
    },
    {
      message: 'Date must be a valid Date String',
    },
  )
  date: string;

  @ApiProperty({
    description: 'Address',
    example: '2nd Floor 1st Street Old Town',
  })
  @IsOptional()
  @IsString({
    message: 'Address must be a valid String',
  })
  address: string;

  @ApiProperty({
    description: 'Start Time',
    example: '2024-06-11T09:00:00',
  })
  @IsNotEmpty({
    message: 'Start Time Can not be empty',
  })
  @IsDateString(
    {
      strict: true,
      strictSeparator: true,
    },
    {
      message: 'Date must be a valid Date String',
    },
  )
  startTime: string;

  @ApiProperty({
    description: 'Start Time',
    example: '2024-06-11T09:00:00',
  })
  @IsNotEmpty({
    message: 'End Time Can not be empty',
  })
  @IsDateString(
    {
      strict: true,
      strictSeparator: true,
    },
    {
      message: 'Date must be a valid Date String',
    },
  )
  endTime: string;

  @ApiProperty({
    description: 'CustomerId of Appointment',
    example: 1,
  })
  @IsNotEmpty({
    message: 'CustomerId of Appointment Can not Be Empty',
  })
  @IsNumber(
    {},
    {
      message: 'customerId should be a number',
    },
  )
  customerId: number;

  @ApiProperty({
    description: 'Location Id is required',
    example: 1,
  })
  @IsNotEmpty({
    message: 'LocationId Can not be empty',
  })
  @IsNumber(
    {},
    {
      message: 'locationId should be a number',
    },
  )
  locationId: number;

  @ApiProperty({
    description: 'Business Id is required',
    example: 1,
  })
  @IsNotEmpty({
    message: 'Business Id Can not be empty',
  })
  @IsNumber(
    {},
    {
      message: 'Business Id should be a number',
    },
  )
  businessId: number;

  @ApiProperty({
    description: 'Service Id is required',
    example: 1,
  })
  @IsNotEmpty({
    message: 'ServiceId Can not be empty',
  })
  @IsNumber(
    {},
    {
      message: 'serviceId should be a number',
    },
  )
  serviceId: number;

  @ApiProperty({
    description: 'Status of Appointment',
    example: '',
  })
  @IsNotEmpty({
    message: 'Status of Appointment required and must be not empty string',
  })
  @IsString({
    message: 'Status of Appointment must be a string',
  })
  @IsIn(['Pending', 'Follow Up'] as AppointmentStatus[], {
    message: 'Status must be one of the following values: Pending Follow Up',
  })
  status: string;
}
