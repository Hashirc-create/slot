import { ApiProperty } from '@nestjs/swagger';
import { AppointmentStatus } from '@seamlessslot/core';
import { IsValidAppointmentsArray } from '../../../shared/validator/bulk.update.appointment.validator';

export class BulkUpdateAppointmentDto {
  @ApiProperty({
    description: 'Id of the record which need to be updated',
    example: 0,
  })
  @IsValidAppointmentsArray()
  payload: {
    id: number;
    status: AppointmentStatus;
  }[];
}
