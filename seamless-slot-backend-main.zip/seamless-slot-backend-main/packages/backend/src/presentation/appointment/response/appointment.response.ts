import {
  AppointmentStatus,
  Currency,
  PaymentStatus,
  SlotPaymentStatus,
  SupportedPaymentMethods,
} from '@seamlessslot/core';

export interface AppointmentResponse {
  id: number;
  date: string;
  status: AppointmentStatus;
  startTime: string;
  endTime: string;
  address: string;
  isActive: boolean;
  locationId: number;
  customerId: number;
}

// id: 2,
// title: 'Meeting',
// start: '2024-06-21T09:32:28.207Z',
// end: '2024-06-22T09:32:28.207Z',
// className: 'completed text-black',
// status: 'Completed'

// date: string;
//   status: PaymentStatus;
//   amount: number;
//   currency: Currency;
//   cardDetails: string;
//   note: string;
//   type: PaymentMethod;
//   squareTransactionId: string;
//   method: SupportedPaymentMethods;
//   appointment: number | Appointment | Appointment[];

export interface AppointmentExtendedPropsWithExtras {
  appointmentId: number;
  startTime: string;
  endTime: string;
  isActive: boolean;
  location: string;
  locationLat: number;
  locationLon: number;
  customerId: number;
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  customerAddress: string;
  appointmentDateDropdown: string;
  appointmentTimeDropdown: string;

  serviceId: number;
  serviceDurationInMins: number;
  serviceBufferTimeInMinutes: number;
  serviceCost: string;
  servicVenue: string;
  serviceName: string;
  day: string;
  hour: string;
  paymentStatus: SlotPaymentStatus;

  paymentId?: number;
  payerName?: string;
  providerPaymentStatus?: PaymentStatus;
  companyBalance?: number;
  transactionId?: string;
  paymentDate?: string;
  paymentMethod?: SupportedPaymentMethods;
  paymentLink?: string;
  amountPaid?: string;
  curreny?: Currency;
  status: AppointmentStatus;

  createdAt: string;
  updatedAt: string;
  createdBy: string;
  updatedBy: string;
}

export interface AppointmentExtendedProps {
  appointmentId: number;
  startTime: string;
  endTime: string;
  isActive: boolean;
  location: string;
  locationLat: number;
  locationLon: number;
  customerId: number;
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  customerAddress: string;
  appointmentDateDropdown: string;
  appointmentTimeDropdown: string;

  serviceId: number;
  serviceDurationInMins: number;
  serviceBufferTimeInMinutes: number;
  serviceCost: string;
  servicVenue: string;
  serviceName: string;
  day: string;
  hour: string;
  paymentStatus: SlotPaymentStatus;

  paymentId?: number;
  payerName?: string;
  providerPaymentStatus?: PaymentStatus;
  companyBalance?: number;
  transactionId?: string;
  paymentDate?: string;
  paymentMethod?: SupportedPaymentMethods;
  paymentLink?: string;
  amountPaid?: string;
  curreny?: Currency;
  status: AppointmentStatus;

  createdAt: string;
}

export interface AppointmentResponseWithLocationAndCustomer {
  id: number;
  title: string;
  start: string;
  end: string;
  className: string;
  extendedProps: AppointmentExtendedPropsWithExtras;
}

export interface AppointmentResponseWithLocationAndCustomerWithExtras {
  id: number;
  title: string;
  start: string;
  end: string;
  className: string;
  extendedProps: AppointmentExtendedPropsWithExtras;
}

export interface AppointmentResponseForPagination {
  prev: number;
  next: number;
  last: number;
  pages: number;
  totalRecords: number;
  data: AppointmentResponseWithLocationAndCustomer[];
}

export interface AppointmentResponseWithLocationCustomerServiceAndPayment {
  id: number;
  date: string;
  status: AppointmentStatus;
  startTime: string;
  endTime: string;
  isActive: boolean;
  locationName: string;
  locationLat: number;
  locationLon: number;
  customerId: number;
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  serviceId: number;
  serviceDurationInMinutes: number;
  serviceBufferTimeInMinutes: number;
  serviceCost: string;
  servicVenue: string;
  serviceTitle: string;
  amountPaid: number;
  currency: string;
  cardDetails: string;
  type: string;
}
