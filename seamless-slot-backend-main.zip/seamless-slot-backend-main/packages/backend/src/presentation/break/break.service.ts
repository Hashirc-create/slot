import { Injectable } from '@nestjs/common';
import { CreateBreakDto } from './dto/create-break.dto';
import { UpdateBreakDto } from './dto/update-break.dto';
import { UseCaseFactory } from '../../usecases/usecase.factory';
import { PresentationMapperFactory } from '../mapper/mapper.factory';
import { Break } from '@seamlessslot/core';
import { format } from 'date-fns';

@Injectable()
export class BreakService {
  constructor(
    private readonly useCaseFactory: UseCaseFactory,
    private mapper: PresentationMapperFactory,
  ) {}

  async create(createBreakDto: CreateBreakDto) {
    const workDayBreak: Break =
      this.mapper.breakPresentationMapper.dtoToDomain(createBreakDto);

    const savedBreak =
      await this.useCaseFactory.createBreakUseCase.execute(workDayBreak);

    return `Break Has Been Saved Against Id : ${savedBreak.id}`;
  }

  async findAllBreaksHistory(locationId: number) {
    const allBreaks =
      await this.useCaseFactory.getAllBreaksByLocationUseCaseForHistory.execute(
        locationId,
      );

    return Promise.all(
      allBreaks.map(async (breakItem) => {
        return await this.mapper.breakPresentationMapper.domainToResponse(
          breakItem,
          this.useCaseFactory.getUserByIdUseCase,
        );
      }),
    );
  }

  async findAllByLocationId(locationId: number) {
    const allWorkingDays =
      await this.useCaseFactory.getAllWorkingDaysByLocationIncludeBreaksUseCase.execute(
        locationId,
      );

    return (
      await Promise.all(
        allWorkingDays.map(async (workingDay) => {
          return {
            workingDayId: workingDay.id,
            day: workingDay.day,
            breaks: await Promise.all(
              workingDay.breaks
                .filter((breakItems) => breakItems.isActive)
                .map(async (breakItem) => {
                  return await this.mapper.breakPresentationMapper.domainToResponse(
                    breakItem,
                    this.useCaseFactory.getUserByIdUseCase,
                  );
                }),
            ),
          };
        }),
      )
    ).sort((a, b) => a.workingDayId - b.workingDayId);
  }

  async update(updateBreakDtos: UpdateBreakDto[]) {
    const allBreaks: Break[] = updateBreakDtos.map((workDayBreak) =>
      this.mapper.breakPresentationMapper.dtoToDomainForUpdate(workDayBreak),
    );

    await this.useCaseFactory.updateBreakUseCase.execute(allBreaks);
    return `All Breaks Update Sucessfully`;
  }

  async remove(id: number) {
    const deletedBreak =
      await this.useCaseFactory.deleteBreakUseCase.execute(id);
    return `Break Delete Sucessfully Against Id ${deletedBreak.id}`;
  }
}
