import {
  Controller,
  Get,
  Post,
  Body,
  Patch,
  HttpCode,
  HttpStatus,
  UseGuards,
  Param,
  Delete,
} from '@nestjs/common';
import { BreakService } from './break.service';
import { CreateBreakDto } from './dto/create-break.dto';
import { UpdateBreakDto } from './dto/update-break.dto';
import { ApiBearerAuth, ApiOperation, ApiTags } from '@nestjs/swagger';
import { RoleGuard } from '../../shared/auth/guard/jwt.guard';
import { Roles } from '../../shared/auth/decorator/role.decorator';

@Controller('break')
@ApiTags('Breaks')
@ApiBearerAuth()
export class BreakController {
  constructor(private readonly breakService: BreakService) {}

  @Post('/add')
  @HttpCode(HttpStatus.CREATED)
  @ApiOperation({
    description: 'Create New Break',
    summary: 'Create New Break',
  })
  @Roles(['Super Admin', 'Admin'])
  @UseGuards(RoleGuard)
  create(
    @Body()
    createBreakDto: CreateBreakDto,
  ) {
    return this.breakService.create(createBreakDto);
  }

  @Get('/findAll/:locationId')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    description: 'Get All Breaks By LocationId ( From Context)',
    summary: 'Get All Breaks By LocationId ( From Context)',
  })
  @Roles(['Super Admin', 'Admin'])
  @UseGuards(RoleGuard)
  findAll(
    @Param('locationId')
    locationId: string,
  ) {
    return this.breakService.findAllByLocationId(+locationId);
  }

  @Get('/findAllHistory/:locationId')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    description: 'Get All Breaks History By LocationId ( From Context)',
    summary: 'Get All Breaks History By LocationId ( From Context)',
  })
  @Roles(['Super Admin', 'Admin'])
  @UseGuards(RoleGuard)
  findAllHistory(
    @Param('locationId')
    locationId: string,
  ) {
    return this.breakService.findAllBreaksHistory(+locationId);
  }

  @Patch('/update')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    description: 'Update Break By Id',
    summary: 'Update Break By Id',
  })
  @Roles(['Super Admin', 'Admin'])
  @UseGuards(RoleGuard)
  update(
    @Body()
    updateBreakDto: UpdateBreakDto[],
  ) {
    return this.breakService.update(updateBreakDto);
  }

  @Delete('/delete/:id')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    description: 'Delete Break By Id',
    summary: 'Delete Break By Id',
  })
  @Roles(['Super Admin', 'Admin'])
  @UseGuards(RoleGuard)
  deleteBreak(
    @Param('id')
    id: string,
  ) {
    return this.breakService.remove(+id);
  }
}
