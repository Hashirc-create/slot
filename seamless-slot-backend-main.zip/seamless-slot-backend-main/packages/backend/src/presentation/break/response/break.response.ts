export interface BreakResponse {
  id: number;
  title: string;
  startTime: string;
  endTime: string;
  day?: string;

  createdBy: string;
  createdAt: string;
  updatedBy: string;
  updatedAt: string;
}
