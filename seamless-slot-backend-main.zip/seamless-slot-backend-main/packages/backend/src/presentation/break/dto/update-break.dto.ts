import { ApiProperty, PartialType } from '@nestjs/swagger';
import { IsNumber } from 'class-validator';
import { CreateBreakDto } from './create-break.dto';

export class UpdateBreakDto extends PartialType(CreateBreakDto) {
  @ApiProperty({
    description: 'Id of the record which need to be updated',
    example: 0,
  })
  @IsNumber(
    {},
    {
      message: 'id is required and must not be empty',
    },
  )
  id: number;

  workingDayId?: number;
}
