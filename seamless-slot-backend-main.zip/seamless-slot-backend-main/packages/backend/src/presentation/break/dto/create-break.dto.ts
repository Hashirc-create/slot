import { ApiProperty } from '@nestjs/swagger';
import { IsDateString, IsNotEmpty, IsNumber, IsString } from 'class-validator';

export class CreateBreakDto {
  @ApiProperty({
    description: 'Title of Break',
    example: 'Lunch Break',
  })
  @IsNotEmpty({
    message: 'Title of Break Can not Be Empty',
  })
  @IsString({
    message: 'title is required and is of type string',
  })
  title: string;

  @ApiProperty({
    description: 'Start Time',
    example: '2024-06-01T09:00:00',
  })
  @IsNotEmpty({
    message: 'Start Time Can not be empty',
  })
  @IsDateString(
    {
      strict: true,
      strictSeparator: true,
    },
    {
      message:
        'Date Time must be a valid Date Time String (yyyy-MM-ddTHH:mm:ss)',
    },
  )
  startTime: string;

  @ApiProperty({
    description: 'End Time',
    example: '2024-06-01T09:00:00',
  })
  @IsNotEmpty({
    message: 'End Time Can not be empty',
  })
  @IsDateString(
    {
      strict: true,
      strictSeparator: true,
    },
    {
      message:
        'Date Time must be a valid Date Time String (yyyy-MM-ddTHH:mm:ss)',
    },
  )
  endTime: string;

  @ApiProperty({
    description: 'Working Day Id is required',
    example: 1,
  })
  @IsNotEmpty({
    message: 'Working Day Id Can not be empty',
  })
  @IsNumber(
    {},
    {
      message: 'Working Day Id should be a number',
    },
  )
  workingDayId: number;
}
