import { Module } from '@nestjs/common';
import { SquareOAuthController } from './square.oauth.controller';

@Module({
  controllers: [SquareOAuthController],
})
export class SquareOAuthModule {}
