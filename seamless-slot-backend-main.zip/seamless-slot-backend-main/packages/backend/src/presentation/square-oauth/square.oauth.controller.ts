import {
  Controller,
  Get,
  HttpCode,
  HttpStatus,
  Inject,
  Query,
  Req,
  Res,
} from '@nestjs/common';
import { ApiOperation, ApiTags } from '@nestjs/swagger';
import { Response, Request } from 'express';
import { SquareEnvService } from '../../shared/square/square.env.service';
import { UseCaseFactory } from '../../usecases/usecase.factory';
import { CustomJwtService } from '../../shared/auth/service/jwt.service';
import { ISquareApi, SquareApi } from '../../shared/square/square.api.service';

@Controller('square-oauth')
@ApiTags('Square OAuth Sandbox')
export class SquareOAuthController {
  constructor(
    private readonly squareEnvService: SquareEnvService,
    private readonly useCaseFactory: UseCaseFactory,
    private readonly jwtService: CustomJwtService,
    @Inject(ISquareApi)
    private readonly squareApi: SquareApi,
  ) {}
  @Get('/login/sandbox')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    description: 'Start OAuth Flow Sandbox',
    summary: 'Start OAuth Flow Sandbox',
  })
  startOAuthFlowSandbox(
    @Res()
    response: Response,
    @Query('jid')
    accessToken: string,
    @Query('locationId')
    locationId: string,
  ) {
    // verfiy access
    this.jwtService.verifyAccessToken(accessToken);

    const locationIdParsed = Number(locationId);
    const basePath = this.squareEnvService.getBasePath();
    const clientIdSandbox = this.squareEnvService.getClientId();

    console.log('Location Id Passsed', locationIdParsed);

    const scopes = [
      'ITEMS_READ',
      'MERCHANT_PROFILE_READ',
      'PAYMENTS_WRITE_ADDITIONAL_RECIPIENTS',
      'PAYMENTS_WRITE',
      'PAYMENTS_READ',
      'ORDERS_WRITE',
      'ORDERS_READ',
      'PAYMENTS_WRITE',
    ];

    const state = locationIdParsed;

    const url = `${basePath}/oauth2/authorize?client_id=${clientIdSandbox}&scope=${scopes.join(
      '%20',
    )}&response_type=code&state=${state}&session=false`;

    const oneDayInMs = 24 * 60 * 60 * 1000;

    response
      .cookie('Auth_State', state, {
        maxAge: oneDayInMs,
      })
      .redirect(url);
  }

  @Get('/callback/sandbox')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    description: 'Callback OAuth Flow Sandbox',
    summary: 'Callback OAuth Flow Sandbox',
  })
  async callbackSqaureOauthFlow(
    @Req()
    request: Request,
    @Res()
    response: Response,
    @Query('code')
    code: string,
    @Query('state')
    state: string,
    @Query('error')
    error: string,
    @Query('error_description')
    errorDescription: string,
    @Query('response_type')
    responseType: string,
  ) {
    if (request.cookies['Auth_State'] !== state)
      response.redirect(
        `${this.squareEnvService.getFrontendRedirectURL()}/callback?error=true&message=${encodeURIComponent('Invalid State')}`,
      );

    if (error) {
      if (error === 'access_denied' && errorDescription === 'user_denied')
        response.redirect(
          `${this.squareEnvService.getFrontendRedirectURL()}/callback?error=true&message=${'Authorization Denied, You chose to deny access to the app.'}`,
        );
      else
        response.redirect(
          `${this.squareEnvService.getFrontendRedirectURL()}/callback?error=true&message=${encodeURIComponent(error + ' - ' + errorDescription)}`,
        );
    }

    if (responseType === 'code') {
      const authorization_code = code;

      // Configure Square OAuth API instance
      const oauthInstance = this.squareEnvService.getSquareClient().oAuthApi;

      try {
        const responseSquare = await oauthInstance.obtainToken({
          clientId: this.squareEnvService.getClientId(),
          clientSecret: this.squareEnvService.getClientSecret(),
          grantType: 'authorization_code',
          code: authorization_code,
        });

        await this.useCaseFactory.createSquarePaymentAccountUseCase.execute({
          accessToken: responseSquare.result.accessToken,
          refreshToken: responseSquare.result.refreshToken,
          createdBy: 0,
          deletedBy: 0,
          updatedBy: 0,
          isActive: true,
          squareDefaultLocationId: 'empty',
          location: Number(state),
          type: 'Square-Pay',
        });

        response.redirect(
          `${this.squareEnvService.getFrontendRedirectURL()}/callback?error=false&message=${encodeURIComponent('Square has been sucessfully connected with SeamlessSlot')}`,
        );
      } catch (error) {
        console.log(JSON.stringify(error));
        response.redirect(
          `${this.squareEnvService.getFrontendRedirectURL()}/callback?error=true&message=${encodeURIComponent('some thing went wrong : ' + JSON.stringify(error))}`,
        );
      }
    }
  }
}
