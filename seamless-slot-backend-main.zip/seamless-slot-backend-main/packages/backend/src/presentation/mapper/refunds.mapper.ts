import { Injectable } from '@nestjs/common';
import {
  Appointment,
  Customer,
  SquarePaymentTransaction,
  SquareRefund,
} from '@seamlessslot/core';
import {
  RefundResponse,
  RefundResponseWithAppointmentAndPatient,
} from '../refunds/response/refund.response';
import { TimeZoneService } from '../../shared/utils/timezone.util';
import { SecurityContext } from '../../shared/auth/context/security.context';

@Injectable()
export class RefundPresentationMapper {
  constructor(
    private readonly timeZoneService: TimeZoneService,
    private readonly securityContext: SecurityContext,
  ) {}

  public domainToResponse(domain: SquareRefund): RefundResponse {
    return {
      id: domain.id,
      refundSquareId: domain.refundSquareId,
      status: domain.status,
      amount: (parseInt(domain.amount) / 100).toString(),
      remaningBalance: (parseInt(domain.remainingBalance) / 100).toString(),
      currency: domain.currency,
      paymentId: (domain.paymentTransaction as SquarePaymentTransaction).id,
      squareTransactionId: domain.paymentId,
      orderId: domain.orderId,
      locationId: domain.squareLocationId,
      reason: domain.reason,
      createdAt: this.timeZoneService.formatDatePreservingUTC(
        domain.createdAt,
        'hh:mm aa - dd MMM, yyyy',
      ),
    };
  }

  public domainToResponseWithAppointmentAndPatient(
    domain: SquareRefund,
  ): RefundResponseWithAppointmentAndPatient {
    return {
      id: domain.id,
      refundSquareId: domain.refundSquareId,
      status: domain.status,
      amount: (parseInt(domain.amount) / 100).toString(),
      remaningBalance: (parseInt(domain.remainingBalance) / 100).toString(),
      currency: domain.currency,
      paymentId: (domain.paymentTransaction as SquarePaymentTransaction).id,
      squareTransactionId: domain.paymentId,
      orderId: domain.orderId,
      locationId: domain.squareLocationId,
      reason: domain.reason,
      createdAt: this.timeZoneService.formatDatePreservingUTC(
        domain.createdAt as Date,
        'hh:mm aa - dd MMM, yyyy',
      ),
      appointmentId: (
        (domain.paymentTransaction as SquarePaymentTransaction)
          .appointment as Appointment
      ).id,
      patientName:
        (
          (
            (domain.paymentTransaction as SquarePaymentTransaction)
              .appointment as Appointment
          ).customer as Customer
        ).firstName +
        ' ' +
        (
          (
            (domain.paymentTransaction as SquarePaymentTransaction)
              .appointment as Appointment
          ).customer as Customer
        ).lastName,
    };
  }
}
