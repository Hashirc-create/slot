import { Injectable } from '@nestjs/common';
import { SecurityContext } from '../../shared/auth/context/security.context';
import { CreateBreakDto } from '../break/dto/create-break.dto';
import { UpdateBreakDto } from '../break/dto/update-break.dto';
import { Break, GetUserByIdUseCase, WorkingDay } from '@seamlessslot/core';
import { BreakResponse } from '../break/response/break.response';
import { TimeZoneService } from '../../shared/utils/timezone.util';

@Injectable()
export class BreakPresentationMapper {
  constructor(
    private readonly timeZoneService: TimeZoneService,
    private readonly securityContext: SecurityContext,
  ) {}

  public dtoToDomain(dto: CreateBreakDto): Break {
    return {
      title: dto.title,
      startTime: this.timeZoneService.convertSimpleDateStringToUTC(
        dto.startTime,
      ),
      endTime: this.timeZoneService.convertSimpleDateStringToUTC(dto.endTime),
      workingDay: dto.workingDayId,
      isActive: true,
      createdBy: this.securityContext.getId() || 0,
      updatedBy: 0,
      deletedBy: 0,
    };
  }

  public dtoToDomainForUpdate(dto: UpdateBreakDto): Break {
    return {
      id: dto.id,
      title: dto.title,
      startTime: this.timeZoneService.convertSimpleDateStringToUTC(
        dto.startTime,
      ),
      endTime: this.timeZoneService.convertSimpleDateStringToUTC(dto.endTime),
      workingDay: 0, // no need for this while update
      isActive: true,
      createdBy: this.securityContext.getId() || 0,
      updatedBy: this.securityContext.getId() || 0,
      deletedBy: 0,
    };
  }

  public async domainToResponse(
    domain: Break,
    getUserById: GetUserByIdUseCase,
  ): Promise<BreakResponse> {
    const createdBy = await getUserById.execute(domain.createdBy);
    const updatedBy = await getUserById.execute(domain.updatedBy);

    const createdAt = this.timeZoneService.formatDatePreservingUTC(
      domain.createdAt as Date,
      'hh:mm aa - dd MMM, yyyy',
    );

    const updatedAt = this.timeZoneService.formatDatePreservingUTC(
      domain.updatedAt as Date,
      'hh:mm aa - dd MMM, yyyy',
    );

    return {
      id: domain.id,
      day: (domain.workingDay as WorkingDay).day,
      title: domain.title,
      startTime: this.timeZoneService.formatDatePreservingUTC(
        domain.startTime as Date,
        'hh:mm aa',
      ),
      endTime: this.timeZoneService.formatDatePreservingUTC(
        domain.endTime as Date,
        'hh:mm aa',
      ),
      createdAt,
      updatedAt,
      createdBy: createdBy
        ? createdBy.firstName + ' ' + createdBy.lastName
        : '',
      updatedBy: updatedBy
        ? updatedBy.firstName + ' ' + updatedBy.lastName
        : '',
    };
  }
}
