import { GoogleAnalytics } from '@seamlessslot/core';
import { GoogleAnalyticsResponse } from '../google-analytics/response/google.analytics.response';
import { Injectable } from '@nestjs/common';

@Injectable()
export class GoogleAnalyticsMapper {
  domainToResponse(googleAnalytics: GoogleAnalytics): GoogleAnalyticsResponse {
    return {
      id: googleAnalytics.id,
      measurementId: googleAnalytics.measurementId,
    };
  }
}
