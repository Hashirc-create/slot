import { Injectable } from '@nestjs/common';
import { CreateBookingPolicyDto } from '../booking-policy/dto/create-booking-policy.dto';
import { BookingPolicy } from '@seamlessslot/core';
import { SecurityContext } from '../../shared/auth/context/security.context';
import { BookingPolicyResponse } from '../booking-policy/response/booking-policy.response';
import { UpdateBookingPolicyDto } from '../booking-policy/dto/update-booking-policy.dto';

@Injectable()
export class BookingPolicyPresentationMapper {
  constructor(private readonly securityContext: SecurityContext) {}

  public dtoToDomain(
    createBookingPolicyDto: CreateBookingPolicyDto | UpdateBookingPolicyDto,
  ): BookingPolicy {
    return {
      id: (createBookingPolicyDto as UpdateBookingPolicyDto).id,
      location: createBookingPolicyDto.location,
      cancellationPolicy: createBookingPolicyDto.cancellationPolicy,
      leadTime: createBookingPolicyDto.leadTime,
      leadTimeType: createBookingPolicyDto.leadTimeType,
      schedulingWindow: createBookingPolicyDto.schedulingWindow,
      schedulingWindowType: createBookingPolicyDto.schedulingWindowType,
      slotSize: createBookingPolicyDto.slotSize,
      slotSizeType: createBookingPolicyDto.slotSizeType,
      isActive: true,
      createdBy: this.securityContext.getId() || 0,
      updatedBy: 0,
      deletedBy: 0,
    };
  }

  public domainToResponse(domain: BookingPolicy): BookingPolicyResponse {
    return {
      id: domain.id,
      cancellationPolicy: domain.cancellationPolicy,
      leadTime: domain.leadTime,
      leadTimeType: domain.leadTimeType,
      schedulingWindow: domain.schedulingWindow,
      schedulingWindowType: domain.schedulingWindowType,
      slotSize: domain.slotSize,
      slotSizeType: domain.slotSizeType,
    };
  }
}
