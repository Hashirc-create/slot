import { GoogleTagManager } from '@seamlessslot/core';
import { GoogleTagManagerResponse } from '../google-tag-manager/response/google.tag.manager.response';
import { Injectable } from '@nestjs/common';

@Injectable()
export class GoogleTagManagerMapper {
  domainToResponse(
    googleTagManager: GoogleTagManager,
  ): GoogleTagManagerResponse {
    return {
      containerId: googleTagManager.containerId,
      id: googleTagManager.id,
    };
  }
}
