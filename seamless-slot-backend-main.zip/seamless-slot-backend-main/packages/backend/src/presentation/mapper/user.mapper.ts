import { Injectable } from '@nestjs/common';
import { RegisterUserDto } from '../user/dto/register-user.dto';
import { User } from '@seamlessslot/core';
import { SecurityContext } from '../../shared/auth/context/security.context';
import { UserResponse } from '../user/response/user.response';
import { UpdateUserDto } from '../user/dto/update-user.dto';
import { Role } from '@seamlessslot/core';

@Injectable()
export class UserPresentationMapper {
  constructor(private readonly securityContext: SecurityContext) {}

  public dtoToDomain(
    createUserDto: RegisterUserDto | UpdateUserDto,
    role?: Role,
    tokenVersion?: number,
  ): User {
    return {
      firstName: createUserDto.firstName,
      lastName: createUserDto.lastName,
      password: createUserDto.password,
      role: role,
      email: createUserDto.email,
      phoneNo: createUserDto.phoneNumber,
      tokenVersion: tokenVersion,
      isActive: true,
      createdBy: this.securityContext.getId() || 0,
      updatedBy: 0,
      deletedBy: 0,
      location: createUserDto.locationId,
      business: createUserDto.businessId,
    };
  }

  public domainToResponse(domain: User): UserResponse {
    return {
      id: domain.id,
      email: domain.email,
      firstName: domain.firstName,
      lastName: domain.lastName,
      phoneNo: domain.phoneNo,
    };
  }
}
