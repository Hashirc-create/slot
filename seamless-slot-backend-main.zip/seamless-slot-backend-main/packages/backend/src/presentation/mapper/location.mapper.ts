import { Injectable } from '@nestjs/common';
import { CreateLocationDto } from '../location/dto/create-location.dto';
import {
  Business,
  GetUserByIdUseCase,
  Location,
  Status,
} from '@seamlessslot/core';
import { SecurityContext } from '../../shared/auth/context/security.context';
import {
  LocationResponse,
  LocationResponseWithBusiness,
} from '../location/response/location.response';
import { UpdateLocationDto } from '../location/dto/update-location.dto';
import { TimeZoneService } from '../../shared/utils/timezone.util';

@Injectable()
export class LocationPresentationMapper {
  constructor(
    private readonly securityContext: SecurityContext,
    private readonly timeZoneService: TimeZoneService,
  ) {}

  public dtoToDomain(createLocationDto: CreateLocationDto): Location {
    return {
      name: createLocationDto.name,
      email: createLocationDto.email,
      site: createLocationDto.site,
      address: createLocationDto.address,
      timeZone: createLocationDto.timeZone,
      latitude: createLocationDto.latitude,
      longitude: createLocationDto.longitude,
      telephone: createLocationDto.telephone,
      country: createLocationDto.country,
      town: createLocationDto.town,
      conferenceCall: createLocationDto.conferenceCall,
      about: createLocationDto.about,
      scheduleSize: 10,
      googleMapUrl: createLocationDto.googleMapUrl,
      status: 'Inactive',
      scheduleSizeUnits: 'days',
      cancellationTimeInHours: 'any time',
      isCancellationPolicyEnabled: false,
      cancellationTime: 0,
      cancellationTimeUnit: 'hours',
      customerReminderTime: 15,
      customerReminderTimeUnit: 'minutes',
      business: createLocationDto.businessId,
      isActive: true,
      createdBy: this.securityContext.getId() || 0,
      updatedBy: 0,
      deletedBy: 0,
    };
  }

  public dtoToDomainForUpdate(updateLocationDto: UpdateLocationDto): Location {
    return {
      name: updateLocationDto.name,
      email: updateLocationDto.email,
      site: updateLocationDto.site,
      address: updateLocationDto.address,
      timeZone: updateLocationDto.timeZone,
      latitude: updateLocationDto.latitude,
      longitude: updateLocationDto.longitude,
      telephone: updateLocationDto.telephone,
      country: updateLocationDto.country,
      town: updateLocationDto.town,
      conferenceCall: updateLocationDto.conferenceCall,
      about: updateLocationDto.about,
      scheduleSize: 10,
      googleMapUrl: updateLocationDto.googleMapUrl,
      status: updateLocationDto.status as Status,
      scheduleSizeUnits: 'days',
      cancellationTimeInHours: 'any time',
      isCancellationPolicyEnabled: false,
      cancellationTime: 0,
      cancellationTimeUnit: 'hours',
      customerReminderTime: 15,
      customerReminderTimeUnit: 'minutes',
      business: updateLocationDto.businessId,
      isActive: true,
      createdBy: this.securityContext.getId() || 0,
      updatedBy: 0,
      deletedBy: 0,
    };
  }

  public domainToResponse(domain: Location): LocationResponse {
    return {
      id: domain.id,
      name: domain.name,
      email: domain.email,
      site: domain.site,
      address: domain.address,
      timeZone: domain.timeZone,
      latitude: domain.latitude,
      longitude: domain.longitude,
      telephone: domain.telephone,
      country: domain.country,
      town: domain.town,
      status: domain.status,
      googleMapUrl: domain.googleMapUrl,
      scheduleWindowSize: domain.scheduleSize,
      scheduleWindowSizeUnit: domain.scheduleSizeUnits,
      cacellationPolicyTimeInHours: domain.cancellationTimeInHours,
      isCancellationPolicyEnabled: domain.isCancellationPolicyEnabled,
      cancellationTime: domain.cancellationTime,
      cancellationTimeUnits: domain.cancellationTimeUnit,
      conferenceCall: domain.conferenceCall,
      about: domain.about,
    };
  }

  public domainToResponseWithBusiness(
    domain: Location,
  ): LocationResponseWithBusiness {
    return {
      businessName: (domain.business as Business).name,
      id: domain.id,
      name: domain.name,
      email: domain.email,
      site: domain.site,
      address: domain.address,
      timeZone: domain.timeZone,
      latitude: domain.latitude,
      longitude: domain.longitude,
      telephone: domain.telephone,
      country: domain.country,
      town: domain.town,
      status: domain.status,
      googleMapUrl: domain.googleMapUrl,
      scheduleWindowSize: domain.scheduleSize,
      scheduleWindowSizeUnit: domain.scheduleSizeUnits,
      cacellationPolicyTimeInHours: domain.cancellationTimeInHours,
      isCancellationPolicyEnabled: domain.isCancellationPolicyEnabled,
      cancellationTime: domain.cancellationTime,
      cancellationTimeUnits: domain.cancellationTimeUnit,
      conferenceCall: domain.conferenceCall,
      about: domain.about,
      customerReminderTime: domain.customerReminderTime,
      customerReminderTimeUnit: domain.customerReminderTimeUnit,
    };
  }

  public async domainToResponseWithExtras(
    domain: Location,
    getUserByIdUseCase: GetUserByIdUseCase,
  ): Promise<LocationResponse> {
    const createdBy = await getUserByIdUseCase.execute(domain.createdBy);
    const updatedBy = await getUserByIdUseCase.execute(domain.updatedBy);

    return {
      id: domain.id,
      name: domain.name,
      email: domain.email,
      site: domain.site,
      address: domain.address,
      timeZone: domain.timeZone,
      latitude: domain.latitude,
      longitude: domain.longitude,
      telephone: domain.telephone,
      country: domain.country,
      town: domain.town,
      status: domain.status,
      googleMapUrl: domain.googleMapUrl,
      scheduleWindowSize: domain.scheduleSize,
      scheduleWindowSizeUnit: domain.scheduleSizeUnits,
      cacellationPolicyTimeInHours: domain.cancellationTimeInHours,
      isCancellationPolicyEnabled: domain.isCancellationPolicyEnabled,
      cancellationTime: domain.cancellationTime,
      cancellationTimeUnits: domain.cancellationTimeUnit,
      conferenceCall: domain.conferenceCall,
      about: domain.about,
      createdAt: this.timeZoneService.formatDatePreservingUTC(
        domain.createdAt as Date,
        `hh:mm aa - dd MMM, yyyy`,
      ),
      updatedAt: this.timeZoneService.formatDatePreservingUTC(
        domain.updatedAt as Date,
        `hh:mm aa - dd MMM, yyyy`,
      ),
      createdBy:
        createdBy !== null
          ? createdBy.firstName + ' ' + createdBy.lastName
          : 'Public Site',
      updatedBy:
        updatedBy !== null
          ? updatedBy.firstName + ' ' + updatedBy.lastName
          : 'Public Site',
    };
  }
}
