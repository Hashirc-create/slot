import { Inject, Injectable } from '@nestjs/common';
import { LocationPresentationMapper } from './location.mapper';
import { ServicePresentationMapper } from './service.mapper';
import { UserPresentationMapper } from './user.mapper';
import { CustomerPresentationMapper } from './customer.mapper';
import { WorkingDayPresentationMapper } from './working.day.mapper';
import { TimeOffPresentationMapper } from './time.off.mapper';
import { BreakPresentationMapper } from './break.mapper';
import { PaymentAccountPresentationMapper } from './payment.account';
import { AppointmentPresentationMapper } from './appointment';
import { BookingBrandDetailPresentationMapper } from './booking.brand.detail';
import { PaymentTransactionPresentationMapper } from './payment.transaction.mapper';
import { BookingPolicyPresentationMapper } from './booking.policy';
import { RefundPresentationMapper } from './refunds.mapper';
import { GoogleTagManagerMapper } from './google.tag.manager.mapper';
import { GoogleAnalyticsMapper } from './google.analytics.mapper';
import { BusinessPresentationMapper } from './business.mapper';
import { PaymentLogPresentationMapper } from './payment.log.mapper';
import { WorkingDayHistoryPresentationMapper } from './working.day.history.mapper';

@Injectable()
export class PresentationMapperFactory {
  @Inject(WorkingDayHistoryPresentationMapper)
  public readonly workingDayHistoryPresentationMapper: WorkingDayHistoryPresentationMapper;

  @Inject(PaymentLogPresentationMapper)
  public readonly paymentLogPresentationMapper: PaymentLogPresentationMapper;

  @Inject(BusinessPresentationMapper)
  public readonly businessPresentationMapper: BusinessPresentationMapper;

  @Inject(LocationPresentationMapper)
  public readonly locationPresentationMapper: LocationPresentationMapper;

  @Inject(ServicePresentationMapper)
  public readonly servicePresentationMapper: ServicePresentationMapper;

  @Inject(UserPresentationMapper)
  public readonly userPresentationMapper: UserPresentationMapper;

  @Inject(CustomerPresentationMapper)
  public readonly customerPresentationMapper: CustomerPresentationMapper;

  @Inject(WorkingDayPresentationMapper)
  public readonly workingDayPresentationMapper: WorkingDayPresentationMapper;

  @Inject(TimeOffPresentationMapper)
  public readonly timeOffPresentationMapper: TimeOffPresentationMapper;

  @Inject(BreakPresentationMapper)
  public readonly breakPresentationMapper: BreakPresentationMapper;

  @Inject(PaymentAccountPresentationMapper)
  public readonly paymentAccountPresentationMapper: PaymentAccountPresentationMapper;

  @Inject(AppointmentPresentationMapper)
  public readonly appointmentPresentationMapper: AppointmentPresentationMapper;

  @Inject(BookingBrandDetailPresentationMapper)
  public readonly bookingBrandDetailPresentationMapper: BookingBrandDetailPresentationMapper;

  @Inject(PaymentTransactionPresentationMapper)
  public readonly paymentTransactionPresentationMapper: PaymentTransactionPresentationMapper;

  @Inject(BookingPolicyPresentationMapper)
  public readonly bookingPolicyPresentationMapper: BookingPolicyPresentationMapper;

  @Inject(RefundPresentationMapper)
  public readonly refundPresentationMapper: RefundPresentationMapper;

  @Inject(GoogleTagManagerMapper)
  public readonly googleTagManagerMapper: GoogleTagManagerMapper;

  @Inject(GoogleAnalyticsMapper)
  public readonly googleAnalyticsMapper: GoogleAnalyticsMapper;
}
