import { Injectable } from '@nestjs/common';
import { CreateBookingBrandDetailDto } from '../booking-brand-detail/dto/create-booking-brand-detail.dto';
import { BookingBrandDetail } from '@seamlessslot/core';
import { SecurityContext } from '../../shared/auth/context/security.context';
import { BookingBrandDetailResponse } from '../booking-brand-detail/response/booking-brand-detail.response';
import { UpdateBookingBrandDetailDto } from '../booking-brand-detail/dto/update-booking-brand-detail.dto';

@Injectable()
export class BookingBrandDetailPresentationMapper {
  constructor(private readonly securityContext: SecurityContext) {}

  public dtoToDomain(
    createBookingBrandDetailDto:
      | CreateBookingBrandDetailDto
      | UpdateBookingBrandDetailDto,
  ): BookingBrandDetail {
    return {
      id: (createBookingBrandDetailDto as UpdateBookingBrandDetailDto).id,
      location: createBookingBrandDetailDto.location,
      about: createBookingBrandDetailDto.about,
      address: createBookingBrandDetailDto.address,
      brand: createBookingBrandDetailDto.brand,
      country: createBookingBrandDetailDto.country,
      currency: createBookingBrandDetailDto.currency,
      email: createBookingBrandDetailDto.email,
      industry: createBookingBrandDetailDto.industry,
      telephone: createBookingBrandDetailDto.telephone,
      town: createBookingBrandDetailDto.town,
      isActive: true,
      createdBy: this.securityContext.getId() || 0,
      updatedBy: 0,
      deletedBy: 0,
    };
  }

  public domainToResponse(
    domain: BookingBrandDetail,
  ): BookingBrandDetailResponse {
    return {
      id: domain.id,
      about: domain.about,
      address: domain.address,
      brand: domain.brand,
      country: domain.country,
      currency: domain.currency,
      email: domain.email,
      industry: domain.industry,
      telephone: domain.telephone,
      town: domain.town,
    };
  }
}
