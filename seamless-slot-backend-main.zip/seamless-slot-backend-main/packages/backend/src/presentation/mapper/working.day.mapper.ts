import { Injectable } from '@nestjs/common';
import { CreateWorkingDayDto } from '../working-day/dto/create-working-day.dto';
import { WorkingDay } from '@seamlessslot/core';
import { SecurityContext } from '../../shared/auth/context/security.context';
import { WorkingDayResponse } from '../working-day/response/working-day.response';
import { UpdateWorkingDayDto } from '../working-day/dto/update-working-day.dto';
import { TimeZoneService } from '../../shared/utils/timezone.util';

@Injectable()
export class WorkingDayPresentationMapper {
  constructor(
    private readonly timeZoneService: TimeZoneService,
    private readonly securityContext: SecurityContext,
  ) {}

  public dtoToDomain(
    createWorkingDayDto: CreateWorkingDayDto | UpdateWorkingDayDto,
  ): WorkingDay {
    return {
      id: (createWorkingDayDto as UpdateWorkingDayDto).id,
      day: createWorkingDayDto.day,
      isClosed: createWorkingDayDto.isClosed,
      from: this.timeZoneService.convertSimpleDateStringToUTC(
        createWorkingDayDto.from,
      ),
      to: this.timeZoneService.convertSimpleDateStringToUTC(
        createWorkingDayDto.to,
      ),
      location: createWorkingDayDto.location,
      isActive: true,
      createdBy: this.securityContext.getId() || 0,
      updatedBy: 0,
      deletedBy: 0,
    };
  }

  public domainToResponse(domain: WorkingDay): WorkingDayResponse {
    return {
      id: domain.id,
      day: domain.day,
      isClosed: domain.isClosed,
      from: this.timeZoneService.formatDatePreservingUTC(
        domain.from as Date,
        'hh:mm aa',
      ),
      to: this.timeZoneService.formatDatePreservingUTC(
        domain.to as Date,
        'hh:mm aa',
      ),
    };
  }
}
