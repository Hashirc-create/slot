import { Injectable } from '@nestjs/common';
import { SecurityContext } from '../../shared/auth/context/security.context';
import { CreateTimeOffDto } from '../time-off/dto/create-time-off.dto';
import { UpdateTimeOffDto } from '../time-off/dto/update-time-off.dto';
import { GetUserByIdUseCase, TimeOff } from '@seamlessslot/core';
import { TimeOffResponse } from '../time-off/response/time.off.response';
import { TimeZoneService } from '../../shared/utils/timezone.util';

@Injectable()
export class TimeOffPresentationMapper {
  constructor(
    private readonly timeZoneService: TimeZoneService,
    private readonly securityContext: SecurityContext,
  ) {}

  public dtoToDomain(dto: CreateTimeOffDto | UpdateTimeOffDto): TimeOff {
    return {
      title: dto.title,
      allDay: dto.allDay,
      startDateTime: this.timeZoneService.convertSimpleDateStringToUTC(
        dto.startDateTime,
      ),
      endDateTime: this.timeZoneService.convertSimpleDateStringToUTC(
        dto.endDateTime,
      ),
      location: dto.locationId,
      isActive: true,
      createdBy: this.securityContext.getId() || 0,
      updatedBy: this.securityContext.getId() || 0,
      deletedBy: 0,
    };
  }

  public async domainToResponse(
    domain: TimeOff,
    getUserById: GetUserByIdUseCase,
  ): Promise<TimeOffResponse> {
    const startDateTime = this.timeZoneService.formatDatePreservingUTC(
      domain.startDateTime as Date,
      'dd MMM yyyy - hh:mm aa',
    );

    const endDateTime = this.timeZoneService.formatDatePreservingUTC(
      domain.endDateTime as Date,
      'dd MMM yyyy - hh:mm aa',
    );

    const startDateOnly = this.timeZoneService.formatDatePreservingUTC(
      domain.startDateTime as Date,
      'yyyy-MM-dd',
    );

    const startTimeOnly = this.timeZoneService.formatDatePreservingUTC(
      domain.startDateTime as Date,
      'hh:mm aa',
    );

    const endDateOnly = this.timeZoneService.formatDatePreservingUTC(
      domain.endDateTime as Date,
      'yyyy-MM-dd',
    );

    const endTimeOnly = this.timeZoneService.formatDatePreservingUTC(
      domain.endDateTime as Date,
      'hh:mm aa',
    );

    const createdAt = this.timeZoneService.formatDatePreservingUTC(
      domain.createdAt as Date,
      'hh:mm aa - dd MMM, yyyy',
    );

    const updatedAt = this.timeZoneService.formatDatePreservingUTC(
      domain.updatedAt as Date,
      'hh:mm aa - dd MMM, yyyy',
    );

    const createdBy = await getUserById.execute(domain.createdBy);
    const updatedBy = await getUserById.execute(domain.updatedBy);

    return {
      id: domain.id,
      title: domain.title,
      startDateTime: startDateTime,
      endDateTime: endDateTime,
      allDay: domain.allDay,
      startDateOnly: startDateOnly,
      startTimeOnly: startTimeOnly,
      endDateOnly: endDateOnly,
      endTimeOnly: endTimeOnly,
      createdBy: createdBy
        ? createdBy.firstName + ' ' + createdBy.lastName
        : '',
      updatedBy: updatedBy
        ? updatedBy.firstName + ' ' + updatedBy.lastName
        : '',
      createdAt,
      updatedAt,
    };
  }
}
