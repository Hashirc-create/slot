import { Injectable } from '@nestjs/common';
import { SecurityContext } from '../../shared/auth/context/security.context';
import {
  Appointment,
  GetUserByIdUseCase,
  SlotPaymentStatus,
} from '@seamlessslot/core';
import { CreateAppointmentDto } from '../appointment/dto/create-appointment.dto';
import { UpdateAppointmentDto } from '../appointment/dto/update-appointment.dto';
import { AppointmentStatus } from '@seamlessslot/core';
import {
  AppointmentResponseWithLocationAndCustomer,
  AppointmentResponseWithLocationAndCustomerWithExtras,
  AppointmentResponseWithLocationCustomerServiceAndPayment,
} from '../appointment/response/appointment.response';
import { Location } from '@seamlessslot/core';
import { User } from '@seamlessslot/core';
import { Service } from '@seamlessslot/core';
import { TimeZoneService } from '../../shared/utils/timezone.util';
import { CreatePublicAppointmentDto } from '../appointment/dto/create-public-appointment.dto';
import { SquarePaymentTransaction } from '@seamlessslot/core';
import { Customer } from '@seamlessslot/core';
import { UTILS } from '../../shared/utils/utils.util';
import { CreatePublicAppointmentWithoutPaymentDto } from '../appointment/dto/create-public-appointment-without-payment.dto';

@Injectable()
export class AppointmentPresentationMapper {
  constructor(
    private readonly timeZoneService: TimeZoneService,
    private readonly securityContext: SecurityContext,
  ) {}

  public dtoToDomain(
    dto: CreateAppointmentDto | UpdateAppointmentDto,
  ): Appointment {
    console.log(dto);

    return {
      date: this.timeZoneService.convertSimpleDateStringToUTC(dto.startTime),
      startTime: this.timeZoneService.convertSimpleDateStringToUTC(
        dto.startTime,
      ),
      endTime: this.timeZoneService.convertSimpleDateStringToUTC(dto.endTime),
      squareOrderId: '',
      location: dto.locationId,
      business: dto.businessId,
      address: dto.address,
      customer: dto.customerId,
      service: dto.serviceId,
      status: dto.status as AppointmentStatus,
      isActive: true,
      createdBy: this.securityContext.getId(),
      updatedBy: this.securityContext.getId(),
      deletedBy: 0,
    };
  }

  public dtoToDomainForPublic(
    dto: CreatePublicAppointmentDto | CreatePublicAppointmentWithoutPaymentDto,
  ): Appointment {
    return {
      date: this.timeZoneService.convertSimpleDateStringToUTC(
        dto.date + 'T09:00:00',
      ),
      startTime: this.timeZoneService.convertSimpleDateStringToUTC(
        dto.startTime,
      ),
      endTime: this.timeZoneService.convertSimpleDateStringToUTC(dto.endTime),
      location: dto.locationId,
      address: dto.address,
      service: dto.serviceId,
      squareOrderId: '',
      customer: 0,
      status: 'Pending' as AppointmentStatus,
      isActive: true,
      createdBy: this.securityContext.getId() || 0,
      updatedBy: 0,
      deletedBy: 0,
    };
  }

  public async domainToResponseWithLocationAndCustomer(
    domain: Appointment,
    getUserById: GetUserByIdUseCase,
  ): Promise<AppointmentResponseWithLocationAndCustomer> {
    const createdBy = await getUserById.execute(domain.createdBy);
    const updatedBy = await getUserById.execute(domain.updatedBy);
    const appointmentStartTime = this.timeZoneService.formatDatePreservingUTC(
      domain.startTime as Date,
      'hh:mm aa',
    );
    const appointmentEndTime = this.timeZoneService.formatDatePreservingUTC(
      domain.endTime as Date,
      'hh:mm aa',
    );

    const appointmentDate = this.timeZoneService.formatDatePreservingUTC(
      domain.date as Date,
      'EEEE dd MMM, yyyy',
    );

    const paymentStatus: SlotPaymentStatus = (() => {
      if (domain.payments === null) return 'Unpaid';

      const payments = domain.payments as SquarePaymentTransaction;

      if (payments.refunds && payments.refunds.length > 0) return 'Refunded';

      return 'Paid';
    })();

    const paylod: AppointmentResponseWithLocationAndCustomer = {
      id: domain.id,
      title: `${appointmentStartTime} ${(domain.customer as Customer).firstName} ${(domain.customer as Customer).lastName}`,
      start: this.timeZoneService.formatDatePreservingUTC(
        domain.startTime as Date,
        `yyyy-MM-dd'T'HH:mm:ss.SSS'Z'`,
      ),
      end: this.timeZoneService.formatDatePreservingUTC(
        domain.endTime as Date,
        `yyyy-MM-dd'T'HH:mm:ss.SSS'Z'`,
      ),
      className: UTILS.getClassFromStatus(domain),
      extendedProps: {
        paymentStatus,
        createdAt: this.timeZoneService.formatDatePreservingUTC(
          domain.createdAt as Date,
          `hh:mm aa - dd MMM, yyyy`,
        ),
        updatedAt: this.timeZoneService.formatDatePreservingUTC(
          domain.updatedAt as Date,
          `hh:mm aa - dd MMM, yyyy`,
        ),
        createdBy:
          createdBy !== null
            ? createdBy.firstName + ' ' + createdBy.lastName
            : 'Public Site',
        updatedBy:
          updatedBy !== null
            ? updatedBy.firstName + ' ' + updatedBy.lastName
            : 'Public Site',
        status: domain.status,
        appointmentId: domain.id,
        startTime: appointmentStartTime,
        endTime: appointmentEndTime,
        isActive: domain.isActive,
        customerId: (domain.customer as User).id,
        customerName:
          (domain.customer as User).firstName +
          ' ' +
          (domain.customer as User).lastName,
        customerEmail: (domain.customer as Customer).email,
        customerPhone: (domain.customer as Customer).phoneNo,
        customerAddress: (domain.customer as Customer).address,
        appointmentDateDropdown: this.timeZoneService.formatDatePreservingUTC(
          domain.endTime as Date,
          `dd MMM yyyy`,
        ),
        appointmentTimeDropdown:
          appointmentStartTime + ' - ' + appointmentEndTime,
        location: (domain.location as Location).name,
        locationLat: (domain.location as Location).latitude,
        locationLon: (domain.location as Location).longitude,
        serviceId: (domain.service as Service).id,
        serviceDurationInMins: (domain.service as Service).durationInMinutes,
        serviceBufferTimeInMinutes: (domain.service as Service)
          .bufferTimeInMinutes,
        serviceCost: (domain.service as Service).cost,
        servicVenue: (domain.service as Service).venue,
        serviceName: (domain.service as Service).title,
        day: appointmentDate,
        hour: appointmentStartTime + ' - ' + appointmentEndTime,
      },
    };

    if (domain.payments !== null) {
      paylod.extendedProps.paymentId = (
        domain.payments as SquarePaymentTransaction
      ).id;
      paylod.extendedProps.paymentLink = (
        domain.payments as SquarePaymentTransaction
      ).squareReceiptURL;
      paylod.extendedProps.companyBalance =
        parseFloat(
          (domain.payments as SquarePaymentTransaction).companyBalance,
        ) / 100;
      paylod.extendedProps.amountPaid = (
        parseFloat((domain.payments as SquarePaymentTransaction).amount) / 100
      ).toString();
      paylod.extendedProps.curreny = (
        domain.payments as SquarePaymentTransaction
      ).currency;
      paylod.extendedProps.payerName =
        (domain.customer as Customer).firstName +
        ' ' +
        (domain.customer as Customer).lastName;

      paylod.extendedProps.providerPaymentStatus = (
        domain.payments as SquarePaymentTransaction
      ).status;
      paylod.extendedProps.transactionId = (
        domain.payments as SquarePaymentTransaction
      ).squareTransactionId;
      paylod.extendedProps.paymentDate =
        this.timeZoneService.formatDatePreservingUTC(
          (domain.payments as SquarePaymentTransaction).createdAt as Date,
          'dd MMM EEEE',
        );
      paylod.extendedProps.paymentMethod = (
        domain.payments as SquarePaymentTransaction
      ).method;
    }

    return paylod;
  }

  public async domainToResponseWithLocationAndCustomerWithExtras(
    domain: Appointment,
    getUserById: GetUserByIdUseCase,
  ): Promise<AppointmentResponseWithLocationAndCustomerWithExtras> {
    const paymentStatus: SlotPaymentStatus = (() => {
      if (domain.payments === null) return 'Unpaid';

      const payments = domain.payments as SquarePaymentTransaction;

      if (payments.refunds && payments.refunds.length > 0) return 'Refunded';

      return 'Paid';
    })();

    const createdBy = await getUserById.execute(domain.createdBy);
    const updatedBy = await getUserById.execute(domain.updatedBy);
    const appointmentStartTime = this.timeZoneService.formatDatePreservingUTC(
      domain.startTime as Date,
      'hh:mm aa',
    );
    const appointmentEndTime = this.timeZoneService.formatDatePreservingUTC(
      domain.endTime as Date,
      'hh:mm aa',
    );

    const appointmentDate = this.timeZoneService.formatDatePreservingUTC(
      domain.date as Date,
      'EEEE dd MMM, yyyy',
    );

    const paylod: AppointmentResponseWithLocationAndCustomerWithExtras = {
      id: domain.id,
      title: `${appointmentStartTime} ${(domain.customer as Customer).firstName} ${(domain.customer as Customer).lastName}`,
      start: appointmentStartTime,
      end: appointmentEndTime,
      className: UTILS.getClassFromStatus(domain),
      extendedProps: {
        paymentStatus,
        createdAt: this.timeZoneService.formatDatePreservingUTC(
          domain.createdAt as Date,
          `hh:mm aa - dd MMM, yyyy`,
        ),
        updatedAt: this.timeZoneService.formatDatePreservingUTC(
          domain.updatedAt as Date,
          `hh:mm aa - dd MMM, yyyy`,
        ),
        createdBy:
          createdBy !== null
            ? createdBy.firstName + ' ' + createdBy.lastName
            : 'Public Site',
        updatedBy:
          updatedBy !== null
            ? updatedBy.firstName + ' ' + updatedBy.lastName
            : 'Public Site',
        status: domain.status,
        appointmentId: domain.id,
        startTime: appointmentStartTime,
        endTime: appointmentEndTime,
        isActive: domain.isActive,
        customerId: (domain.customer as User).id,
        customerName:
          (domain.customer as User).firstName +
          ' ' +
          (domain.customer as User).lastName,
        customerEmail: (domain.customer as Customer).email,
        customerPhone: (domain.customer as Customer).phoneNo,
        customerAddress: (domain.customer as Customer).address,
        appointmentDateDropdown: this.timeZoneService.formatDatePreservingUTC(
          domain.endTime as Date,
          `dd MMM yyyy`,
        ),
        appointmentTimeDropdown:
          appointmentStartTime + ' - ' + appointmentEndTime,
        location: (domain.location as Location).name,
        locationLat: (domain.location as Location).latitude,
        locationLon: (domain.location as Location).longitude,
        serviceId: (domain.service as Service).id,
        serviceDurationInMins: (domain.service as Service).durationInMinutes,
        serviceBufferTimeInMinutes: (domain.service as Service)
          .bufferTimeInMinutes,
        serviceCost: (domain.service as Service).cost,
        servicVenue: (domain.service as Service).venue,
        serviceName: (domain.service as Service).title,
        day: appointmentDate,
        hour: appointmentStartTime + ' - ' + appointmentEndTime,
      },
    };

    if (domain.payments !== null) {
      paylod.extendedProps.paymentId = (
        domain.payments as SquarePaymentTransaction
      ).id;
      paylod.extendedProps.paymentLink = (
        domain.payments as SquarePaymentTransaction
      ).squareReceiptURL;
      paylod.extendedProps.companyBalance =
        parseFloat(
          (domain.payments as SquarePaymentTransaction).companyBalance,
        ) / 100;
      paylod.extendedProps.amountPaid = (
        parseFloat((domain.payments as SquarePaymentTransaction).amount) / 100
      ).toString();
      paylod.extendedProps.curreny = (
        domain.payments as SquarePaymentTransaction
      ).currency;
      paylod.extendedProps.payerName =
        (domain.customer as Customer).firstName +
        ' ' +
        (domain.customer as Customer).lastName;

      paylod.extendedProps.providerPaymentStatus = (
        domain.payments as SquarePaymentTransaction
      ).status;
      paylod.extendedProps.transactionId = (
        domain.payments as SquarePaymentTransaction
      ).squareTransactionId;
      paylod.extendedProps.paymentDate =
        this.timeZoneService.formatDatePreservingUTC(
          (domain.payments as SquarePaymentTransaction).createdAt as Date,
          'dd MMM EEEE',
        );
      paylod.extendedProps.paymentMethod = (
        domain.payments as SquarePaymentTransaction
      ).method;
    }

    return paylod;
  }

  public domainToResponseWithLocationCustomerServiceAndTransaction(
    domain: Appointment,
  ): AppointmentResponseWithLocationCustomerServiceAndPayment {
    const appointmentStartTime = this.timeZoneService.formatDatePreservingUTC(
      domain.startTime as Date,
      'hh:mm aa',
    );
    const appointmentEndTime = this.timeZoneService.formatDatePreservingUTC(
      domain.endTime as Date,
      'hh:mm aa',
    );

    const appointmentDate = this.timeZoneService.formatDatePreservingUTC(
      domain.date as Date,
      'EEEE dd MMM, yyyy',
    );

    return {
      id: domain.id,
      date: appointmentDate,
      startTime: appointmentStartTime,
      endTime: appointmentEndTime,
      status: domain.status,
      isActive: domain.isActive,
      customerId: (domain.customer as User).id,
      customerName:
        (domain.customer as User).firstName +
        ' ' +
        (domain.customer as User).lastName,
      customerEmail: (domain.customer as Customer).email,
      customerPhone: (domain.customer as Customer).phoneNo,
      locationName: (domain.location as Location).name,
      locationLat: (domain.location as Location).latitude,
      locationLon: (domain.location as Location).longitude,
      serviceId: (domain.service as Service).id,
      serviceDurationInMinutes: (domain.service as Service).durationInMinutes,
      serviceBufferTimeInMinutes: (domain.service as Service)
        .bufferTimeInMinutes,
      serviceCost: (domain.service as Service).cost,
      servicVenue: (domain.service as Service).venue,
      serviceTitle: (domain.service as Service).title,
      amountPaid:
        parseFloat((domain.payments as SquarePaymentTransaction).amount) / 100, // since square
      type: (domain.payments as SquarePaymentTransaction).type,
      cardDetails: (domain.payments as SquarePaymentTransaction).cardDetails,
      currency: (domain.payments as SquarePaymentTransaction).currency,
    };
  }
}
