import { Injectable } from '@nestjs/common';
import {
  Appointment,
  Customer,
  PaymentLog,
  SquarePaymentTransaction,
} from '@seamlessslot/core';
import {
  PaymentLogResponse,
  PaymentLogResponseWithAppointmentAndPatient,
} from '../payment-log/response/payment-log.response';
import { TimeZoneService } from '../../shared/utils/timezone.util';
import { SecurityContext } from '../../shared/auth/context/security.context';

@Injectable()
export class PaymentLogPresentationMapper {
  constructor(
    private readonly timeZoneService: TimeZoneService,
    private readonly securityContext: SecurityContext,
  ) {}

  public domainToResponse(domain: PaymentLog): PaymentLogResponse {
    return {
      id: domain.id,
      transactionId: domain.transactionId,
      status: domain.status,
      failedReason: domain.failedReason,
      paymentMethod: domain.paymentMethod,
      errorCode: domain.errorCode,
      errorDetail: domain.errorDetail,
      errorCategory: domain.errorCategory,
      amount: domain.amount / 100,
      currency: domain.currency,
      cardBrand: domain.cardBrand,
      last4Digits: domain.last4Digits,
      cardExpMonth: domain.cardExpMonth,
      cardExpYear: domain.cardExpYear,
      cardType: domain.cardType,
      entryMethod: domain.entryMethod,
      cvvStatus: domain.cvvStatus,
      avsStatus: domain.avsStatus,
      fullPayload: domain.fullPayload,
      createdAt: this.timeZoneService.formatDatePreservingUTC(
        domain.createdAt as Date,
        `hh:mm aa - dd MMM, yyyy`,
      ),
    };
  }

  public domainToResponseWithAppointmentAndPatient(
    domain: PaymentLog,
  ): PaymentLogResponseWithAppointmentAndPatient {
    const appointment = domain.appointment as Appointment;
    const paymentTransaction = appointment.payments as SquarePaymentTransaction;

    return {
      id: domain.id,
      transactionId: domain.transactionId,
      status: domain.status,
      failedReason: domain.failedReason,
      paymentMethod: domain.paymentMethod,
      errorCode: domain.errorCode,
      errorDetail: domain.errorDetail,
      errorCategory: domain.errorCategory,
      amount: domain.amount / 100,
      currency: domain.currency,
      cardBrand: domain.cardBrand,
      last4Digits: domain.last4Digits,
      cardExpMonth: domain.cardExpMonth,
      cardExpYear: domain.cardExpYear,
      cardType: domain.cardType,
      entryMethod: domain.entryMethod,
      cvvStatus: domain.cvvStatus,
      avsStatus: domain.avsStatus,
      appointmentId: (domain.appointment as Appointment).id,
      createdAt: this.timeZoneService.formatDatePreservingUTC(
        domain.createdAt as Date,
        `hh:mm aa - dd MMM, yyyy`,
      ),
      patientName:
        ((domain.appointment as Appointment).customer as Customer).firstName +
        ' ' +
        ((domain.appointment as Appointment).customer as Customer).lastName,
      paymentId: paymentTransaction === null ? null : paymentTransaction.id,
      fullPayload: domain.fullPayload,
    };
  }
}
