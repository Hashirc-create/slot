import { Injectable } from '@nestjs/common';
import { GetUserByIdUseCase, WorkingDayHistory } from '@seamlessslot/core';
import { TimeZoneService } from '../../shared/utils/timezone.util';
import { WorkingDayHistoryResponse } from '../working-day-history/response/working.day.response';

@Injectable()
export class WorkingDayHistoryPresentationMapper {
  constructor(private readonly timeZoneService: TimeZoneService) {}

  public async domainToResponse(
    domain: WorkingDayHistory,
    getUserById: GetUserByIdUseCase,
  ): Promise<WorkingDayHistoryResponse> {
    const user = await getUserById.execute(domain.createdBy);
    return {
      id: domain.id,
      day: domain.day,
      prev:
        this.timeZoneService.formatDatePreservingUTC(
          domain.prevFrom as Date,
          'hh:mm a',
        ) +
        ' - ' +
        this.timeZoneService.formatDatePreservingUTC(
          domain.prevTo as Date,
          'hh:mm a',
        ),

      prevIsClosed: domain.prevIsClosed,
      new:
        this.timeZoneService.formatDatePreservingUTC(
          domain.newFrom as Date,
          'hh:mm a',
        ) +
        ' - ' +
        this.timeZoneService.formatDatePreservingUTC(
          domain.newTo as Date,
          'hh:mm a',
        ),
      newIsClosed: domain.newIsClosed,
      createdBy: user.firstName + ' ' + user.lastName,
      createdAt: this.timeZoneService.formatDatePreservingUTC(
        domain.createdAt as Date,
        'hh:mm aa - dd MMM, yyyy',
      ),
    };
  }
}
