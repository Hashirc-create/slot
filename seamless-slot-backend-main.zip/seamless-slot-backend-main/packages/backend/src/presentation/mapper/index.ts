import { AppointmentPresentationMapper } from './appointment';
import { BreakPresentationMapper } from './break.mapper';
import { CustomerPresentationMapper } from './customer.mapper';
import { LocationPresentationMapper } from './location.mapper';
import { PaymentAccountPresentationMapper } from './payment.account';
import { PaymentTransactionPresentationMapper } from './payment.transaction.mapper';
import { ServicePresentationMapper } from './service.mapper';
import { TimeOffPresentationMapper } from './time.off.mapper';
import { UserPresentationMapper } from './user.mapper';
import { WorkingDayPresentationMapper } from './working.day.mapper';
import { BookingBrandDetailPresentationMapper } from './booking.brand.detail';
import { BookingPolicyPresentationMapper } from './booking.policy';
import { RefundPresentationMapper } from './refunds.mapper';
import { GoogleTagManagerMapper } from './google.tag.manager.mapper';
import { GoogleAnalyticsMapper } from './google.analytics.mapper';
import { BusinessPresentationMapper } from './business.mapper';
import { PaymentLogPresentationMapper } from './payment.log.mapper';
import { WorkingDayHistoryPresentationMapper } from './working.day.history.mapper';

export const PRESENTATION_MAPPERS = [
  LocationPresentationMapper,
  ServicePresentationMapper,
  UserPresentationMapper,
  CustomerPresentationMapper,
  WorkingDayPresentationMapper,
  TimeOffPresentationMapper,
  BreakPresentationMapper,
  PaymentAccountPresentationMapper,
  AppointmentPresentationMapper,
  BookingBrandDetailPresentationMapper,
  PaymentTransactionPresentationMapper,
  BookingPolicyPresentationMapper,
  RefundPresentationMapper,
  GoogleTagManagerMapper,
  GoogleAnalyticsMapper,
  BusinessPresentationMapper,
  PaymentLogPresentationMapper,
  WorkingDayHistoryPresentationMapper,
];
