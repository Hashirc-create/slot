import { Injectable } from '@nestjs/common';
import { SecurityContext } from '../../shared/auth/context/security.context';
import { SquarePaymentTransaction } from '@seamlessslot/core';
import { PaymentTransactionResponse } from '../payment-transaction/response/payment.transcation.response';
import { Appointment } from '@seamlessslot/core';
import { Location } from '@seamlessslot/core';
import { Customer } from '@seamlessslot/core';
import { Service } from '@seamlessslot/core';
import { TimeZoneService } from '../../shared/utils/timezone.util';

@Injectable()
export class PaymentTransactionPresentationMapper {
  constructor(
    private readonly timeZoneService: TimeZoneService,
    private readonly securityContext: SecurityContext,
  ) {}

  public domainToResponse(
    domain: SquarePaymentTransaction,
  ): PaymentTransactionResponse {
    const appointment = domain.appointment as Appointment;
    const customer = appointment.customer as Customer;
    const location = appointment.location as Location;
    const service = appointment.service as Service;
    return {
      id: domain.id,
      paymentDateAndTime: this.timeZoneService.formatDatePreservingUTC(
        domain.date as Date,
        'hh:mm aa - dd MMM, yyyy',
      ),
      customerName: customer.firstName + ' ' + customer.lastName,
      serviceTitle: service.title,
      locationName: location.name,
      amount: parseFloat(domain.amount) / 100, // since the saved amount is in its lowest unit
      paymentStatus: domain.status,
      bookingId: appointment.id,
      paymentReceipt: domain.squareReceiptURL,
      paymentMethod: domain.method,
    };
  }
}
