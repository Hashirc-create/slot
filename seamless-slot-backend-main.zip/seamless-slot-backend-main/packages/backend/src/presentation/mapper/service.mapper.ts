import { Service } from '@seamlessslot/core';
import { SecurityContext } from '../../shared/auth/context/security.context';
import { CreateServiceDto } from '../service/dto/create-service.dto';
import { UpdateServiceDto } from '../service/dto/update-service.dto';
import { ServiceResponse } from '../service/response/service.response';
import { Injectable } from '@nestjs/common';

@Injectable()
export class ServicePresentationMapper {
  constructor(private readonly securityContext: SecurityContext) {}

  dtoToDomain(dto: CreateServiceDto | UpdateServiceDto): Service {
    const isUpdating: boolean = dto instanceof UpdateServiceDto;

    return {
      title: dto.title,
      durationInMinutes: dto.durationInMinutes,
      bufferTimeInMinutes: dto.bufferTimeInMinutes,
      cost: dto.cost,
      venue: dto.venue,
      order: dto.order ?? 1,
      isLive: dto.isLive ?? true,
      location: dto.locationId,
      business: dto.businessId,
      isActive: true,
      createdBy: this.securityContext.getId() || 0,
      updatedBy: isUpdating ? this.securityContext.getId() : 0,
      deletedBy: 0,
    };
  }

  domainToResponse(domain: Service): ServiceResponse {
    return {
      id: domain.id,
      title: domain.title,
      durationInMinutes: domain.durationInMinutes,
      bufferTimeInMinutes: domain.bufferTimeInMinutes,
      cost: domain.cost,
      order: domain.order,
      isLive: domain.isLive,
      venue: domain.venue,
    };
  }
}
