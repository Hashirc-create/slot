import { Injectable } from '@nestjs/common';
import {
  Business,
  GetUserByIdUseCase,
  Location,
  Status,
} from '@seamlessslot/core';
import {
  BusinessResponseWithCompleteLocations,
  BusinessWithLocationResponse,
} from '../business/response/business.response';
import { CreateBusinessDto } from '../business/dto/create.business.dto';
import { SecurityContext } from '../../shared/auth/context/security.context';
import { ConfigService } from '@nestjs/config';
import { LocationPresentationMapper } from './location.mapper';
import { UpdateBusinessDto } from '../business/dto/updateBusinessDto';
import { TimeZoneService } from '../../shared/utils/timezone.util';
import { LocationResponse } from '../location/response/location.response';

@Injectable()
export class BusinessPresentationMapper {
  constructor(
    private readonly securityContext: SecurityContext,
    private readonly configService: ConfigService,
    private readonly timeZoneService: TimeZoneService,
  ) {}

  public dtoToDomain(dto: CreateBusinessDto): Business {
    return {
      name: dto.name,
      phoneNo: dto.phoneNo,
      address: dto.address,
      email: dto.email,
      contact: dto.contact,
      status: dto.status as Status,
      subdomain: dto.subdomain,
      isActive: true,
      createdBy: this.securityContext.getId(),
      deletedBy: 0,
      updatedBy: this.securityContext.getId(),
      locations: [],
    };
  }

  public dtoToDomainForUpdate(dto: UpdateBusinessDto): Business {
    return {
      id: dto.businessId,
      name: dto.name,
      phoneNo: dto.phoneNo,
      address: dto.address,
      email: dto.email,
      contact: dto.contact,
      status: dto.status as Status,
      subdomain: dto.subdomain,
      updatedBy: this.securityContext.getId(),
      isActive: true,
      deletedBy: 0,
      createdBy: this.securityContext.getId(),
    };
  }

  public domainToResponseWithLocation(
    domain: Business,
  ): BusinessWithLocationResponse {
    return {
      id: domain.id,
      name: domain.name,
      subdomain: `https://${domain.subdomain}.${this.configService.get('PARENT_DOMAIN')}/appointment`,
      phoneNo: domain.phoneNo,
      email: domain.email,
      status: domain.status,
      locations: domain.locations.map((loc) => {
        return {
          id: (loc as Location).id,
          name: (loc as Location).name,
        };
      }),
    };
  }

  public async domainToResponseIncludingLocation(
    domain: Business,
    getUserByIdUseCase: GetUserByIdUseCase,
  ): Promise<BusinessResponseWithCompleteLocations> {
    const createdBy = await getUserByIdUseCase.execute(domain.createdBy);
    const updatedBy = await getUserByIdUseCase.execute(domain.updatedBy);
    const locations: LocationResponse[] = [];

    for (const loc of domain.locations) {
      const location = await new LocationPresentationMapper(
        this.securityContext,
        this.timeZoneService,
      ).domainToResponseWithExtras(loc as Location, getUserByIdUseCase);

      locations.push({
        ...location,
        subdomain: `https://${domain.subdomain}.${this.configService.get('PARENT_DOMAIN')}/appointment?locationId=${location.id}`,
      } as LocationResponse & {
        subdomain: string;
      });
    }

    return {
      id: domain.id,
      name: domain.name,
      contact: domain.contact,
      address: domain.address,
      phoneNo: domain.phoneNo,
      email: domain.email,
      subdomain: domain.subdomain,
      status: domain.status,
      createdAt: this.timeZoneService.formatDatePreservingUTC(
        domain.createdAt as Date,
        `hh:mm aa - dd MMM, yyyy`,
      ),
      updatedAt: this.timeZoneService.formatDatePreservingUTC(
        domain.updatedAt as Date,
        `hh:mm aa - dd MMM, yyyy`,
      ),
      createdBy:
        createdBy !== null
          ? createdBy.firstName + ' ' + createdBy.lastName
          : 'Public Site',
      updatedBy:
        updatedBy !== null
          ? updatedBy.firstName + ' ' + updatedBy.lastName
          : 'Public Site',
      locations,
    };
  }
}
