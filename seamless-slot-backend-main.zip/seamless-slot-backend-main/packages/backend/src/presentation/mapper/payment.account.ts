import { Injectable } from '@nestjs/common';
import { SecurityContext } from '../../shared/auth/context/security.context';
import { CreateDojoPaymentAccountDto } from '../payment-account/dto/create-dojo-payment-account.dto';
import { UpdatePaymentAccountDto } from '../payment-account/dto/update-payment-account.dto';
import { PaymentAccount } from '@seamlessslot/core';
import { PaymentAccountResponse } from '../payment-account/response/payment.account.response';
import { PaymentAccountType } from '@seamlessslot/core';

@Injectable()
export class PaymentAccountPresentationMapper {
  constructor(private readonly securityContext: SecurityContext) {}

  public dtoToDomain(
    dto: CreateDojoPaymentAccountDto | UpdatePaymentAccountDto,
  ): PaymentAccount {
    return {
      accessToken: dto.accessToken,
      refreshToken: '',
      squareDefaultLocationId: 'empty',
      location: dto.locationId,
      type: dto.type as PaymentAccountType,
      isActive: true,
      createdBy: this.securityContext.getId() || 0,
      updatedBy: 0,
      deletedBy: 0,
    };
  }

  public domainToResponse(domain: PaymentAccount): PaymentAccountResponse {
    return {
      id: domain.id,
      type: domain.type,
      squareLocationId: domain.squareDefaultLocationId,
      accessToken: domain.accessToken,
      refreshToken: domain.refreshToken,
    };
  }
}
