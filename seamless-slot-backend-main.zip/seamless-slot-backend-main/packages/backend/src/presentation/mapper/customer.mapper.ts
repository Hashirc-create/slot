import { Injectable } from '@nestjs/common';
import { SecurityContext } from '../../shared/auth/context/security.context';
import { CreateCustomerDto } from '../customer/dto/create-customer.dto';
import { UpdateCustomerDto } from '../customer/dto/update-customer.dto';
import {
  CustomerResponse,
  CustomerResponseWithExtras,
} from '../customer/response/customer.response';
import {
  Customer,
  GetUserByIdUseCase,
  SlotPaymentStatus,
  SquarePaymentTransaction,
} from '@seamlessslot/core';
import { Appointment } from '@seamlessslot/core';
import { Service } from '@seamlessslot/core';
import { Location } from '@seamlessslot/core';
import { TimeZoneService } from '../../shared/utils/timezone.util';
import { CreatePublicAppointmentDto } from '../appointment/dto/create-public-appointment.dto';
import { CreatePublicAppointmentWithoutPaymentDto } from '../appointment/dto/create-public-appointment-without-payment.dto';

@Injectable()
export class CustomerPresentationMapper {
  constructor(
    private readonly timeZoneService: TimeZoneService,
    private readonly securityContext: SecurityContext,
  ) {
    console.log(JSON.stringify(this.securityContext));
  }

  public dtoToDomain(
    customer: CreateCustomerDto | UpdateCustomerDto,
  ): Customer {
    return {
      firstName: customer.firstName,
      lastName: customer.lastName,
      email: customer.email,
      password: customer.password,
      companyName: customer.companyName ?? '',
      address: customer.address ?? '',
      notes: customer.notes,
      phoneNo: customer.phoneNo,
      role: 'Customer',
      tokenVersion: 0,
      isActive: true,
      createdBy: this.securityContext.getId(),
      updatedBy: this.securityContext.getId(),
      deletedBy: 0,
      location: customer.locationId ?? this.securityContext.getLocationId(),
      business: customer.businessId,
      appointments: [],
    };
  }

  public dtoToDomainFromPublicAppointment(
    customer:
      | CreatePublicAppointmentDto
      | CreatePublicAppointmentWithoutPaymentDto,
  ): Customer {
    return {
      firstName: customer.firstNameCustomer,
      lastName: customer.lastNameCustomer,
      email: customer.customerEmail,
      password: customer.passwordCustomer,
      companyName: '',
      address: customer.customerAddress,
      notes: customer.notes,
      phoneNo: customer.phoneNoCustomer,
      role: 'Customer',
      tokenVersion: 0,
      isActive: true,
      createdBy: 0,
      updatedBy: 0,
      deletedBy: 0,
      location: customer.locationId,
      appointments: [],
    };
  }

  public domainToResponse(domain: Customer): CustomerResponse {
    return {
      id: domain.id,
      firstName: domain.firstName,
      lastName: domain.lastName,
      email: domain.email,
      fullName: domain.firstName + ' ' + domain.lastName,
      phoneNo: domain.phoneNo,
      companyName: domain.companyName,
      address: domain.address,
      notes: domain.notes,
      appointments: (domain.appointments as Appointment[]).map(
        (appointment) => {
          const appointmentStartTime =
            this.timeZoneService.formatDatePreservingUTC(
              appointment.startTime as Date,
              'hh:mm aa',
            );
          const appointmentEndTime =
            this.timeZoneService.formatDatePreservingUTC(
              appointment.endTime as Date,
              'hh:mm aa',
            );

          const appointmentDate = this.timeZoneService.formatDatePreservingUTC(
            appointment.date as Date,
            'EEEE dd MMM, yyyy',
          );

          return {
            id: appointment.id,
            day: appointmentDate,
            hour: appointmentStartTime + ' - ' + appointmentEndTime,
            serviceName: (appointment.service as Service).title,
            serviceCost: (appointment.service as Service).cost,
            serviceDurationInMins: (appointment.service as Service)
              .durationInMinutes,
            location: (appointment.location as Location).name,
          };
        },
      ),
    };
  }

  public async domainToResponseWithExtras(
    domain: Customer,
    getUserByIdUseCase: GetUserByIdUseCase,
  ): Promise<CustomerResponseWithExtras> {
    const createdBy = await getUserByIdUseCase.execute(domain.createdBy);
    const updatedBy = await getUserByIdUseCase.execute(domain.updatedBy);

    return {
      id: domain.id,
      firstName: domain.firstName,
      lastName: domain.lastName,
      email: domain.email,
      fullName: domain.firstName + ' ' + domain.lastName,
      phoneNo: domain.phoneNo,
      companyName: domain.companyName,
      address: domain.address,
      notes: domain.notes,
      createdAt: this.timeZoneService.formatDatePreservingUTC(
        domain.createdAt as Date,
        `hh:mm aa - dd MMM, yyyy`,
      ),
      updatedAt: this.timeZoneService.formatDatePreservingUTC(
        domain.updatedAt as Date,
        `hh:mm aa - dd MMM, yyyy`,
      ),
      createdBy:
        createdBy !== null
          ? createdBy.firstName + ' ' + createdBy.lastName
          : 'Public Site',
      updatedBy:
        updatedBy !== null
          ? updatedBy.firstName + ' ' + updatedBy.lastName
          : 'Public Site',
      appointments: (domain.appointments as Appointment[]).map(
        (appointment) => {
          const appointmentStartTime =
            this.timeZoneService.formatDatePreservingUTC(
              appointment.startTime as Date,
              'hh:mm aa',
            );
          const appointmentEndTime =
            this.timeZoneService.formatDatePreservingUTC(
              appointment.endTime as Date,
              'hh:mm aa',
            );

          const appointmentDate = this.timeZoneService.formatDatePreservingUTC(
            appointment.date as Date,
            'EEEE dd MMM, yyyy',
          );

          const paymentStatus: SlotPaymentStatus = (() => {
            if (appointment.payments === null) return 'Unpaid';

            const payments = appointment.payments as SquarePaymentTransaction;

            if (payments.refunds && payments.refunds.length > 0)
              return 'Refunded';

            return 'Paid';
          })();

          return {
            id: appointment.id,
            day: appointmentDate,
            hour: appointmentStartTime + ' - ' + appointmentEndTime,
            serviceName: (appointment.service as Service).title,
            serviceCost: (appointment.service as Service).cost,
            serviceDurationInMins: (appointment.service as Service)
              .durationInMinutes,
            location: (appointment.location as Location).name,
            status: appointment.status,
            paymentStatus: paymentStatus,
          };
        },
      ),
    };
  }
}
