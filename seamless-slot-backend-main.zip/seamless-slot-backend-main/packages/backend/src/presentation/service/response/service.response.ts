export interface ServiceResponse {
  id: number;
  title: string;
  durationInMinutes: number;
  bufferTimeInMinutes: number;
  cost: string;
  venue: string;
  order: number;
  isLive: boolean;
  serviceCategoryName?: string;
  serviceCategoryId?: number;
}
