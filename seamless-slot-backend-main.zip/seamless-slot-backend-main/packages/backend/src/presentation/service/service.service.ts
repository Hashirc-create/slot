import { Injectable } from '@nestjs/common';
import { CreateServiceDto } from './dto/create-service.dto';
import { UpdateServiceDto } from './dto/update-service.dto';
import { UseCaseFactory } from '../../usecases/usecase.factory';
import { PresentationMapperFactory } from '../mapper/mapper.factory';

@Injectable()
export class ServiceService {
  constructor(
    private readonly useCaseFactory: UseCaseFactory,
    private readonly mapper: PresentationMapperFactory,
  ) {}

  async create(createServiceDto: CreateServiceDto) {
    const saved = await this.useCaseFactory.createServiceUseCase.execute(
      this.mapper.servicePresentationMapper.dtoToDomain(createServiceDto),
    );

    return `Service has been sucessfully Created Against Id : ${saved.id}`;
  }

  async findAll(page: number, limit: number) {
    const { data, total } =
      await this.useCaseFactory.getAllServiceUseCase.execute(page, limit);

    const response = data.map((service) =>
      this.mapper.servicePresentationMapper.domainToResponse(service),
    );

    return {
      totalRecords: total,
      data: response,
    };
  }

  async findOne(id: number) {
    const found = await this.useCaseFactory.getServiceByIdUseCase.execute(id);
    return this.mapper.servicePresentationMapper.domainToResponse(found);
  }

  async update(updateServiceDto: UpdateServiceDto) {
    const updatedService =
      await this.useCaseFactory.updateServiceUseCase.execute(
        updateServiceDto.id,
        this.mapper.servicePresentationMapper.dtoToDomain(updateServiceDto),
      );
    return `Service has been sucessfully updated Against Id : ${updatedService.id}`;
  }

  async remove(id: number) {
    const deletedService =
      await this.useCaseFactory.deleteServiceUseCase.execute(id);

    return `Service Has Been Sucessfully Deleted Against Id : ${deletedService.id}`;
  }

  async findAllLiveServicesByLocation(locationId: number) {
    const allServices =
      await this.useCaseFactory.getAllLiveServiceByLocationUseCase.execute(
        locationId,
      );

    return allServices.map((service) =>
      this.mapper.servicePresentationMapper.domainToResponse(service),
    );
  }

  async findAllByLocation(locationId: number) {
    const allServices =
      await this.useCaseFactory.getAllServicesByLocationUseCase.execute(
        locationId,
      );

    return allServices.map((service) =>
      this.mapper.servicePresentationMapper.domainToResponse(service),
    );
  }
}
