import {
  Controller,
  Get,
  Post,
  Body,
  Patch,
  Param,
  Delete,
  HttpCode,
  HttpStatus,
  UseGuards,
} from '@nestjs/common';
import { ServiceService } from './service.service';
import { CreateServiceDto } from './dto/create-service.dto';
import { UpdateServiceDto } from './dto/update-service.dto';
import { ApiBearerAuth, ApiOperation, ApiTags } from '@nestjs/swagger';
import { RoleGuard } from '../../shared/auth/guard/jwt.guard';
import { Roles } from '../../shared/auth/decorator/role.decorator';

@Controller('service')
@ApiTags('Services')
@ApiBearerAuth()
export class ServiceController {
  constructor(private readonly serviceService: ServiceService) {}

  @Post('/add')
  @HttpCode(HttpStatus.CREATED)
  @ApiOperation({
    description: 'Register New Service',
    summary: 'Register New Service',
  })
  @Roles(['Super Admin', 'Admin'])
  @UseGuards(RoleGuard)
  create(
    @Body()
    createServiceDto: CreateServiceDto,
  ) {
    return this.serviceService.create(createServiceDto);
  }

  @Get('/findAll/:page/:limit')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    description: 'Get All Services By Page And Limit',
    summary: 'Get All Services By Page And Limit',
  })
  @Roles(['Super Admin', 'Admin'])
  @UseGuards(RoleGuard)
  findAll(
    @Param('page')
    page: string,
    @Param('limit')
    limit: string,
  ) {
    return this.serviceService.findAll(+page, +limit);
  }

  @Get('/findAllByLocation/:locationId')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    description: 'Get All Services By Location Which are Live Only (Public)',
    summary: 'Get All Services By Location Which are Live Only (Public)',
  })
  findAllLiveServicesByLocation(
    @Param('locationId')
    locationId: string,
  ) {
    return this.serviceService.findAllLiveServicesByLocation(+locationId);
  }

  @Get('/findByLocation/:locationId')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    description: 'Get All Services By Location',
    summary: 'Get All Services By Location',
  })
  @Roles(['Super Admin', 'Admin'])
  @UseGuards(RoleGuard)
  @ApiBearerAuth()
  findAllByLocation(
    @Param('locationId')
    locationId: string,
  ) {
    return this.serviceService.findAllByLocation(+locationId);
  }

  @Get('/findById/:id')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    description: 'Get Service By Id',
    summary: 'Get Service By Id',
  })
  @Roles(['Super Admin', 'Admin'])
  @UseGuards(RoleGuard)
  findOne(
    @Param('id')
    id: string,
  ) {
    return this.serviceService.findOne(+id);
  }

  @Patch('/update')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    description: 'Update Service By Id',
    summary: 'Update Service By Id',
  })
  @Roles(['Super Admin', 'Admin'])
  @UseGuards(RoleGuard)
  update(
    @Body()
    updateServiceDto: UpdateServiceDto,
  ) {
    return this.serviceService.update(updateServiceDto);
  }

  @Delete('/delete/:id')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    description: 'Delete Service  By Id',
    summary: 'Delete Service  By Id',
  })
  @Roles(['Super Admin', 'Admin'])
  @UseGuards(RoleGuard)
  remove(
    @Param('id')
    id: string,
  ) {
    return this.serviceService.remove(+id);
  }
}
