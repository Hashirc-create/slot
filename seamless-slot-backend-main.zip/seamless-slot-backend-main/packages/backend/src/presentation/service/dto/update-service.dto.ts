import { ApiProperty, PartialType } from '@nestjs/swagger';
import { CreateServiceDto } from './create-service.dto';
import { IsNumber } from 'class-validator';

export class UpdateServiceDto extends PartialType(CreateServiceDto) {
  @ApiProperty({
    description: 'Id of the record which needs to be updated',
    example: 0,
  })
  @IsNumber(
    {},
    {
      message: 'Id of the record which needs to be updated',
    },
  )
  id: number;
}
