import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsNumber, IsOptional, IsString } from 'class-validator';

export class CreateServiceDto {
  @ApiProperty({
    description: 'Duration in Minutes',
    example: 0,
  })
  @IsNumber(
    {},
    {
      message: 'Duration in Minutes must be a number',
    },
  )
  durationInMinutes: number;

  @ApiProperty({
    description: 'Buffer Time',
    example: 0,
  })
  @IsNumber(
    {},
    {
      message: 'Buffer Time must be a number and Is Required',
    },
  )
  bufferTimeInMinutes: number;

  @ApiProperty({
    description: 'Cost of the Service',
    example: 0,
  })
  @IsString({
    message:
      'Cost of Service is required and must of type string and decimal number',
  })
  cost: string;

  @ApiProperty({
    description: 'Venue of Service',
    example: 'In House',
  })
  @IsNotEmpty({
    message: 'Venue of Service Can not Be Empty',
  })
  @IsString({
    message: 'Venue of Service is required and must of type string',
  })
  venue: string;

  @ApiProperty({
    description: 'Title of Service',
    example: 'Emergency Service Dental For Child',
  })
  @IsNotEmpty({
    message: 'Title of Service Can not Be Empty',
  })
  @IsString({
    message: 'Title of Service is required and must of type string',
  })
  title: string;

  @ApiProperty({
    description: 'Service Category Id',
    example: 0,
  })
  @IsOptional({
    message: 'Service Category Id Is Optional',
  })
  serviceCategoryId?: number;

  @ApiProperty({
    description: 'Location Id',
    example: 0,
  })
  @IsNumber(
    {},
    {
      message: 'Location Id is Required',
    },
  )
  locationId: number;

  @ApiProperty({
    description: 'Business Id ',
    example: 0,
  })
  @IsNumber(
    {},
    {
      message: 'Business Id is Required',
    },
  )
  businessId: number;

  @ApiProperty({
    description: 'Order',
    example: 1,
  })
  @IsOptional({
    message: 'Order is Optional',
  })
  order: number;

  @ApiProperty({
    description: 'Is Sevice Live',
    example: 1,
  })
  @IsOptional({
    message: 'Is service live for public',
  })
  isLive: boolean;
}
