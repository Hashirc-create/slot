import { Module } from '@nestjs/common';
import { WorkingDayHistoryController } from './working.day.history.controller';

@Module({
  controllers: [WorkingDayHistoryController],
})
export class WorkingDayHistoryModule {}
