import {
  Controller,
  HttpCode,
  HttpStatus,
  UseGuards,
  Get,
  Param,
} from '@nestjs/common';
import { ApiTags, ApiOperation, ApiBearerAuth } from '@nestjs/swagger';
import { RoleGuard } from '../../shared/auth/guard/jwt.guard';
import { Roles } from '../../shared/auth/decorator/role.decorator';
import { UseCaseFactory } from '../../usecases/usecase.factory';
import { PresentationMapperFactory } from '../mapper/mapper.factory';

@Controller('working-day-history')
@ApiTags('Working Day History')
@ApiBearerAuth()
export class WorkingDayHistoryController {
  constructor(
    private readonly useCaseFactory: UseCaseFactory,
    private readonly mapper: PresentationMapperFactory,
  ) {}

  @Get('/findAllByLocation/:locationId')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    description: 'Get All Admins By Location',
    summary: 'Get All Admin By Location',
  })
  @ApiBearerAuth()
  @Roles(['Super Admin', 'Admin'])
  @UseGuards(RoleGuard)
  async findAllByLocation(
    @Param('locationId')
    locationId: string,
  ) {
    const response =
      await this.useCaseFactory.getAllWorkingDaysHistoryByLocationUseCase.execute(
        +locationId,
      );

    return await Promise.all(
      response.map(async (res) => {
        return await this.mapper.workingDayHistoryPresentationMapper.domainToResponse(
          res,
          this.useCaseFactory.getUserByIdUseCase,
        );
      }),
    );
  }
}
