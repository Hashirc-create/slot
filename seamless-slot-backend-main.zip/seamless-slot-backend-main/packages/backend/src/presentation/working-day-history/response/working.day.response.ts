export interface WorkingDayHistoryResponse {
  id: number;
  day: string;
  prev: string;
  prevIsClosed: boolean;
  new: string;
  newIsClosed: boolean;
  createdBy: string;
  createdAt: string;
}
