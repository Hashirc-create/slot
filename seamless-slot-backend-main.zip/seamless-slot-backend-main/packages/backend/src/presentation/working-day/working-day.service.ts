import { Injectable } from '@nestjs/common';
import { CreateWorkingDayDto } from './dto/create-working-day.dto';
import { UpdateWorkingDayDto } from './dto/update-working-day.dto';
import { UseCaseFactory } from '../../usecases/usecase.factory';
import { PresentationMapperFactory } from '../mapper/mapper.factory';
import { SecurityContext } from '../../shared/auth/context/security.context';
import { WorkingDay } from '@seamlessslot/core';

@Injectable()
export class WorkingDayService {
  constructor(
    private readonly useCaseFactory: UseCaseFactory,
    private readonly presentationMapperFactory: PresentationMapperFactory,
    private readonly securityContext: SecurityContext,
  ) {}

  async create(createWorkingDayDto: CreateWorkingDayDto) {
    const savedWorkingDay =
      await this.useCaseFactory.registerWorkingDayUseCase.execute(
        this.presentationMapperFactory.workingDayPresentationMapper.dtoToDomain(
          createWorkingDayDto,
        ),
      );

    return `WorkingDay Has Been Registered Against Id : ${savedWorkingDay.id}`;
  }

  async findAllByLocation(locationId?: number) {
    const allWorkingDays =
      await this.useCaseFactory.getAllWorkingDayByLocationUseCase.execute(
        locationId || this.securityContext.getLocationId(),
      );

    return allWorkingDays.map((workingDay) =>
      this.presentationMapperFactory.workingDayPresentationMapper.domainToResponse(
        workingDay,
      ),
    );
  }

  async update(updateWorkingDayDtos: UpdateWorkingDayDto[]) {
    const workingDaysToUpdate: WorkingDay[] = updateWorkingDayDtos.map(
      (workingDay) => {
        return this.presentationMapperFactory.workingDayPresentationMapper.dtoToDomain(
          workingDay,
        );
      },
    );
    await this.useCaseFactory.updateWorkingDaysUseCase.execute(
      workingDaysToUpdate,
    );
    return `All Working Days have been updated successfully.`;
  }
}
