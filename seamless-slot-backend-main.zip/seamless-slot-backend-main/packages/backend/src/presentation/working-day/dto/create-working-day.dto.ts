import { ApiProperty } from '@nestjs/swagger';
import {
  IsBoolean,
  IsIn,
  IsNotEmpty,
  IsNumber,
  IsString,
} from 'class-validator';
import { WeekDays } from '@seamlessslot/core';
import { CONSTANTS } from '../../../shared/utils/constants';

export class CreateWorkingDayDto {
  @ApiProperty({
    description: 'Name of Working Day',
    example: 'Monday',
  })
  @IsNotEmpty({
    message: 'Name of Working Day Can not Be Empty',
  })
  @IsIn([...CONSTANTS.WEEKDAYS], {
    message: `Name of Working Day must be one of the following: ${[...CONSTANTS.WEEKDAYS]} `,
  })
  day: WeekDays;

  @ApiProperty({
    description: 'Time From of Working Day',
    example: '9:00 AM',
  })
  @IsNotEmpty({
    message: 'Time From of WorkingDay Can not Be Empty',
  })
  @IsString({
    message: 'Time From of Working Day is required and must of type string',
  })
  from?: string;

  @ApiProperty({
    description: 'Time To of Working Day',
    example: '5:00 PM',
  })
  @IsNotEmpty({
    message: 'Time To of Working Day Can not Be Empty',
  })
  @IsString({
    message: 'Time To of Working Day is required and must of type string',
  })
  to?: string;

  @ApiProperty({
    description: 'Is Closed of Working Day',
    example: false,
  })
  @IsNotEmpty({
    message: 'Is Closed of Working Day Can not Be Empty',
  })
  @IsBoolean({
    message: 'Is Closed of Working Day is required and must of type boolean',
  })
  isClosed: boolean;

  @ApiProperty({
    description: 'Location of Working Day',
    example: 1,
  })
  @IsNotEmpty({
    message: 'Location of Working Day Can not Be Empty',
  })
  @IsNumber(
    {},
    {
      message: 'Location of Working Day is required and must of type number',
    },
  )
  location: number;
}
