import { ApiProperty, PartialType } from '@nestjs/swagger';
import { CreateWorkingDayDto } from './create-working-day.dto';
import { IsNumber } from 'class-validator';

export class UpdateWorkingDayDto extends PartialType(CreateWorkingDayDto) {
  @ApiProperty({
    description: 'Id of the record which needs to be updated',
    example: 0,
  })
  @IsNumber(
    {},
    {
      message: 'Id of the record which needs to be updated',
    },
  )
  id: number;
}
