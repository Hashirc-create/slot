export interface WorkingDayResponse {
  id: number;
  day: string;
  from?: Date | string;
  to?: Date | string;
  isClosed: boolean;
}
