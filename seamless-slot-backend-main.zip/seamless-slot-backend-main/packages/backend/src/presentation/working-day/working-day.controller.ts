import {
  Controller,
  Get,
  Body,
  Param,
  HttpCode,
  HttpStatus,
  Patch,
  UseGuards,
} from '@nestjs/common';
import { WorkingDayService } from './working-day.service';
import { ApiBearerAuth, ApiOperation, ApiTags } from '@nestjs/swagger';
import { UpdateWorkingDayDto } from './dto/update-working-day.dto';
import { RoleGuard } from '../../shared/auth/guard/jwt.guard';
import { Roles } from '../../shared/auth/decorator/role.decorator';

@Controller('working-day')
@ApiTags('WorkingDays')
@ApiBearerAuth()
export class WorkingDayController {
  constructor(private readonly workingDayService: WorkingDayService) {}

  @Get('/findAllByLocation/:locationId')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    description: 'Get All Services By Location',
    summary: 'Get All Services By Location',
  })
  @Roles(['Super Admin', 'Admin'])
  @UseGuards(RoleGuard)
  async findAllByLocation(
    @Param('locationId')
    locationId: string,
  ) {
    const response =
      await this.workingDayService.findAllByLocation(+locationId);

    console.log(response);
    return response;
  }

  @Patch('/update')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    description: 'Update WorkingDay By Id',
    summary: 'Update WorkingDay By Id',
  })
  @Roles(['Super Admin', 'Admin'])
  @UseGuards(RoleGuard)
  update(
    @Body()
    updateWorkingDayDtos: UpdateWorkingDayDto[],
  ) {
    return this.workingDayService.update(updateWorkingDayDtos);
  }
}
