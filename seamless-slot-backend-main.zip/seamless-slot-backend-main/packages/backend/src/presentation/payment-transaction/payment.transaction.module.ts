import { Module } from '@nestjs/common';
import { PaymentTransactionController } from './payment.transaction.controller';
import { PaymentTransactionService } from './payment.transcation.service';

@Module({
  controllers: [PaymentTransactionController],
  providers: [PaymentTransactionService],
})
export class PaymentTransactionModule {}
