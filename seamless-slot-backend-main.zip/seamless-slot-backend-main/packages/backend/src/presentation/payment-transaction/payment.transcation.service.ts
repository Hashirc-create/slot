import { Injectable } from '@nestjs/common';
import { UseCaseFactory } from '../../usecases/usecase.factory';
import { PresentationMapperFactory } from '../mapper/mapper.factory';
import { SquarePaymentTransaction } from '@seamlessslot/core';

@Injectable()
export class PaymentTransactionService {
  constructor(
    private readonly useCaseFactory: UseCaseFactory,
    private readonly mapper: PresentationMapperFactory,
  ) {}

  async getAllTransactionsByLocation(locationId: number) {
    const transactions =
      await this.useCaseFactory.getAllPaymentTransactionsByLocationUseCase.execute(
        locationId,
      );

    return transactions.map((transaction) =>
      this.mapper.paymentTransactionPresentationMapper.domainToResponse(
        transaction,
      ),
    );
  }

  async getAllTransactionsByLocationIdWithPagination(
    locationId: number,
    page: number,
    perPage: number,
    startDate: string,
    endDate: string,
  ) {
    const response =
      await this.useCaseFactory.getAllPaymentTransactionByLocationWithPaginationUseCase.execute(
        locationId,
        page,
        perPage,
        startDate,
        endDate,
      );

    return {
      prev: response.prev,
      next: response.next,
      last: response.last,
      pages: response.pages,
      totalRecords: response.total,
      data: response.data.map((transaction: SquarePaymentTransaction) => {
        return this.mapper.paymentTransactionPresentationMapper.domainToResponse(
          transaction,
        );
      }),
    };
  }

  async searchPaymentTransactionWithPagination(
    locationId: number,
    searchString: string,
    page: number,
    limit: number,
  ) {
    const data =
      await this.useCaseFactory.searchAllTransactionsByLocationWithPaginationUseCase.execute(
        locationId,
        searchString,
        page,
        limit,
      );

    return {
      prev: data.prev,
      next: data.next,
      last: data.last,
      pages: data.pages,
      totalRecords: data.total,
      data: data.data.map(async (paymentTransaction) => {
        return this.mapper.paymentTransactionPresentationMapper.domainToResponse(
          paymentTransaction,
        );
      }),
    };
  }
}
