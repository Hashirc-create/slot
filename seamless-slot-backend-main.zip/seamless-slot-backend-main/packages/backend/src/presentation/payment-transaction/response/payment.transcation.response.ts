import { PaymentStatus } from '@seamlessslot/core';

export interface PaymentTransactionResponse {
  id: number;
  paymentDateAndTime: string;
  customerName: string;
  serviceTitle: string;
  locationName: string;
  amount: number;
  paymentStatus: PaymentStatus;
  bookingId: number;
  paymentReceipt: string;
  paymentMethod: string;
}
