import {
  Controller,
  Get,
  HttpCode,
  HttpStatus,
  UseGuards,
  Param,
  Query,
  Post,
  Body,
} from '@nestjs/common';
import { ApiBearerAuth, ApiOperation, ApiTags } from '@nestjs/swagger';
import { RoleGuard } from '../../shared/auth/guard/jwt.guard';
import { PaymentTransactionService } from './payment.transcation.service';
import { Roles } from '../../shared/auth/decorator/role.decorator';
import { SearchAppointmentsDto } from '../appointment/dto/search.appointments.dto';

@Controller('paymentTransaction')
@ApiTags('Payment Transactions')
@ApiBearerAuth()
export class PaymentTransactionController {
  constructor(
    private readonly paymentTransactionService: PaymentTransactionService,
  ) {}

  @Get('/getAllByLocation/:locationId')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    description: 'Get All Transactions By LocationId',
    summary: 'Get All Transactions By LocationId',
  })
  @Roles(['Super Admin', 'Admin'])
  @UseGuards(RoleGuard)
  findAll(
    @Param('locationId')
    locationId: string,
  ) {
    return this.paymentTransactionService.getAllTransactionsByLocation(
      +locationId,
    );
  }

  @Get('/getAllByLocationWithPagination')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    description: 'Get All Transactions By LocationId With Pagination',
    summary: 'Get All Transactions By LocationId With Pagination',
  })
  @Roles(['Super Admin', 'Admin'])
  @UseGuards(RoleGuard)
  findAllWithPagination(
    @Query('locationId')
    locationId: string,
    @Query('page')
    page: string,
    @Query('perPage')
    perPage: string,
    @Query('startDate')
    startDate: string,
    @Query('endDate')
    endDate: string,
  ) {
    return this.paymentTransactionService.getAllTransactionsByLocationIdWithPagination(
      +locationId,
      +page,
      +perPage,
      startDate,
      endDate,
    );
  }

  @Post('/searchWithPagination')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    description: 'Search Payment Transaction By Pagination',
    summary: 'Search Payment Transaction By Pagination',
  })
  @Roles(['Super Admin', 'Admin'])
  @UseGuards(RoleGuard)
  async searchAppointmentsWithPagination(
    @Body()
    dto: SearchAppointmentsDto,
  ) {
    const response =
      await this.paymentTransactionService.searchPaymentTransactionWithPagination(
        dto.locationId,
        dto.searchString,
        dto.page,
        dto.limit,
      );

    return {
      ...response,
      data: await Promise.all(response.data),
    };
  }
}
